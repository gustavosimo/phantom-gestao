# Phantom Gestão

Aplicativo de gestão da **Phantom Financeira** para clientes, empréstimos, garantias em custódia, estoque, compras, vendas, pagamentos, caixa, cobrança, contratos, notificações e relatórios.

O sistema opera como aplicativo desktop e, opcionalmente, serve a mesma interface pelo navegador. Nos dois modos, os dados permanecem na máquina que executa o backend: o banco é SQLite e documentos, fotos, comprovantes e relatórios ficam em um cofre local cifrado.

> O Phantom Gestão **não usa inteligência artificial**. Análises de crédito, cálculos e automações são determinísticos, baseados em regras explícitas e configurações auditáveis.

## Sumário

- [Visão geral](#visão-geral)
- [Como subir o projeto](#como-subir-o-projeto)
- [Tecnologias](#tecnologias)
- [Arquitetura](#arquitetura)
- [Funcionalidades](#funcionalidades)
- [Papéis e permissões](#papéis-e-permissões)
- [Regras de negócio](#regras-de-negócio)
- [Fluxos ponta a ponta](#fluxos-ponta-a-ponta)
- [Estados e ciclos de vida](#estados-e-ciclos-de-vida)
- [Dados e persistência](#dados-e-persistência)
- [Segurança](#segurança)
- [Modo web e acesso remoto](#modo-web-e-acesso-remoto)
- [Configurações](#configurações)
- [Testes e qualidade](#testes-e-qualidade)
- [Build e distribuição](#build-e-distribuição)
- [Guia de manutenção](#guia-de-manutenção)
- [Limitações e riscos conhecidos](#limitações-e-riscos-conhecidos)
- [Rastreabilidade](#rastreabilidade)

## Visão geral

O projeto cobre a operação de uma financeira que também compra e vende produtos. Seus principais usuários são administradores, gerentes, operadores e pessoas com acesso somente para consulta.

As capacidades centrais são:

- cadastro de pessoas físicas e jurídicas, documentos e histórico consolidado;
- simulação e contratação de crédito com Tabela Price, CET, multa e mora;
- análise cadastral determinística, aprovação e desembolso;
- avaliação, custódia, prorrogação, resgate e devolução de garantias;
- catálogo, custo, preço, estoque, reservas, inventário e histórico de movimentações;
- compras com comprovação de procedência e entrada automática no estoque;
- vendas com controle de desconto, estoque, pagamento, devolução e cancelamento;
- contas a pagar/receber, parcelas, caixa, conciliação, recibos e estornos;
- contratos versionados em PDF a partir de modelos aprovados pelo jurídico;
- cobranças manuais sujeitas a opt-out, janela de contato e limites de frequência;
- notificações automáticas, dashboard e relatórios PDF/CSV;
- usuários, perfis, permissões, auditoria, backup e restauração.

### Escopo e confiabilidade desta documentação

Este README foi reconstruído em **19/10/2026** a partir do frontend React, comandos Tauri, serviços Rust, repositórios, oito migrações SQLite, scripts operacionais e testes do repositório. Foram excluídos `node_modules`, artefatos de `target`, builds e binários gerados.

Nas seções de regras e rastreabilidade:

- **Código/teste**: comportamento imposto pelo backend, banco e/ou coberto por teste;
- **Documentação**: intenção registrada no repositório, sem confirmação equivalente em código;
- **Inferido**: conclusão arquitetural apoiada por evidências, mas sem contrato explícito;
- **Não confirmado**: depende de ambiente, serviço externo ou decisão ausente.

## Como subir o projeto

### Pré-requisitos

- Node.js e npm;
- Rust e Cargo;
- requisitos de compilação do [Tauri 2](https://v2.tauri.app/start/prerequisites/) para o sistema operacional;
- no Windows, WebView2 e toolchain MSVC disponíveis.

As versões exatas das bibliotecas JavaScript e Rust estão travadas em `package-lock.json` e `src-tauri/Cargo.lock`.

### Instalação

```powershell
cd C:\Users\fpf\Phantom\phantom-gestao
npm install
```

Em automações e ambientes reproduzíveis, prefira `npm ci`.

### Modo de desenvolvimento desktop

Este é o comando principal. Ele sobe o Vite em `http://localhost:1420`, recompila o backend Rust quando necessário e abre a janela Tauri:

```powershell
npm run tauri dev
```

Na primeira compilação, o Cargo pode levar alguns minutos para baixar e compilar dependências.

### Somente frontend no navegador

```powershell
npm run dev
```

O frontend será servido em `http://localhost:1420`. Várias ações dependem do backend Tauri ou da API do modo web; executar apenas o Vite é útil sobretudo para trabalho visual.

### Dados isolados para desenvolvimento

`PHANTOM_DATA_DIR` troca a pasta do banco e do cofre, evitando tocar nos dados reais:

```powershell
$env:PHANTOM_DATA_DIR = 'C:\tmp\phantom-dev'
npm run tauri dev
```

Ao terminar:

```powershell
Remove-Item Env:PHANTOM_DATA_DIR
```

O backend cria automaticamente a pasta, o arquivo `phantom.db`, o diretório `vault` e aplica as migrações pendentes.

### Primeiro acesso

Quando o banco ainda não possui usuários, a tela inicial solicita nome completo, nome de usuário e senha. O primeiro usuário sempre recebe o perfil `admin`. A senha precisa ter pelo menos 10 caracteres, uma letra e um número.

### Modo web local

```powershell
$env:PHANTOM_WEB = '1'
$env:PHANTOM_WEB_PORT = '8787' # opcional; 8787 é o padrão
npm run tauri dev
```

Depois acesse `http://127.0.0.1:8787`. O servidor escuta apenas no loopback; exposição remota é feita separadamente por Tailscale ou Cloudflare Tunnel.

### Comandos disponíveis

| Comando | Finalidade |
|---|---|
| `npm run dev` | inicia somente o Vite |
| `npm run tauri dev` | inicia frontend, backend Rust e janela desktop |
| `npm run build` | valida TypeScript e gera o frontend em `dist` |
| `npm run tauri build` | gera o binário e instaladores da plataforma |
| `npm run preview` | serve localmente o frontend já compilado |
| `npm run typecheck` | executa `tsc --noEmit` |
| `npm test` | executa os testes Vitest do frontend |
| `cargo test --lib --manifest-path src-tauri/Cargo.toml` | executa os testes Rust |

## Tecnologias

| Camada | Tecnologia | Uso no projeto |
|---|---|---|
| Desktop | Tauri 2 | janela nativa, comandos IPC, diálogos e abertura externa |
| Frontend | React 19 + TypeScript | telas, rotas, formulários e autenticação |
| Build web | Vite 8 | servidor de desenvolvimento e bundle de produção |
| UI | Tailwind CSS 4, Radix UI, Lucide | estilos, componentes e ícones |
| Estado | Zustand | sessão e permissões no frontend |
| Gráficos | Recharts | indicadores do dashboard |
| PDFs | gerador Rust próprio + `pdfjs-dist` | geração, armazenamento e visualização |
| Backend | Rust, edição 2024 | regras de negócio, segurança e persistência |
| Banco | SQLite via `rusqlite` | dados transacionais e migrações locais |
| Valores financeiros | `rust_decimal` + `i64` | cálculos determinísticos sem ponto flutuante binário |
| Senhas | Argon2id | hash com salt aleatório |
| Cofre | AES-256-GCM + keyring do SO | anexos e segredos cifrados |
| Servidor web | Axum + Tokio | API JSON e arquivos estáticos no modo web |
| Testes | Rust, Vitest e Puppeteer | domínio, serviços, segurança, UI e E2E |

## Arquitetura

```text
React / navegador ou WebView
        │
        ├── IPC Tauri (desktop)
        └── POST /api/{comando} (modo web)
                    │
              commands/*
        sessão + autorização por permissão
                    │
              services/*
       regras e transações de negócio
                    │
            repositories/*
          SQL e mapeamento de dados
                    │
        SQLite + cofre AES-256-GCM
```

### Estrutura de diretórios

```text
src/
  app/                 bootstrap, autenticação, rotas e navegação
  components/          componentes compartilhados e visualizadores
  layouts/             shell, menu, cabeçalho e usuário
  modules/             14 módulos funcionais
  services/api.ts      contrato frontend → Tauri/API web
  types/               tipos de domínio do frontend

src-tauri/
  migrations/          esquema SQLite versionado
  src/commands/        fronteira de autorização e serialização
  src/domain/          dinheiro, validações e cálculos de crédito
  src/services/        casos de uso transacionais
  src/repositories/    consultas e escrita SQL
  src/security/        senha, sessão, cofre e escopo de arquivos
  src/web/             servidor web, sessões e uploads

scripts/               geração do dispatch web e acesso remoto
tests/                 testes frontend e fluxos E2E
```

### Fluxo de uma operação

1. A tela chama uma função de `src/services/api.ts`.
2. No desktop, a chamada usa `invoke`; no navegador, usa `/api/{cmd}`.
3. O comando Rust exige sessão e permissão em `commands/guard.rs`.
4. O serviço valida dados e regras, abre uma transação e coordena repositórios.
5. Banco, caixa, estoque, auditoria e cofre são atualizados na mesma operação quando aplicável.
6. Em caso de erro, a transação é revertida e a interface exibe a mensagem de negócio.

## Funcionalidades

O menu possui 14 módulos funcionais.

| Módulo | O que oferece | Permissão de entrada |
|---|---|---|
| Dashboard | carteira, recebimentos, atrasos, previsões, pendências, operações recentes e avisos | `dashboard.view` |
| Clientes | cadastro PF/PJ, documentos, status, resumo, histórico e contratos | `clients.view` / `clients.manage` |
| Empréstimos | simulação, solicitação, análise, decisão, contratação, desembolso, parcelas, quitação e renegociação | `loans.view` e permissões operacionais |
| Garantias | cadastro, fotos, avaliação, aprovação, custódia, prorrogação, resgate, devolução e procedimento legal | `collateral.view` / `collateral.manage` |
| Produtos e Estoque | catálogo, SKU, custos, preços, fotos, ajustes, reservas, inventário e históricos | `products.view` / `products.manage` |
| Compras | item existente ou novo, vendedor, procedência, pagamento, estoque, cancelamento e comprovante | `purchases.view` / `purchases.manage` |
| Vendas | ponto de venda, consumidor opcional, desconto, estoque, devolução, cancelamento e comprovante | `sales.view` / `sales.manage` |
| Pagamentos | contas avulsas, recebimentos, despesas, parcelas, estornos, recibos, caixa e conciliação | `payments.view` / `payments.manage` |
| Cobranças | parcelas a vencer/em atraso, mensagens, WhatsApp, e-mail, ligação e histórico | `collections.view` / `collections.manage` |
| Modelos | modelos de contrato, variáveis, preview, versões, imagens e aprovação jurídica | `contracts.manage` / `contracts.legal` |
| Contratos | geração de PDF, versões, assinatura externa registrada, consulta e cancelamento | `contracts.view` / `contracts.manage` |
| Notificações | avisos, tarefas automáticas, filtros, leitura e estatísticas de contato | `notifications.view` |
| Relatórios | visão consolidada, prévia e exportação PDF/CSV | `reports.view` / `reports.export` |
| Configurações | empresa, regionalização, regras, comunicação, integrações, usuários, auditoria e backup | permissões específicas |

### Relatórios disponíveis

- empréstimos, parcelas e inadimplência por cliente;
- garantias e posição de estoque;
- compras, vendas, recebimentos e despesas;
- fluxo de caixa e lucratividade.

Exportações ficam registradas em `generated_reports` e armazenadas cifradas no cofre. CSV usa `;`, BOM UTF-8 e proteção contra fórmulas iniciadas por `=`, `+`, `-` ou `@`.

## Papéis e permissões

### Perfis iniciais

| Perfil | Acesso inicial |
|---|---|
| Administrador | todas as permissões; a matriz do perfil não pode ser reduzida |
| Gerente | operação ampla, sem usuários, backup, regras regulatórias, administração geral e aprovação jurídica |
| Operador | dashboard, clientes, produtos, compras, vendas, pagamentos, notificações e cobrança operacional |
| Consulta | dashboard, relatórios e notificações, somente leitura |

A matriz pode ser alterada por quem possui `users.manage`, exceto o perfil Administrador. O backend, e não apenas o menu, valida a permissão de cada comando.

### Permissões sensíveis

| Permissão | Poder concedido |
|---|---|
| `clients.sensitive` | consultar CPF/CNPJ completo e documentos pessoais |
| `sales.discount` | ultrapassar o percentual normal de desconto |
| `sales.cancel` | cancelar venda ou registrar devolução |
| `payments.reverse` | estornar pagamento confirmado |
| `loans.approve` | aprovar/recusar crédito e garantia; registrar procedimento legal |
| `loans.disburse` | contratar e desembolsar empréstimo |
| `contracts.legal` | aprovar versão de modelo contratual |
| `regulatory.manage` | habilitar/desabilitar crédito e garantias |
| `users.manage` | usuários, perfis e matriz de permissões |
| `audit.view` | trilha de auditoria |
| `backup.manage` | backup, restauração e demo em desenvolvimento |

## Regras de negócio

### Catálogo principal

| ID | Regra | Gatilho e efeito | Evidência | Certeza |
|---|---|---|---|---|
| RN-001 | Valores monetários são inteiros em centavos; cálculos usam `Decimal`. | Toda operação financeira evita `float`; arredondamento é meio para longe de zero. | `domain/money.rs`, `domain/loan.rs` | Código/teste |
| RN-002 | CPF/CNPJ deve ser válido e único. | Cadastro/edição normaliza para dígitos e recusa documento inválido ou duplicado. | `validation.rs`, `client_service.rs` | Código/teste |
| RN-003 | Dados pessoais são mascarados sem permissão sensível. | Consultar valor completo exige `clients.sensitive` e gera auditoria. | `client_service.rs`, `client_repo.rs` | Código/teste |
| RN-004 | Crédito e garantias começam desabilitados. | Contratação/desembolso e custódia aguardam habilitação regulatória auditada. | migrações 0001/0004, `loan_service.rs` | Código/teste |
| RN-005 | Habilitação regulatória exige referência formal. | Habilitar requer nota de 20+ caracteres; desabilitar, motivo de 5+. | `settings_service::set_regulatory` | Código/teste |
| RN-006 | Simulação respeita limites configurados. | Valor positivo até o máximo, prazo válido, taxa de 0% a 20% a.m. e vencimento futuro. | `loan_service::simulation` | Código/teste |
| RN-007 | Parcelas seguem Tabela Price. | Parcela fixa e ajuste do principal na última parcela garantem soma exata. | `domain/loan.rs` | Código/teste |
| RN-008 | CET usa o valor líquido liberado. | Tarifa e IOF reduzem o líquido; TIR mensal é anualizada por `(1+r)^12-1`. | `domain/loan::simulate` | Código/teste |
| RN-009 | A análise de crédito é objetiva e sem IA. | Cadastro ativo, contato, atrasos e exposição bloqueiam; endereço/documentos alertam. | `loan_service::analyze` | Código/teste |
| RN-010 | Aprovação exige análise sem pendências obrigatórias. | Só solicitação em `analysis` pode ser decidida; parecer é obrigatório. | `loan_service::decide` | Código/teste |
| RN-011 | Contratação exige solicitação aprovada. | Cria empréstimo e cronograma; solicitação vira `contracted`. | `loan_service::contract` | Código/teste |
| RN-012 | Desembolso exige contrato assinado. | Cria pagamento e saída de caixa pelo líquido e ativa o empréstimo. | `loan_service::disburse` | Código/teste |
| RN-013 | Atraso aplica multa uma vez e mora pro rata. | Multa sobre saldo aberto; juros proporcionais aos dias/30. | `domain/loan::late_charges` | Código/teste |
| RN-014 | Encargos vencidos são pagos antes do principal. | Pagamento parcial precisa cobrir integralmente multa e mora. | `payment_service::pay_installment` | Código/teste |
| RN-015 | Pagamentos não excedem o devido. | Parcela rejeita valor maior que saldo mais encargos. | `payment_service.rs` | Código/teste |
| RN-016 | Quitação baixa todas as parcelas abertas. | Soma saldo/encargos, cria um recebimento e marca `paid_off`. | `payment_service::settle_loan` | Código/teste |
| RN-017 | Renegociação preserva o histórico. | Parcelas abertas viram `renegotiated` e um novo cronograma é criado. | `loan_service::renegotiate` | Código/teste |
| RN-018 | Operações críticas aceitam idempotência. | Repetir venda, recebimento ou quitação com a mesma chave não duplica. | `sale_service.rs`, `payment_service.rs` | Código/teste |
| RN-019 | Estorno é compensatório. | Original vira `reversed`; lançamento inverso restaura caixa e parcelas. | `payment_service::reverse_in_tx` | Código/teste |
| RN-020 | Pagamentos de venda/compra são estornados pela origem. | Cancelamento coordena estoque, pagamento e caixa atomicamente. | serviços comercial/financeiro | Código/teste |
| RN-021 | Estoque disponível é `estoque - reservado`. | Venda e reserva validam disponibilidade; saldo não fica abaixo do reservado. | `product_service.rs` | Código/teste |
| RN-022 | Movimentações de estoque são imutáveis. | Compra, venda, retorno, ajuste, inventário e reserva geram histórico append-only. | migração 0002 | Código/teste |
| RN-023 | Compras exigem procedência. | Comprovante textual é obrigatório; vendedor avulso aceita CPF/CNPJ válido. | `purchase_service::register` | Código/teste |
| RN-024 | Compra confirmada entra no estoque e sai do caixa. | Custo unitário é total ÷ quantidade e entra no histórico. | `purchase_service.rs` | Código/teste |
| RN-025 | Compra só é cancelada se os itens ainda estiverem disponíveis. | Item vendido/reservado bloqueia; caso válido reverte estoque e pagamento. | `purchase_service::cancel` | Código/teste |
| RN-026 | Venda usa preço e custo do banco. | Backend recalcula subtotal e valida item ativo e estoque. | `sale_service::create` | Código/teste |
| RN-027 | Desconto acima do limite requer permissão. | Padrão 10%; `sales.discount` permite ultrapassar, nunca superar subtotal. | `sale_service.rs` | Código/teste |
| RN-028 | Devolução rateia o desconto. | Reembolso = bruto devolvido × total ÷ subtotal; estoque é reposto. | `sale_service::return_item` | Código/teste |
| RN-029 | Garantia é separada do estoque comercial. | Não há vínculo com produtos nem apropriação/venda automática. | migração 0004, `collateral_service.rs` | Código/teste |
| RN-030 | Série/IMEI ativo de garantia é único. | Duplicidade é bloqueada nos estados operacionais. | `collateral_service::create` | Código/teste |
| RN-031 | Custódia exige avaliação, aprovação, habilitação e termo assinado. | Só `approved` entra em custódia; gera termo em PDF. | `collateral_service::receive_custody` | Código/teste |
| RN-032 | Resgate de garantia vinculada exige quitação. | Empréstimo precisa estar `paid_off`; devolução administrativa continua possível. | `collateral_service::release` | Código/teste |
| RN-033 | Vencimento de custódia não transfere propriedade. | O sistema apenas registra referência do procedimento legal adotado. | `mark_legal_procedure` | Código/teste |
| RN-034 | Contrato só usa modelo ativo e aprovado. | Mudança de conteúdo revoga aprovação e cria nova versão `draft`. | `contract_service.rs` | Código/teste |
| RN-035 | Contratos e modelos são versionados. | Regeneração anterior à assinatura cria PDF novo e preserva versões. | migração 0004, `generate` | Código/teste |
| RN-036 | Assinatura é apenas registrada. | Armazena nome, data e observação de assinatura feita fora do sistema. | `contract_service::sign` | Código/teste |
| RN-037 | Contrato de empréstimo desembolsado não pode ser cancelado. | Cancelamento só enquanto `pending_disbursement`. | `contract_service::cancel` | Código/teste |
| RN-038 | Cobrança respeita consentimento e horário. | Opt-out bloqueia; padrão 08h–20h e domingos bloqueados. | `check_contact_policy` | Código/teste |
| RN-039 | Cobrança limita frequência. | Padrão: 2 contatos/dia e 4 nos últimos 7 dias por cliente. | migração 0005, `notification_service.rs` | Código/teste |
| RN-040 | Tentativas bloqueadas também são registradas. | Evento `blocked` guarda motivo, mas não conta como contato efetivo. | `register_contact_at` | Código/teste |
| RN-041 | Notificações automáticas são deduplicadas. | Chaves únicas evitam duplicação; regras rodam ao iniciar e a cada 30 min. | `run_rules`, `lib.rs` | Código/teste |
| RN-042 | Auditoria é imutável. | Triggers impedem `UPDATE` e `DELETE`. | migração 0001 | Código/teste |
| RN-043 | Caixa e custódia preservam histórico. | Caixa não pode ser excluído; eventos de custódia não podem ser alterados/excluídos. | migrações 0003/0004 | Código/teste |
| RN-044 | Anexos têm formato e tamanho controlados. | PDF, PNG, JPG/JPEG e WEBP; 15 MB; conteúdo cifrado. | `attachment_service.rs` | Código/teste |
| RN-045 | Backup protege banco, cofre e chave. | Senha de 10+; restauração valida tudo e cria cópia de segurança. | `backup_service.rs` | Código/teste |

### Parâmetros financeiros iniciais

| Parâmetro | Valor inicial | Faixa aceita |
|---|---:|---:|
| Taxa mensal padrão | 2,40% (`240 bp`) | 0% a 20% a.m. |
| Tarifa de cadastro | 0% | 0% a 20% |
| IOF configurado | 0% | 0% a 10% |
| Multa por atraso | 2% | 0% a 10% |
| Juros de mora | 1% a.m. | 0% a 5% a.m. |
| Prazo máximo | 60 meses | 1 a 120 |
| Valor máximo | R$ 50.000,00 | maior que zero |
| Desconto de venda | 10% | 0% a 100% |

`bp` significa centésimo de ponto percentual: `240 bp = 2,40%`.

## Fluxos ponta a ponta

### Crédito

1. `loans.manage` seleciona cliente, valor, prazo, taxa, vencimento e eventual garantia.
2. O sistema simula parcelas, juros, encargos, líquido e CET.
3. A solicitação nasce `draft`; a análise verifica cadastro, contato, endereço, documentos, atrasos e exposição.
4. `loans.approve` registra parecer e aprova ou recusa.
5. Com crédito habilitado, `loans.disburse` cria empréstimo `pending_disbursement` e cronograma.
6. Um modelo jurídico aprovado gera o contrato; a assinatura externa é registrada.
7. O desembolso gera saída de caixa e ativa o empréstimo.
8. Recebimentos atualizam parcelas e caixa; a quitação final marca `paid_off`.

> **Exemplo hipotético:** um crédito de R$ 10.000,00 em 12 meses a 2,40% a.m. é simulado pela Tabela Price. Mesmo aprovado, não é desembolsado enquanto o crédito não estiver habilitado e o contrato não estiver assinado.

### Garantia em custódia

1. A garantia é cadastrada separada do estoque e pode receber até oito fotos na criação.
2. Avaliação cria histórico; um aprovador aceita ou recusa.
3. Custódia exige operação habilitada e termo assinado; gera termo de recebimento.
4. O prazo pode ser prorrogado com motivo.
5. Garantia vinculada só é resgatada após quitação; devolução também gera termo.
6. Após o prazo, o sistema permite apenas documentar o procedimento legal.

### Compra

1. Informa-se vendedor, item, quantidade, valor, pagamento e procedência.
2. Compra imediata é confirmada; compra futura exige vencimento e fica `pending`.
3. Confirmar cria saída no caixa, estoque e histórico de custo na mesma transação.
4. Cancelamento confirmado exige que os itens ainda estejam disponíveis.

### Venda e devolução

1. Backend consolida itens repetidos e relê preços, custos e estoque.
2. Desconto é validado contra configuração e permissão.
3. Venda, estoque, pagamento e caixa são confirmados atomicamente.
4. Devolução parcial repõe estoque e reembolsa proporcionalmente ao desconto.
5. Cancelamento integral repõe o restante e compensa o pagamento.

> **Exemplo hipotético:** quatro unidades de R$ 100,00 com R$ 40,00 de desconto totalizam R$ 360,00. Devolver uma unidade reembolsa R$ 90,00.

### Cobrança

1. A tela lista parcelas próximas, de hoje ou atrasadas.
2. O operador escolhe WhatsApp, e-mail ou ligação.
3. Backend valida opt-out, horário local, domingo e limites de frequência.
4. WhatsApp/e-mail produzem link externo; nenhum envio automático ocorre nesta versão.
5. Resultado, mensagem ou bloqueio ficam no histórico.

### Backup e restauração

1. Backup cria cópia consistente do SQLite, copia o cofre e exporta a chave protegida.
2. Verificação confere manifesto, versão, integridade do SQLite e chave.
3. Restauração valida a senha antes de tocar nos dados.
4. Uma cópia `pre-restore-*` do estado atual é criada antes da substituição.

## Estados e ciclos de vida

| Entidade | Estados | Transições principais |
|---|---|---|
| Cliente | `pending`, `active`, `inactive` | alteração administrativa; inativo não contrata crédito nem participa de venda identificada |
| Solicitação | `draft`, `analysis`, `approved`, `rejected`, `contracted`, `cancelled` | criar → analisar → decidir → contratar; edição retorna a `draft` |
| Empréstimo | `pending_disbursement`, `active`, `paid_off`, `renegotiated`, `cancelled` | contratar → assinar/desembolsar → receber/quitar ou renegociar |
| Parcela | `open`, `partial`, `paid`, `renegotiated` | pagamento parcial/total, estorno e renegociação |
| Garantia | `registered`, `appraising`, `approved`, `rejected`, `in_custody`, `legal_procedure`, `redeemed`, `returned` | cadastrar → avaliar → decidir → custodiar → liberar/procedimento |
| Compra | `pending`, `confirmed`, `cancelled` | registrar → confirmar/cancelar |
| Venda | `completed`, `partially_returned`, `cancelled` | concluir → devolver ou cancelar |
| Pagamento | `pending`, `confirmed`, `reversed` | registrar → confirmar → estornar por inversão |
| Contrato | `pending_signature`, `active`, `completed`, `late`, `cancelled` | gerar → assinar; exibição reflete atraso/quitação da referência |
| Modelo | `draft`, `approved` | salvar/alterar → aprovação jurídica; alteração volta a `draft` |

`near_deadline` e `evaluating` são estados derivados de exibição para garantias.

## Dados e persistência

### Principais grupos de tabelas

| Domínio | Tabelas |
|---|---|
| Acesso | `users`, `roles`, `permissions`, `role_permissions`, `audit_logs`, `settings` |
| Clientes | `clients`, `client_documents`, `attachments` |
| Produtos | `products`, `product_cost_history`, `inventory_movements` |
| Comercial | `purchases`, `sales`, `sale_items`, `sale_returns` |
| Financeiro | `payments`, `payment_allocations`, `cash_movements` |
| Crédito | `credit_applications`, `loans`, `loan_installments`, `loan_renegotiations` |
| Garantias | `collateral_assets`, `collateral_valuations`, `custody_events` |
| Contratos | `contract_templates`, `contract_template_versions`, `template_images`, `contracts`, `contract_versions` |
| Comunicação | `notifications`, `notification_templates`, `collection_events`, `secrets` |
| Relatórios | `generated_reports` |

### Estratégia SQLite

- migrações em ordem, registradas em `schema_migrations`;
- migrações publicadas não devem ser editadas;
- `foreign_keys = ON`, `journal_mode = WAL`, `synchronous = FULL`;
- uma conexão protegida por `Mutex` no processo;
- operações compostas dentro de transações;
- dinheiro como `INTEGER` em centavos;
- constraints, FKs, índices e triggers reforçam invariantes.

### Migrações existentes

| Versão | Conteúdo |
|---:|---|
| 1 | usuários, papéis, permissões, auditoria e configurações |
| 2 | clientes, anexos, produtos e estoque |
| 3 | pagamentos, caixa, compras e vendas |
| 4 | crédito, parcelas, garantias e contratos |
| 5 | cobrança, notificações, integrações e relatórios |
| 6 | versão de layout em contratos |
| 7 | versão de layout em anexos |
| 8 | biblioteca de imagens dos modelos |

## Segurança

### Autenticação

- Argon2id com salt aleatório;
- senha mínima de 10 caracteres, uma letra e um número;
- mesma mensagem para usuário inexistente e senha inválida;
- hash descartável reduz diferença de tempo;
- cinco falhas bloqueiam por 15 minutos;
- usuário inativo não entra;
- login, logout, falhas e bloqueios são auditados.

### Sessão e autorização

- sessão desktop apenas na memória;
- sessão web isolada por navegador;
- backend exige autenticação e permissão em cada comando;
- frontend também protege menu e rotas, como camada adicional;
- não se pode desativar a si mesmo nem remover o último admin ativo;
- redefinir senha limpa falhas/bloqueio; troca própria exige senha atual.

### Cofre e anexos

- anexos cifrados individualmente com AES-256-GCM e nonce aleatório;
- chave de 256 bits no gerenciador de credenciais do SO;
- nomes internos aleatórios;
- alteração do ciphertext ou chave errada falha;
- travessia de diretório é recusada;
- segredos de integrações são cifrados e nunca voltam ao frontend.

Auditoria, movimentações de estoque e eventos de custódia são append-only. Caixa não pode ser excluído; correções financeiras usam compensação.

## Modo web e acesso remoto

### Variáveis de ambiente

| Variável | Finalidade | Padrão |
|---|---|---|
| `PHANTOM_DATA_DIR` | diretório do SQLite, cofre e uploads | dados do aplicativo |
| `PHANTOM_WEB` | habilita servidor quando `1` | desabilitado |
| `PHANTOM_WEB_PORT` | porta local | `8787` |
| `PHANTOM_WEB_DIST` | assets web alternativos | assets incorporados |

### Proteções web

- bind apenas em `127.0.0.1`;
- cookie `HttpOnly`, `SameSite=Strict` e `Secure` em HTTPS;
- expiração em 30 minutos inativo ou 12 horas totais;
- token aleatório de 256 bits;
- 10 tentativas de login por IP em 15 minutos;
- `X-Requested-With: phantom` e validação `Origin`/`Host` contra CSRF;
- CSP, `X-Frame-Options: DENY`, `nosniff` e `no-referrer`;
- corpo limitado a 25 MB;
- upload por sessão, validade de 2 horas e máximo de 30 pendentes;
- leitura de arquivos limitada à pasta de uploads e escrita arbitrária bloqueada;
- setup, backup, restauração e demo apenas no desktop.

### Atalho remoto

Após gerar o executável:

```powershell
npx tauri build --no-bundle
powershell -ExecutionPolicy Bypass -File scripts\phantomfinanceira.ps1
```

Modos: `auto`, `tailscale` (privado), `funnel` (público) e `rapido` (Cloudflare). Para endereço Cloudflare fixo:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\configurar-tunel-nomeado.ps1 -Hostname gestao.seudominio.com.br
```

Proteja qualquer exposição pública com Tailscale privado ou Cloudflare Access.

## Configurações

- **Empresa:** razão social, CNPJ, e-mail, telefone e endereço.
- **Regional:** `DD/MM/AAAA` ou `AAAA-MM-DD`; offset UTC entre -12 e +14.
- **Financeiro:** taxas, tarifa, IOF, mora, limites de prazo/valor e desconto.
- **Comunicação:** lembretes, horário, domingo, frequência e templates.
- **Regulatório:** habilitação auditada de crédito e garantias.
- **Usuários:** contas, perfis, permissões, senhas e desbloqueio.
- **Sistema:** auditoria, backup, restauração e dados demo em desenvolvimento.

### Integrações

Existem configuração e armazenamento cifrado para WhatsApp Business, SMTP e emissão fiscal, porém os conectores não estão implementados. Nesta versão, WhatsApp/e-mail abrem links externos, contatos são registrados manualmente e comprovantes não são documentos fiscais.

## Testes e qualidade

### Backend

```powershell
cargo test --lib --manifest-path src-tauri/Cargo.toml
```

Os testes cobrem migrações, validações, cálculos, autenticação, permissões, operações comerciais e financeiras, crédito, garantias, contratos, cobrança, notificações, cofre, anexos, backup, web e desempenho.

### Frontend

```powershell
npm test
npm run typecheck
npm run build
```

Vitest cobre dinheiro, percentuais, máscaras, datas e navegação/permissões.

### E2E visual

```powershell
$env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = '--remote-debugging-port=9222'
npm run tauri dev
```

Em outro terminal:

```powershell
node tests/e2e/step1-setup.mjs
node tests/e2e/step2-screens.mjs
node tests/e2e/step3-flows.mjs
node tests/e2e/step4-login.mjs
node tests/e2e/step5-permissions.mjs
```

`step6-release.mjs` valida o binário de produção. E2E manipula dados; use `PHANTOM_DATA_DIR` isolado.

### Administrador de desenvolvimento

```powershell
$env:PHANTOM_DATA_DIR = 'C:\tmp\phantom-e2e'
cargo test --lib --manifest-path src-tauri/Cargo.toml seed_dev_admin -- --ignored
```

`seed_dev_demo` também existe como teste ignorado. A demo pela interface só aparece em desenvolvimento e exige base sem clientes.

## Build e distribuição

```powershell
npm run build
npm run tauri build
```

No Windows, a configuração prevê NSIS em português e instalação por usuário. Para apenas o executável:

```powershell
npx tauri build --no-bundle
```

Release Rust usa LTO, uma unidade de codegen, otimização 3, `panic = abort` e remoção de símbolos. Não há CI/CD confirmado no repositório.

## Guia de manutenção

### Funcionalidade nova ou alterada

1. Implemente a regra em `src-tauri/src/services`, não apenas no React.
2. Coloque acesso SQL reutilizável em `repositories`; mantenha transação no serviço.
3. Exponha comando com permissão mínima em `commands`.
4. Atualize `src/services/api.ts` e `src/types`.
5. Ajuste `src/modules/<modulo>`.
6. Adicione testes Rust e frontend/E2E conforme o risco.
7. Rode `python scripts/gen_web_dispatch.py` ao alterar comandos Tauri.
8. Execute testes, typecheck e build.

### Banco

- não altere migrações publicadas;
- crie a próxima migração SQL e registre-a em `database/mod.rs`;
- preserve históricos append-only;
- valide backup/restauração e compatibilidade do esquema.

### Regras financeiras

Revise `domain/loan.rs`, `loan_service.rs`, `payment_service.rs`, `settings_service.rs`, dashboard, relatórios, PDFs e testes de arredondamento, atraso, parcial, quitação e estorno.

### Permissões e documentos

Atualize backend, migração, navegação e componentes condicionais. Para documentos, mudança de texto cria versão em rascunho e exige nova aprovação jurídica; mudança de layout deve gerar nova versão do PDF.

## Limitações e riscos conhecidos

| Item | Situação atual | Impacto |
|---|---|---|
| WhatsApp Business | conector ausente | contato depende de link externo e operador |
| E-mail SMTP | conector ausente | abre cliente de e-mail via `mailto` |
| Emissão fiscal | conector ausente | comprovantes são internos, não fiscais |
| Assinatura eletrônica | não implementada | só registra assinatura externa |
| Modelos iniciais | minutas sem validade jurídica | exigem revisão e aprovação real |
| Acesso remoto | depende de Tailscale/Cloudflare | disponibilidade externa fora do app |
| Sessão desktop | única e em memória | sem isolamento entre múltiplas janelas |
| Banco local | conexão SQLite com mutex | não é arquitetura multi-servidor |
| Linux | build não confirmado neste ambiente | empacotamento precisa ser validado |
| CI/CD | ausente | testes e releases são manuais |

Antes de uso real, confirme enquadramento jurídico, modelos, política de cobrança, parâmetros, backup externo e controle de acesso ao túnel.

## Rastreabilidade

| Regra/funcionalidade | Implementação | Persistência | Interface/teste | Situação |
|---|---|---|---|---|
| Autenticação | `auth_service.rs`, `password.rs` | `users`, `audit_logs` | `LoginPage`; Rust/E2E | Confirmado |
| Clientes | `client_service.rs`, `client_repo.rs` | clientes/documentos | módulo `clients`; Rust/E2E | Confirmado |
| Crédito | `domain/loan.rs`, `loan_service.rs` | aplicações/empréstimos/parcelas | módulo `loans`; Rust/E2E | Confirmado |
| Pagamentos | `payment_service.rs`, `payment_repo.rs` | pagamentos/alocações/caixa | módulo `payments`; Rust | Confirmado |
| Garantias | `collateral_service.rs` | ativos/avaliações/eventos | módulo `collateral`; Rust | Confirmado |
| Estoque | `product_service.rs`, `product_repo.rs` | produtos/custos/movimentos | módulo `products`; Rust | Confirmado |
| Compras | `purchase_service.rs` | compras/pagamentos/estoque | módulo `purchases`; Rust | Confirmado |
| Vendas | `sale_service.rs` | vendas/itens/retornos | módulo `sales`; Rust/E2E | Confirmado |
| Contratos | `contract_service.rs`, `pdf.rs` | modelos/versões/anexos | `templates`/`contracts`; Rust | Confirmado |
| Cobrança | `notification_service.rs` | `collection_events` | módulo `collections`; Rust | Confirmado |
| Notificações | `run_rules`, scheduler | `notifications` | módulo `notifications`; Rust | Confirmado |
| Relatórios | `report_service.rs` | relatórios/anexos | módulo `reports`; E2E | Confirmado |
| Backup | `backup_service.rs`, `vault.rs` | SQLite/vault/key/manifesto | configurações; Rust | Confirmado |
| Modo web | `web/*` | sessões e uploads temporários | testes web Rust | Confirmado |
| Integrações | `settings_service.rs` | settings/secrets | configurações | Conectores ausentes |

### Índice de evidências

| Caminho | Por que importa |
|---|---|
| `package.json` | scripts e dependências frontend |
| `src/app/navigation.ts` | módulos, rotas e permissões |
| `src/services/api.ts` | contrato frontend/backend |
| `src-tauri/Cargo.toml` | dependências e perfil Rust |
| `src-tauri/src/domain/loan.rs` | Price, CET e atraso |
| `src-tauri/src/services/*.rs` | regras e casos de uso |
| `src-tauri/src/commands/*.rs` | autorização por operação |
| `src-tauri/migrations/*.sql` | dados, defaults, constraints e triggers |
| `src-tauri/src/security/*` | senha, sessão, cofre e arquivos |
| `src-tauri/src/web/*` | API web, cookie, CSRF, rate limit e uploads |
| `tests/` | formatação, navegação e fluxos E2E |
| `scripts/` | dispatch web e publicação remota |

### Pontos não confirmados pelo repositório

- deploy, versionamento e rollback em produção;
- política externa de retenção dos backups;
- homologação jurídica dos modelos de uma instalação real;
- credenciais/disponibilidade de serviços externos;
- build e testes em todas as distribuições Linux suportadas.
