# Phantom Gestao - configura um tunel nomeado do Cloudflare (URL fixa), uma unica vez.
#
# Requisitos: conta Cloudflare (gratuita) e um dominio adicionado a ela (ex.: seudominio.com.br).
# Uso:
#   powershell -ExecutionPolicy Bypass -File scripts\configurar-tunel-nomeado.ps1 -Hostname gestao.seudominio.com.br
#
# O que faz: (1) abre o navegador para voce autorizar o cloudflared na sua conta, (2) cria o tunel,
# (3) aponta o endereco (DNS) para ele e (4) grava %USERPROFILE%\.phantom\web.json, que o atalho
# phantomfinanceira passa a usar. Depois, proteja o endereco com o Cloudflare Access (veja o final).
param(
    [Parameter(Mandatory = $true)][string]$Hostname,
    [string]$TunnelName = 'phantom'
)
$ErrorActionPreference = 'Stop'

$cf = Get-Command cloudflared -ErrorAction SilentlyContinue
$Cloudflared = if ($cf) { $cf.Source } else { 'C:\Program Files (x86)\cloudflared\cloudflared.exe' }
if (-not (Test-Path $Cloudflared)) { throw 'cloudflared nao encontrado. Instale com: winget install Cloudflare.cloudflared' }
if ($Hostname -notmatch '^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$') { throw "Endereco invalido: $Hostname" }

function Run-Cloudflared {
    & $Cloudflared @args
    if ($LASTEXITCODE -ne 0) { throw "cloudflared falhou (codigo $LASTEXITCODE): $($args -join ' ')" }
}

$cert = Join-Path $env:USERPROFILE '.cloudflared\cert.pem'
if (-not (Test-Path $cert)) {
    Write-Host '1/4 Autorize o cloudflared na sua conta (o navegador vai abrir; escolha o dominio).' -ForegroundColor Yellow
    Run-Cloudflared tunnel login
} else {
    Write-Host '1/4 cloudflared ja autorizado nesta maquina.' -ForegroundColor Green
}

$existing = & $Cloudflared tunnel list --output json 2>$null | ConvertFrom-Json
if ($existing | Where-Object { $_.name -eq $TunnelName }) {
    Write-Host "2/4 Tunel '$TunnelName' ja existe." -ForegroundColor Green
} else {
    Write-Host "2/4 Criando o tunel '$TunnelName'..." -ForegroundColor Yellow
    Run-Cloudflared tunnel create $TunnelName
}

Write-Host "3/4 Apontando $Hostname para o tunel..." -ForegroundColor Yellow
Run-Cloudflared tunnel route dns --overwrite-dns $TunnelName $Hostname

$dir = Join-Path $env:USERPROFILE '.phantom'
New-Item -ItemType Directory -Force $dir | Out-Null
@{ tunnelName = $TunnelName; hostname = $Hostname } | ConvertTo-Json | Set-Content -Path (Join-Path $dir 'web.json') -Encoding UTF8
Write-Host "4/4 Configuracao salva em $dir\web.json" -ForegroundColor Green

Write-Host ''
Write-Host "Pronto. O atalho phantomfinanceira agora publica https://$Hostname" -ForegroundColor Cyan
Write-Host ''
Write-Host 'IMPORTANTE - proteja o endereco com o Cloudflare Access (e-mail + codigo) antes de divulgar:' -ForegroundColor Yellow
Write-Host '  1. Acesse https://one.dash.cloudflare.com  >  Zero Trust (crie a conta gratuita, ate 50 usuarios).'
Write-Host '  2. Access > Applications > Add an application > Self-hosted.'
Write-Host "  3. Application domain: $Hostname"
Write-Host '  4. Policy: Action = Allow; Include = Emails; informe os e-mails de quem pode acessar.'
Write-Host '  5. Login method: One-time PIN (codigo enviado por e-mail). Salve.'
Write-Host 'Quem nao estiver na lista nem chega a tela de login do Phantom.'
