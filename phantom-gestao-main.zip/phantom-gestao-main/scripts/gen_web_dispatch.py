#!/usr/bin/env python3
"""Gera, em cada módulo de src-tauri/src/commands, a função `web_dispatch` usada pelo servidor web.

Lê as assinaturas dos `#[tauri::command]` e cria um `match` por nome que desserializa os argumentos
(camelCase, como o frontend envia) e chama o próprio comando. Reexecute após adicionar/alterar comandos:

    python scripts/gen_web_dispatch.py

Ficam bloqueados no modo web os comandos que gravam no disco do servidor (`dir`, backup, salvar em
caminho), o desktop (AppHandle) e dados de demonstração. Comandos que leem arquivos (`path`/`file_path`)
continuam disponíveis, mas só enxergam uploads do próprio navegador (security::fs_scope + web::uploads).
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent / "src-tauri" / "src" / "commands"
MODULES = ["auth", "commercial", "credit", "registry", "system"]
CTX = {"Db": "Db(ctx.db)", "Sess": "Sess(ctx.session)", "Vlt": "Vlt(ctx.vault)", "Paths": "Paths(ctx.paths)"}
DISK_PARAMS = {"dir"}
BLOCKED_NAMES = {"demo_seed", "open_external", "setup_admin", "attachment_save_to"}
BEGIN = "// ==== BEGIN GENERATED WEB DISPATCH (scripts/gen_web_dispatch.py) ===="
END = "// ==== END GENERATED WEB DISPATCH ===="


def split_params(s):
    out, depth, cur = [], 0, ""
    for ch in s:
        if ch in "<([":
            depth += 1
        elif ch in ">)]":
            depth -= 1
        if ch == "," and depth == 0:
            out.append(cur)
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur)
    return [p.strip() for p in out if p.strip()]


def commands(src):
    for m in re.finditer(r"#\[tauri::command[^\]]*\]\s*(?:#\[[^\]]*\]\s*)*pub fn (\w+)\(", src):
        i, depth = m.end(), 1
        while depth:
            depth += {"(": 1, ")": -1}.get(src[i], 0)
            i += 1
        yield m.group(1), split_params(src[m.end() : i - 1])


def arm(name, params):
    ctx_args, fields, blocked = [], [], name in BLOCKED_NAMES or name.startswith("backup_")
    for p in params:
        pname, ptype = [x.strip() for x in p.split(":", 1)]
        if ptype in CTX:
            ctx_args.append((pname, CTX[ptype]))
        elif "AppHandle" in ptype:
            blocked = True
        else:
            if pname in DISK_PARAMS:
                blocked = True
            fields.append((pname, ptype))
    if blocked:
        return f'        "{name}" => Some(Err(crate::error::AppError::Validation("Recurso disponível apenas no aplicativo desktop.".into()))),\n'
    call_args = []
    for p in params:
        pname, ptype = [x.strip() for x in p.split(":", 1)]
        call_args.append(CTX[ptype] if ptype in CTX else f"a.{pname}")
    struct_fields = "".join(f"                {n}: {t},\n" for n, t in fields)
    return (
        f'        "{name}" => Some((|| {{\n'
        "            #[derive(serde::Deserialize)]\n"
        '            #[serde(rename_all = "camelCase")]\n'
        "            #[allow(dead_code)]\n"
        "            struct A {\n" + struct_fields + "            }\n"
        "            let a: A = parse_args(args)?;\n"
        f"            to_json({name}({', '.join(call_args)})?)\n"
        "        })()),\n"
    )


def main():
    total = 0
    for mod in MODULES:
        path = ROOT / f"{mod}.rs"
        src = path.read_text(encoding="utf-8")
        if BEGIN in src:
            src = src[: src.index(BEGIN)].rstrip() + "\n"
        # o bloco gerado fica antes de `#[cfg(test)]`? Não: módulos de comando não têm testes; vai ao fim.
        arms = "".join(arm(n, p) for n, p in commands(src))
        total += arms.count("=> Some(")
        block = (
            f"\n{BEGIN}\n"
            "#[allow(unused_variables, clippy::redundant_closure_call)]\n"
            "pub fn web_dispatch(cmd: &str, ctx: &Ctx, args: serde_json::Value) -> Option<AppResult<serde_json::Value>> {\n"
            "    match cmd {\n" + arms + "        _ => None,\n    }\n}\n"
            f"{END}\n"
        )
        path.write_text(src + block, encoding="utf-8")
    print(f"{total} comandos gerados")


if __name__ == "__main__":
    sys.exit(main())
