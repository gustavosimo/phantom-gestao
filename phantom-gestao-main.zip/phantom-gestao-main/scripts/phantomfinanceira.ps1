﻿# Phantom Gestao - abre o aplicativo em modo web e libera o acesso remoto.
#
#   * Fecha (com a sua confirmacao) o app, se estiver aberto, e o reabre com o modo web ligado.
#   * O servidor web so escuta neste computador (127.0.0.1); quem expoe e o Tailscale ou o tunel do Cloudflare.
#   * Modos (parametro -Modo, padrao "auto"):
#       tailscale  Endereco FIXO e PRIVADO (https://<maquina>.<tailnet>.ts.net): so quem esta na sua rede
#                  Tailscale acessa. E o padrao quando o Tailscale esta conectado.
#       funnel     Mesmo endereco fixo, mas PUBLICO (qualquer pessoa com o link). Exige habilitar o Funnel.
#       rapido     Tunel rapido do Cloudflare: URL aleatoria *.trycloudflare.com, publica, muda a cada abertura.
#       auto       tailscale se estiver conectado; caso contrario, rapido.
#     Com %USERPROFILE%\.phantom\web.json o modo "rapido" usa o tunel nomeado do Cloudflare
#     (veja scripts\configurar-tunel-nomeado.ps1).
#
# Para encerrar o acesso remoto: Ctrl+C ou feche esta janela.
param(
    [ValidateSet('auto', 'tailscale', 'funnel', 'rapido')][string]$Modo = 'auto'
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Exe = Join-Path $Root 'src-tauri\target\release\phantom-gestao.exe'
$Port = 8787
$LocalUrl = "http://127.0.0.1:$Port"
$ConfigFile = Join-Path $env:USERPROFILE '.phantom\web.json'
$TailscaleExe = 'C:\Program Files\Tailscale\tailscale.exe'

function Stop-WithMessage($msg) {
    Write-Host ''
    Write-Host $msg -ForegroundColor Red
    Write-Host ''
    Read-Host 'Pressione ENTER para sair' | Out-Null
    exit 1
}

# Endereco do Tailscale desta maquina, se estiver instalado e conectado (senao, $null).
function Get-TailscaleUrl {
    $exe = $TailscaleExe
    $cmd = Get-Command tailscale -ErrorAction SilentlyContinue
    if ($cmd) { $exe = $cmd.Source }
    if (-not (Test-Path $exe)) { return $null }
    try {
        $st = & $exe status --json 2>$null | ConvertFrom-Json
        if ($st.BackendState -ne 'Running' -or -not $st.Self.DNSName) { return $null }
        return "https://$($st.Self.DNSName.TrimEnd('.'))"
    } catch { return $null }
}

Clear-Host
Write-Host '=== Phantom Gestao - acesso remoto ===' -ForegroundColor Yellow
Write-Host ''

# --- escolhe o modo ----------------------------------------------------------------------------
$tsUrl = Get-TailscaleUrl
if ($Modo -eq 'auto') { $Modo = if ($tsUrl) { 'tailscale' } else { 'rapido' } }
if (($Modo -eq 'tailscale' -or $Modo -eq 'funnel') -and -not $tsUrl) {
    Stop-WithMessage 'O Tailscale nao esta instalado ou conectado. Abra o Tailscale e entre na conta, ou use: -Modo rapido'
}

# --- pre-requisitos ---------------------------------------------------------------------------
if (-not (Test-Path $Exe)) { Stop-WithMessage "Aplicativo nao encontrado em:`n$Exe`nCompile com: npx tauri build --no-bundle" }
$Cloudflared = $null
if ($Modo -eq 'rapido') {
    $cf = Get-Command cloudflared -ErrorAction SilentlyContinue
    $Cloudflared = if ($cf) { $cf.Source } else { 'C:\Program Files (x86)\cloudflared\cloudflared.exe' }
    if (-not (Test-Path $Cloudflared)) { Stop-WithMessage 'cloudflared nao encontrado. Instale com: winget install Cloudflare.cloudflared' }
}

# --- o app precisa abrir em modo web; duas instancias no mesmo banco nao sao permitidas ---------
$running = @(Get-Process -Name 'phantom-gestao' -ErrorAction SilentlyContinue)
if ($running.Count -gt 0) {
    Write-Host 'O Phantom Gestao ja esta aberto e precisa ser reiniciado em modo web.' -ForegroundColor Yellow
    $ans = Read-Host 'Fechar agora? Salve o que estiver fazendo antes. (S/N)'
    if ($ans -notmatch '^[sSyY]') { Stop-WithMessage 'Cancelado. Feche o aplicativo e abra este atalho novamente.' }
    foreach ($p in $running) { [void]$p.CloseMainWindow() }
    $deadline = (Get-Date).AddSeconds(20)
    while ((Get-Process -Name 'phantom-gestao' -ErrorAction SilentlyContinue) -and (Get-Date) -lt $deadline) { Start-Sleep -Milliseconds 500 }
    if (Get-Process -Name 'phantom-gestao' -ErrorAction SilentlyContinue) { Stop-WithMessage 'O aplicativo nao fechou. Feche-o manualmente e abra este atalho novamente.' }
}
if (Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue) {
    Stop-WithMessage "A porta $Port ja esta em uso por outro programa."
}

# --- sobe o app com o modo web ligado -----------------------------------------------------------
Write-Host 'Abrindo o aplicativo em modo web...'
$env:PHANTOM_WEB = '1'
$env:PHANTOM_WEB_PORT = "$Port"
[void](Start-Process -FilePath $Exe -WorkingDirectory (Split-Path $Exe))
Remove-Item Env:PHANTOM_WEB, Env:PHANTOM_WEB_PORT -ErrorAction SilentlyContinue

$ready = $false
for ($i = 0; $i -lt 60; $i++) {
    try {
        $r = Invoke-WebRequest -Uri "$LocalUrl/healthz" -UseBasicParsing -TimeoutSec 2
        if ($r.Content -eq 'ok') { $ready = $true; break }
    } catch { }
    Start-Sleep -Milliseconds 500
}
if (-not $ready) { Stop-WithMessage 'O servidor web nao respondeu em 30 segundos. Abra o aplicativo normalmente e verifique.' }
Write-Host 'Servidor web local pronto.' -ForegroundColor Green

$ErrorActionPreference = 'Continue'   # os programas de rede escrevem o log no stderr

# --- Tailscale (Serve = privado, Funnel = publico), em primeiro plano: fechar a janela encerra ----
if ($Modo -eq 'tailscale' -or $Modo -eq 'funnel') {
    $verbo = if ($Modo -eq 'funnel') { 'funnel' } else { 'serve' }
    $out = Join-Path $env:TEMP 'phantom-tailscale.out'
    $err = Join-Path $env:TEMP 'phantom-tailscale.err'
    Remove-Item $out, $err -ErrorAction SilentlyContinue
    & $TailscaleExe serve reset 2>$null | Out-Null
    $proc = Start-Process -FilePath $TailscaleExe -ArgumentList $verbo, $LocalUrl -NoNewWindow -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
    # confirma que a publicacao ficou ativa (ou mostra o motivo)
    $active = $false
    for ($i = 0; $i -lt 30 -and -not $proc.HasExited; $i++) {
        Start-Sleep -Milliseconds 700
        try {
            # publicacoes em primeiro plano nao aparecem em "serve status": o teste e abrir o proprio endereco
            if ((Invoke-WebRequest -Uri "$tsUrl/healthz" -UseBasicParsing -TimeoutSec 4).Content -eq 'ok') { $active = $true; break }
        } catch { }
    }
    if (-not $active) {
        $msg = ((Get-Content $out, $err -ErrorAction SilentlyContinue) -join ' ').Trim()
        if (-not $proc.HasExited) { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
        Stop-WithMessage "Nao foi possivel publicar pelo Tailscale ($verbo).`n$msg`nPara usar o tunel rapido: -Modo rapido"
    }
    Write-Host ''
    if ($Modo -eq 'funnel') {
        Write-Host 'Acesso remoto PUBLICO (Tailscale Funnel, endereco fixo):' -ForegroundColor Green
        Write-Host "  $tsUrl" -ForegroundColor Cyan
        Write-Host '  Qualquer pessoa com este link chega a tela de login.' -ForegroundColor Yellow
    } else {
        Write-Host 'Acesso remoto PRIVADO (Tailscale Serve, endereco fixo):' -ForegroundColor Green
        Write-Host "  $tsUrl" -ForegroundColor Cyan
        Write-Host '  So quem estiver na sua rede Tailscale (com o app instalado e logado) consegue abrir.'
    }
    try { Set-Clipboard -Value $tsUrl } catch { }
    Write-Host '  (link copiado para a area de transferencia)'
    Write-Host ''
    Write-Host 'Ctrl+C ou fechar esta janela encerra o acesso remoto.' -ForegroundColor DarkGray
    try { $proc.WaitForExit() } finally {
        if (-not $proc.HasExited) { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
        & $TailscaleExe serve reset 2>$null | Out-Null
    }
}
else {
    # --- Cloudflare: tunel nomeado (URL fixa) ou rapido (URL aleatoria) ---------------------------
    $named = $null
    if (Test-Path $ConfigFile) {
        try { $named = Get-Content $ConfigFile -Raw | ConvertFrom-Json } catch { Stop-WithMessage "Arquivo de configuracao invalido: $ConfigFile" }
    }
    if ($named -and $named.tunnelName -and $named.hostname) {
        $url = "https://$($named.hostname)"
        Write-Host ''
        Write-Host 'Acesso remoto (tunel nomeado):' -ForegroundColor Green
        Write-Host "  $url" -ForegroundColor Cyan
        try { Set-Clipboard -Value $url } catch { }
        Write-Host '  (link copiado para a area de transferencia)'
        Write-Host ''
        Write-Host 'Ctrl+C ou fechar esta janela encerra o acesso remoto.' -ForegroundColor DarkGray
        & $Cloudflared tunnel --no-autoupdate run --url $LocalUrl $named.tunnelName 2>&1 | ForEach-Object {
            $l = "$_"
            if ($l -match '\bERR\b|error|failed') { Write-Host $l -ForegroundColor DarkYellow }
        }
    } else {
        Write-Host 'Criando o tunel...'
        $shown = $false
        & $Cloudflared tunnel --no-autoupdate --url $LocalUrl 2>&1 | ForEach-Object {
            $l = "$_"
            if (-not $shown -and $l -match 'https://[a-z0-9-]+\.trycloudflare\.com') {
                $shown = $true
                $url = $Matches[0]
                Write-Host ''
                Write-Host 'Acesso remoto (tunel rapido, PUBLICO):' -ForegroundColor Green
                Write-Host "  $url" -ForegroundColor Cyan
                try { Set-Clipboard -Value $url } catch { }
                Write-Host '  (link copiado para a area de transferencia)'
                Write-Host ''
                Write-Host 'Atencao: qualquer pessoa com este link chega a tela de login. Envie so a quem deve acessar;' -ForegroundColor Yellow
                Write-Host 'o link muda a cada vez que este atalho e aberto. Para endereco fixo e privado, use o Tailscale (-Modo tailscale).' -ForegroundColor Yellow
                Write-Host ''
                Write-Host 'Ctrl+C ou fechar esta janela encerra o acesso remoto.' -ForegroundColor DarkGray
            } elseif ($l -match '\bERR\b|error|failed') {
                Write-Host $l -ForegroundColor DarkYellow
            }
        }
    }
}

Write-Host ''
Write-Host 'Acesso remoto encerrado. O aplicativo continua aberto; o modo web so responde neste computador.' -ForegroundColor Yellow
Read-Host 'Pressione ENTER para sair' | Out-Null

