-- Fase 1 — Fundação: acesso, permissões, auditoria e configurações.
-- Valores monetários (fases seguintes) serão armazenados como inteiros em centavos.

CREATE TABLE roles (
    id          INTEGER PRIMARY KEY,
    code        TEXT NOT NULL UNIQUE,
    name        TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT ''
);

CREATE TABLE permissions (
    id          INTEGER PRIMARY KEY,
    code        TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL
);

CREATE TABLE role_permissions (
    role_id       INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id INTEGER NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE users (
    id              INTEGER PRIMARY KEY,
    username        TEXT NOT NULL COLLATE NOCASE UNIQUE,
    full_name       TEXT NOT NULL,
    password_hash   TEXT NOT NULL,
    role_id         INTEGER NOT NULL REFERENCES roles(id),
    active          INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0, 1)),
    failed_attempts INTEGER NOT NULL DEFAULT 0 CHECK (failed_attempts >= 0),
    locked_until    TEXT,
    last_login_at   TEXT,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    updated_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_users_role ON users(role_id);

CREATE TABLE audit_logs (
    id          INTEGER PRIMARY KEY,
    occurred_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    user_id     INTEGER REFERENCES users(id),
    username    TEXT,
    action      TEXT NOT NULL,
    entity      TEXT,
    entity_id   TEXT,
    details     TEXT
);
CREATE INDEX idx_audit_logs_occurred ON audit_logs(occurred_at);
CREATE INDEX idx_audit_logs_user ON audit_logs(user_id);

-- A trilha de auditoria é append-only.
CREATE TRIGGER audit_logs_no_update BEFORE UPDATE ON audit_logs
BEGIN SELECT RAISE(ABORT, 'audit_logs é imutável'); END;
CREATE TRIGGER audit_logs_no_delete BEFORE DELETE ON audit_logs
BEGIN SELECT RAISE(ABORT, 'audit_logs é imutável'); END;

CREATE TABLE settings (
    key        TEXT PRIMARY KEY,
    value      TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

INSERT INTO roles (code, name, description) VALUES
    ('admin',    'Administrador', 'Acesso total ao sistema'),
    ('manager',  'Gerente',       'Operação completa, sem administração de usuários'),
    ('operator', 'Operador',      'Cadastros e operação comercial'),
    ('viewer',   'Consulta',      'Somente leitura');

INSERT INTO permissions (code, description) VALUES
    ('dashboard.view',     'Visualizar o dashboard'),
    ('clients.view',       'Visualizar clientes'),
    ('loans.view',         'Visualizar empréstimos'),
    ('collateral.view',    'Visualizar garantias'),
    ('products.view',      'Visualizar produtos e estoque'),
    ('purchases.view',     'Visualizar compras'),
    ('sales.view',         'Visualizar vendas'),
    ('payments.view',      'Visualizar pagamentos'),
    ('collections.view',   'Visualizar cobranças'),
    ('contracts.view',     'Visualizar contratos'),
    ('notifications.view', 'Visualizar notificações'),
    ('reports.view',       'Visualizar relatórios'),
    ('settings.view',      'Visualizar configurações'),
    ('users.manage',       'Gerenciar usuários e perfis'),
    ('audit.view',         'Consultar a trilha de auditoria');

-- admin: tudo
INSERT INTO role_permissions SELECT r.id, p.id FROM roles r, permissions p WHERE r.code = 'admin';
-- manager: tudo, exceto gestão de usuários
INSERT INTO role_permissions SELECT r.id, p.id FROM roles r, permissions p
    WHERE r.code = 'manager' AND p.code <> 'users.manage';
-- operator: operação, sem relatórios, configurações e auditoria
INSERT INTO role_permissions SELECT r.id, p.id FROM roles r, permissions p
    WHERE r.code = 'operator' AND p.code IN
    ('dashboard.view','clients.view','products.view','purchases.view','sales.view',
     'payments.view','notifications.view');
-- viewer: dashboard e relatórios
INSERT INTO role_permissions SELECT r.id, p.id FROM roles r, permissions p
    WHERE r.code = 'viewer' AND p.code IN ('dashboard.view','reports.view','notifications.view');

INSERT INTO settings (key, value) VALUES
    ('credit.enabled', 'false'),
    ('collateral.enabled', 'false');
