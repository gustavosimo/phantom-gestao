-- Fase 2 — Cadastros: anexos, clientes, produtos e estoque.
-- Todos os valores monetários são inteiros em centavos (nunca ponto flutuante).

INSERT INTO permissions (code, description) VALUES
    ('clients.manage',     'Cadastrar e editar clientes'),
    ('clients.sensitive',  'Ver CPF/CNPJ completo e documentos pessoais'),
    ('products.manage',    'Cadastrar produtos e movimentar estoque'),
    ('purchases.manage',   'Registrar compras'),
    ('sales.manage',       'Registrar vendas'),
    ('sales.discount',     'Conceder descontos acima do limite'),
    ('sales.cancel',       'Cancelar vendas e registrar devoluções'),
    ('payments.manage',    'Registrar pagamentos e lançamentos'),
    ('payments.reverse',   'Estornar pagamentos'),
    ('loans.manage',       'Criar e analisar solicitações de empréstimo'),
    ('loans.approve',      'Aprovar ou recusar empréstimos'),
    ('loans.disburse',     'Contratar e desembolsar empréstimos'),
    ('collateral.manage',  'Cadastrar e movimentar garantias'),
    ('collections.manage', 'Registrar contatos de cobrança'),
    ('contracts.manage',   'Gerar contratos e gerenciar modelos'),
    ('contracts.legal',    'Aprovar modelos contratuais (responsável jurídico)'),
    ('reports.export',     'Exportar relatórios'),
    ('settings.manage',    'Alterar configurações do sistema'),
    ('backup.manage',      'Realizar backup e recuperação'),
    ('regulatory.manage',  'Habilitar operações reguladas (crédito e garantias)');

INSERT OR IGNORE INTO role_permissions SELECT r.id, p.id FROM roles r, permissions p
    WHERE r.code = 'admin';
INSERT OR IGNORE INTO role_permissions SELECT r.id, p.id FROM roles r, permissions p
    WHERE r.code = 'manager' AND p.code NOT IN ('users.manage','backup.manage','settings.manage','regulatory.manage','contracts.legal');
INSERT OR IGNORE INTO role_permissions SELECT r.id, p.id FROM roles r, permissions p
    WHERE r.code = 'operator' AND p.code IN
    ('clients.manage','products.manage','purchases.manage','sales.manage','payments.manage','collections.view');

CREATE TABLE attachments (
    id            INTEGER PRIMARY KEY,
    owner_type    TEXT NOT NULL,
    owner_id      INTEGER NOT NULL,
    kind          TEXT NOT NULL,
    original_name TEXT NOT NULL,
    stored_name   TEXT NOT NULL UNIQUE,
    mime          TEXT NOT NULL,
    size_bytes    INTEGER NOT NULL CHECK (size_bytes >= 0),
    created_by    INTEGER REFERENCES users(id),
    created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_attachments_owner ON attachments(owner_type, owner_id);

CREATE TABLE clients (
    id             INTEGER PRIMARY KEY,
    kind           TEXT NOT NULL CHECK (kind IN ('PF', 'PJ')),
    name           TEXT NOT NULL,
    document       TEXT NOT NULL UNIQUE,          -- somente dígitos (CPF/CNPJ)
    rg             TEXT,
    birth_date     TEXT,
    profession     TEXT,
    marital_status TEXT,
    email          TEXT,
    phone          TEXT,
    phone2         TEXT,
    zip            TEXT,
    street         TEXT,
    number         TEXT,
    complement     TEXT,
    district       TEXT,
    city           TEXT,
    state          TEXT,
    notes          TEXT,
    status         TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('active','pending','inactive')),
    contact_opt_out INTEGER NOT NULL DEFAULT 0 CHECK (contact_opt_out IN (0,1)),
    created_by     INTEGER REFERENCES users(id),
    created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    updated_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_clients_name ON clients(name COLLATE NOCASE);
CREATE INDEX idx_clients_status ON clients(status);

CREATE TABLE client_documents (
    id            INTEGER PRIMARY KEY,
    client_id     INTEGER NOT NULL REFERENCES clients(id) ON DELETE RESTRICT,
    doc_type      TEXT NOT NULL,
    number        TEXT,
    attachment_id INTEGER REFERENCES attachments(id),
    expires_at    TEXT,
    created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_client_documents_client ON client_documents(client_id);

CREATE TABLE products (
    id            INTEGER PRIMARY KEY,
    sku           TEXT NOT NULL UNIQUE,
    name          TEXT NOT NULL,
    category      TEXT NOT NULL,
    brand         TEXT,
    model         TEXT,
    serial_number TEXT,
    cost_cents    INTEGER NOT NULL DEFAULT 0 CHECK (cost_cents >= 0),
    price_cents   INTEGER NOT NULL DEFAULT 0 CHECK (price_cents >= 0),
    stock_qty     INTEGER NOT NULL DEFAULT 0 CHECK (stock_qty >= 0),
    reserved_qty  INTEGER NOT NULL DEFAULT 0 CHECK (reserved_qty >= 0 AND reserved_qty <= stock_qty),
    min_stock     INTEGER NOT NULL DEFAULT 1 CHECK (min_stock >= 0),
    active        INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
    notes         TEXT,
    created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_products_category ON products(category);
CREATE INDEX idx_products_name ON products(name COLLATE NOCASE);

CREATE TABLE product_cost_history (
    id         INTEGER PRIMARY KEY,
    product_id INTEGER NOT NULL REFERENCES products(id),
    cost_cents INTEGER NOT NULL CHECK (cost_cents >= 0),
    reason     TEXT NOT NULL,
    user_id    INTEGER REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

-- Movimentações de estoque: append-only. Saldo = soma das movimentações.
CREATE TABLE inventory_movements (
    id              INTEGER PRIMARY KEY,
    product_id      INTEGER NOT NULL REFERENCES products(id),
    kind            TEXT NOT NULL CHECK (kind IN ('purchase','sale','return','adjustment','inventory','reserve','release')),
    qty             INTEGER NOT NULL CHECK (qty <> 0),
    unit_cost_cents INTEGER,
    reason          TEXT,
    ref_type        TEXT,
    ref_id          INTEGER,
    user_id         INTEGER REFERENCES users(id),
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_inv_mov_product ON inventory_movements(product_id);
CREATE TRIGGER inventory_movements_no_update BEFORE UPDATE ON inventory_movements
BEGIN SELECT RAISE(ABORT, 'inventory_movements é imutável'); END;
CREATE TRIGGER inventory_movements_no_delete BEFORE DELETE ON inventory_movements
BEGIN SELECT RAISE(ABORT, 'inventory_movements é imutável'); END;

INSERT INTO settings (key, value) VALUES
    ('company.name', ''), ('company.document', ''), ('company.email', ''),
    ('company.phone', ''), ('company.address', ''),
    ('regional.date_format', 'DD/MM/AAAA'), ('regional.tz_offset_hours', '-3'),
    ('sales.max_discount_pct', '10');
