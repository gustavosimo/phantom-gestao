-- Fase 3 — Operação comercial: pagamentos, caixa, compras e vendas.

-- Pagamentos / contas a pagar e a receber. Nunca são excluídos: estornos geram
-- um novo lançamento ligado ao original.
CREATE TABLE payments (
    id              INTEGER PRIMARY KEY,
    client_id       INTEGER REFERENCES clients(id),
    party_name      TEXT,
    direction       TEXT NOT NULL CHECK (direction IN ('in','out')),
    origin_type     TEXT NOT NULL CHECK (origin_type IN ('loan','sale','purchase','payable','receivable','collateral','other')),
    origin_id       INTEGER,
    description     TEXT,
    amount_cents    INTEGER NOT NULL CHECK (amount_cents > 0),
    method          TEXT NOT NULL CHECK (method IN ('cash','pix','card','transfer','boleto')),
    status          TEXT NOT NULL CHECK (status IN ('pending','confirmed','reversed')),
    due_date        TEXT,
    paid_at         TEXT,
    reversal_of_id  INTEGER REFERENCES payments(id),
    reversal_reason TEXT,
    idempotency_key TEXT UNIQUE,
    created_by      INTEGER REFERENCES users(id),
    confirmed_by    INTEGER REFERENCES users(id),
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_payments_client ON payments(client_id);
CREATE INDEX idx_payments_status ON payments(status, due_date);
CREATE INDEX idx_payments_origin ON payments(origin_type, origin_id);

CREATE TABLE payment_allocations (
    id              INTEGER PRIMARY KEY,
    payment_id      INTEGER NOT NULL REFERENCES payments(id),
    installment_id  INTEGER NOT NULL,
    principal_cents INTEGER NOT NULL CHECK (principal_cents >= 0),
    fee_cents       INTEGER NOT NULL DEFAULT 0 CHECK (fee_cents >= 0),
    interest_cents  INTEGER NOT NULL DEFAULT 0 CHECK (interest_cents >= 0)
);
CREATE INDEX idx_alloc_payment ON payment_allocations(payment_id);
CREATE INDEX idx_alloc_installment ON payment_allocations(installment_id);

CREATE TABLE cash_movements (
    id            INTEGER PRIMARY KEY,
    kind          TEXT NOT NULL CHECK (kind IN ('in','out')),
    amount_cents  INTEGER NOT NULL CHECK (amount_cents > 0),
    method        TEXT NOT NULL,
    category      TEXT NOT NULL,
    description   TEXT,
    payment_id    INTEGER REFERENCES payments(id),
    occurred_at   TEXT NOT NULL,
    reconciled    INTEGER NOT NULL DEFAULT 0 CHECK (reconciled IN (0,1)),
    reconciled_at TEXT,
    reconciled_by INTEGER REFERENCES users(id),
    created_by    INTEGER REFERENCES users(id),
    created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_cash_occurred ON cash_movements(occurred_at);
CREATE TRIGGER cash_movements_no_delete BEFORE DELETE ON cash_movements
BEGIN SELECT RAISE(ABORT, 'cash_movements é imutável'); END;

CREATE TABLE purchases (
    id               INTEGER PRIMARY KEY,
    seller_client_id INTEGER REFERENCES clients(id),
    seller_name      TEXT NOT NULL,
    seller_document  TEXT,
    product_id       INTEGER NOT NULL REFERENCES products(id),
    product_name     TEXT NOT NULL,
    category         TEXT NOT NULL,
    qty              INTEGER NOT NULL DEFAULT 1 CHECK (qty > 0),
    amount_cents     INTEGER NOT NULL CHECK (amount_cents > 0),
    valuation_cents  INTEGER,
    payment_method   TEXT NOT NULL CHECK (payment_method IN ('cash','pix','card','transfer','boleto')),
    status           TEXT NOT NULL CHECK (status IN ('pending','confirmed','cancelled')),
    origin_proof     TEXT,
    purchased_at     TEXT NOT NULL,
    payment_id       INTEGER REFERENCES payments(id),
    notes            TEXT,
    created_by       INTEGER REFERENCES users(id),
    created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_purchases_seller ON purchases(seller_client_id);

CREATE TABLE sales (
    id             INTEGER PRIMARY KEY,
    client_id      INTEGER REFERENCES clients(id),
    subtotal_cents INTEGER NOT NULL CHECK (subtotal_cents >= 0),
    discount_cents INTEGER NOT NULL DEFAULT 0 CHECK (discount_cents >= 0),
    total_cents    INTEGER NOT NULL CHECK (total_cents >= 0),
    payment_method TEXT NOT NULL CHECK (payment_method IN ('cash','pix','card','transfer','boleto')),
    status         TEXT NOT NULL CHECK (status IN ('completed','cancelled','partially_returned')),
    fiscal_status  TEXT NOT NULL DEFAULT 'not_configured',
    payment_id     INTEGER REFERENCES payments(id),
    cancel_reason  TEXT,
    created_by     INTEGER REFERENCES users(id),
    created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    CHECK (discount_cents <= subtotal_cents AND total_cents = subtotal_cents - discount_cents)
);
CREATE INDEX idx_sales_client ON sales(client_id);
CREATE INDEX idx_sales_created ON sales(created_at);

CREATE TABLE sale_items (
    id               INTEGER PRIMARY KEY,
    sale_id          INTEGER NOT NULL REFERENCES sales(id),
    product_id       INTEGER NOT NULL REFERENCES products(id),
    product_name     TEXT NOT NULL,
    qty              INTEGER NOT NULL CHECK (qty > 0),
    unit_price_cents INTEGER NOT NULL CHECK (unit_price_cents >= 0),
    unit_cost_cents  INTEGER NOT NULL CHECK (unit_cost_cents >= 0),
    returned_qty     INTEGER NOT NULL DEFAULT 0 CHECK (returned_qty >= 0 AND returned_qty <= qty)
);
CREATE INDEX idx_sale_items_sale ON sale_items(sale_id);

CREATE TABLE sale_returns (
    id           INTEGER PRIMARY KEY,
    sale_id      INTEGER NOT NULL REFERENCES sales(id),
    sale_item_id INTEGER NOT NULL REFERENCES sale_items(id),
    qty          INTEGER NOT NULL CHECK (qty > 0),
    amount_cents INTEGER NOT NULL CHECK (amount_cents >= 0),
    reason       TEXT NOT NULL,
    payment_id   INTEGER REFERENCES payments(id),
    created_by   INTEGER REFERENCES users(id),
    created_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
