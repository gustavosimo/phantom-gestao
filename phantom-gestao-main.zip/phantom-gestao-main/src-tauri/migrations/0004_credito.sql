-- Fase 4 — Crédito, garantias e contratos.
-- Contratação e desembolso permanecem bloqueados enquanto settings.credit.enabled = 'false'.

CREATE TABLE credit_applications (
    id               INTEGER PRIMARY KEY,
    client_id        INTEGER NOT NULL REFERENCES clients(id),
    amount_cents     INTEGER NOT NULL CHECK (amount_cents > 0),
    term_months      INTEGER NOT NULL CHECK (term_months BETWEEN 1 AND 120),
    rate_bp          INTEGER NOT NULL CHECK (rate_bp >= 0),   -- % ao mês em centésimos (240 = 2,40%)
    purpose          TEXT,
    first_due_date   TEXT NOT NULL,
    collateral_id    INTEGER,
    status           TEXT NOT NULL DEFAULT 'draft'
                     CHECK (status IN ('draft','analysis','approved','rejected','contracted','cancelled')),
    analysis_notes   TEXT,
    analysis_json    TEXT,
    analyzed_by      INTEGER REFERENCES users(id),
    decided_by       INTEGER REFERENCES users(id),
    decided_at       TEXT,
    decision_notes   TEXT,
    created_by       INTEGER REFERENCES users(id),
    created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    updated_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_credit_apps_client ON credit_applications(client_id);

CREATE TABLE loans (
    id               INTEGER PRIMARY KEY,
    application_id   INTEGER REFERENCES credit_applications(id),
    client_id        INTEGER NOT NULL REFERENCES clients(id),
    principal_cents  INTEGER NOT NULL CHECK (principal_cents > 0),
    term_months      INTEGER NOT NULL,
    rate_bp          INTEGER NOT NULL,
    fee_cents        INTEGER NOT NULL DEFAULT 0,
    cet_annual_bp    INTEGER,
    first_due_date   TEXT NOT NULL,
    status           TEXT NOT NULL DEFAULT 'pending_disbursement'
                     CHECK (status IN ('pending_disbursement','active','paid_off','renegotiated','cancelled')),
    contracted_at    TEXT NOT NULL,
    disbursed_at     TEXT,
    disbursed_by     INTEGER REFERENCES users(id),
    disbursement_payment_id INTEGER REFERENCES payments(id),
    paid_off_at      TEXT,
    purpose          TEXT,
    created_by       INTEGER REFERENCES users(id),
    created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_loans_client ON loans(client_id);
CREATE INDEX idx_loans_status ON loans(status);

CREATE TABLE loan_installments (
    id               INTEGER PRIMARY KEY,
    loan_id          INTEGER NOT NULL REFERENCES loans(id),
    number           INTEGER NOT NULL,
    due_date         TEXT NOT NULL,
    amount_cents     INTEGER NOT NULL CHECK (amount_cents > 0),
    principal_cents  INTEGER NOT NULL CHECK (principal_cents >= 0),
    interest_cents   INTEGER NOT NULL CHECK (interest_cents >= 0),
    paid_cents       INTEGER NOT NULL DEFAULT 0 CHECK (paid_cents >= 0 AND paid_cents <= amount_cents),
    late_fee_applied INTEGER NOT NULL DEFAULT 0 CHECK (late_fee_applied IN (0,1)),
    interest_through TEXT,
    status           TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','partial','paid','renegotiated')),
    paid_at          TEXT
);
CREATE INDEX idx_installments_loan ON loan_installments(loan_id);
CREATE INDEX idx_installments_due ON loan_installments(due_date, status);

CREATE TABLE loan_renegotiations (
    id               INTEGER PRIMARY KEY,
    loan_id          INTEGER NOT NULL REFERENCES loans(id),
    balance_cents    INTEGER NOT NULL,
    new_term_months  INTEGER NOT NULL,
    new_rate_bp      INTEGER NOT NULL,
    first_due_date   TEXT NOT NULL,
    reason           TEXT NOT NULL,
    created_by       INTEGER REFERENCES users(id),
    created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE collateral_assets (
    id               INTEGER PRIMARY KEY,
    client_id        INTEGER NOT NULL REFERENCES clients(id),
    loan_id          INTEGER REFERENCES loans(id),
    application_id   INTEGER REFERENCES credit_applications(id),
    category         TEXT NOT NULL,
    name             TEXT NOT NULL,
    brand            TEXT,
    model            TEXT,
    serial_number    TEXT,
    condition        TEXT NOT NULL DEFAULT 'used' CHECK (condition IN ('new','refurbished','used','damaged')),
    appraised_cents  INTEGER CHECK (appraised_cents IS NULL OR appraised_cents >= 0),
    linked_value_cents INTEGER CHECK (linked_value_cents IS NULL OR linked_value_cents >= 0),
    storage_location TEXT,
    custody_days     INTEGER,
    custody_start    TEXT,
    custody_due      TEXT,
    notes            TEXT,
    status           TEXT NOT NULL DEFAULT 'registered'
                     CHECK (status IN ('registered','appraising','approved','in_custody','near_deadline','redeemed','returned','legal_procedure','rejected')),
    created_by       INTEGER REFERENCES users(id),
    created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    updated_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_collateral_client ON collateral_assets(client_id);
CREATE INDEX idx_collateral_status ON collateral_assets(status);
-- Garantias nunca entram no estoque comercial: não há vínculo com products.

CREATE TABLE collateral_valuations (
    id           INTEGER PRIMARY KEY,
    asset_id     INTEGER NOT NULL REFERENCES collateral_assets(id),
    value_cents  INTEGER NOT NULL CHECK (value_cents >= 0),
    notes        TEXT,
    valued_by    INTEGER REFERENCES users(id),
    created_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE custody_events (
    id          INTEGER PRIMARY KEY,
    asset_id    INTEGER NOT NULL REFERENCES collateral_assets(id),
    kind        TEXT NOT NULL,
    description TEXT NOT NULL,
    user_id     INTEGER REFERENCES users(id),
    created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_custody_asset ON custody_events(asset_id);
CREATE TRIGGER custody_events_no_update BEFORE UPDATE ON custody_events
BEGIN SELECT RAISE(ABORT, 'custody_events é imutável'); END;
CREATE TRIGGER custody_events_no_delete BEFORE DELETE ON custody_events
BEGIN SELECT RAISE(ABORT, 'custody_events é imutável'); END;

CREATE TABLE contract_templates (
    id            INTEGER PRIMARY KEY,
    kind          TEXT NOT NULL CHECK (kind IN ('loan','collateral','sale','purchase')),
    name          TEXT NOT NULL,
    body          TEXT NOT NULL,
    version       INTEGER NOT NULL DEFAULT 1,
    legal_status  TEXT NOT NULL DEFAULT 'draft' CHECK (legal_status IN ('draft','approved')),
    approved_by   TEXT,
    approved_at   TEXT,
    active        INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
    updated_by    INTEGER REFERENCES users(id),
    updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE contract_template_versions (
    id          INTEGER PRIMARY KEY,
    template_id INTEGER NOT NULL REFERENCES contract_templates(id),
    version     INTEGER NOT NULL,
    body        TEXT NOT NULL,
    legal_status TEXT NOT NULL,
    approved_by TEXT,
    saved_by    INTEGER REFERENCES users(id),
    saved_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE contracts (
    id            INTEGER PRIMARY KEY,
    number        TEXT NOT NULL UNIQUE,
    kind          TEXT NOT NULL CHECK (kind IN ('loan','collateral','sale','purchase')),
    client_id     INTEGER REFERENCES clients(id),
    ref_type      TEXT NOT NULL,
    ref_id        INTEGER NOT NULL,
    template_id   INTEGER REFERENCES contract_templates(id),
    template_version INTEGER,
    status        TEXT NOT NULL DEFAULT 'pending_signature'
                  CHECK (status IN ('pending_signature','active','completed','late','cancelled')),
    attachment_id INTEGER REFERENCES attachments(id),
    signed_at     TEXT,
    signed_by_name TEXT,
    signature_note TEXT,
    created_by    INTEGER REFERENCES users(id),
    created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_contracts_ref ON contracts(ref_type, ref_id);
CREATE INDEX idx_contracts_client ON contracts(client_id);

-- Versões geradas do mesmo contrato (cada regeração cria uma nova versão; nada é sobrescrito).
CREATE TABLE contract_versions (
    id            INTEGER PRIMARY KEY,
    contract_id   INTEGER NOT NULL REFERENCES contracts(id),
    version       INTEGER NOT NULL,
    attachment_id INTEGER NOT NULL REFERENCES attachments(id),
    reason        TEXT,
    created_by    INTEGER REFERENCES users(id),
    created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    UNIQUE (contract_id, version)
);

INSERT INTO settings (key, value) VALUES
    ('loan.default_rate_bp', '240'),
    ('loan.origination_fee_bp', '0'),
    ('loan.iof_bp', '0'),
    ('loan.late_fee_bp', '200'),
    ('loan.late_interest_month_bp', '100'),
    ('loan.max_term_months', '60'),
    ('loan.max_amount_cents', '5000000'),
    ('regulatory.credit_note', ''),
    ('regulatory.collateral_note', '');

INSERT INTO contract_templates (kind, name, body) VALUES
('loan', 'Minuta — Contrato de empréstimo',
'# CONTRATO DE EMPRÉSTIMO {contrato_numero}
MINUTA SEM VALIDADE JURÍDICA — requer aprovação do responsável jurídico antes do uso.

## Partes
CREDORA: {empresa}, CNPJ {empresa_documento}.
DEVEDOR(A): {cliente_nome}, documento {cliente_documento}, residente em {cliente_endereco}.

## Condições financeiras
Empréstimo nº {emprestimo_numero}. Valor: {valor}. Prazo: {prazo}. Taxa de juros: {taxa_mensal}. CET: {cet_anual}.
Valor de cada parcela: {parcela}. Primeiro vencimento: {primeiro_vencimento}. Total a pagar: {total_pagar}.

## Cláusulas
[CLÁUSULAS A SEREM DEFINIDAS PELO RESPONSÁVEL JURÍDICO]

Data: {data}

____________________________________   ____________________________________
Credora                                                                      Devedor(a)'),
('collateral', 'Minuta — Termo de garantia em custódia',
'# TERMO DE GARANTIA EM CUSTÓDIA {contrato_numero}
MINUTA SEM VALIDADE JURÍDICA — requer aprovação do responsável jurídico antes do uso.

## Partes
CUSTODIANTE: {empresa}, CNPJ {empresa_documento}.
PROPRIETÁRIO(A): {cliente_nome}, documento {cliente_documento}.

## Bem
Garantia {garantia_codigo}: {bem_descricao}. Série/IMEI: {bem_serie}. Estado: {bem_condicao}.
Valor de avaliação: {bem_avaliacao}. Local de custódia: {local_custodia}. Prazo: {prazo_custodia}.
Contrato vinculado: {emprestimo_numero}.

## Cláusulas
[CLÁUSULAS A SEREM DEFINIDAS PELO RESPONSÁVEL JURÍDICO]

Data: {data}

____________________________________   ____________________________________
Custodiante                                                              Proprietário(a)'),
('sale', 'Minuta — Contrato de venda',
'# CONTRATO DE VENDA {contrato_numero}
MINUTA SEM VALIDADE JURÍDICA — requer aprovação do responsável jurídico antes do uso.

VENDEDORA: {empresa}, CNPJ {empresa_documento}.
COMPRADOR(A): {cliente_nome}, documento {cliente_documento}.
Venda {venda_codigo}. Valor total: {valor}.

[CLÁUSULAS A SEREM DEFINIDAS PELO RESPONSÁVEL JURÍDICO]

Data: {data}'),
('purchase', 'Minuta — Contrato de compra',
'# CONTRATO DE COMPRA {contrato_numero}
MINUTA SEM VALIDADE JURÍDICA — requer aprovação do responsável jurídico antes do uso.

COMPRADORA: {empresa}, CNPJ {empresa_documento}.
VENDEDOR(A): {cliente_nome}, documento {cliente_documento}.
Compra {compra_codigo}: {produto}. Valor: {valor}.

[CLÁUSULAS A SEREM DEFINIDAS PELO RESPONSÁVEL JURÍDICO]

Data: {data}');

INSERT INTO contract_template_versions (template_id, version, body, legal_status)
    SELECT id, 1, body, 'draft' FROM contract_templates;