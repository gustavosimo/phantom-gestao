-- Fase 5 — Cobranças, notificações, integrações e relatórios gerados.

CREATE TABLE notifications (
    id          INTEGER PRIMARY KEY,
    kind        TEXT NOT NULL CHECK (kind IN ('due_today','due_soon','overdue','contract_pending','collateral_deadline',
                                              'collateral_appraisal','document_pending','payment_confirmed','loan_paid_off',
                                              'new_clients','collateral_redeemed','task','system')),
    category    TEXT NOT NULL CHECK (category IN ('alert','due','payment','pending','info')),
    severity    TEXT NOT NULL DEFAULT 'info' CHECK (severity IN ('info','warning','error','success')),
    title       TEXT NOT NULL,
    body        TEXT,
    entity_type TEXT,
    entity_id   INTEGER,
    dedupe_key  TEXT UNIQUE,
    read_at     TEXT,
    created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_notifications_read ON notifications(read_at, created_at);

CREATE TABLE notification_templates (
    id         INTEGER PRIMARY KEY,
    code       TEXT NOT NULL UNIQUE,
    channel    TEXT NOT NULL CHECK (channel IN ('whatsapp','email','call')),
    name       TEXT NOT NULL,
    body       TEXT NOT NULL,
    active     INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

-- Histórico de contatos de cobrança (envios, tentativas e falhas).
CREATE TABLE collection_events (
    id             INTEGER PRIMARY KEY,
    client_id      INTEGER NOT NULL REFERENCES clients(id),
    installment_id INTEGER REFERENCES loan_installments(id),
    channel        TEXT NOT NULL CHECK (channel IN ('whatsapp','email','call')),
    status         TEXT NOT NULL CHECK (status IN ('sent','attempted','failed','answered','no_answer','blocked')),
    mode           TEXT NOT NULL DEFAULT 'manual' CHECK (mode IN ('manual','integration')),
    message        TEXT,
    error          TEXT,
    user_id        INTEGER REFERENCES users(id),
    created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX idx_collection_client ON collection_events(client_id, created_at);

-- Segredos de integrações (tokens) são gravados cifrados.
CREATE TABLE secrets (
    key        TEXT PRIMARY KEY,
    value_enc  TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE generated_reports (
    id            INTEGER PRIMARY KEY,
    report_type   TEXT NOT NULL,
    title         TEXT NOT NULL,
    period_label  TEXT NOT NULL,
    format        TEXT NOT NULL CHECK (format IN ('pdf','csv')),
    attachment_id INTEGER NOT NULL REFERENCES attachments(id),
    created_by    INTEGER REFERENCES users(id),
    created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

INSERT INTO notification_templates (code, channel, name, body) VALUES
    ('due_reminder',  'whatsapp', 'Lembrete de vencimento',
     'Olá, {nome}! Lembramos que a parcela {parcela} do contrato {contrato}, no valor de {valor}, vence em {vencimento}.'),
    ('overdue_notice','whatsapp', 'Aviso de atraso',
     'Olá, {nome}. Identificamos que a parcela {parcela} do contrato {contrato} ({valor}) venceu em {vencimento}. Podemos ajudar a regularizar?'),
    ('due_email',     'email',    'E-mail de vencimento',
     'Prezado(a) {nome}, a parcela {parcela} do contrato {contrato}, no valor de {valor}, vence em {vencimento}.'),
    ('overdue_email', 'email',    'E-mail de atraso',
     'Prezado(a) {nome}, a parcela {parcela} do contrato {contrato} ({valor}) está vencida desde {vencimento}.');

INSERT INTO settings (key, value) VALUES
    ('collections.whatsapp_3d_before', 'true'),
    ('collections.email_on_due', 'true'),
    ('collections.call_after_5d', 'false'),
    ('collections.quiet_start_hour', '8'),
    ('collections.quiet_end_hour', '20'),
    ('collections.allow_sunday', 'false'),
    ('collections.max_per_client_day', '2'),
    ('collections.max_per_client_week', '4'),
    ('notifications.due_soon_days', '7'),
    ('notifications.collateral_days', '7'),
    ('integrations.whatsapp.enabled', 'false'),
    ('integrations.whatsapp.phone_id', ''),
    ('integrations.email.enabled', 'false'),
    ('integrations.email.host', ''),
    ('integrations.email.port', '587'),
    ('integrations.email.user', ''),
    ('integrations.fiscal.enabled', 'false'),
    ('integrations.fiscal.regime', ''),
    ('integrations.fiscal.provider', '');
