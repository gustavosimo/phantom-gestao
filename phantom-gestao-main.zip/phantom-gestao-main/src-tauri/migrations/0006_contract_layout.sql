-- Versão do layout do PDF (2 = cabeçalho institucional com logo e nome da empresa).
ALTER TABLE contract_versions ADD COLUMN layout INTEGER NOT NULL DEFAULT 1;
