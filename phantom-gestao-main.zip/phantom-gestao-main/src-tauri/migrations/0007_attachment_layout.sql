-- Versão do layout de PDFs gerados pelo sistema (2 = cabeçalho institucional com logo e nome da empresa).
ALTER TABLE attachments ADD COLUMN layout INTEGER NOT NULL DEFAULT 1;
