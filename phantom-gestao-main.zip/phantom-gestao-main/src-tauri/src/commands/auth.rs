use super::ctx::{parse_args, to_json, Ctx, Db, Sess};
use crate::domain::user::User;
use crate::error::AppResult;
use crate::services::auth_service;

#[tauri::command]
pub fn setup_required(db: Db) -> AppResult<bool> {
    auth_service::setup_required(&db)
}

#[tauri::command]
pub fn setup_admin(
    db: Db,
    session: Sess,
    full_name: String,
    username: String,
    password: String,
) -> AppResult<User> {
    let user = auth_service::setup_admin(&db, &full_name, &username, &password)?;
    session.set(user.clone());
    Ok(user)
}

#[tauri::command]
pub fn login(
    db: Db,
    session: Sess,
    username: String,
    password: String,
) -> AppResult<User> {
    let user = auth_service::login(&db, &username, &password)?;
    session.set(user.clone());
    Ok(user)
}

#[tauri::command]
pub fn logout(db: Db, session: Sess) -> AppResult<()> {
    if let Some(user) = session.clear() {
        auth_service::logout(&db, &user)?;
    }
    Ok(())
}

#[tauri::command]
pub fn current_user(session: Sess) -> AppResult<Option<User>> {
    Ok(session.user().ok())
}

// ==== BEGIN GENERATED WEB DISPATCH (scripts/gen_web_dispatch.py) ====
#[allow(unused_variables, clippy::redundant_closure_call)]
pub fn web_dispatch(cmd: &str, ctx: &Ctx, args: serde_json::Value) -> Option<AppResult<serde_json::Value>> {
    match cmd {
        "setup_required" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(setup_required(Db(ctx.db))?)
        })()),
        "setup_admin" => Some(Err(crate::error::AppError::Validation("Recurso disponível apenas no aplicativo desktop.".into()))),
        "login" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                username: String,
                password: String,
            }
            let a: A = parse_args(args)?;
            to_json(login(Db(ctx.db), Sess(ctx.session), a.username, a.password)?)
        })()),
        "logout" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(logout(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "current_user" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(current_user(Sess(ctx.session))?)
        })()),
        _ => None,
    }
}
// ==== END GENERATED WEB DISPATCH ====
