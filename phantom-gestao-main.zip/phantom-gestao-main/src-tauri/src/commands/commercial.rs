use serde::Serialize;

use super::guard::*;
use crate::error::AppResult;
use crate::repositories::payment_repo::{self, CashRow, CashSummary, PaymentFilter, PaymentRow};
use crate::repositories::commerce_repo::{self, PurchaseRow, SaleItemRow, SaleRow};
use crate::repositories::{settings_repo, Page, PageQuery};
use crate::services::attachment_service::Attachment;
use crate::services::payment_service::{self, InstallmentDue, ManualPaymentInput};
use crate::services::purchase_service::{self, PurchaseInput};
use crate::services::sale_service::{self, SaleInput, SaleResult};

use super::ctx::{parse_args, to_json, Ctx, Db, Sess, Vlt};

// ------------------------------------------------------------------- compras

#[tauri::command(async)]
pub fn purchases_list(db: Db, s: Sess, query: PageQuery) -> AppResult<Page<PurchaseRow>> {
    run(&db, &s, "purchases.view", |c, _| commerce_repo::list_purchases(c, &query))
}

#[tauri::command(async)]
pub fn purchase_register(db: Db, s: Sess, vault: Vlt, input: PurchaseInput) -> AppResult<i64> {
    run(&db, &s, "purchases.manage", |c, u| purchase_service::register(c, &vault, u, input))
}

#[tauri::command(async)]
pub fn purchase_confirm(db: Db, s: Sess, id: i64) -> AppResult<()> {
    run(&db, &s, "purchases.manage", |c, u| purchase_service::confirm(c, u, id))
}

#[tauri::command(async)]
pub fn purchase_cancel(db: Db, s: Sess, id: i64, reason: String) -> AppResult<()> {
    run(&db, &s, "purchases.manage", |c, u| purchase_service::cancel(c, u, id, &reason))
}

#[tauri::command(async)]
pub fn purchase_receipt(db: Db, s: Sess, vault: Vlt, id: i64) -> AppResult<Attachment> {
    run(&db, &s, "purchases.view", |c, u| purchase_service::receipt(c, &vault, u, id))
}

// -------------------------------------------------------------------- vendas

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SaleDetail {
    pub sale: SaleRow,
    pub items: Vec<SaleItemRow>,
}

#[tauri::command(async)]
pub fn sales_list(db: Db, s: Sess, query: PageQuery) -> AppResult<Page<SaleRow>> {
    run(&db, &s, "sales.view", |c, _| commerce_repo::list_sales(c, &query))
}

#[tauri::command(async)]
pub fn sale_get(db: Db, s: Sess, id: i64) -> AppResult<SaleDetail> {
    run(&db, &s, "sales.view", |c, _| Ok(SaleDetail { sale: commerce_repo::get_sale(c, id)?, items: commerce_repo::sale_items(c, id)? }))
}

#[tauri::command(async)]
pub fn sale_create(db: Db, s: Sess, input: SaleInput) -> AppResult<SaleResult> {
    run(&db, &s, "sales.manage", |c, u| sale_service::create(c, u, input))
}

#[tauri::command(async)]
pub fn sale_cancel(db: Db, s: Sess, id: i64, reason: String) -> AppResult<()> {
    run(&db, &s, "sales.cancel", |c, u| sale_service::cancel(c, u, id, &reason))
}

#[tauri::command(async)]
pub fn sale_return_item(db: Db, s: Sess, sale_id: i64, item_id: i64, qty: i64, reason: String) -> AppResult<i64> {
    run(&db, &s, "sales.cancel", |c, u| sale_service::return_item(c, u, sale_id, item_id, qty, &reason))
}

#[tauri::command(async)]
pub fn sale_receipt(db: Db, s: Sess, vault: Vlt, id: i64) -> AppResult<Attachment> {
    run(&db, &s, "sales.view", |c, u| sale_service::receipt(c, &vault, u, id))
}

// ---------------------------------------------------------------- pagamentos

#[tauri::command(async)]
pub fn payments_list(db: Db, s: Sess, query: PageQuery, filter: PaymentFilter) -> AppResult<Page<PaymentRow>> {
    run(&db, &s, "payments.view", |c, _| {
        let today = settings_repo::today(c).to_string();
        payment_repo::list(c, &query, &filter, &today)
    })
}

#[tauri::command(async)]
pub fn payment_register_manual(db: Db, s: Sess, input: ManualPaymentInput) -> AppResult<i64> {
    run(&db, &s, "payments.manage", |c, u| payment_service::register_manual(c, u, input))
}

#[tauri::command(async)]
pub fn payment_confirm(db: Db, s: Sess, id: i64, method: Option<String>) -> AppResult<()> {
    run(&db, &s, "payments.manage", |c, u| payment_service::confirm(c, u, id, method))
}

#[tauri::command(async)]
pub fn payment_reverse(db: Db, s: Sess, id: i64, reason: String) -> AppResult<i64> {
    run(&db, &s, "payments.reverse", |c, u| payment_service::reverse(c, u, id, &reason))
}

#[tauri::command(async)]
pub fn payment_receipt(db: Db, s: Sess, vault: Vlt, id: i64) -> AppResult<Attachment> {
    run(&db, &s, "payments.view", |c, u| payment_service::receipt(c, &vault, u, id))
}

#[tauri::command(async)]
pub fn installment_pay(db: Db, s: Sess, installment_id: i64, amount_cents: i64, method: String, idempotency_key: Option<String>) -> AppResult<i64> {
    run(&db, &s, "payments.manage", |c, u| payment_service::pay_installment(c, u, installment_id, amount_cents, &method, idempotency_key))
}

#[tauri::command(async)]
pub fn loan_settle(db: Db, s: Sess, loan_id: i64, method: String, idempotency_key: Option<String>) -> AppResult<i64> {
    run(&db, &s, "payments.manage", |c, u| payment_service::settle_loan(c, u, loan_id, &method, idempotency_key))
}

#[tauri::command(async)]
pub fn installment_due(db: Db, s: Sess, installment_id: i64) -> AppResult<InstallmentDue> {
    run_any(&db, &s, &["payments.view", "loans.view"], |c, _| {
        let inst = crate::repositories::loan_repo::installment(c, installment_id)?;
        payment_service::installment_due(c, &inst, settings_repo::today(c))
    })
}

#[tauri::command(async)]
pub fn cash_list(db: Db, s: Sess, query: PageQuery) -> AppResult<Page<CashRow>> {
    run(&db, &s, "payments.view", |c, _| payment_repo::cash_list(c, &query))
}

#[tauri::command(async)]
pub fn cash_summary(db: Db, s: Sess) -> AppResult<CashSummary> {
    run(&db, &s, "payments.view", |c, _| payment_repo::cash_summary(c))
}

#[tauri::command(async)]
pub fn cash_manual(db: Db, s: Sess, kind: String, amount_cents: i64, method: String, description: String) -> AppResult<i64> {
    run(&db, &s, "payments.manage", |c, u| payment_service::manual_cash(c, u, &kind, amount_cents, &method, &description))
}

#[tauri::command(async)]
pub fn cash_reconcile(db: Db, s: Sess, ids: Vec<i64>, value: bool) -> AppResult<()> {
    run(&db, &s, "payments.manage", |c, u| payment_service::reconcile(c, u, &ids, value))
}

// ==== BEGIN GENERATED WEB DISPATCH (scripts/gen_web_dispatch.py) ====
#[allow(unused_variables, clippy::redundant_closure_call)]
pub fn web_dispatch(cmd: &str, ctx: &Ctx, args: serde_json::Value) -> Option<AppResult<serde_json::Value>> {
    match cmd {
        "purchases_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                query: PageQuery,
            }
            let a: A = parse_args(args)?;
            to_json(purchases_list(Db(ctx.db), Sess(ctx.session), a.query)?)
        })()),
        "purchase_register" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: PurchaseInput,
            }
            let a: A = parse_args(args)?;
            to_json(purchase_register(Db(ctx.db), Sess(ctx.session), Vlt(ctx.vault), a.input)?)
        })()),
        "purchase_confirm" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(purchase_confirm(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "purchase_cancel" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                reason: String,
            }
            let a: A = parse_args(args)?;
            to_json(purchase_cancel(Db(ctx.db), Sess(ctx.session), a.id, a.reason)?)
        })()),
        "purchase_receipt" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(purchase_receipt(Db(ctx.db), Sess(ctx.session), Vlt(ctx.vault), a.id)?)
        })()),
        "sales_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                query: PageQuery,
            }
            let a: A = parse_args(args)?;
            to_json(sales_list(Db(ctx.db), Sess(ctx.session), a.query)?)
        })()),
        "sale_get" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(sale_get(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "sale_create" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: SaleInput,
            }
            let a: A = parse_args(args)?;
            to_json(sale_create(Db(ctx.db), Sess(ctx.session), a.input)?)
        })()),
        "sale_cancel" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                reason: String,
            }
            let a: A = parse_args(args)?;
            to_json(sale_cancel(Db(ctx.db), Sess(ctx.session), a.id, a.reason)?)
        })()),
        "sale_return_item" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                sale_id: i64,
                item_id: i64,
                qty: i64,
                reason: String,
            }
            let a: A = parse_args(args)?;
            to_json(sale_return_item(Db(ctx.db), Sess(ctx.session), a.sale_id, a.item_id, a.qty, a.reason)?)
        })()),
        "sale_receipt" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(sale_receipt(Db(ctx.db), Sess(ctx.session), Vlt(ctx.vault), a.id)?)
        })()),
        "payments_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                query: PageQuery,
                filter: PaymentFilter,
            }
            let a: A = parse_args(args)?;
            to_json(payments_list(Db(ctx.db), Sess(ctx.session), a.query, a.filter)?)
        })()),
        "payment_register_manual" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: ManualPaymentInput,
            }
            let a: A = parse_args(args)?;
            to_json(payment_register_manual(Db(ctx.db), Sess(ctx.session), a.input)?)
        })()),
        "payment_confirm" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                method: Option<String>,
            }
            let a: A = parse_args(args)?;
            to_json(payment_confirm(Db(ctx.db), Sess(ctx.session), a.id, a.method)?)
        })()),
        "payment_reverse" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                reason: String,
            }
            let a: A = parse_args(args)?;
            to_json(payment_reverse(Db(ctx.db), Sess(ctx.session), a.id, a.reason)?)
        })()),
        "payment_receipt" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(payment_receipt(Db(ctx.db), Sess(ctx.session), Vlt(ctx.vault), a.id)?)
        })()),
        "installment_pay" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                installment_id: i64,
                amount_cents: i64,
                method: String,
                idempotency_key: Option<String>,
            }
            let a: A = parse_args(args)?;
            to_json(installment_pay(Db(ctx.db), Sess(ctx.session), a.installment_id, a.amount_cents, a.method, a.idempotency_key)?)
        })()),
        "loan_settle" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                loan_id: i64,
                method: String,
                idempotency_key: Option<String>,
            }
            let a: A = parse_args(args)?;
            to_json(loan_settle(Db(ctx.db), Sess(ctx.session), a.loan_id, a.method, a.idempotency_key)?)
        })()),
        "installment_due" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                installment_id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(installment_due(Db(ctx.db), Sess(ctx.session), a.installment_id)?)
        })()),
        "cash_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                query: PageQuery,
            }
            let a: A = parse_args(args)?;
            to_json(cash_list(Db(ctx.db), Sess(ctx.session), a.query)?)
        })()),
        "cash_summary" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(cash_summary(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "cash_manual" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                kind: String,
                amount_cents: i64,
                method: String,
                description: String,
            }
            let a: A = parse_args(args)?;
            to_json(cash_manual(Db(ctx.db), Sess(ctx.session), a.kind, a.amount_cents, a.method, a.description)?)
        })()),
        "cash_reconcile" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                ids: Vec<i64>,
                value: bool,
            }
            let a: A = parse_args(args)?;
            to_json(cash_reconcile(Db(ctx.db), Sess(ctx.session), a.ids, a.value)?)
        })()),
        _ => None,
    }
}
// ==== END GENERATED WEB DISPATCH ====
