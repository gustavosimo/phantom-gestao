use serde::Serialize;

use super::guard::*;
use crate::domain::loan::Simulation;
use crate::error::AppResult;
use crate::repositories::loan_repo::{self, LoanRow};
use crate::repositories::{settings_repo, Page, PageQuery};
use crate::services::attachment_service::{self, Attachment};
use crate::services::collateral_service::{self, CollateralInput, CollateralRow, CollateralStats, EventRow};
use crate::services::contract_service::{self, ContractRow, TemplateInput, TemplateRow, TemplateVersion, VariableInfo, VersionRow};
use crate::services::loan_service::{self, ApplicationInput, ApplicationRow, LoanDetail, RenegotiationInput, SimulationInput};

use super::ctx::{parse_args, to_json, Ctx, Db, Sess, Vlt};

// --------------------------------------------------------------- empréstimos

#[tauri::command(async)]
pub fn loan_simulate(db: Db, s: Sess, input: SimulationInput) -> AppResult<Simulation> {
    run_any(&db, &s, &["loans.view", "loans.manage"], |c, _| loan_service::simulation(c, &input))
}

#[tauri::command(async)]
pub fn loans_list(db: Db, s: Sess, query: PageQuery) -> AppResult<Page<LoanRow>> {
    run(&db, &s, "loans.view", |c, _| {
        let today = settings_repo::today(c).to_string();
        loan_repo::list_loans(c, &query, &today)
    })
}

#[tauri::command(async)]
pub fn loan_get(db: Db, s: Sess, id: i64) -> AppResult<LoanDetail> {
    run(&db, &s, "loans.view", |c, _| loan_service::detail(c, id))
}

#[tauri::command(async)]
pub fn application_create(db: Db, s: Sess, input: ApplicationInput) -> AppResult<i64> {
    run(&db, &s, "loans.manage", |c, u| loan_service::create_application(c, u, input))
}

#[tauri::command(async)]
pub fn application_update(db: Db, s: Sess, id: i64, input: ApplicationInput) -> AppResult<()> {
    run(&db, &s, "loans.manage", |c, u| loan_service::update_application(c, u, id, input))
}

#[tauri::command(async)]
pub fn application_get(db: Db, s: Sess, id: i64) -> AppResult<ApplicationRow> {
    run(&db, &s, "loans.view", |c, _| loan_service::get_application(c, id))
}

#[tauri::command(async)]
pub fn applications_list(db: Db, s: Sess, status: Option<String>) -> AppResult<Vec<ApplicationRow>> {
    run(&db, &s, "loans.view", |c, _| loan_service::list_applications(c, status.as_deref()))
}

#[tauri::command(async)]
pub fn application_analyze(db: Db, s: Sess, id: i64, notes: Option<String>) -> AppResult<serde_json::Value> {
    run(&db, &s, "loans.manage", |c, u| loan_service::analyze(c, u, id, notes))
}

#[tauri::command(async)]
pub fn application_decide(db: Db, s: Sess, id: i64, approve: bool, notes: String) -> AppResult<()> {
    run(&db, &s, "loans.approve", |c, u| loan_service::decide(c, u, id, approve, &notes))
}

#[tauri::command(async)]
pub fn application_cancel(db: Db, s: Sess, id: i64) -> AppResult<()> {
    run(&db, &s, "loans.manage", |c, u| loan_service::cancel_application(c, u, id))
}

#[tauri::command(async)]
pub fn loan_contract(db: Db, s: Sess, application_id: i64) -> AppResult<i64> {
    run(&db, &s, "loans.disburse", |c, u| loan_service::contract(c, u, application_id))
}

#[tauri::command(async)]
pub fn loan_disburse(db: Db, s: Sess, loan_id: i64, method: String) -> AppResult<()> {
    run(&db, &s, "loans.disburse", |c, u| loan_service::disburse(c, u, loan_id, &method))
}

#[tauri::command(async)]
pub fn loan_renegotiate(db: Db, s: Sess, input: RenegotiationInput) -> AppResult<i64> {
    run(&db, &s, "loans.manage", |c, u| loan_service::renegotiate(c, u, input))
}

// ----------------------------------------------------------------- garantias

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CollateralDetail {
    pub asset: CollateralRow,
    pub events: Vec<EventRow>,
    pub photos: Vec<Attachment>,
    pub terms: Vec<Attachment>,
}

#[tauri::command(async)]
pub fn collateral_list(db: Db, s: Sess, query: PageQuery) -> AppResult<Page<CollateralRow>> {
    run(&db, &s, "collateral.view", |c, _| collateral_service::list(c, &query))
}

#[tauri::command(async)]
pub fn collateral_stats(db: Db, s: Sess) -> AppResult<CollateralStats> {
    run(&db, &s, "collateral.view", |c, _| collateral_service::stats(c))
}

#[tauri::command(async)]
pub fn collateral_get(db: Db, s: Sess, id: i64) -> AppResult<CollateralDetail> {
    run(&db, &s, "collateral.view", |c, _| {
        let mut terms = attachment_service::list(c, "collateral", id, Some("receipt_term"))?;
        terms.extend(attachment_service::list(c, "collateral", id, Some("return_term"))?);
        Ok(CollateralDetail {
            asset: collateral_service::get(c, id)?,
            events: collateral_service::events(c, id)?,
            photos: attachment_service::list(c, "collateral", id, Some("photo"))?,
            terms,
        })
    })
}

#[tauri::command(async)]
pub fn collateral_create(db: Db, s: Sess, vault: Vlt, input: CollateralInput) -> AppResult<i64> {
    run(&db, &s, "collateral.manage", |c, u| collateral_service::create(c, &vault, u, input))
}

#[tauri::command(async)]
pub fn collateral_valuate(db: Db, s: Sess, id: i64, value_cents: i64, notes: Option<String>) -> AppResult<()> {
    run(&db, &s, "collateral.manage", |c, u| collateral_service::valuate(c, u, id, value_cents, notes))
}

#[tauri::command(async)]
pub fn collateral_approve(db: Db, s: Sess, id: i64, approve: bool, notes: Option<String>) -> AppResult<()> {
    run(&db, &s, "loans.approve", |c, u| collateral_service::approve(c, u, id, approve, notes))
}

#[tauri::command(async)]
pub fn collateral_receive(db: Db, s: Sess, vault: Vlt, id: i64, location: String, days: i64) -> AppResult<()> {
    run(&db, &s, "collateral.manage", |c, u| collateral_service::receive_custody(c, &vault, u, id, &location, days))
}

#[tauri::command(async)]
pub fn collateral_extend(db: Db, s: Sess, id: i64, extra_days: i64, reason: String) -> AppResult<()> {
    run(&db, &s, "collateral.manage", |c, u| collateral_service::extend(c, u, id, extra_days, &reason))
}

#[tauri::command(async)]
pub fn collateral_release(db: Db, s: Sess, vault: Vlt, id: i64, kind: String, note: String) -> AppResult<()> {
    run(&db, &s, "collateral.manage", |c, u| collateral_service::release(c, &vault, u, id, &kind, &note))
}

#[tauri::command(async)]
pub fn collateral_legal(db: Db, s: Sess, id: i64, reference: String) -> AppResult<()> {
    run(&db, &s, "loans.approve", |c, u| collateral_service::mark_legal_procedure(c, u, id, &reference))
}

// ----------------------------------------------------------------- contratos

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ContractDetail {
    pub contract: ContractRow,
    pub versions: Vec<VersionRow>,
    pub documents: Vec<Attachment>,
}

#[tauri::command(async)]
pub fn contracts_list(db: Db, s: Sess, query: PageQuery) -> AppResult<Page<ContractRow>> {
    run(&db, &s, "contracts.view", |c, _| contract_service::list(c, &query))
}

#[tauri::command(async)]
pub fn contract_get(db: Db, s: Sess, id: i64) -> AppResult<ContractDetail> {
    run(&db, &s, "contracts.view", |c, _| {
        let contract = contract_service::get(c, id)?;
        // histórico de documentos: versões do contrato + comprovantes de pagamento do empréstimo
        let mut documents = vec![];
        for v in contract_service::versions(c, id)? {
            documents.push(attachment_service::get(c, v.attachment_id)?);
        }
        if contract.kind == "loan" {
            let mut stmt = c.prepare("SELECT a.id FROM attachments a JOIN payments p ON p.id = a.owner_id WHERE a.owner_type='payment' AND a.kind='receipt' AND p.origin_type='loan' AND p.origin_id = ?1 ORDER BY a.id")?;
            let ids: Vec<i64> = stmt.query_map([contract.ref_id], |r| r.get(0))?.collect::<Result<_, _>>()?;
            for id in ids {
                documents.push(attachment_service::get(c, id)?);
            }
        }
        Ok(ContractDetail { versions: contract_service::versions(c, id)?, contract, documents })
    })
}

#[tauri::command(async)]
pub fn contract_generate(db: Db, s: Sess, vault: Vlt, kind: String, ref_id: i64, reason: Option<String>) -> AppResult<i64> {
    run(&db, &s, "contracts.manage", |c, u| contract_service::generate(c, &vault, u, &kind, ref_id, reason))
}

#[tauri::command(async)]
pub fn contract_sign(db: Db, s: Sess, id: i64, signer: String, note: Option<String>) -> AppResult<()> {
    run(&db, &s, "contracts.manage", |c, u| contract_service::sign(c, u, id, &signer, note))
}

#[tauri::command(async)]
pub fn contract_cancel(db: Db, s: Sess, id: i64, reason: String) -> AppResult<()> {
    run(&db, &s, "contracts.manage", |c, u| contract_service::cancel(c, u, id, &reason))
}

#[tauri::command(async)]
pub fn contract_for_ref(db: Db, s: Sess, kind: String, ref_id: i64) -> AppResult<Option<ContractRow>> {
    run(&db, &s, "contracts.view", |c, _| {
        let id: Option<i64> = c
            .query_row("SELECT id FROM contracts WHERE ref_type = ?1 AND ref_id = ?2 AND status <> 'cancelled' ORDER BY id DESC LIMIT 1", (&kind, ref_id), |r| r.get(0))
            .ok();
        id.map(|i| contract_service::get(c, i)).transpose()
    })
}

#[tauri::command(async)]
pub fn contract_templates(db: Db, s: Sess) -> AppResult<Vec<TemplateRow>> {
    run_any(&db, &s, &["contracts.manage", "settings.view"], |c, _| contract_service::templates(c))
}

#[tauri::command(async)]
pub fn contract_template_save(db: Db, s: Sess, input: TemplateInput) -> AppResult<i64> {
    run(&db, &s, "contracts.manage", |c, u| contract_service::save_template(c, u, input))
}

#[tauri::command(async)]
pub fn contract_template_approve(db: Db, s: Sess, id: i64, approver: String) -> AppResult<()> {
    run(&db, &s, "contracts.legal", |c, u| contract_service::approve_template(c, u, id, &approver))
}

#[tauri::command(async)]
pub fn contract_variables(s: Sess, kind: String) -> AppResult<Vec<VariableInfo>> {
    s.require("contracts.manage")?;
    Ok(contract_service::variables_for(&kind))
}

#[tauri::command(async)]
pub fn contract_template_versions(db: Db, s: Sess, id: i64) -> AppResult<Vec<TemplateVersion>> {
    run(&db, &s, "contracts.manage", |c, _| contract_service::template_versions(c, id))
}

/// PDF de pré-visualização (base64) com dados fictícios; nada é gravado.
#[tauri::command(async)]
pub fn contract_template_preview(db: Db, s: Sess, kind: String, body: String) -> AppResult<String> {
    use base64::Engine;
    run(&db, &s, "contracts.manage", |c, _| {
        Ok(base64::engine::general_purpose::STANDARD.encode(contract_service::preview_pdf(c, &kind, &body)?))
    })
}

#[tauri::command(async)]
pub fn template_images_list(db: Db, s: Sess) -> AppResult<Vec<contract_service::TemplateImage>> {
    run(&db, &s, "contracts.manage", |c, _| contract_service::list_images(c))
}

#[tauri::command(async)]
pub fn template_image_add(db: Db, s: Sess, name: String, data_base64: String) -> AppResult<i64> {
    use base64::Engine;
    let data = base64::engine::general_purpose::STANDARD
        .decode(data_base64.as_bytes())
        .map_err(|_| crate::error::AppError::Validation("Imagem inválida.".into()))?;
    run(&db, &s, "contracts.manage", |c, u| contract_service::add_image(c, u, &name, data))
}

#[tauri::command(async)]
pub fn template_image_delete(db: Db, s: Sess, id: i64) -> AppResult<()> {
    run(&db, &s, "contracts.manage", |c, u| contract_service::delete_image(c, u, id))
}

// ==== BEGIN GENERATED WEB DISPATCH (scripts/gen_web_dispatch.py) ====
#[allow(unused_variables, clippy::redundant_closure_call)]
pub fn web_dispatch(cmd: &str, ctx: &Ctx, args: serde_json::Value) -> Option<AppResult<serde_json::Value>> {
    match cmd {
        "loan_simulate" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: SimulationInput,
            }
            let a: A = parse_args(args)?;
            to_json(loan_simulate(Db(ctx.db), Sess(ctx.session), a.input)?)
        })()),
        "loans_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                query: PageQuery,
            }
            let a: A = parse_args(args)?;
            to_json(loans_list(Db(ctx.db), Sess(ctx.session), a.query)?)
        })()),
        "loan_get" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(loan_get(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "application_create" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: ApplicationInput,
            }
            let a: A = parse_args(args)?;
            to_json(application_create(Db(ctx.db), Sess(ctx.session), a.input)?)
        })()),
        "application_update" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                input: ApplicationInput,
            }
            let a: A = parse_args(args)?;
            to_json(application_update(Db(ctx.db), Sess(ctx.session), a.id, a.input)?)
        })()),
        "application_get" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(application_get(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "applications_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                status: Option<String>,
            }
            let a: A = parse_args(args)?;
            to_json(applications_list(Db(ctx.db), Sess(ctx.session), a.status)?)
        })()),
        "application_analyze" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                notes: Option<String>,
            }
            let a: A = parse_args(args)?;
            to_json(application_analyze(Db(ctx.db), Sess(ctx.session), a.id, a.notes)?)
        })()),
        "application_decide" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                approve: bool,
                notes: String,
            }
            let a: A = parse_args(args)?;
            to_json(application_decide(Db(ctx.db), Sess(ctx.session), a.id, a.approve, a.notes)?)
        })()),
        "application_cancel" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(application_cancel(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "loan_contract" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                application_id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(loan_contract(Db(ctx.db), Sess(ctx.session), a.application_id)?)
        })()),
        "loan_disburse" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                loan_id: i64,
                method: String,
            }
            let a: A = parse_args(args)?;
            to_json(loan_disburse(Db(ctx.db), Sess(ctx.session), a.loan_id, a.method)?)
        })()),
        "loan_renegotiate" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: RenegotiationInput,
            }
            let a: A = parse_args(args)?;
            to_json(loan_renegotiate(Db(ctx.db), Sess(ctx.session), a.input)?)
        })()),
        "collateral_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                query: PageQuery,
            }
            let a: A = parse_args(args)?;
            to_json(collateral_list(Db(ctx.db), Sess(ctx.session), a.query)?)
        })()),
        "collateral_stats" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(collateral_stats(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "collateral_get" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(collateral_get(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "collateral_create" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: CollateralInput,
            }
            let a: A = parse_args(args)?;
            to_json(collateral_create(Db(ctx.db), Sess(ctx.session), Vlt(ctx.vault), a.input)?)
        })()),
        "collateral_valuate" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                value_cents: i64,
                notes: Option<String>,
            }
            let a: A = parse_args(args)?;
            to_json(collateral_valuate(Db(ctx.db), Sess(ctx.session), a.id, a.value_cents, a.notes)?)
        })()),
        "collateral_approve" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                approve: bool,
                notes: Option<String>,
            }
            let a: A = parse_args(args)?;
            to_json(collateral_approve(Db(ctx.db), Sess(ctx.session), a.id, a.approve, a.notes)?)
        })()),
        "collateral_receive" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                location: String,
                days: i64,
            }
            let a: A = parse_args(args)?;
            to_json(collateral_receive(Db(ctx.db), Sess(ctx.session), Vlt(ctx.vault), a.id, a.location, a.days)?)
        })()),
        "collateral_extend" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                extra_days: i64,
                reason: String,
            }
            let a: A = parse_args(args)?;
            to_json(collateral_extend(Db(ctx.db), Sess(ctx.session), a.id, a.extra_days, a.reason)?)
        })()),
        "collateral_release" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                kind: String,
                note: String,
            }
            let a: A = parse_args(args)?;
            to_json(collateral_release(Db(ctx.db), Sess(ctx.session), Vlt(ctx.vault), a.id, a.kind, a.note)?)
        })()),
        "collateral_legal" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                reference: String,
            }
            let a: A = parse_args(args)?;
            to_json(collateral_legal(Db(ctx.db), Sess(ctx.session), a.id, a.reference)?)
        })()),
        "contracts_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                query: PageQuery,
            }
            let a: A = parse_args(args)?;
            to_json(contracts_list(Db(ctx.db), Sess(ctx.session), a.query)?)
        })()),
        "contract_get" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(contract_get(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "contract_generate" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                kind: String,
                ref_id: i64,
                reason: Option<String>,
            }
            let a: A = parse_args(args)?;
            to_json(contract_generate(Db(ctx.db), Sess(ctx.session), Vlt(ctx.vault), a.kind, a.ref_id, a.reason)?)
        })()),
        "contract_sign" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                signer: String,
                note: Option<String>,
            }
            let a: A = parse_args(args)?;
            to_json(contract_sign(Db(ctx.db), Sess(ctx.session), a.id, a.signer, a.note)?)
        })()),
        "contract_cancel" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                reason: String,
            }
            let a: A = parse_args(args)?;
            to_json(contract_cancel(Db(ctx.db), Sess(ctx.session), a.id, a.reason)?)
        })()),
        "contract_for_ref" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                kind: String,
                ref_id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(contract_for_ref(Db(ctx.db), Sess(ctx.session), a.kind, a.ref_id)?)
        })()),
        "contract_templates" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(contract_templates(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "contract_template_save" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: TemplateInput,
            }
            let a: A = parse_args(args)?;
            to_json(contract_template_save(Db(ctx.db), Sess(ctx.session), a.input)?)
        })()),
        "contract_template_approve" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                approver: String,
            }
            let a: A = parse_args(args)?;
            to_json(contract_template_approve(Db(ctx.db), Sess(ctx.session), a.id, a.approver)?)
        })()),
        "contract_variables" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                kind: String,
            }
            let a: A = parse_args(args)?;
            to_json(contract_variables(Sess(ctx.session), a.kind)?)
        })()),
        "contract_template_versions" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(contract_template_versions(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "contract_template_preview" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                kind: String,
                body: String,
            }
            let a: A = parse_args(args)?;
            to_json(contract_template_preview(Db(ctx.db), Sess(ctx.session), a.kind, a.body)?)
        })()),
        "template_images_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(template_images_list(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "template_image_add" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                name: String,
                data_base64: String,
            }
            let a: A = parse_args(args)?;
            to_json(template_image_add(Db(ctx.db), Sess(ctx.session), a.name, a.data_base64)?)
        })()),
        "template_image_delete" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(template_image_delete(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        _ => None,
    }
}
// ==== END GENERATED WEB DISPATCH ====
