//! Tipos de contexto dos comandos. Dentro do Tauri vêm do estado gerenciado; no modo web são
//! montados pelo servidor HTTP (com a sessão do navegador), e o mesmo código de comando atende aos dois.
use std::ops::Deref;

use tauri::ipc::{CommandArg, CommandItem, InvokeError};
use tauri::{Runtime, State};

use super::system::AppPaths;
use crate::database::Database;
use crate::security::session::SessionState;
use crate::security::vault::Vault;

macro_rules! ctx_type {
    ($name:ident, $inner:ty) => {
        pub struct $name<'a>(pub &'a $inner);

        impl Deref for $name<'_> {
            type Target = $inner;
            fn deref(&self) -> &$inner {
                self.0
            }
        }

        impl<'de, R: Runtime> CommandArg<'de, R> for $name<'de> {
            fn from_command(command: CommandItem<'de, R>) -> Result<Self, InvokeError> {
                State::<'de, $inner>::from_command(command).map(|s| $name(s.inner()))
            }
        }
    };
}

ctx_type!(Db, Database);
ctx_type!(Sess, SessionState);
ctx_type!(Vlt, Vault);
ctx_type!(Paths, AppPaths);

/// Dependências de uma requisição web: banco/cofre compartilhados e a sessão do navegador que chamou.
pub struct Ctx<'a> {
    pub db: &'a Database,
    pub vault: &'a Vault,
    pub session: &'a SessionState,
    #[allow(dead_code)]
    pub paths: &'a AppPaths,
}

/// Desserializa os argumentos JSON de uma chamada web (objeto vazio quando ausente).
pub fn parse_args<T: serde::de::DeserializeOwned>(args: serde_json::Value) -> crate::error::AppResult<T> {
    let args = if args.is_null() { serde_json::Value::Object(Default::default()) } else { args };
    serde_json::from_value(args)
        .map_err(|e| crate::error::AppError::Validation(format!("Parâmetros inválidos: {e}")))
}

pub fn to_json<T: serde::Serialize>(v: T) -> crate::error::AppResult<serde_json::Value> {
    serde_json::to_value(v).map_err(|e| crate::error::AppError::Internal(e.to_string()))
}
