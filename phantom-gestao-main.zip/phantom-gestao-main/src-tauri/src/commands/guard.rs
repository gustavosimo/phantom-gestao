use rusqlite::Connection;

use crate::database::Database;
use crate::domain::user::User;
use crate::error::AppResult;
use crate::security::session::SessionState;

/// Executa `f` apenas se houver sessão com a permissão informada. Todo comando de negócio passa por aqui.
pub fn run<T>(
    db: &Database,
    session: &SessionState,
    permission: &str,
    f: impl FnOnce(&mut Connection, &User) -> AppResult<T>,
) -> AppResult<T> {
    let user = session.require(permission)?;
    let mut conn = db.conn()?;
    f(&mut conn, &user)
}

/// Variante para qualquer usuário autenticado (sem permissão específica).
pub fn run_authenticated<T>(
    db: &Database,
    session: &SessionState,
    f: impl FnOnce(&mut Connection, &User) -> AppResult<T>,
) -> AppResult<T> {
    let user = session.user()?;
    let mut conn = db.conn()?;
    f(&mut conn, &user)
}

/// Exige que o usuário possua ao menos uma das permissões.
pub fn run_any<T>(
    db: &Database,
    session: &SessionState,
    permissions: &[&str],
    f: impl FnOnce(&mut Connection, &User) -> AppResult<T>,
) -> AppResult<T> {
    let user = session.user()?;
    if !permissions.iter().any(|p| user.permissions.iter().any(|u| u == p)) {
        return Err(crate::error::AppError::Forbidden);
    }
    let mut conn = db.conn()?;
    f(&mut conn, &user)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::error::AppError;
    use crate::testutil::env;

    #[test]
    fn commands_require_session_and_permission() {
        let e = env();
        let s = SessionState::default();
        assert!(matches!(run(&e.db, &s, "clients.view", |_, _| Ok(1)), Err(AppError::Unauthenticated)));
        assert!(matches!(run_authenticated(&e.db, &s, |_, _| Ok(1)), Err(AppError::Unauthenticated)));

        let mut viewer = e.admin.clone();
        viewer.permissions = vec!["dashboard.view".into()];
        s.set(viewer);
        assert!(run(&e.db, &s, "dashboard.view", |_, _| Ok(1)).is_ok());
        assert!(matches!(run(&e.db, &s, "regulatory.manage", |_, _| Ok(1)), Err(AppError::Forbidden)));
        assert!(matches!(run(&e.db, &s, "users.manage", |_, _| Ok(1)), Err(AppError::Forbidden)));
        assert!(matches!(run_any(&e.db, &s, &["loans.disburse", "loans.approve"], |_, _| Ok(1)), Err(AppError::Forbidden)));
        assert!(run_any(&e.db, &s, &["loans.approve", "dashboard.view"], |_, _| Ok(1)).is_ok());
        s.clear();
        assert!(matches!(run(&e.db, &s, "dashboard.view", |_, _| Ok(1)), Err(AppError::Unauthenticated)));
    }

    #[test]
    fn seeded_roles_enforce_least_privilege() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let load = |c: &rusqlite::Connection, role: &str| -> Vec<String> {
            let mut st = c.prepare("SELECT p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id JOIN roles r ON r.id = rp.role_id WHERE r.code = ?1").unwrap();
            st.query_map([role], |r| r.get(0)).unwrap().map(|r| r.unwrap()).collect()
        };
        let op = load(&conn, "operator");
        for forbidden in ["loans.disburse", "loans.approve", "regulatory.manage", "users.manage", "backup.manage", "settings.manage", "payments.reverse", "clients.sensitive", "contracts.legal"] {
            assert!(!op.iter().any(|p| p == forbidden), "operator não deve ter {forbidden}");
        }
        let viewer = load(&conn, "viewer");
        assert!(viewer.iter().all(|p| p.ends_with(".view")), "consulta só pode ter permissões de leitura: {viewer:?}");
        let mgr = load(&conn, "manager");
        assert!(!mgr.iter().any(|p| p == "regulatory.manage" || p == "users.manage" || p == "contracts.legal"));
        // nenhum perfil exceto administrador habilita operações reguladas
        let _ = &mut conn;
    }
}
