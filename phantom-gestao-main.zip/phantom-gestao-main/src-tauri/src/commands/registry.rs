use base64::Engine;
use serde::Serialize;

use super::guard::*;
use crate::error::{AppError, AppResult};
use crate::repositories::client_repo::{self, ClientInput};
use crate::repositories::product_repo::{self, ProductInput};
use crate::repositories::{audit_repo, settings_repo, Page, PageQuery};
use crate::services::{attachment_service, client_service, dashboard_service, product_service};

use super::ctx::{parse_args, to_json, Ctx, Db, Sess, Vlt};

// ----------------------------------------------------------------- dashboard

#[tauri::command(async)]
pub fn dashboard_load(db: Db, s: Sess, period: dashboard_service::Period) -> AppResult<dashboard_service::Dashboard> {
    run(&db, &s, "dashboard.view", |c, _| dashboard_service::load(c, &period))
}

// ------------------------------------------------------------------ clientes

#[tauri::command(async)]
pub fn clients_list(db: Db, s: Sess, query: PageQuery) -> AppResult<Page<client_repo::ClientRow>> {
    run(&db, &s, "clients.view", |c, _| {
        let today = settings_repo::today(c).to_string();
        let mut page = client_repo::list(c, &query, &today)?;
        // listagens sempre exibem o documento mascarado (LGPD); o detalhe respeita clients.sensitive
        for r in page.items.iter_mut() {
            r.document = crate::domain::validation::mask_document(&r.document);
        }
        Ok(page)
    })
}

#[tauri::command(async)]
pub fn client_options(db: Db, s: Sess, search: Option<String>) -> AppResult<Vec<client_repo::ClientOption>> {
    run_any(&db, &s, &["clients.view", "sales.manage", "loans.manage", "collateral.manage"], |c, _| {
        let mut v = client_repo::options(c, &search)?;
        for o in v.iter_mut() {
            o.document = crate::domain::validation::mask_document(&o.document);
        }
        Ok(v)
    })
}

#[tauri::command(async)]
pub fn client_get(db: Db, s: Sess, id: i64) -> AppResult<client_repo::ClientDetail> {
    run(&db, &s, "clients.view", |c, u| client_service::detail(c, u, id))
}

#[tauri::command(async)]
pub fn client_create(db: Db, s: Sess, input: ClientInput) -> AppResult<i64> {
    run(&db, &s, "clients.manage", |c, u| client_service::create(c, u, input))
}

#[tauri::command(async)]
pub fn client_update(db: Db, s: Sess, id: i64, input: ClientInput) -> AppResult<()> {
    run(&db, &s, "clients.manage", |c, u| client_service::update(c, u, id, input))
}

#[tauri::command(async)]
pub fn client_set_status(db: Db, s: Sess, id: i64, status: String) -> AppResult<()> {
    run(&db, &s, "clients.manage", |c, u| client_service::set_status(c, u, id, &status))
}

#[tauri::command(async)]
pub fn client_summary(db: Db, s: Sess, id: i64) -> AppResult<client_repo::ClientSummary> {
    run(&db, &s, "clients.view", |c, _| client_repo::summary(c, id))
}

#[tauri::command(async)]
pub fn client_history(db: Db, s: Sess, id: i64, kind: Option<String>) -> AppResult<Vec<client_repo::HistoryRow>> {
    run(&db, &s, "clients.view", |c, _| client_repo::history(c, id, kind.as_deref(), 100))
}

#[tauri::command(async)]
pub fn client_documents(db: Db, s: Sess, id: i64) -> AppResult<Vec<client_repo::ClientDocRow>> {
    run(&db, &s, "clients.sensitive", |c, _| client_repo::documents(c, id))
}

#[tauri::command(async)]
#[allow(clippy::too_many_arguments)]
pub fn client_add_document(db: Db, s: Sess, vault: Vlt, client_id: i64, doc_type: String, number: Option<String>, file_path: Option<String>, expires_at: Option<String>) -> AppResult<i64> {
    run(&db, &s, "clients.manage", |c, u| client_service::add_document(c, &vault, u, client_id, &doc_type, number, file_path, expires_at))
}

// ------------------------------------------------------------------- anexos

fn owner_permission(owner: &str) -> AppResult<&'static str> {
    Ok(match owner {
        "client" => "clients.sensitive",
        "product" => "products.view",
        "collateral" => "collateral.view",
        "purchase" => "purchases.view",
        "sale" => "sales.view",
        "payment" => "payments.view",
        "contract" => "contracts.view",
        "report" => "reports.view",
        _ => return Err(AppError::Forbidden),
    })
}

fn manage_permission(owner: &str) -> AppResult<&'static str> {
    Ok(match owner {
        "client" => "clients.manage",
        "product" => "products.manage",
        "collateral" => "collateral.manage",
        "purchase" => "purchases.manage",
        _ => return Err(AppError::Forbidden),
    })
}

#[tauri::command(async)]
pub fn attachment_list(db: Db, s: Sess, owner_type: String, owner_id: i64, kind: Option<String>) -> AppResult<Vec<attachment_service::Attachment>> {
    run(&db, &s, owner_permission(&owner_type)?, |c, _| attachment_service::list(c, &owner_type, owner_id, kind.as_deref()))
}

#[tauri::command(async)]
pub fn attachment_add(db: Db, s: Sess, vault: Vlt, owner_type: String, owner_id: i64, kind: String, path: String) -> AppResult<attachment_service::Attachment> {
    run(&db, &s, manage_permission(&owner_type)?, |c, u| {
        let a = attachment_service::add_from_path(c, &vault, u, &owner_type, owner_id, &kind, &path)?;
        audit_repo::log(c, u, "attachment.add", &owner_type, owner_id, &a.original_name)?;
        Ok(a)
    })
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AttachmentData {
    pub meta: attachment_service::Attachment,
    pub data_base64: String,
}

fn owner_of(conn: &rusqlite::Connection, id: i64) -> AppResult<String> {
    Ok(attachment_service::get(conn, id)?.owner_type)
}

#[tauri::command(async)]
pub fn attachment_read(db: Db, s: Sess, vault: Vlt, id: i64) -> AppResult<AttachmentData> {
    let owner = {
        let conn = db.conn()?;
        owner_of(&conn, id)?
    };
    run(&db, &s, owner_permission(&owner)?, |c, u| {
        let (meta, bytes) = attachment_service::read(c, &vault, id)?;
        if meta.owner_type == "client" {
            audit_repo::log(c, u, "attachment.view_sensitive", "attachments", id, &meta.original_name)?;
        }
        Ok(AttachmentData { meta, data_base64: base64::engine::general_purpose::STANDARD.encode(bytes) })
    })
}

/// Grava uma cópia decifrada em um caminho escolhido pelo usuário (diálogo "Salvar como").
#[tauri::command(async)]
pub fn attachment_save_to(db: Db, s: Sess, vault: Vlt, id: i64, path: String) -> AppResult<()> {
    let owner = {
        let conn = db.conn()?;
        owner_of(&conn, id)?
    };
    run(&db, &s, owner_permission(&owner)?, |c, u| {
        crate::security::fs_scope::deny_write()?;
        let (meta, bytes) = attachment_service::read(c, &vault, id)?;
        std::fs::write(&path, bytes).map_err(|e| AppError::Validation(format!("Não foi possível salvar o arquivo: {e}")))?;
        audit_repo::log(c, u, "attachment.export", "attachments", id, &meta.original_name)?;
        Ok(())
    })
}

// ------------------------------------------------------------------ produtos

#[tauri::command(async)]
pub fn products_list(db: Db, s: Sess, query: PageQuery) -> AppResult<Page<product_repo::ProductRow>> {
    run_any(&db, &s, &["products.view", "sales.manage", "purchases.manage"], |c, _| product_repo::list(c, &query))
}

#[tauri::command(async)]
pub fn product_get(db: Db, s: Sess, id: i64) -> AppResult<product_repo::ProductRow> {
    run(&db, &s, "products.view", |c, _| product_repo::get(c, id))
}

#[tauri::command(async)]
pub fn product_categories(db: Db, s: Sess) -> AppResult<Vec<String>> {
    run_authenticated(&db, &s, |c, _| product_repo::categories(c))
}

#[tauri::command(async)]
pub fn product_create(db: Db, s: Sess, input: ProductInput) -> AppResult<i64> {
    run(&db, &s, "products.manage", |c, u| product_service::create(c, u, input))
}

#[tauri::command(async)]
pub fn product_update(db: Db, s: Sess, id: i64, input: ProductInput) -> AppResult<()> {
    run(&db, &s, "products.manage", |c, u| product_service::update(c, u, id, input))
}

#[tauri::command(async)]
pub fn product_adjust_stock(db: Db, s: Sess, id: i64, delta: i64, reason: String) -> AppResult<()> {
    run(&db, &s, "products.manage", |c, u| product_service::adjust_stock(c, u, id, delta, &reason))
}

#[tauri::command(async)]
pub fn product_inventory_count(db: Db, s: Sess, id: i64, counted: i64, note: String) -> AppResult<i64> {
    run(&db, &s, "products.manage", |c, u| product_service::count_inventory(c, u, id, counted, &note))
}

#[tauri::command(async)]
pub fn product_reserve(db: Db, s: Sess, id: i64, delta: i64) -> AppResult<()> {
    run(&db, &s, "products.manage", |c, u| product_service::reserve(c, u, id, delta))
}

#[tauri::command(async)]
pub fn product_movements(db: Db, s: Sess, id: i64) -> AppResult<Vec<product_repo::MovementRow>> {
    run(&db, &s, "products.view", |c, _| product_repo::movements(c, id))
}

#[tauri::command(async)]
pub fn product_costs(db: Db, s: Sess, id: i64) -> AppResult<Vec<product_repo::CostRow>> {
    run(&db, &s, "products.view", |c, _| product_repo::cost_history(c, id))
}

/// Pré-visualização (base64) de uma imagem escolhida no seletor, antes de anexá-la. Só lê imagens de até 10 MB.
#[tauri::command(async)]
pub fn local_image_preview(s: Sess, path: String) -> AppResult<String> {
    s.user()?;
    let p = std::path::Path::new(&path);
    crate::security::fs_scope::check_read(p)?;
    let ext = p.extension().and_then(|e| e.to_str()).unwrap_or("").to_lowercase();
    if !["png", "jpg", "jpeg", "webp", "gif", "bmp"].contains(&ext.as_str()) {
        return Err(crate::error::AppError::Validation("Arquivo não é uma imagem suportada.".into()));
    }
    let meta = std::fs::metadata(p).map_err(|e| crate::error::AppError::Validation(format!("Não foi possível ler o arquivo: {e}")))?;
    if meta.len() > 10 * 1024 * 1024 {
        return Err(crate::error::AppError::Validation("Imagem maior que 10 MB.".into()));
    }
    let bytes = std::fs::read(p).map_err(|e| crate::error::AppError::Validation(format!("Não foi possível ler o arquivo: {e}")))?;
    let mime = if ext == "jpg" || ext == "jpeg" { "jpeg" } else { ext.as_str() };
    Ok(format!("data:image/{mime};base64,{}", base64::engine::general_purpose::STANDARD.encode(bytes)))
}

// ==== BEGIN GENERATED WEB DISPATCH (scripts/gen_web_dispatch.py) ====
#[allow(unused_variables, clippy::redundant_closure_call)]
pub fn web_dispatch(cmd: &str, ctx: &Ctx, args: serde_json::Value) -> Option<AppResult<serde_json::Value>> {
    match cmd {
        "dashboard_load" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                period: dashboard_service::Period,
            }
            let a: A = parse_args(args)?;
            to_json(dashboard_load(Db(ctx.db), Sess(ctx.session), a.period)?)
        })()),
        "clients_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                query: PageQuery,
            }
            let a: A = parse_args(args)?;
            to_json(clients_list(Db(ctx.db), Sess(ctx.session), a.query)?)
        })()),
        "client_options" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                search: Option<String>,
            }
            let a: A = parse_args(args)?;
            to_json(client_options(Db(ctx.db), Sess(ctx.session), a.search)?)
        })()),
        "client_get" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(client_get(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "client_create" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: ClientInput,
            }
            let a: A = parse_args(args)?;
            to_json(client_create(Db(ctx.db), Sess(ctx.session), a.input)?)
        })()),
        "client_update" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                input: ClientInput,
            }
            let a: A = parse_args(args)?;
            to_json(client_update(Db(ctx.db), Sess(ctx.session), a.id, a.input)?)
        })()),
        "client_set_status" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                status: String,
            }
            let a: A = parse_args(args)?;
            to_json(client_set_status(Db(ctx.db), Sess(ctx.session), a.id, a.status)?)
        })()),
        "client_summary" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(client_summary(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "client_history" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                kind: Option<String>,
            }
            let a: A = parse_args(args)?;
            to_json(client_history(Db(ctx.db), Sess(ctx.session), a.id, a.kind)?)
        })()),
        "client_documents" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(client_documents(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "client_add_document" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                client_id: i64,
                doc_type: String,
                number: Option<String>,
                file_path: Option<String>,
                expires_at: Option<String>,
            }
            let a: A = parse_args(args)?;
            to_json(client_add_document(Db(ctx.db), Sess(ctx.session), Vlt(ctx.vault), a.client_id, a.doc_type, a.number, a.file_path, a.expires_at)?)
        })()),
        "attachment_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                owner_type: String,
                owner_id: i64,
                kind: Option<String>,
            }
            let a: A = parse_args(args)?;
            to_json(attachment_list(Db(ctx.db), Sess(ctx.session), a.owner_type, a.owner_id, a.kind)?)
        })()),
        "attachment_add" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                owner_type: String,
                owner_id: i64,
                kind: String,
                path: String,
            }
            let a: A = parse_args(args)?;
            to_json(attachment_add(Db(ctx.db), Sess(ctx.session), Vlt(ctx.vault), a.owner_type, a.owner_id, a.kind, a.path)?)
        })()),
        "attachment_read" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(attachment_read(Db(ctx.db), Sess(ctx.session), Vlt(ctx.vault), a.id)?)
        })()),
        "attachment_save_to" => Some(Err(crate::error::AppError::Validation("Recurso disponível apenas no aplicativo desktop.".into()))),
        "products_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                query: PageQuery,
            }
            let a: A = parse_args(args)?;
            to_json(products_list(Db(ctx.db), Sess(ctx.session), a.query)?)
        })()),
        "product_get" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(product_get(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "product_categories" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(product_categories(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "product_create" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: ProductInput,
            }
            let a: A = parse_args(args)?;
            to_json(product_create(Db(ctx.db), Sess(ctx.session), a.input)?)
        })()),
        "product_update" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                input: ProductInput,
            }
            let a: A = parse_args(args)?;
            to_json(product_update(Db(ctx.db), Sess(ctx.session), a.id, a.input)?)
        })()),
        "product_adjust_stock" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                delta: i64,
                reason: String,
            }
            let a: A = parse_args(args)?;
            to_json(product_adjust_stock(Db(ctx.db), Sess(ctx.session), a.id, a.delta, a.reason)?)
        })()),
        "product_inventory_count" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                counted: i64,
                note: String,
            }
            let a: A = parse_args(args)?;
            to_json(product_inventory_count(Db(ctx.db), Sess(ctx.session), a.id, a.counted, a.note)?)
        })()),
        "product_reserve" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                delta: i64,
            }
            let a: A = parse_args(args)?;
            to_json(product_reserve(Db(ctx.db), Sess(ctx.session), a.id, a.delta)?)
        })()),
        "product_movements" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(product_movements(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "product_costs" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(product_costs(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "local_image_preview" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                path: String,
            }
            let a: A = parse_args(args)?;
            to_json(local_image_preview(Sess(ctx.session), a.path)?)
        })()),
        _ => None,
    }
}
// ==== END GENERATED WEB DISPATCH ====
