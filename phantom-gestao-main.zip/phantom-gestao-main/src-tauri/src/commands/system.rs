use std::collections::BTreeMap;
use std::path::PathBuf;


use super::guard::*;
use crate::error::{AppError, AppResult};
use crate::repositories::{audit_repo, settings_repo, Page, PageQuery};
use crate::services::dashboard_service::Period;
use crate::services::notification_service::{self, ContactEventRow, ContactInput, ContactResult, DeliveryStat, NotificationRow};
use crate::services::report_service::{self, ExportInput, GeneratedReport, ReportType};
use crate::services::settings_service::{self, *};
use crate::services::user_service::{self, NewUser, RoleMatrix, UserRow, UserUpdate};
use crate::services::{backup_service, loan_service};

use super::ctx::{parse_args, to_json, Ctx, Db, Paths, Sess, Vlt};

pub struct AppPaths {
    pub data_dir: PathBuf,
}

// ---------------------------------------------------------------- notificações

#[tauri::command(async)]
pub fn notifications_list(db: Db, s: Sess, query: PageQuery) -> AppResult<Page<NotificationRow>> {
    run(&db, &s, "notifications.view", |c, _| notification_service::list(c, &query))
}

#[tauri::command(async)]
pub fn notifications_unread_count(db: Db, s: Sess) -> AppResult<i64> {
    run(&db, &s, "notifications.view", |c, _| notification_service::unread_count(c))
}

#[tauri::command(async)]
pub fn notification_mark_read(db: Db, s: Sess, id: i64) -> AppResult<()> {
    run(&db, &s, "notifications.view", |c, _| notification_service::mark_read(c, id))
}

#[tauri::command(async)]
pub fn notifications_mark_all_read(db: Db, s: Sess) -> AppResult<()> {
    run(&db, &s, "notifications.view", |c, u| notification_service::mark_all_read(c, u))
}

#[tauri::command(async)]
pub fn notifications_run_rules(db: Db, s: Sess) -> AppResult<usize> {
    run(&db, &s, "notifications.view", |c, _| notification_service::run_rules(c))
}

#[tauri::command(async)]
pub fn notification_delivery_stats(db: Db, s: Sess) -> AppResult<Vec<DeliveryStat>> {
    run(&db, &s, "notifications.view", |c, _| notification_service::delivery_stats(c))
}

// -------------------------------------------------------------------- cobranças

#[tauri::command(async)]
pub fn collections_list(db: Db, s: Sess, scope: String) -> AppResult<Vec<loan_service::CollectionRow>> {
    run(&db, &s, "collections.view", |c, _| loan_service::collection_rows(c, &scope))
}

#[tauri::command(async)]
pub fn collection_render_message(db: Db, s: Sess, channel: String, installment_id: i64) -> AppResult<String> {
    run(&db, &s, "collections.view", |c, _| notification_service::render_message(c, &channel, installment_id))
}

#[tauri::command(async)]
pub fn collection_register_contact(db: Db, s: Sess, input: ContactInput) -> AppResult<ContactResult> {
    run(&db, &s, "collections.manage", |c, u| notification_service::register_contact(c, u, input))
}

#[tauri::command(async)]
pub fn collection_history(db: Db, s: Sess, client_id: Option<i64>) -> AppResult<Vec<ContactEventRow>> {
    run(&db, &s, "collections.view", |c, _| notification_service::contact_history(c, client_id, 50))
}

#[derive(serde::Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CollectionsSummary {
    pub due_today_count: i64,
    pub due_week_count: i64,
    pub overdue_count: i64,
    pub overdue_cents: i64,
}

#[tauri::command(async)]
pub fn collections_summary(db: Db, s: Sess) -> AppResult<CollectionsSummary> {
    run(&db, &s, "collections.view", |c, _| {
        let today = settings_repo::today(c).to_string();
        let one = |sql: &str| -> AppResult<(i64, i64)> {
            Ok(c.query_row(sql, [&today], |r| Ok((r.get(0)?, r.get(1)?)))?)
        };
        let base = "SELECT COUNT(*), COALESCE(SUM(i.amount_cents - i.paid_cents),0) FROM loan_installments i JOIN loans l ON l.id=i.loan_id WHERE i.status IN ('open','partial') AND l.status='active' AND ";
        Ok(CollectionsSummary {
            due_today_count: one(&format!("{base}i.due_date = ?1"))?.0,
            due_week_count: one(&format!("{base}i.due_date BETWEEN ?1 AND date(?1,'+7 days')"))?.0,
            overdue_count: one(&format!("{base}i.due_date < ?1"))?.0,
            overdue_cents: one(&format!("{base}i.due_date < ?1"))?.1,
        })
    })
}

/// Abre um link externo, restrito a WhatsApp (wa.me) e e-mail (mailto:).
#[tauri::command(async)]
pub fn open_external(app: tauri::AppHandle, s: Sess, url: String) -> AppResult<()> {
    use tauri_plugin_opener::OpenerExt;
    s.require("collections.manage")?;
    if !(url.starts_with("https://wa.me/") || url.starts_with("mailto:")) {
        return Err(AppError::Forbidden);
    }
    app.opener().open_url(url, None::<&str>).map_err(|e| AppError::Validation(format!("Não foi possível abrir o aplicativo externo: {e}")))
}

// -------------------------------------------------------------------- relatórios

#[tauri::command(async)]
pub fn report_overview(db: Db, s: Sess, period: Period) -> AppResult<report_service::Overview> {
    run(&db, &s, "reports.view", |c, _| report_service::overview(c, &period))
}

#[tauri::command(async)]
pub fn report_types(s: Sess) -> AppResult<Vec<ReportType>> {
    s.require("reports.view")?;
    Ok(report_service::types())
}

#[tauri::command(async)]
pub fn report_preview(db: Db, s: Sess, report_type: String, period: Period) -> AppResult<serde_json::Value> {
    run(&db, &s, "reports.view", |c, _| report_service::preview(c, &report_type, &period))
}

#[tauri::command(async)]
pub fn report_export(db: Db, s: Sess, vault: Vlt, input: ExportInput) -> AppResult<GeneratedReport> {
    run(&db, &s, "reports.export", |c, u| report_service::export(c, &vault, u, input))
}

#[tauri::command(async)]
pub fn report_generated(db: Db, s: Sess) -> AppResult<Vec<GeneratedReport>> {
    run(&db, &s, "reports.view", |c, _| report_service::generated(c, 20))
}

// ------------------------------------------------------------------ configurações

#[tauri::command(async)]
pub fn settings_all(db: Db, s: Sess) -> AppResult<BTreeMap<String, String>> {
    run_authenticated(&db, &s, |c, _| settings_service::all(c))
}

#[tauri::command(async)]
pub fn settings_save_company(db: Db, s: Sess, input: CompanyInput) -> AppResult<()> {
    run(&db, &s, "settings.manage", |c, u| settings_service::save_company(c, u, input))
}

#[tauri::command(async)]
pub fn settings_save_regional(db: Db, s: Sess, input: RegionalInput) -> AppResult<()> {
    run(&db, &s, "settings.manage", |c, u| settings_service::save_regional(c, u, input))
}

#[tauri::command(async)]
pub fn settings_save_financial(db: Db, s: Sess, input: FinancialRules) -> AppResult<()> {
    run(&db, &s, "settings.manage", |c, u| settings_service::save_financial_rules(c, u, input))
}

#[tauri::command(async)]
pub fn settings_save_notifications(db: Db, s: Sess, input: NotificationConfig) -> AppResult<()> {
    run(&db, &s, "settings.manage", |c, u| settings_service::save_notification_config(c, u, input))
}

#[tauri::command(async)]
pub fn message_templates(db: Db, s: Sess) -> AppResult<Vec<MessageTemplate>> {
    run_any(&db, &s, &["settings.view", "collections.view"], |c, _| settings_service::message_templates(c))
}

#[tauri::command(async)]
pub fn message_template_save(db: Db, s: Sess, id: i64, body: String, active: bool) -> AppResult<()> {
    run(&db, &s, "settings.manage", |c, u| settings_service::save_message_template(c, u, id, &body, active))
}

#[tauri::command(async)]
pub fn regulatory_get(db: Db, s: Sess) -> AppResult<Regulatory> {
    run_authenticated(&db, &s, |c, _| settings_service::regulatory(c))
}

#[tauri::command(async)]
pub fn regulatory_set(db: Db, s: Sess, kind: String, enabled: bool, note: String) -> AppResult<()> {
    run(&db, &s, "regulatory.manage", |c, u| settings_service::set_regulatory(c, u, &kind, enabled, &note))
}

#[tauri::command(async)]
pub fn integrations_get(db: Db, s: Sess) -> AppResult<Vec<IntegrationStatus>> {
    run(&db, &s, "settings.view", |c, _| settings_service::integrations(c))
}

#[tauri::command(async)]
pub fn integration_save(db: Db, s: Sess, vault: Vlt, input: IntegrationInput) -> AppResult<()> {
    run(&db, &s, "settings.manage", |c, u| settings_service::save_integration(c, &vault, u, input))
}

// ---------------------------------------------------------------------- usuários

#[tauri::command(async)]
pub fn users_list(db: Db, s: Sess) -> AppResult<Vec<UserRow>> {
    run(&db, &s, "users.manage", |c, _| user_service::list(c))
}

#[tauri::command(async)]
pub fn user_create(db: Db, s: Sess, input: NewUser) -> AppResult<i64> {
    run(&db, &s, "users.manage", |c, u| user_service::create(c, u, input))
}

#[tauri::command(async)]
pub fn user_update(db: Db, s: Sess, id: i64, input: UserUpdate) -> AppResult<()> {
    run(&db, &s, "users.manage", |c, u| {
        user_service::update(c, u, id, input)?;
        if id == u.id {
            s.set(user_service::reload(c, u.id)?);
        }
        Ok(())
    })
}

#[tauri::command(async)]
pub fn user_reset_password(db: Db, s: Sess, id: i64, new_password: String) -> AppResult<()> {
    run(&db, &s, "users.manage", |c, u| user_service::reset_password(c, u, id, &new_password))
}

#[tauri::command(async)]
pub fn user_unlock(db: Db, s: Sess, id: i64) -> AppResult<()> {
    run(&db, &s, "users.manage", |c, u| user_service::unlock(c, u, id))
}

#[tauri::command(async)]
pub fn roles_matrix(db: Db, s: Sess) -> AppResult<RoleMatrix> {
    run(&db, &s, "users.manage", |c, _| user_service::matrix(c))
}

#[tauri::command(async)]
pub fn role_permission_set(db: Db, s: Sess, role_code: String, permission: String, granted: bool) -> AppResult<()> {
    run(&db, &s, "users.manage", |c, u| {
        user_service::set_permission(c, u, &role_code, &permission, granted)?;
        s.set(user_service::reload(c, u.id)?);
        Ok(())
    })
}

#[tauri::command(async)]
pub fn change_password(db: Db, s: Sess, current: String, new_password: String) -> AppResult<()> {
    run_authenticated(&db, &s, |c, u| user_service::change_own_password(c, u, &current, &new_password))
}

#[tauri::command(async)]
pub fn audit_list(db: Db, s: Sess, query: PageQuery) -> AppResult<Page<audit_repo::AuditRow>> {
    run(&db, &s, "audit.view", |c, _| audit_repo::list(c, &query))
}

// ----------------------------------------------------------------------- backup

#[derive(serde::Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BackupInfo {
    pub last_at: Option<String>,
    pub data_dir: String,
}

#[tauri::command(async)]
pub fn backup_info(db: Db, s: Sess, paths: Paths) -> AppResult<BackupInfo> {
    run(&db, &s, "backup.manage", |c, _| Ok(BackupInfo { last_at: settings_repo::get(c, "backup.last_at")?, data_dir: paths.data_dir.to_string_lossy().into() }))
}

#[tauri::command(async)]
pub fn backup_create(db: Db, s: Sess, vault: Vlt, dir: String, passphrase: String) -> AppResult<String> {
    let user = s.require("backup.manage")?;
    backup_service::create(&db, &vault, &user, std::path::Path::new(&dir), &passphrase).map(|p| p.to_string_lossy().into())
}

#[tauri::command(async)]
pub fn backup_verify(s: Sess, dir: String) -> AppResult<i64> {
    s.require("backup.manage")?;
    backup_service::verify(std::path::Path::new(&dir))
}

/// Restauração: ação crítica, exige a confirmação digitada "RESTAURAR". Encerra a sessão ao final.
#[tauri::command(async)]
pub fn backup_restore(db: Db, s: Sess, vault: Vlt, paths: Paths, dir: String, passphrase: String, confirmation: String) -> AppResult<String> {
    let user = s.require("backup.manage")?;
    if confirmation.trim() != "RESTAURAR" {
        return Err(AppError::Validation("Digite RESTAURAR para confirmar.".into()));
    }
    let safety = backup_service::restore(&db, &vault, std::path::Path::new(&dir), &passphrase, &paths.data_dir.join("safety"), true)?;
    {
        let conn = db.conn()?;
        audit_repo::record(&conn, Some(user.id), Some(&user.username), "backup.restore", Some("backup"), Some(&dir))?;
    }
    s.clear();
    Ok(safety.to_string_lossy().into())
}

/// Carrega dados de demonstração. Existe apenas em builds de desenvolvimento (debug).
#[cfg(debug_assertions)]
#[tauri::command(async)]
pub fn demo_seed(db: Db, s: Sess, vault: Vlt) -> AppResult<()> {
    run(&db, &s, "backup.manage", |c, u| crate::services::demo_seed::run(c, &vault, u))
}

// ==== BEGIN GENERATED WEB DISPATCH (scripts/gen_web_dispatch.py) ====
#[allow(unused_variables, clippy::redundant_closure_call)]
pub fn web_dispatch(cmd: &str, ctx: &Ctx, args: serde_json::Value) -> Option<AppResult<serde_json::Value>> {
    match cmd {
        "notifications_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                query: PageQuery,
            }
            let a: A = parse_args(args)?;
            to_json(notifications_list(Db(ctx.db), Sess(ctx.session), a.query)?)
        })()),
        "notifications_unread_count" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(notifications_unread_count(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "notification_mark_read" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(notification_mark_read(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "notifications_mark_all_read" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(notifications_mark_all_read(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "notifications_run_rules" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(notifications_run_rules(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "notification_delivery_stats" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(notification_delivery_stats(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "collections_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                scope: String,
            }
            let a: A = parse_args(args)?;
            to_json(collections_list(Db(ctx.db), Sess(ctx.session), a.scope)?)
        })()),
        "collection_render_message" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                channel: String,
                installment_id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(collection_render_message(Db(ctx.db), Sess(ctx.session), a.channel, a.installment_id)?)
        })()),
        "collection_register_contact" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: ContactInput,
            }
            let a: A = parse_args(args)?;
            to_json(collection_register_contact(Db(ctx.db), Sess(ctx.session), a.input)?)
        })()),
        "collection_history" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                client_id: Option<i64>,
            }
            let a: A = parse_args(args)?;
            to_json(collection_history(Db(ctx.db), Sess(ctx.session), a.client_id)?)
        })()),
        "collections_summary" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(collections_summary(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "open_external" => Some(Err(crate::error::AppError::Validation("Recurso disponível apenas no aplicativo desktop.".into()))),
        "report_overview" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                period: Period,
            }
            let a: A = parse_args(args)?;
            to_json(report_overview(Db(ctx.db), Sess(ctx.session), a.period)?)
        })()),
        "report_types" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(report_types(Sess(ctx.session))?)
        })()),
        "report_preview" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                report_type: String,
                period: Period,
            }
            let a: A = parse_args(args)?;
            to_json(report_preview(Db(ctx.db), Sess(ctx.session), a.report_type, a.period)?)
        })()),
        "report_export" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: ExportInput,
            }
            let a: A = parse_args(args)?;
            to_json(report_export(Db(ctx.db), Sess(ctx.session), Vlt(ctx.vault), a.input)?)
        })()),
        "report_generated" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(report_generated(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "settings_all" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(settings_all(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "settings_save_company" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: CompanyInput,
            }
            let a: A = parse_args(args)?;
            to_json(settings_save_company(Db(ctx.db), Sess(ctx.session), a.input)?)
        })()),
        "settings_save_regional" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: RegionalInput,
            }
            let a: A = parse_args(args)?;
            to_json(settings_save_regional(Db(ctx.db), Sess(ctx.session), a.input)?)
        })()),
        "settings_save_financial" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: FinancialRules,
            }
            let a: A = parse_args(args)?;
            to_json(settings_save_financial(Db(ctx.db), Sess(ctx.session), a.input)?)
        })()),
        "settings_save_notifications" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: NotificationConfig,
            }
            let a: A = parse_args(args)?;
            to_json(settings_save_notifications(Db(ctx.db), Sess(ctx.session), a.input)?)
        })()),
        "message_templates" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(message_templates(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "message_template_save" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                body: String,
                active: bool,
            }
            let a: A = parse_args(args)?;
            to_json(message_template_save(Db(ctx.db), Sess(ctx.session), a.id, a.body, a.active)?)
        })()),
        "regulatory_get" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(regulatory_get(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "regulatory_set" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                kind: String,
                enabled: bool,
                note: String,
            }
            let a: A = parse_args(args)?;
            to_json(regulatory_set(Db(ctx.db), Sess(ctx.session), a.kind, a.enabled, a.note)?)
        })()),
        "integrations_get" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(integrations_get(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "integration_save" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: IntegrationInput,
            }
            let a: A = parse_args(args)?;
            to_json(integration_save(Db(ctx.db), Sess(ctx.session), Vlt(ctx.vault), a.input)?)
        })()),
        "users_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(users_list(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "user_create" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                input: NewUser,
            }
            let a: A = parse_args(args)?;
            to_json(user_create(Db(ctx.db), Sess(ctx.session), a.input)?)
        })()),
        "user_update" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                input: UserUpdate,
            }
            let a: A = parse_args(args)?;
            to_json(user_update(Db(ctx.db), Sess(ctx.session), a.id, a.input)?)
        })()),
        "user_reset_password" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
                new_password: String,
            }
            let a: A = parse_args(args)?;
            to_json(user_reset_password(Db(ctx.db), Sess(ctx.session), a.id, a.new_password)?)
        })()),
        "user_unlock" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                id: i64,
            }
            let a: A = parse_args(args)?;
            to_json(user_unlock(Db(ctx.db), Sess(ctx.session), a.id)?)
        })()),
        "roles_matrix" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
            }
            let a: A = parse_args(args)?;
            to_json(roles_matrix(Db(ctx.db), Sess(ctx.session))?)
        })()),
        "role_permission_set" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                role_code: String,
                permission: String,
                granted: bool,
            }
            let a: A = parse_args(args)?;
            to_json(role_permission_set(Db(ctx.db), Sess(ctx.session), a.role_code, a.permission, a.granted)?)
        })()),
        "change_password" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                current: String,
                new_password: String,
            }
            let a: A = parse_args(args)?;
            to_json(change_password(Db(ctx.db), Sess(ctx.session), a.current, a.new_password)?)
        })()),
        "audit_list" => Some((|| {
            #[derive(serde::Deserialize)]
            #[serde(rename_all = "camelCase")]
            #[allow(dead_code)]
            struct A {
                query: PageQuery,
            }
            let a: A = parse_args(args)?;
            to_json(audit_list(Db(ctx.db), Sess(ctx.session), a.query)?)
        })()),
        "backup_info" => Some(Err(crate::error::AppError::Validation("Recurso disponível apenas no aplicativo desktop.".into()))),
        "backup_create" => Some(Err(crate::error::AppError::Validation("Recurso disponível apenas no aplicativo desktop.".into()))),
        "backup_verify" => Some(Err(crate::error::AppError::Validation("Recurso disponível apenas no aplicativo desktop.".into()))),
        "backup_restore" => Some(Err(crate::error::AppError::Validation("Recurso disponível apenas no aplicativo desktop.".into()))),
        "demo_seed" => Some(Err(crate::error::AppError::Validation("Recurso disponível apenas no aplicativo desktop.".into()))),
        _ => None,
    }
}
// ==== END GENERATED WEB DISPATCH ====
