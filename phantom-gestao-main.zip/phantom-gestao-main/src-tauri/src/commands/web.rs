//! Despacho dos comandos para o servidor web: tenta cada módulo até achar o comando pelo nome.
use super::ctx::Ctx;
use crate::error::AppResult;

pub fn dispatch(cmd: &str, ctx: &Ctx, args: serde_json::Value) -> Option<AppResult<serde_json::Value>> {
    super::auth::web_dispatch(cmd, ctx, args.clone())
        .or_else(|| super::commercial::web_dispatch(cmd, ctx, args.clone()))
        .or_else(|| super::credit::web_dispatch(cmd, ctx, args.clone()))
        .or_else(|| super::registry::web_dispatch(cmd, ctx, args.clone()))
        .or_else(|| super::system::web_dispatch(cmd, ctx, args))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::error::AppError;
    use crate::security::session::SessionState;
    use crate::testutil::env;
    use serde_json::json;

    use super::super::system::AppPaths;

    fn paths() -> AppPaths {
        AppPaths { data_dir: std::env::temp_dir() }
    }

    #[test]
    fn every_manifest_command_has_a_web_route() {
        let e = env();
        let p = paths();
        let s = SessionState::default();
        let ctx = Ctx { db: &e.db, vault: &e.vault, session: &s, paths: &p };
        let build = include_str!("../../build.rs");
        let names: Vec<&str> = build.lines().filter_map(|l| l.trim().strip_prefix('"')?.strip_suffix("\",")).collect();
        assert!(names.len() > 100, "manifesto não lido: {}", names.len());
        for n in names {
            assert!(dispatch(n, &ctx, json!({})).is_some(), "comando sem rota web: {n} (rode scripts/gen_web_dispatch.py)");
        }
        assert!(dispatch("nao_existe", &ctx, json!({})).is_none());
    }

    #[test]
    fn web_sessions_are_isolated_and_permissioned() {
        let e = env();
        let p = paths();
        let anon = SessionState::default();
        fn mk<'a>(e: &'a crate::testutil::Env, p: &'a AppPaths, s: &'a SessionState) -> Ctx<'a> {
            Ctx { db: &e.db, vault: &e.vault, session: s, paths: p }
        }

        // sem login nada passa
        let r = dispatch("users_list", &mk(&e, &p, &anon), json!({})).unwrap();
        assert!(matches!(r, Err(AppError::Unauthenticated)));

        // login com credenciais erradas não cria sessão
        let bad = SessionState::default();
        let r = dispatch("login", &mk(&e, &p, &bad), json!({"username": "admin", "password": "errada"})).unwrap();
        assert!(r.is_err());
        assert!(bad.user().is_err());

        // admin autentica na sua própria sessão; a anônima segue sem acesso
        let admin = SessionState::default();
        let r = dispatch("login", &mk(&e, &p, &admin), json!({"username": "admin", "password": "senhaforte123"})).unwrap();
        assert!(r.is_ok());
        assert!(dispatch("users_list", &mk(&e, &p, &admin), json!({})).unwrap().is_ok());
        assert!(matches!(dispatch("users_list", &mk(&e, &p, &anon), json!({})).unwrap(), Err(AppError::Unauthenticated)));

        // perfil só de consulta: autenticado mas sem permissão de administração
        let mut viewer_user = e.admin.clone();
        viewer_user.permissions = vec!["dashboard.view".into()];
        let viewer = SessionState::default();
        viewer.set(viewer_user);
        assert!(matches!(dispatch("users_list", &mk(&e, &p, &viewer), json!({})).unwrap(), Err(AppError::Forbidden)));
    }

    #[test]
    fn camel_case_args_and_validation() {
        let e = env();
        let p = paths();
        let admin = SessionState::default();
        admin.set(e.admin.clone());
        let ctx = Ctx { db: &e.db, vault: &e.vault, session: &admin, paths: &p };
        // argumentos em camelCase, como o frontend envia
        let r = dispatch("client_history", &ctx, json!({"id": 1, "kind": null})).unwrap();
        assert!(!matches!(r, Err(AppError::Validation(ref m)) if m.starts_with("Parâmetros inválidos")), "{r:?}");
        // argumento obrigatório ausente/tipo errado vira erro de validação, sem pânico
        let r = dispatch("client_get", &ctx, json!({"id": "x"})).unwrap();
        assert!(matches!(r, Err(AppError::Validation(ref m)) if m.starts_with("Parâmetros inválidos")));
    }

    #[test]
    fn disk_and_desktop_commands_are_blocked_on_web() {
        let e = env();
        let p = paths();
        let admin = SessionState::default();
        admin.set(e.admin.clone());
        let ctx = Ctx { db: &e.db, vault: &e.vault, session: &admin, paths: &p };
        let blocked = [
            ("attachment_save_to", json!({"id": 1, "path": "C:/x.bin"})),
            ("backup_create", json!({"dir": "C:/x", "passphrase": "x"})),
            ("backup_restore", json!({"dir": "C:/x", "passphrase": "x", "confirmation": "x"})),
            ("backup_info", json!({})),
            ("backup_verify", json!({"dir": "C:/x"})),
            ("demo_seed", json!({})),
            ("open_external", json!({"url": "mailto:a@b.c"})),
            ("setup_admin", json!({"fullName": "A", "username": "x", "password": "y"})),
        ];
        for (cmd, args) in blocked {
            let r = dispatch(cmd, &ctx, args).unwrap_or_else(|| panic!("{cmd} sem rota"));
            assert!(matches!(r, Err(AppError::Validation(ref m)) if m.contains("apenas no aplicativo desktop")), "{cmd} não bloqueado: {r:?}");
        }
    }

    #[test]
    fn raw_paths_are_refused_by_the_file_scope() {
        let e = env();
        let p = paths();
        let admin = SessionState::default();
        admin.set(e.admin.clone());
        let ctx = Ctx { db: &e.db, vault: &e.vault, session: &admin, paths: &p };
        let _scope = crate::security::fs_scope::WebScope::enter(&std::env::temp_dir().join("phantom-no-such-root"));
        for (cmd, args) in [
            ("attachment_add", json!({"ownerType": "client", "ownerId": 1, "kind": "x", "path": "C:/Windows/win.ini"})),
            ("client_add_document", json!({"clientId": 1, "docType": "cpf", "filePath": "C:/Windows/win.ini"})),
            ("local_image_preview", json!({"path": "C:/Windows/Web/Wallpaper/Windows/img0.jpg"})),
        ] {
            let r = dispatch(cmd, &ctx, args).unwrap();
            assert!(r.is_err(), "{cmd} deveria falhar: {r:?}");
        }
    }
}
