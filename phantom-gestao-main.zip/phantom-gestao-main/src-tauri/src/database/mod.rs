use std::path::Path;
use std::sync::{Mutex, MutexGuard};

use rusqlite::Connection;

use crate::error::{AppError, AppResult};

/// Migrações versionadas, aplicadas em ordem. Nunca edite uma migração já
/// publicada: adicione uma nova.
const MIGRATIONS: &[(i64, &str, &str)] = &[
    (1, "foundation", include_str!("../../migrations/0001_foundation.sql")),
    (2, "cadastros", include_str!("../../migrations/0002_cadastros.sql")),
    (3, "comercial", include_str!("../../migrations/0003_comercial.sql")),
    (4, "credito", include_str!("../../migrations/0004_credito.sql")),
    (5, "cobranca_notificacoes", include_str!("../../migrations/0005_cobranca_notificacoes.sql")),
    (6, "contract_layout", include_str!("../../migrations/0006_contract_layout.sql")),
    (7, "attachment_layout", include_str!("../../migrations/0007_attachment_layout.sql")),
    (8, "template_images", include_str!("../../migrations/0008_template_images.sql")),
];

/// Maior versão de esquema conhecida por este binário.
pub fn latest_version() -> i64 {
    MIGRATIONS.last().map(|m| m.0).unwrap_or(0)
}

pub struct Database {
    conn: Mutex<Connection>,
}

impl Database {
    pub fn open(path: &Path) -> AppResult<Self> {
        let conn = Connection::open(path)?;
        conn.pragma_update(None, "journal_mode", "WAL")?;
        Self::init(conn)
    }

    #[cfg(test)]
    pub fn open_in_memory() -> AppResult<Self> {
        Self::init(Connection::open_in_memory()?)
    }

    fn init(conn: Connection) -> AppResult<Self> {
        conn.pragma_update(None, "foreign_keys", "ON")?;
        conn.pragma_update(None, "synchronous", "FULL")?;
        let db = Self { conn: Mutex::new(conn) };
        db.migrate()?;
        Ok(db)
    }

    pub fn conn(&self) -> AppResult<MutexGuard<'_, Connection>> {
        self.conn
            .lock()
            .map_err(|_| AppError::Internal("conexão do banco envenenada".into()))
    }

    pub fn migrate(&self) -> AppResult<()> {
        let mut conn = self.conn()?;
        conn.execute_batch(
            "CREATE TABLE IF NOT EXISTS schema_migrations (
                version    INTEGER PRIMARY KEY,
                name       TEXT NOT NULL,
                applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
            );",
        )?;
        for (version, name, sql) in MIGRATIONS {
            let applied: bool = conn.query_row(
                "SELECT EXISTS(SELECT 1 FROM schema_migrations WHERE version = ?1)",
                [version],
                |r| r.get(0),
            )?;
            if applied {
                continue;
            }
            let tx = conn.transaction()?;
            tx.execute_batch(sql)?;
            tx.execute(
                "INSERT INTO schema_migrations (version, name) VALUES (?1, ?2)",
                (version, name),
            )?;
            tx.commit()?;
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn migrations_apply_and_are_idempotent() {
        let db = Database::open_in_memory().unwrap();
        db.migrate().unwrap();
        let conn = db.conn().unwrap();
        let n: i64 = conn
            .query_row("SELECT COUNT(*) FROM schema_migrations", [], |r| r.get(0))
            .unwrap();
        assert_eq!(n as usize, MIGRATIONS.len());
        let roles: i64 = conn.query_row("SELECT COUNT(*) FROM roles", [], |r| r.get(0)).unwrap();
        assert_eq!(roles, 4);
    }

    #[test]
    fn audit_log_is_immutable() {
        let db = Database::open_in_memory().unwrap();
        let conn = db.conn().unwrap();
        conn.execute("INSERT INTO audit_logs (action) VALUES ('x')", []).unwrap();
        assert!(conn.execute("UPDATE audit_logs SET action = 'y'", []).is_err());
        assert!(conn.execute("DELETE FROM audit_logs", []).is_err());
    }
}
