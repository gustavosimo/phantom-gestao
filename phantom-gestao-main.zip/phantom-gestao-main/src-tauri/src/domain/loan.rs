//! Cálculos determinísticos de crédito. Toda a aritmética usa `Decimal` e valores
//! em centavos; nenhum ponto flutuante binário é utilizado.

use chrono::{Datelike, Duration, NaiveDate};
use rust_decimal::prelude::*;
use rust_decimal::MathematicalOps;
use serde::Serialize;

use crate::domain::money::{bp_to_fraction, round_cents};
use crate::error::{AppError, AppResult};

pub struct LoanParams {
    pub principal_cents: i64,
    pub term_months: u32,
    /// Taxa mensal em centésimos de ponto percentual (240 = 2,40% a.m.).
    pub rate_bp: i64,
    pub first_due: NaiveDate,
    /// Tarifa de cadastro, % do principal em centésimos.
    pub fee_bp: i64,
    /// IOF configurável, % do principal em centésimos.
    pub iof_bp: i64,
}

#[derive(Debug, Clone, Serialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct ScheduleItem {
    pub number: u32,
    pub due_date: NaiveDate,
    pub amount_cents: i64,
    pub principal_cents: i64,
    pub interest_cents: i64,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Simulation {
    pub principal_cents: i64,
    pub term_months: u32,
    pub rate_bp: i64,
    pub installment_cents: i64,
    pub total_cents: i64,
    pub total_interest_cents: i64,
    pub fees_cents: i64,
    pub net_cents: i64,
    pub cet_monthly_bp: i64,
    pub cet_annual_bp: i64,
    pub schedule: Vec<ScheduleItem>,
}

pub fn add_months(d: NaiveDate, months: u32) -> NaiveDate {
    d.checked_add_months(chrono::Months::new(months)).unwrap_or(d)
}

/// Parcela fixa (Tabela Price) em centavos, ainda sem ajuste da última parcela.
pub fn pmt_cents(principal_cents: i64, term: u32, rate_bp: i64) -> i64 {
    let p = Decimal::from(principal_cents);
    if rate_bp == 0 {
        return round_cents(p / Decimal::from(term));
    }
    let i = bp_to_fraction(rate_bp);
    let f = (Decimal::ONE + i).powi(term as i64);
    round_cents(p * i * f / (f - Decimal::ONE))
}

/// Cronograma de amortização. A soma das parcelas de principal é exatamente o
/// principal; a diferença de arredondamento é absorvida pela última parcela.
pub fn build_schedule(
    principal_cents: i64,
    term: u32,
    rate_bp: i64,
    first_due: NaiveDate,
) -> AppResult<Vec<ScheduleItem>> {
    if principal_cents <= 0 || term == 0 {
        return Err(AppError::Validation("Valor e prazo devem ser positivos.".into()));
    }
    let i = bp_to_fraction(rate_bp);
    let pmt = pmt_cents(principal_cents, term, rate_bp);
    let mut balance = principal_cents;
    let mut out = Vec::with_capacity(term as usize);
    for k in 1..=term {
        let interest = round_cents(Decimal::from(balance) * i);
        let (principal, amount) = if k == term {
            (balance, balance + interest)
        } else {
            (pmt - interest, pmt)
        };
        if principal < 0 {
            return Err(AppError::Validation("Parâmetros geram amortização negativa.".into()));
        }
        balance -= principal;
        out.push(ScheduleItem {
            number: k,
            due_date: add_months(first_due, k - 1),
            amount_cents: amount,
            principal_cents: principal,
            interest_cents: interest,
        });
    }
    Ok(out)
}

/// Taxa interna de retorno mensal (bisseção) do fluxo: +líquido em t0 e -parcelas.
fn irr_monthly(net: i64, amounts: &[i64]) -> Decimal {
    let npv = |r: Decimal| -> Decimal {
        let base = Decimal::ONE + r;
        let mut acc = Decimal::from(net);
        let mut pow = Decimal::ONE;
        for a in amounts {
            pow *= base;
            acc -= Decimal::from(*a) / pow;
        }
        acc
    };
    let (mut lo, mut hi) = (Decimal::ZERO, Decimal::ONE);
    if npv(lo) >= Decimal::ZERO {
        return Decimal::ZERO;
    }
    for _ in 0..80 {
        let mid = (lo + hi) / Decimal::TWO;
        if npv(mid) < Decimal::ZERO { lo = mid } else { hi = mid }
    }
    (lo + hi) / Decimal::TWO
}

pub fn simulate(p: &LoanParams) -> AppResult<Simulation> {
    let schedule = build_schedule(p.principal_cents, p.term_months, p.rate_bp, p.first_due)?;
    let fees = round_cents(Decimal::from(p.principal_cents) * bp_to_fraction(p.fee_bp))
        + round_cents(Decimal::from(p.principal_cents) * bp_to_fraction(p.iof_bp));
    let net = p.principal_cents - fees;
    if net <= 0 {
        return Err(AppError::Validation("Encargos superam o valor liberado.".into()));
    }
    let amounts: Vec<i64> = schedule.iter().map(|s| s.amount_cents).collect();
    let total: i64 = amounts.iter().sum();
    let r = irr_monthly(net, &amounts);
    let annual = (Decimal::ONE + r).powi(12) - Decimal::ONE;
    Ok(Simulation {
        principal_cents: p.principal_cents,
        term_months: p.term_months,
        rate_bp: p.rate_bp,
        installment_cents: schedule[0].amount_cents,
        total_cents: total,
        total_interest_cents: total - p.principal_cents,
        fees_cents: fees,
        net_cents: net,
        cet_monthly_bp: round_cents(r * Decimal::from(10_000)),
        cet_annual_bp: round_cents(annual * Decimal::from(10_000)),
        schedule,
    })
}

#[derive(Debug, PartialEq, Eq, Clone, Copy, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct LateCharges {
    pub days_late: i64,
    pub fee_cents: i64,
    pub interest_cents: i64,
}

impl LateCharges {
    pub fn total(&self) -> i64 {
        self.fee_cents + self.interest_cents
    }
}

/// Multa (uma única vez) + juros de mora pro rata die sobre o saldo em aberto da parcela.
pub fn late_charges(
    remaining_cents: i64,
    due: NaiveDate,
    as_of: NaiveDate,
    fee_already_applied: bool,
    interest_through: Option<NaiveDate>,
    fee_bp: i64,
    interest_month_bp: i64,
) -> LateCharges {
    if as_of <= due || remaining_cents <= 0 {
        return LateCharges { days_late: 0, fee_cents: 0, interest_cents: 0 };
    }
    let days_late = (as_of - due).num_days();
    let fee = if fee_already_applied {
        0
    } else {
        round_cents(Decimal::from(remaining_cents) * bp_to_fraction(fee_bp))
    };
    let from = interest_through.filter(|d| *d > due).unwrap_or(due);
    let days = (as_of - from).num_days().max(0);
    let interest = round_cents(
        Decimal::from(remaining_cents) * bp_to_fraction(interest_month_bp) * Decimal::from(days)
            / Decimal::from(30),
    );
    LateCharges { days_late, fee_cents: fee, interest_cents: interest }
}

pub fn last_day_of_month(y: i32, m: u32) -> NaiveDate {
    let first_next = if m == 12 {
        NaiveDate::from_ymd_opt(y + 1, 1, 1)
    } else {
        NaiveDate::from_ymd_opt(y, m + 1, 1)
    };
    first_next.map(|d| d - Duration::days(1)).unwrap_or_default()
}

pub fn month_start(d: NaiveDate) -> NaiveDate {
    NaiveDate::from_ymd_opt(d.year(), d.month(), 1).unwrap_or(d)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn d(y: i32, m: u32, day: u32) -> NaiveDate {
        NaiveDate::from_ymd_opt(y, m, day).unwrap()
    }

    #[test]
    fn pmt_known_value() {
        // 15.000,00 em 12x a 2,4% a.m. (Tabela Price): PMT = P·i·(1+i)^n / ((1+i)^n − 1)
        let pmt = pmt_cents(1_500_000, 12, 240);
        assert_eq!(pmt, 145_347);
    }

    #[test]
    fn zero_rate_splits_evenly() {
        let s = build_schedule(100_000, 4, 0, d(2024, 1, 31)).unwrap();
        assert!(s.iter().all(|i| i.amount_cents == 25_000 && i.interest_cents == 0));
    }

    #[test]
    fn schedule_principal_sums_exactly() {
        for (p, n, r) in [(1_500_000, 12, 240), (999_999, 7, 199), (123_457, 3, 1), (5_000_000, 60, 350)] {
            let s = build_schedule(p, n, r, d(2024, 11, 15)).unwrap();
            assert_eq!(s.len() as u32, n);
            assert_eq!(s.iter().map(|i| i.principal_cents).sum::<i64>(), p);
            assert!(s.iter().all(|i| i.amount_cents == i.principal_cents + i.interest_cents));
        }
    }

    #[test]
    fn schedule_dates_clamp_to_month_end() {
        let s = build_schedule(100_000, 3, 100, d(2024, 1, 31)).unwrap();
        assert_eq!(s[1].due_date, d(2024, 2, 29));
        assert_eq!(s[2].due_date, d(2024, 3, 31));
    }

    #[test]
    fn schedule_is_deterministic() {
        let a = build_schedule(777_700, 10, 211, d(2025, 1, 10)).unwrap();
        let b = build_schedule(777_700, 10, 211, d(2025, 1, 10)).unwrap();
        assert_eq!(a, b);
    }

    #[test]
    fn rejects_invalid_params() {
        assert!(build_schedule(0, 12, 100, d(2024, 1, 1)).is_err());
        assert!(build_schedule(1000, 0, 100, d(2024, 1, 1)).is_err());
    }

    #[test]
    fn cet_equals_rate_without_fees() {
        let p = LoanParams { principal_cents: 1_500_000, term_months: 12, rate_bp: 240, first_due: d(2024, 11, 15), fee_bp: 0, iof_bp: 0 };
        let s = simulate(&p).unwrap();
        // sem encargos o CET mensal coincide com a taxa nominal (±1 bp por arredondamento de parcelas)
        assert!((s.cet_monthly_bp - 240).abs() <= 1, "cet = {}", s.cet_monthly_bp);
        assert!(s.cet_annual_bp > 3000 && s.cet_annual_bp < 3400);
        assert_eq!(s.fees_cents, 0);
        assert_eq!(s.total_cents - s.principal_cents, s.total_interest_cents);
    }

    #[test]
    fn cet_grows_with_fees() {
        let base = LoanParams { principal_cents: 1_000_000, term_months: 12, rate_bp: 200, first_due: d(2024, 11, 15), fee_bp: 0, iof_bp: 0 };
        let with_fee = LoanParams { fee_bp: 300, ..base };
        let a = simulate(&LoanParams { fee_bp: 0, ..base }).unwrap();
        let b = simulate(&with_fee).unwrap();
        assert!(b.cet_annual_bp > a.cet_annual_bp);
        assert_eq!(b.fees_cents, 30_000);
        assert_eq!(b.net_cents, 970_000);
    }

    #[test]
    fn late_charges_rules() {
        let due = d(2024, 10, 1);
        assert_eq!(late_charges(100_000, due, due, false, None, 200, 100).total(), 0);
        let c = late_charges(100_000, due, d(2024, 10, 11), false, None, 200, 100);
        assert_eq!(c.days_late, 10);
        assert_eq!(c.fee_cents, 2_000); // multa 2%
        assert_eq!(c.interest_cents, 333); // 1% a.m. * 10/30 de 1.000,00
        let again = late_charges(100_000, due, d(2024, 10, 11), true, Some(d(2024, 10, 11)), 200, 100);
        assert_eq!(again.total(), 0);
    }

    #[test]
    fn month_helpers() {
        assert_eq!(last_day_of_month(2024, 2), d(2024, 2, 29));
        assert_eq!(last_day_of_month(2024, 12), d(2024, 12, 31));
        assert_eq!(month_start(d(2024, 5, 17)), d(2024, 5, 1));
    }
}
