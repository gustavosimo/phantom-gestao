use rust_decimal::prelude::*;

/// Formata centavos como "R$ 1.234,56".
pub fn format_brl(cents: i64) -> String {
    let neg = cents < 0;
    let abs = cents.unsigned_abs();
    let (reais, c) = (abs / 100, abs % 100);
    let digits = reais.to_string();
    let mut out = String::new();
    for (i, ch) in digits.chars().enumerate() {
        if i > 0 && (digits.len() - i) % 3 == 0 {
            out.push('.');
        }
        out.push(ch);
    }
    format!("{}R$ {},{:02}", if neg { "-" } else { "" }, out, c)
}

/// "AAAA-MM-DD" ou "AAAA-MM-DDTHH:MM..." → "DD/MM/AAAA" (e " HH:MM"). Outros textos passam inalterados.
pub fn br_date(s: &str) -> String {
    let b = s.as_bytes();
    if s.len() >= 10 && b[..10].is_ascii() && b[4] == b'-' && b[7] == b'-' && b[..4].iter().all(|c| c.is_ascii_digit()) {
        let d = format!("{}/{}/{}", &s[8..10], &s[5..7], &s[0..4]);
        if s.len() >= 16 && b[..16].is_ascii() && (b[10] == b'T' || b[10] == b' ') {
            return format!("{d} {}", &s[11..16]);
        }
        return d;
    }
    s.to_string()
}

/// Arredonda (meio para longe do zero) um valor decimal em centavos.
pub fn round_cents(d: Decimal) -> i64 {
    d.round_dp_with_strategy(0, RoundingStrategy::MidpointAwayFromZero)
        .to_i64()
        .unwrap_or(0)
}

/// `bp` em centésimos de ponto percentual (240 = 2,40%) → fração decimal.
pub fn bp_to_fraction(bp: i64) -> Decimal {
    Decimal::from(bp) / Decimal::from(10_000)
}

/// Percentual com 2 casas para exibição: 240 → "2,40".
pub fn format_bp(bp: i64) -> String {
    format!("{},{:02}", bp / 100, bp.abs() % 100)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn formats_brl() {
        assert_eq!(format_brl(0), "R$ 0,00");
        assert_eq!(format_brl(141250), "R$ 1.412,50");
        assert_eq!(format_brl(248035000), "R$ 2.480.350,00");
        assert_eq!(format_brl(-5), "-R$ 0,05");
    }

    #[test]
    fn formats_br_dates() {
        assert_eq!(br_date("2026-10-11"), "11/10/2026");
        assert_eq!(br_date("2026-10-11T17:09:21Z"), "11/10/2026 17:09");
        assert_eq!(br_date("—"), "—");
        assert_eq!(br_date("abc"), "abc");
        assert_eq!(br_date("2026-ã-aaçãoção"), "2026-ã-aaçãoção");
    }

    #[test]
    fn rounds_half_away() {
        assert_eq!(round_cents(Decimal::new(25, 1)), 3);
        assert_eq!(round_cents(Decimal::new(24, 1)), 2);
    }

    #[test]
    fn formats_rate() {
        assert_eq!(format_bp(240), "2,40");
        assert_eq!(format_bp(5), "0,05");
    }
}
