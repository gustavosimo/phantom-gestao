use serde::Serialize;

use crate::error::{AppError, AppResult};

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct User {
    pub id: i64,
    pub username: String,
    pub full_name: String,
    pub role_code: String,
    pub role_name: String,
    pub permissions: Vec<String>,
}

pub fn normalize_username(raw: &str) -> AppResult<String> {
    let u = raw.trim().to_lowercase();
    let valid = (3..=32).contains(&u.chars().count())
        && u.chars().all(|c| c.is_ascii_alphanumeric() || matches!(c, '.' | '_' | '-'));
    if valid {
        Ok(u)
    } else {
        Err(AppError::Validation(
            "Usuário deve ter de 3 a 32 caracteres (letras, números, ponto, hífen ou sublinhado).".into(),
        ))
    }
}

pub fn validate_full_name(raw: &str) -> AppResult<String> {
    let n = raw.trim();
    if n.chars().count() < 3 || n.chars().count() > 120 {
        return Err(AppError::Validation("Informe o nome completo.".into()));
    }
    Ok(n.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn username_rules() {
        assert_eq!(normalize_username("  Ricardo.Martins ").unwrap(), "ricardo.martins");
        assert!(normalize_username("ab").is_err());
        assert!(normalize_username("com espaço").is_err());
    }
}
