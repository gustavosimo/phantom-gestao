use crate::error::{AppError, AppResult};

pub fn digits(s: &str) -> String {
    s.chars().filter(|c| c.is_ascii_digit()).collect()
}

fn check_digit(nums: &[u32], weights: &[u32]) -> u32 {
    let sum: u32 = nums.iter().zip(weights).map(|(n, w)| n * w).sum();
    let r = sum % 11;
    if r < 2 { 0 } else { 11 - r }
}

pub fn is_valid_cpf(raw: &str) -> bool {
    let d: Vec<u32> = digits(raw).chars().filter_map(|c| c.to_digit(10)).collect();
    if d.len() != 11 || d.iter().all(|x| *x == d[0]) {
        return false;
    }
    let w1: Vec<u32> = (2..=10).rev().collect();
    let w2: Vec<u32> = (2..=11).rev().collect();
    check_digit(&d[..9], &w1) == d[9] && check_digit(&d[..10], &w2) == d[10]
}

pub fn is_valid_cnpj(raw: &str) -> bool {
    let d: Vec<u32> = digits(raw).chars().filter_map(|c| c.to_digit(10)).collect();
    if d.len() != 14 || d.iter().all(|x| *x == d[0]) {
        return false;
    }
    let w1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    let w2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    check_digit(&d[..12], &w1) == d[12] && check_digit(&d[..13], &w2) == d[13]
}

/// Valida e normaliza o documento (somente dígitos) conforme o tipo de pessoa.
pub fn normalize_document(kind: &str, raw: &str) -> AppResult<String> {
    let d = digits(raw);
    match kind {
        "PF" if is_valid_cpf(&d) => Ok(d),
        "PF" => Err(AppError::Validation("CPF inválido.".into())),
        "PJ" if is_valid_cnpj(&d) => Ok(d),
        "PJ" => Err(AppError::Validation("CNPJ inválido.".into())),
        _ => Err(AppError::Validation("Tipo de pessoa inválido.".into())),
    }
}

/// Mascara o documento para listagens: 123.***.***-45 / 12.***.***/0001-90.
pub fn mask_document(d: &str) -> String {
    match d.len() {
        11 => format!("{}.***.***-{}", &d[..3], &d[9..]),
        14 => format!("{}.***.***/{}-{}", &d[..2], &d[8..12], &d[12..]),
        _ => "***".into(),
    }
}

pub fn format_document(d: &str) -> String {
    match d.len() {
        11 => format!("{}.{}.{}-{}", &d[..3], &d[3..6], &d[6..9], &d[9..]),
        14 => format!("{}.{}.{}/{}-{}", &d[..2], &d[2..5], &d[5..8], &d[8..12], &d[12..]),
        _ => d.to_string(),
    }
}

pub fn validate_email(raw: &str) -> AppResult<()> {
    let e = raw.trim();
    let ok = e.contains('@')
        && !e.starts_with('@')
        && !e.ends_with('@')
        && e.split('@').nth(1).is_some_and(|d| d.contains('.') && !d.ends_with('.'))
        && !e.contains(' ');
    if ok { Ok(()) } else { Err(AppError::Validation("E-mail inválido.".into())) }
}

pub fn validate_phone(raw: &str) -> AppResult<String> {
    let d = digits(raw);
    if (10..=11).contains(&d.len()) { Ok(d) } else { Err(AppError::Validation("Telefone inválido (use DDD + número).".into())) }
}

pub fn parse_date(raw: &str) -> AppResult<chrono::NaiveDate> {
    chrono::NaiveDate::parse_from_str(raw.trim(), "%Y-%m-%d")
        .map_err(|_| AppError::Validation("Data inválida (use AAAA-MM-DD).".into()))
}

pub fn require_text(raw: &str, label: &str, max: usize) -> AppResult<String> {
    let t = raw.trim();
    if t.is_empty() || t.chars().count() > max {
        return Err(AppError::Validation(format!("{label} é obrigatório (até {max} caracteres).")));
    }
    Ok(t.to_string())
}

pub fn opt_text(raw: &Option<String>) -> Option<String> {
    raw.as_ref().map(|s| s.trim().to_string()).filter(|s| !s.is_empty())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cpf() {
        assert!(is_valid_cpf("529.982.247-25"));
        assert!(!is_valid_cpf("529.982.247-24"));
        assert!(!is_valid_cpf("111.111.111-11"));
        assert!(!is_valid_cpf("123"));
    }

    #[test]
    fn cnpj() {
        assert!(is_valid_cnpj("11.222.333/0001-81"));
        assert!(!is_valid_cnpj("11.222.333/0001-82"));
        assert!(!is_valid_cnpj("00000000000000"));
    }

    #[test]
    fn masks() {
        assert_eq!(mask_document("52998224725"), "529.***.***-25");
        assert_eq!(mask_document("11222333000181"), "11.***.***/0001-81");
        assert_eq!(format_document("52998224725"), "529.982.247-25");
    }

    #[test]
    fn normalize_by_kind() {
        assert_eq!(normalize_document("PF", "529.982.247-25").unwrap(), "52998224725");
        assert!(normalize_document("PJ", "529.982.247-25").is_err());
    }

    #[test]
    fn email_phone() {
        assert!(validate_email("a@b.com").is_ok());
        assert!(validate_email("a@b").is_err());
        assert_eq!(validate_phone("(11) 98421-0012").unwrap(), "11984210012");
        assert!(validate_phone("123").is_err());
    }
}
