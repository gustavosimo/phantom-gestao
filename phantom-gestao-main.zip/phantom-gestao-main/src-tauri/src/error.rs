use serde::{Serialize, Serializer};

/// Erro de aplicação. Apenas a mensagem é exposta ao frontend; detalhes
/// internos (SQL, hashing) nunca atravessam a fronteira dos comandos.
#[derive(Debug, thiserror::Error)]
pub enum AppError {
    #[error("{0}")]
    Validation(String),
    #[error("Usuário ou senha inválidos.")]
    InvalidCredentials,
    #[error("Acesso temporariamente bloqueado por excesso de tentativas. Tente novamente em {0} minuto(s).")]
    Locked(i64),
    #[error("Usuário inativo. Procure um administrador.")]
    Inactive,
    #[error("Sessão não iniciada.")]
    Unauthenticated,
    #[error("Você não tem permissão para esta ação.")]
    Forbidden,
    #[error("A configuração inicial já foi concluída.")]
    AlreadyConfigured,
    #[error("Erro interno. Consulte os registros do sistema.")]
    Internal(String),
}

impl From<rusqlite::Error> for AppError {
    fn from(e: rusqlite::Error) -> Self {
        AppError::Internal(e.to_string())
    }
}

impl Serialize for AppError {
    fn serialize<S: Serializer>(&self, s: S) -> Result<S::Ok, S::Error> {
        s.serialize_str(&self.to_string())
    }
}

pub type AppResult<T> = Result<T, AppError>;
