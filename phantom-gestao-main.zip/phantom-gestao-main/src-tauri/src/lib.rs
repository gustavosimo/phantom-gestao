mod commands;
mod database;
mod domain;
mod error;
mod repositories;
mod security;
mod services;
mod web;
#[cfg(test)]
mod testutil;

use std::time::Duration;

use tauri::Manager;

/// Agendador de regras de notificação (sem IA): roda ao iniciar e a cada 30 minutos.
fn spawn_scheduler(app: tauri::AppHandle) {
    std::thread::spawn(move || loop {
        {
            let db = app.state::<database::Database>();
            match db.conn() {
                Ok(conn) => {
                    if let Err(e) = services::notification_service::run_rules(&conn) {
                        eprintln!("[agendador] falha ao executar regras: {e:?}");
                    }
                }
                Err(e) => eprintln!("[agendador] banco indisponível: {e:?}"),
            }
        }
        std::thread::sleep(Duration::from_secs(30 * 60));
    });
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_opener::init())
        .setup(|app| {
            // PHANTOM_DATA_DIR permite usar outra pasta de dados (testes e execuções isoladas).
            let dir = match std::env::var_os("PHANTOM_DATA_DIR") {
                Some(d) => std::path::PathBuf::from(d),
                None => app.path().app_data_dir()?,
            };
            std::fs::create_dir_all(&dir)?;
            let db = database::Database::open(&dir.join("phantom.db"))?;
            let vault = security::vault::Vault::open(&dir.join("vault"))?;
            {
                let mut conn = db.conn()?;
                if let Err(e) = services::document_refresh::refresh_all(&mut conn, &vault) {
                    eprintln!("[documentos] falha ao atualizar layout: {e:?}");
                }
                match services::contract_service::refresh_layouts(&mut conn, &vault) {
                    Ok(n) if n > 0 => eprintln!("[contratos] {n} contrato(s) atualizados para o layout institucional"),
                    Ok(_) => {}
                    Err(e) => eprintln!("[contratos] falha ao atualizar layout: {e:?}"),
                }
            }
            app.manage(db);
            app.manage(vault);
            app.manage(security::session::SessionState::default());
            app.manage(commands::system::AppPaths { data_dir: dir });
            spawn_scheduler(app.handle().clone());
            web::start_if_enabled(app.handle().clone());
            Ok(())
        })
        .invoke_handler(commands::app_handler!())
        .run(tauri::generate_context!())
        .expect("erro ao executar o Phantom Gestão");
}
