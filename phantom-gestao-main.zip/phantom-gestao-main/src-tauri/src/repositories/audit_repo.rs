use rusqlite::Connection;
use serde::Serialize;

use crate::domain::user::User;
use crate::error::AppResult;
use crate::repositories::{pick_sort, Page, PageQuery};

pub fn record(
    conn: &Connection,
    user_id: Option<i64>,
    username: Option<&str>,
    action: &str,
    entity: Option<&str>,
    details: Option<&str>,
) -> AppResult<()> {
    conn.execute(
        "INSERT INTO audit_logs (user_id, username, action, entity, details)
         VALUES (?1, ?2, ?3, ?4, ?5)",
        (user_id, username, action, entity, details),
    )?;
    Ok(())
}

/// Registra uma ação de negócio do usuário autenticado.
pub fn log(conn: &Connection, user: &User, action: &str, entity: &str, entity_id: i64, details: &str) -> AppResult<()> {
    conn.execute(
        "INSERT INTO audit_logs (user_id, username, action, entity, entity_id, details)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
        (user.id, &user.username, action, entity, entity_id.to_string(), details),
    )?;
    Ok(())
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AuditRow {
    pub id: i64,
    pub occurred_at: String,
    pub username: Option<String>,
    pub action: String,
    pub entity: Option<String>,
    pub entity_id: Option<String>,
    pub details: Option<String>,
}

pub fn list(conn: &Connection, q: &PageQuery) -> AppResult<Page<AuditRow>> {
    let like = q.like();
    let where_sql = "WHERE (?1 IS NULL OR action LIKE ?1 OR username LIKE ?1 OR entity LIKE ?1 OR details LIKE ?1)";
    let total: i64 = conn.query_row(&format!("SELECT COUNT(*) FROM audit_logs {where_sql}"), [&like], |r| r.get(0))?;
    let sort = pick_sort(&q.sort, &[("occurredAt", "id"), ("action", "action"), ("username", "username")], "id");
    let sql = format!(
        "SELECT id, occurred_at, username, action, entity, entity_id, details FROM audit_logs {where_sql}
         ORDER BY {sort} {} LIMIT ?2 OFFSET ?3",
        if q.sort.is_none() { "DESC" } else { q.dir() }
    );
    let mut stmt = conn.prepare(&sql)?;
    let items = stmt
        .query_map((&like, q.limit(), q.offset()), |r| {
            Ok(AuditRow {
                id: r.get(0)?,
                occurred_at: r.get(1)?,
                username: r.get(2)?,
                action: r.get(3)?,
                entity: r.get(4)?,
                entity_id: r.get(5)?,
                details: r.get(6)?,
            })
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Page::new(items, total, q))
}
