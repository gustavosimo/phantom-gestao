use rusqlite::{Connection, OptionalExtension};
use serde::{Deserialize, Serialize};

use crate::error::{AppError, AppResult};
use crate::repositories::{pick_sort, Page, PageQuery};

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ClientInput {
    pub kind: String,
    pub name: String,
    pub document: String,
    pub rg: Option<String>,
    pub birth_date: Option<String>,
    pub profession: Option<String>,
    pub marital_status: Option<String>,
    pub email: Option<String>,
    pub phone: Option<String>,
    pub phone2: Option<String>,
    pub zip: Option<String>,
    pub street: Option<String>,
    pub number: Option<String>,
    pub complement: Option<String>,
    pub district: Option<String>,
    pub city: Option<String>,
    pub state: Option<String>,
    pub notes: Option<String>,
    pub status: Option<String>,
    pub contact_opt_out: Option<bool>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ClientRow {
    pub id: i64,
    pub kind: String,
    pub name: String,
    pub document: String,
    pub phone: Option<String>,
    pub status: String,
    pub created_at: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ClientDetail {
    pub id: i64,
    pub kind: String,
    pub name: String,
    pub document: String,
    pub document_masked: bool,
    pub rg: Option<String>,
    pub birth_date: Option<String>,
    pub profession: Option<String>,
    pub marital_status: Option<String>,
    pub email: Option<String>,
    pub phone: Option<String>,
    pub phone2: Option<String>,
    pub zip: Option<String>,
    pub street: Option<String>,
    pub number: Option<String>,
    pub complement: Option<String>,
    pub district: Option<String>,
    pub city: Option<String>,
    pub state: Option<String>,
    pub notes: Option<String>,
    pub status: String,
    pub derived_status: String,
    pub contact_opt_out: bool,
    pub created_at: String,
}

const DERIVED: &str = "CASE WHEN c.status = 'active' AND EXISTS (
        SELECT 1 FROM loans l JOIN loan_installments i ON i.loan_id = l.id
        WHERE l.client_id = c.id AND i.status IN ('open','partial') AND i.due_date < ?4)
    THEN 'late' ELSE c.status END";

pub fn exists_document(conn: &Connection, doc: &str, except_id: Option<i64>) -> AppResult<bool> {
    Ok(conn.query_row(
        "SELECT EXISTS(SELECT 1 FROM clients WHERE document = ?1 AND (?2 IS NULL OR id <> ?2))",
        (doc, except_id),
        |r| r.get(0),
    )?)
}

pub fn insert(conn: &Connection, c: &ClientInput, doc: &str, status: &str, user_id: i64) -> AppResult<i64> {
    conn.execute(
        "INSERT INTO clients (kind, name, document, rg, birth_date, profession, marital_status, email, phone, phone2,
            zip, street, number, complement, district, city, state, notes, status, contact_opt_out, created_by)
         VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,?18,?19,?20,?21)",
        rusqlite::params![
            c.kind, c.name.trim(), doc, c.rg, c.birth_date, c.profession, c.marital_status, c.email, c.phone, c.phone2,
            c.zip, c.street, c.number, c.complement, c.district, c.city, c.state, c.notes, status,
            c.contact_opt_out.unwrap_or(false) as i64, user_id
        ],
    )?;
    Ok(conn.last_insert_rowid())
}

pub fn update(conn: &Connection, id: i64, c: &ClientInput, doc: &str, status: &str) -> AppResult<()> {
    let n = conn.execute(
        "UPDATE clients SET kind=?2, name=?3, document=?4, rg=?5, birth_date=?6, profession=?7, marital_status=?8,
            email=?9, phone=?10, phone2=?11, zip=?12, street=?13, number=?14, complement=?15, district=?16, city=?17,
            state=?18, notes=?19, status=?20, contact_opt_out=?21,
            updated_at = strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id = ?1",
        rusqlite::params![
            id, c.kind, c.name.trim(), doc, c.rg, c.birth_date, c.profession, c.marital_status, c.email, c.phone,
            c.phone2, c.zip, c.street, c.number, c.complement, c.district, c.city, c.state, c.notes, status,
            c.contact_opt_out.unwrap_or(false) as i64
        ],
    )?;
    if n == 0 {
        return Err(AppError::Validation("Cliente não encontrado.".into()));
    }
    Ok(())
}

pub fn set_status(conn: &Connection, id: i64, status: &str) -> AppResult<()> {
    conn.execute(
        "UPDATE clients SET status = ?2, updated_at = strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id = ?1",
        (id, status),
    )?;
    Ok(())
}

pub fn get(conn: &Connection, id: i64, today: &str) -> AppResult<ClientDetail> {
    conn.query_row(
        &format!(
            "SELECT c.id, c.kind, c.name, c.document, c.rg, c.birth_date, c.profession, c.marital_status, c.email,
                    c.phone, c.phone2, c.zip, c.street, c.number, c.complement, c.district, c.city, c.state, c.notes,
                    c.status, {DERIVED}, c.contact_opt_out, c.created_at
             FROM clients c WHERE c.id = ?1"
        )
        .replace("?4", "?2"),
        rusqlite::params![id, today],
        |r| {
            Ok(ClientDetail {
                id: r.get(0)?,
                kind: r.get(1)?,
                name: r.get(2)?,
                document: r.get(3)?,
                document_masked: false,
                rg: r.get(4)?,
                birth_date: r.get(5)?,
                profession: r.get(6)?,
                marital_status: r.get(7)?,
                email: r.get(8)?,
                phone: r.get(9)?,
                phone2: r.get(10)?,
                zip: r.get(11)?,
                street: r.get(12)?,
                number: r.get(13)?,
                complement: r.get(14)?,
                district: r.get(15)?,
                city: r.get(16)?,
                state: r.get(17)?,
                notes: r.get(18)?,
                status: r.get(19)?,
                derived_status: r.get(20)?,
                contact_opt_out: r.get::<_, i64>(21)? == 1,
                created_at: r.get(22)?,
            })
        },
    )
    .optional()?
    .ok_or_else(|| AppError::Validation("Cliente não encontrado.".into()))
}

/// Filtro `extra`: período de cadastro ("7d", "30d", "90d", "year").
pub fn list(conn: &Connection, q: &PageQuery, today: &str) -> AppResult<Page<ClientRow>> {
    let like = q.like();
    let digits: Option<String> = q
        .search
        .as_ref()
        .map(|s| s.chars().filter(|c| c.is_ascii_digit()).collect::<String>())
        .filter(|d| d.len() >= 3)
        .map(|d| format!("%{d}%"));
    let days: Option<i64> = match q.extra.as_deref() {
        Some("7d") => Some(7),
        Some("30d") => Some(30),
        Some("90d") => Some(90),
        Some("year") => Some(365),
        _ => None,
    };
    let derived = DERIVED.replace("?4", "?4");
    let base = format!(
        "FROM (SELECT c.*, {derived} AS dstatus FROM clients c) c
         WHERE (?1 IS NULL OR c.name LIKE ?1 OR c.document LIKE COALESCE(?2, '%@@none@@%') OR c.email LIKE ?1)
           AND (?3 IS NULL OR c.dstatus = ?3)
           AND (?5 IS NULL OR c.created_at >= date(?4, '-' || ?5 || ' days'))
           AND (?6 IS NULL OR c.kind = ?6)"
    );
    let total: i64 = conn.query_row(
        &format!("SELECT COUNT(*) {base}"),
        rusqlite::params![like, digits, q.status, today, days, q.category],
        |r| r.get(0),
    )?;
    let sort = pick_sort(
        &q.sort,
        &[("name", "c.name COLLATE NOCASE"), ("createdAt", "c.created_at"), ("status", "c.dstatus")],
        "c.name COLLATE NOCASE",
    );
    let sql = format!(
        "SELECT c.id, c.kind, c.name, c.document, c.phone, c.dstatus, c.created_at {base}
         ORDER BY {sort} {} LIMIT ?7 OFFSET ?8",
        q.dir()
    );
    let mut stmt = conn.prepare(&sql)?;
    let items = stmt
        .query_map(rusqlite::params![like, digits, q.status, today, days, q.category, q.limit(), q.offset()], |r| {
            Ok(ClientRow {
                id: r.get(0)?,
                kind: r.get(1)?,
                name: r.get(2)?,
                document: r.get(3)?,
                phone: r.get(4)?,
                status: r.get(5)?,
                created_at: r.get(6)?,
            })
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Page::new(items, total, q))
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ClientOption {
    pub id: i64,
    pub name: String,
    pub document: String,
    pub status: String,
}

pub fn options(conn: &Connection, search: &Option<String>) -> AppResult<Vec<ClientOption>> {
    let like = search.as_ref().map(|s| format!("%{}%", s.trim())).filter(|s| s != "%%");
    let mut stmt = conn.prepare(
        "SELECT id, name, document, status FROM clients WHERE status <> 'inactive' AND (?1 IS NULL OR name LIKE ?1 OR document LIKE ?1)
         ORDER BY name COLLATE NOCASE LIMIT 100",
    )?;
    let rows = stmt
        .query_map([like], |r| {
            Ok(ClientOption { id: r.get(0)?, name: r.get(1)?, document: r.get(2)?, status: r.get(3)? })
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ClientSummary {
    pub total_lent_cents: i64,
    pub open_balance_cents: i64,
    pub active_collaterals: i64,
    pub last_purchase_at: Option<String>,
}

pub fn summary(conn: &Connection, id: i64) -> AppResult<ClientSummary> {
    Ok(ClientSummary {
        total_lent_cents: conn.query_row(
            "SELECT COALESCE(SUM(principal_cents),0) FROM loans WHERE client_id = ?1 AND status IN ('active','paid_off','pending_disbursement')",
            [id],
            |r| r.get(0),
        )?,
        open_balance_cents: conn.query_row(
            "SELECT COALESCE(SUM(i.amount_cents - i.paid_cents),0) FROM loan_installments i
             JOIN loans l ON l.id = i.loan_id WHERE l.client_id = ?1 AND i.status IN ('open','partial')",
            [id],
            |r| r.get(0),
        )?,
        active_collaterals: conn.query_row(
            "SELECT COUNT(*) FROM collateral_assets WHERE client_id = ?1 AND status IN ('in_custody','near_deadline','approved','appraising')",
            [id],
            |r| r.get(0),
        )?,
        last_purchase_at: conn.query_row(
            "SELECT MAX(created_at) FROM sales WHERE client_id = ?1 AND status <> 'cancelled'",
            [id],
            |r| r.get(0),
        )?,
    })
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct HistoryRow {
    pub kind: String,
    pub description: String,
    pub amount_cents: Option<i64>,
    pub occurred_at: String,
    pub status: String,
    pub ref_id: i64,
}

/// Histórico de movimentações do cliente em todas as áreas.
pub fn history(conn: &Connection, id: i64, kind: Option<&str>, limit: i64) -> AppResult<Vec<HistoryRow>> {
    let mut stmt = conn.prepare(
        "SELECT * FROM (
            SELECT 'loan' AS kind, 'Contrato #' || l.id || ' · ' || COALESCE(l.purpose, 'Empréstimo') AS description,
                   l.principal_cents AS amount, l.contracted_at AS at, l.status AS status, l.id AS ref_id
              FROM loans l WHERE l.client_id = ?1
            UNION ALL
            SELECT 'collateral', a.name || ' · ' || COALESCE(a.brand,''), a.appraised_cents, a.created_at, a.status, a.id
              FROM collateral_assets a WHERE a.client_id = ?1
            UNION ALL
            SELECT 'payment', COALESCE(p.description, 'Pagamento #' || p.id), p.amount_cents, COALESCE(p.paid_at, p.created_at), p.status, p.id
              FROM payments p WHERE p.client_id = ?1 AND p.origin_type IN ('loan','receivable','payable')
            UNION ALL
            SELECT 'sale', 'Venda #' || s.id, s.total_cents, s.created_at, s.status, s.id
              FROM sales s WHERE s.client_id = ?1
            UNION ALL
            SELECT 'purchase', 'Compra · ' || pu.product_name, pu.amount_cents, pu.created_at, pu.status, pu.id
              FROM purchases pu WHERE pu.seller_client_id = ?1
         ) WHERE (?2 IS NULL OR kind = ?2) ORDER BY at DESC LIMIT ?3",
    )?;
    let rows = stmt
        .query_map(rusqlite::params![id, kind, limit], |r| {
            Ok(HistoryRow {
                kind: r.get(0)?,
                description: r.get(1)?,
                amount_cents: r.get(2)?,
                occurred_at: r.get(3)?,
                status: r.get(4)?,
                ref_id: r.get(5)?,
            })
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ClientDocRow {
    pub id: i64,
    pub doc_type: String,
    pub number: Option<String>,
    pub attachment_id: Option<i64>,
    pub file_name: Option<String>,
    pub expires_at: Option<String>,
    pub created_at: String,
}

pub fn add_document(
    conn: &Connection,
    client_id: i64,
    doc_type: &str,
    number: Option<&str>,
    attachment_id: Option<i64>,
    expires_at: Option<&str>,
) -> AppResult<i64> {
    conn.execute(
        "INSERT INTO client_documents (client_id, doc_type, number, attachment_id, expires_at) VALUES (?1,?2,?3,?4,?5)",
        rusqlite::params![client_id, doc_type, number, attachment_id, expires_at],
    )?;
    Ok(conn.last_insert_rowid())
}

pub fn documents(conn: &Connection, client_id: i64) -> AppResult<Vec<ClientDocRow>> {
    let mut stmt = conn.prepare(
        "SELECT d.id, d.doc_type, d.number, d.attachment_id, a.original_name, d.expires_at, d.created_at
         FROM client_documents d LEFT JOIN attachments a ON a.id = d.attachment_id
         WHERE d.client_id = ?1 ORDER BY d.id DESC",
    )?;
    let rows = stmt
        .query_map([client_id], |r| {
            Ok(ClientDocRow {
                id: r.get(0)?,
                doc_type: r.get(1)?,
                number: r.get(2)?,
                attachment_id: r.get(3)?,
                file_name: r.get(4)?,
                expires_at: r.get(5)?,
                created_at: r.get(6)?,
            })
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}
