use rusqlite::{Connection, OptionalExtension};
use serde::Serialize;

use crate::error::{AppError, AppResult};
use crate::repositories::{pick_sort, Page, PageQuery};

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PurchaseRow {
    pub id: i64,
    pub seller_client_id: Option<i64>,
    pub seller_name: String,
    pub seller_document: Option<String>,
    pub product_id: i64,
    pub product_name: String,
    pub category: String,
    pub qty: i64,
    pub amount_cents: i64,
    pub valuation_cents: Option<i64>,
    pub payment_method: String,
    pub status: String,
    pub origin_proof: Option<String>,
    pub purchased_at: String,
    pub payment_id: Option<i64>,
    pub notes: Option<String>,
}

const PCOLS: &str = "id, seller_client_id, seller_name, seller_document, product_id, product_name, category, qty, amount_cents,
    valuation_cents, payment_method, status, origin_proof, purchased_at, payment_id, notes";

fn pmap(r: &rusqlite::Row) -> rusqlite::Result<PurchaseRow> {
    Ok(PurchaseRow {
        id: r.get(0)?,
        seller_client_id: r.get(1)?,
        seller_name: r.get(2)?,
        seller_document: r.get(3)?,
        product_id: r.get(4)?,
        product_name: r.get(5)?,
        category: r.get(6)?,
        qty: r.get(7)?,
        amount_cents: r.get(8)?,
        valuation_cents: r.get(9)?,
        payment_method: r.get(10)?,
        status: r.get(11)?,
        origin_proof: r.get(12)?,
        purchased_at: r.get(13)?,
        payment_id: r.get(14)?,
        notes: r.get(15)?,
    })
}

pub fn get_purchase(conn: &Connection, id: i64) -> AppResult<PurchaseRow> {
    conn.query_row(&format!("SELECT {PCOLS} FROM purchases WHERE id = ?1"), [id], pmap)
        .optional()?
        .ok_or_else(|| AppError::Validation("Compra não encontrada.".into()))
}

pub fn list_purchases(conn: &Connection, q: &PageQuery) -> AppResult<Page<PurchaseRow>> {
    let like = q.like();
    let w = "WHERE (?1 IS NULL OR product_name LIKE ?1 OR seller_name LIKE ?1) AND (?2 IS NULL OR status = ?2)";
    let total: i64 = conn.query_row(&format!("SELECT COUNT(*) FROM purchases {w}"), rusqlite::params![like, q.status], |r| r.get(0))?;
    let mut stmt = conn.prepare(&format!("SELECT {PCOLS} FROM purchases {w} ORDER BY id DESC LIMIT ?3 OFFSET ?4"))?;
    let items = stmt
        .query_map(rusqlite::params![like, q.status, q.limit(), q.offset()], pmap)?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Page::new(items, total, q))
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SaleRow {
    pub id: i64,
    pub code: String,
    pub client_id: Option<i64>,
    pub client_name: Option<String>,
    pub subtotal_cents: i64,
    pub discount_cents: i64,
    pub total_cents: i64,
    pub payment_method: String,
    pub status: String,
    pub fiscal_status: String,
    pub payment_id: Option<i64>,
    pub cancel_reason: Option<String>,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SaleItemRow {
    pub id: i64,
    pub product_id: i64,
    pub product_name: String,
    pub qty: i64,
    pub unit_price_cents: i64,
    pub unit_cost_cents: i64,
    pub returned_qty: i64,
}

const SCOLS: &str = "s.id, 'VEN-' || printf('%03d', s.id), s.client_id, c.name, s.subtotal_cents, s.discount_cents, s.total_cents,
    s.payment_method, s.status, s.fiscal_status, s.payment_id, s.cancel_reason, s.created_at";

fn smap(r: &rusqlite::Row) -> rusqlite::Result<SaleRow> {
    Ok(SaleRow {
        id: r.get(0)?,
        code: r.get(1)?,
        client_id: r.get(2)?,
        client_name: r.get(3)?,
        subtotal_cents: r.get(4)?,
        discount_cents: r.get(5)?,
        total_cents: r.get(6)?,
        payment_method: r.get(7)?,
        status: r.get(8)?,
        fiscal_status: r.get(9)?,
        payment_id: r.get(10)?,
        cancel_reason: r.get(11)?,
        created_at: r.get(12)?,
    })
}

pub fn get_sale(conn: &Connection, id: i64) -> AppResult<SaleRow> {
    conn.query_row(
        &format!("SELECT {SCOLS} FROM sales s LEFT JOIN clients c ON c.id = s.client_id WHERE s.id = ?1"),
        [id],
        smap,
    )
    .optional()?
    .ok_or_else(|| AppError::Validation("Venda não encontrada.".into()))
}

pub fn sale_items(conn: &Connection, sale_id: i64) -> AppResult<Vec<SaleItemRow>> {
    let mut stmt = conn.prepare(
        "SELECT id, product_id, product_name, qty, unit_price_cents, unit_cost_cents, returned_qty FROM sale_items WHERE sale_id = ?1 ORDER BY id",
    )?;
    let rows = stmt
        .query_map([sale_id], |r| {
            Ok(SaleItemRow {
                id: r.get(0)?,
                product_id: r.get(1)?,
                product_name: r.get(2)?,
                qty: r.get(3)?,
                unit_price_cents: r.get(4)?,
                unit_cost_cents: r.get(5)?,
                returned_qty: r.get(6)?,
            })
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

pub fn list_sales(conn: &Connection, q: &PageQuery) -> AppResult<Page<SaleRow>> {
    let like = q.like();
    let w = "WHERE (?1 IS NULL OR c.name LIKE ?1 OR ('VEN-' || printf('%03d', s.id)) LIKE ?1) AND (?2 IS NULL OR s.status = ?2)";
    let total: i64 = conn.query_row(
        &format!("SELECT COUNT(*) FROM sales s LEFT JOIN clients c ON c.id = s.client_id {w}"),
        rusqlite::params![like, q.status],
        |r| r.get(0),
    )?;
    let sort = pick_sort(&q.sort, &[("total", "s.total_cents"), ("date", "s.created_at")], "s.id");
    let dir = if q.sort.is_some() { q.dir() } else { "DESC" };
    let mut stmt = conn.prepare(&format!(
        "SELECT {SCOLS} FROM sales s LEFT JOIN clients c ON c.id = s.client_id {w} ORDER BY {sort} {dir} LIMIT ?3 OFFSET ?4"
    ))?;
    let items = stmt
        .query_map(rusqlite::params![like, q.status, q.limit(), q.offset()], smap)?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Page::new(items, total, q))
}
