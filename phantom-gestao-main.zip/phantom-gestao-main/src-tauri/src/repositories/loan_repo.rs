use chrono::NaiveDate;
use rusqlite::{Connection, OptionalExtension};
use serde::Serialize;

use crate::error::{AppError, AppResult};
use crate::repositories::{pick_sort, Page, PageQuery};

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct InstallmentRow {
    pub id: i64,
    pub loan_id: i64,
    pub number: i64,
    pub due_date: String,
    pub amount_cents: i64,
    pub principal_cents: i64,
    pub interest_cents: i64,
    pub paid_cents: i64,
    pub late_fee_applied: bool,
    pub interest_through: Option<String>,
    pub status: String,
    pub paid_at: Option<String>,
}

const ICOLS: &str = "id, loan_id, number, due_date, amount_cents, principal_cents, interest_cents, paid_cents,
    late_fee_applied, interest_through, status, paid_at";

fn imap(r: &rusqlite::Row) -> rusqlite::Result<InstallmentRow> {
    Ok(InstallmentRow {
        id: r.get(0)?,
        loan_id: r.get(1)?,
        number: r.get(2)?,
        due_date: r.get(3)?,
        amount_cents: r.get(4)?,
        principal_cents: r.get(5)?,
        interest_cents: r.get(6)?,
        paid_cents: r.get(7)?,
        late_fee_applied: r.get::<_, i64>(8)? == 1,
        interest_through: r.get(9)?,
        status: r.get(10)?,
        paid_at: r.get(11)?,
    })
}

impl InstallmentRow {
    pub fn remaining(&self) -> i64 {
        self.amount_cents - self.paid_cents
    }
    pub fn due(&self) -> NaiveDate {
        NaiveDate::parse_from_str(&self.due_date, "%Y-%m-%d").unwrap_or_default()
    }
    pub fn through(&self) -> Option<NaiveDate> {
        self.interest_through.as_deref().and_then(|d| NaiveDate::parse_from_str(d, "%Y-%m-%d").ok())
    }
}

pub fn installment(conn: &Connection, id: i64) -> AppResult<InstallmentRow> {
    conn.query_row(&format!("SELECT {ICOLS} FROM loan_installments WHERE id = ?1"), [id], imap)
        .optional()?
        .ok_or_else(|| AppError::Validation("Parcela não encontrada.".into()))
}

pub fn installments(conn: &Connection, loan_id: i64, include_renegotiated: bool) -> AppResult<Vec<InstallmentRow>> {
    let mut stmt = conn.prepare(&format!(
        "SELECT {ICOLS} FROM loan_installments WHERE loan_id = ?1 AND (?2 = 1 OR status <> 'renegotiated') ORDER BY id"
    ))?;
    let rows = stmt.query_map((loan_id, include_renegotiated as i64), imap)?.collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

pub fn open_installments(conn: &Connection, loan_id: i64) -> AppResult<Vec<InstallmentRow>> {
    let mut stmt = conn.prepare(&format!(
        "SELECT {ICOLS} FROM loan_installments WHERE loan_id = ?1 AND status IN ('open','partial') ORDER BY due_date, id"
    ))?;
    let rows = stmt.query_map([loan_id], imap)?.collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

pub fn insert_installment(
    conn: &Connection,
    loan_id: i64,
    number: u32,
    due: &str,
    amount: i64,
    principal: i64,
    interest: i64,
) -> AppResult<i64> {
    conn.execute(
        "INSERT INTO loan_installments (loan_id, number, due_date, amount_cents, principal_cents, interest_cents)
         VALUES (?1,?2,?3,?4,?5,?6)",
        rusqlite::params![loan_id, number, due, amount, principal, interest],
    )?;
    Ok(conn.last_insert_rowid())
}

/// Aplica (delta > 0) ou desfaz (delta < 0) um valor pago na parcela e recalcula o status.
pub fn apply_paid(
    conn: &Connection,
    id: i64,
    delta: i64,
    fee_applied: Option<bool>,
    through: Option<&str>,
    today: &str,
) -> AppResult<()> {
    conn.execute(
        "UPDATE loan_installments SET paid_cents = paid_cents + ?2,
            late_fee_applied = COALESCE(?3, late_fee_applied),
            interest_through = COALESCE(?4, interest_through),
            status = CASE WHEN paid_cents + ?2 >= amount_cents THEN 'paid' WHEN paid_cents + ?2 > 0 THEN 'partial' ELSE 'open' END,
            paid_at = CASE WHEN paid_cents + ?2 >= amount_cents THEN ?5 ELSE NULL END
         WHERE id = ?1",
        rusqlite::params![id, delta, fee_applied.map(|b| b as i64), through, today],
    )
    .map_err(|_| AppError::Validation("Valor pago inconsistente com a parcela.".into()))?;
    Ok(())
}

pub fn loan_status(conn: &Connection, loan_id: i64) -> AppResult<String> {
    Ok(conn.query_row("SELECT status FROM loans WHERE id = ?1", [loan_id], |r| r.get(0))?)
}

pub fn set_loan_status(conn: &Connection, loan_id: i64, status: &str, paid_off_at: Option<&str>) -> AppResult<()> {
    conn.execute(
        "UPDATE loans SET status = ?2, paid_off_at = ?3 WHERE id = ?1",
        rusqlite::params![loan_id, status, paid_off_at],
    )?;
    Ok(())
}

pub fn count_open(conn: &Connection, loan_id: i64) -> AppResult<i64> {
    Ok(conn.query_row(
        "SELECT COUNT(*) FROM loan_installments WHERE loan_id = ?1 AND status IN ('open','partial')",
        [loan_id],
        |r| r.get(0),
    )?)
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct LoanRow {
    pub id: i64,
    pub client_id: i64,
    pub client_name: String,
    pub principal_cents: i64,
    pub balance_cents: i64,
    pub term_months: i64,
    pub paid_installments: i64,
    pub total_installments: i64,
    pub next_due: Option<String>,
    pub status: String,
    pub derived_status: String,
    pub contracted_at: String,
}

const LCOLS: &str = "l.id, l.client_id, c.name, l.principal_cents,
    COALESCE((SELECT SUM(i.amount_cents - i.paid_cents) FROM loan_installments i WHERE i.loan_id = l.id AND i.status IN ('open','partial')),0),
    l.term_months,
    (SELECT COUNT(*) FROM loan_installments i WHERE i.loan_id = l.id AND i.status = 'paid'),
    (SELECT COUNT(*) FROM loan_installments i WHERE i.loan_id = l.id AND i.status <> 'renegotiated'),
    (SELECT MIN(i.due_date) FROM loan_installments i WHERE i.loan_id = l.id AND i.status IN ('open','partial')),
    l.status,
    CASE WHEN l.status = 'active' AND EXISTS (SELECT 1 FROM loan_installments i WHERE i.loan_id = l.id AND i.status IN ('open','partial') AND i.due_date < ?1)
         THEN 'late' ELSE l.status END,
    l.contracted_at";

fn lmap(r: &rusqlite::Row) -> rusqlite::Result<LoanRow> {
    Ok(LoanRow {
        id: r.get(0)?,
        client_id: r.get(1)?,
        client_name: r.get(2)?,
        principal_cents: r.get(3)?,
        balance_cents: r.get(4)?,
        term_months: r.get(5)?,
        paid_installments: r.get(6)?,
        total_installments: r.get(7)?,
        next_due: r.get(8)?,
        status: r.get(9)?,
        derived_status: r.get(10)?,
        contracted_at: r.get(11)?,
    })
}

pub fn get_loan(conn: &Connection, id: i64, today: &str) -> AppResult<LoanRow> {
    conn.query_row(
        &format!("SELECT {LCOLS} FROM loans l JOIN clients c ON c.id = l.client_id WHERE l.id = ?2"),
        rusqlite::params![today, id],
        lmap,
    )
    .optional()?
    .ok_or_else(|| AppError::Validation("Empréstimo não encontrado.".into()))
}

/// Filtro `status`: em_dia (ativo sem atraso), late, pending_disbursement, paid_off.
/// Filtro `extra`: vencimento ("7d", "30d", "overdue").
pub fn list_loans(conn: &Connection, q: &PageQuery, today: &str) -> AppResult<Page<LoanRow>> {
    let like = q.like();
    let w = "WHERE (?2 IS NULL OR c.name LIKE ?2 OR CAST(l.id AS TEXT) LIKE ?2 OR ('#' || l.id) LIKE ?2)
        AND (?3 IS NULL OR (CASE WHEN l.status = 'active' AND EXISTS (SELECT 1 FROM loan_installments i WHERE i.loan_id = l.id AND i.status IN ('open','partial') AND i.due_date < ?1) THEN 'late' ELSE l.status END) = ?3)
        AND (?4 IS NULL
             OR (?4 = 'overdue' AND EXISTS (SELECT 1 FROM loan_installments i WHERE i.loan_id = l.id AND i.status IN ('open','partial') AND i.due_date < ?1))
             OR (?4 = '7d' AND EXISTS (SELECT 1 FROM loan_installments i WHERE i.loan_id = l.id AND i.status IN ('open','partial') AND i.due_date BETWEEN ?1 AND date(?1,'+7 days')))
             OR (?4 = '30d' AND EXISTS (SELECT 1 FROM loan_installments i WHERE i.loan_id = l.id AND i.status IN ('open','partial') AND i.due_date BETWEEN ?1 AND date(?1,'+30 days'))))";
    let total: i64 = conn.query_row(
        &format!("SELECT COUNT(*) FROM loans l JOIN clients c ON c.id = l.client_id {w}"),
        rusqlite::params![today, like, q.status, q.extra],
        |r| r.get(0),
    )?;
    let sort = pick_sort(
        &q.sort,
        &[("id", "l.id"), ("client", "c.name COLLATE NOCASE"), ("value", "l.principal_cents"), ("due", "9")],
        "l.id",
    );
    let dir = if q.sort.is_some() { q.dir() } else { "DESC" };
    let mut stmt = conn.prepare(&format!(
        "SELECT {LCOLS} FROM loans l JOIN clients c ON c.id = l.client_id {w} ORDER BY {sort} {dir} LIMIT ?5 OFFSET ?6"
    ))?;
    let items = stmt
        .query_map(rusqlite::params![today, like, q.status, q.extra, q.limit(), q.offset()], lmap)?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Page::new(items, total, q))
}
