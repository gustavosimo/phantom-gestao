pub mod audit_repo;
pub mod client_repo;
pub mod commerce_repo;
pub mod loan_repo;
pub mod payment_repo;
pub mod product_repo;
pub mod settings_repo;
pub mod user_repo;

use serde::{Deserialize, Serialize};

/// Consulta paginada genérica usada pelas listagens.
#[derive(Debug, Clone, Deserialize, Default)]
#[serde(rename_all = "camelCase", default)]
pub struct PageQuery {
    pub page: i64,
    pub page_size: i64,
    pub search: Option<String>,
    pub status: Option<String>,
    pub category: Option<String>,
    pub extra: Option<String>,
    pub sort: Option<String>,
    pub desc: bool,
}

impl PageQuery {
    pub fn limit(&self) -> i64 {
        if self.page_size <= 0 { 20 } else { self.page_size.min(200) }
    }
    pub fn offset(&self) -> i64 {
        (self.page.max(1) - 1) * self.limit()
    }
    pub fn like(&self) -> Option<String> {
        self.search
            .as_ref()
            .map(|s| s.trim())
            .filter(|s| !s.is_empty())
            .map(|s| format!("%{}%", s.replace('%', "").replace('_', "")))
    }
    pub fn dir(&self) -> &'static str {
        if self.desc { "DESC" } else { "ASC" }
    }
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Page<T> {
    pub items: Vec<T>,
    pub total: i64,
    pub page: i64,
    pub page_size: i64,
}

impl<T> Page<T> {
    pub fn new(items: Vec<T>, total: i64, q: &PageQuery) -> Self {
        Self { items, total, page: q.page.max(1), page_size: q.limit() }
    }
}

/// Valida a coluna de ordenação contra uma lista permitida (evita injeção de SQL).
pub fn pick_sort<'a>(requested: &Option<String>, allowed: &[(&'a str, &'a str)], default: &'a str) -> &'a str {
    requested
        .as_deref()
        .and_then(|r| allowed.iter().find(|(k, _)| *k == r).map(|(_, col)| *col))
        .unwrap_or(default)
}
