use rusqlite::{Connection, OptionalExtension};
use serde::{Deserialize, Serialize};

use crate::error::{AppError, AppResult};
use crate::repositories::{pick_sort, Page, PageQuery};

#[derive(Debug, Clone)]
pub struct NewPayment<'a> {
    pub client_id: Option<i64>,
    pub party_name: Option<&'a str>,
    pub direction: &'a str,
    pub origin_type: &'a str,
    pub origin_id: Option<i64>,
    pub description: Option<&'a str>,
    pub amount_cents: i64,
    pub method: &'a str,
    pub status: &'a str,
    pub due_date: Option<&'a str>,
    pub paid_at: Option<&'a str>,
    pub idempotency_key: Option<&'a str>,
    pub user_id: i64,
}

pub fn find_by_key(conn: &Connection, key: &str) -> AppResult<Option<i64>> {
    Ok(conn
        .query_row("SELECT id FROM payments WHERE idempotency_key = ?1", [key], |r| r.get(0))
        .optional()?)
}

pub fn insert(conn: &Connection, p: &NewPayment) -> AppResult<i64> {
    conn.execute(
        "INSERT INTO payments (client_id, party_name, direction, origin_type, origin_id, description, amount_cents,
            method, status, due_date, paid_at, idempotency_key, created_by, confirmed_by)
         VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13, CASE WHEN ?9 = 'confirmed' THEN ?13 END)",
        rusqlite::params![
            p.client_id, p.party_name, p.direction, p.origin_type, p.origin_id, p.description, p.amount_cents,
            p.method, p.status, p.due_date, p.paid_at, p.idempotency_key, p.user_id
        ],
    )?;
    Ok(conn.last_insert_rowid())
}

pub fn insert_cash(
    conn: &Connection,
    kind: &str,
    amount: i64,
    method: &str,
    category: &str,
    description: Option<&str>,
    payment_id: Option<i64>,
    occurred_at: &str,
    user_id: i64,
) -> AppResult<i64> {
    conn.execute(
        "INSERT INTO cash_movements (kind, amount_cents, method, category, description, payment_id, occurred_at, created_by)
         VALUES (?1,?2,?3,?4,?5,?6,?7,?8)",
        rusqlite::params![kind, amount, method, category, description, payment_id, occurred_at, user_id],
    )?;
    Ok(conn.last_insert_rowid())
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PaymentRow {
    pub id: i64,
    pub code: String,
    pub client_id: Option<i64>,
    pub client_name: Option<String>,
    pub direction: String,
    pub origin_type: String,
    pub origin_id: Option<i64>,
    pub description: Option<String>,
    pub amount_cents: i64,
    pub method: String,
    pub status: String,
    pub due_date: Option<String>,
    pub paid_at: Option<String>,
    pub reversal_of_id: Option<i64>,
    pub created_at: String,
}

#[derive(Deserialize, Default)]
#[serde(rename_all = "camelCase", default)]
pub struct PaymentFilter {
    pub origin: Option<String>,
    pub direction: Option<String>,
}

const COLS: &str = "p.id, 'PAG-' || printf('%04d', p.id), p.client_id, COALESCE(c.name, p.party_name), p.direction, p.origin_type,
    p.origin_id, p.description, p.amount_cents, p.method,
    CASE WHEN p.status = 'pending' AND p.due_date IS NOT NULL AND p.due_date < ?1 THEN 'overdue' ELSE p.status END,
    p.due_date, p.paid_at, p.reversal_of_id, p.created_at";

fn map(r: &rusqlite::Row) -> rusqlite::Result<PaymentRow> {
    Ok(PaymentRow {
        id: r.get(0)?,
        code: r.get(1)?,
        client_id: r.get(2)?,
        client_name: r.get(3)?,
        direction: r.get(4)?,
        origin_type: r.get(5)?,
        origin_id: r.get(6)?,
        description: r.get(7)?,
        amount_cents: r.get(8)?,
        method: r.get(9)?,
        status: r.get(10)?,
        due_date: r.get(11)?,
        paid_at: r.get(12)?,
        reversal_of_id: r.get(13)?,
        created_at: r.get(14)?,
    })
}

pub fn get(conn: &Connection, id: i64, today: &str) -> AppResult<PaymentRow> {
    conn.query_row(
        &format!("SELECT {COLS} FROM payments p LEFT JOIN clients c ON c.id = p.client_id WHERE p.id = ?2"),
        rusqlite::params![today, id],
        map,
    )
    .optional()?
    .ok_or_else(|| AppError::Validation("Pagamento não encontrado.".into()))
}

pub fn list(conn: &Connection, q: &PageQuery, f: &PaymentFilter, today: &str) -> AppResult<Page<PaymentRow>> {
    let like = q.like();
    let where_sql = "WHERE (?2 IS NULL OR c.name LIKE ?2 OR p.party_name LIKE ?2 OR ('PAG-' || printf('%04d', p.id)) LIKE ?2 OR p.description LIKE ?2)
        AND (?3 IS NULL OR p.origin_type = ?3)
        AND (?4 IS NULL OR (CASE WHEN p.status = 'pending' AND p.due_date IS NOT NULL AND p.due_date < ?1 THEN 'overdue' ELSE p.status END) = ?4)
        AND (?5 IS NULL OR p.direction = ?5)";
    let params = rusqlite::params![today, like, f.origin, q.status, f.direction];
    let total: i64 = conn.query_row(
        &format!("SELECT COUNT(*) FROM payments p LEFT JOIN clients c ON c.id = p.client_id {where_sql}"),
        params,
        |r| r.get(0),
    )?;
    let sort = pick_sort(
        &q.sort,
        &[("amount", "p.amount_cents"), ("date", "COALESCE(p.paid_at, p.due_date, p.created_at)"), ("client", "COALESCE(c.name, p.party_name)")],
        "p.id",
    );
    let dir = if q.sort.is_some() { q.dir() } else { "DESC" };
    let sql = format!(
        "SELECT {COLS} FROM payments p LEFT JOIN clients c ON c.id = p.client_id {where_sql}
         ORDER BY {sort} {dir} LIMIT ?6 OFFSET ?7"
    );
    let mut stmt = conn.prepare(&sql)?;
    let items = stmt
        .query_map(rusqlite::params![today, like, f.origin, q.status, f.direction, q.limit(), q.offset()], map)?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Page::new(items, total, q))
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CashRow {
    pub id: i64,
    pub kind: String,
    pub amount_cents: i64,
    pub method: String,
    pub category: String,
    pub description: Option<String>,
    pub payment_id: Option<i64>,
    pub occurred_at: String,
    pub reconciled: bool,
}

pub fn cash_list(conn: &Connection, q: &PageQuery) -> AppResult<Page<CashRow>> {
    let rec: Option<i64> = match q.status.as_deref() {
        Some("reconciled") => Some(1),
        Some("unreconciled") => Some(0),
        _ => None,
    };
    let like = q.like();
    let w = "WHERE (?1 IS NULL OR reconciled = ?1) AND (?2 IS NULL OR description LIKE ?2 OR category LIKE ?2)";
    let total: i64 = conn.query_row(&format!("SELECT COUNT(*) FROM cash_movements {w}"), rusqlite::params![rec, like], |r| r.get(0))?;
    let mut stmt = conn.prepare(&format!(
        "SELECT id, kind, amount_cents, method, category, description, payment_id, occurred_at, reconciled
         FROM cash_movements {w} ORDER BY occurred_at DESC, id DESC LIMIT ?3 OFFSET ?4"
    ))?;
    let items = stmt
        .query_map(rusqlite::params![rec, like, q.limit(), q.offset()], |r| {
            Ok(CashRow {
                id: r.get(0)?,
                kind: r.get(1)?,
                amount_cents: r.get(2)?,
                method: r.get(3)?,
                category: r.get(4)?,
                description: r.get(5)?,
                payment_id: r.get(6)?,
                occurred_at: r.get(7)?,
                reconciled: r.get::<_, i64>(8)? == 1,
            })
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Page::new(items, total, q))
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CashSummary {
    pub balance_cents: i64,
    pub inflow_cents: i64,
    pub outflow_cents: i64,
    pub unreconciled_count: i64,
    pub receivable_pending_cents: i64,
    pub payable_pending_cents: i64,
}

pub fn cash_summary(conn: &Connection) -> AppResult<CashSummary> {
    let (inflow, outflow): (i64, i64) = conn.query_row(
        "SELECT COALESCE(SUM(CASE WHEN kind='in' THEN amount_cents END),0), COALESCE(SUM(CASE WHEN kind='out' THEN amount_cents END),0) FROM cash_movements",
        [],
        |r| Ok((r.get(0)?, r.get(1)?)),
    )?;
    let (rec, pay): (i64, i64) = conn.query_row(
        "SELECT COALESCE(SUM(CASE WHEN direction='in' THEN amount_cents END),0), COALESCE(SUM(CASE WHEN direction='out' THEN amount_cents END),0)
         FROM payments WHERE status = 'pending'",
        [],
        |r| Ok((r.get(0)?, r.get(1)?)),
    )?;
    Ok(CashSummary {
        balance_cents: inflow - outflow,
        inflow_cents: inflow,
        outflow_cents: outflow,
        unreconciled_count: conn.query_row("SELECT COUNT(*) FROM cash_movements WHERE reconciled = 0", [], |r| r.get(0))?,
        receivable_pending_cents: rec,
        payable_pending_cents: pay,
    })
}
