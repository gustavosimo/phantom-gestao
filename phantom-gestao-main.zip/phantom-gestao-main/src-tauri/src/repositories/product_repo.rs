use rusqlite::{Connection, OptionalExtension};
use serde::{Deserialize, Serialize};

use crate::error::{AppError, AppResult};
use crate::repositories::{pick_sort, Page, PageQuery};

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ProductInput {
    pub sku: Option<String>,
    pub name: String,
    pub category: String,
    pub brand: Option<String>,
    pub model: Option<String>,
    pub serial_number: Option<String>,
    pub cost_cents: i64,
    pub price_cents: i64,
    pub min_stock: Option<i64>,
    pub active: Option<bool>,
    pub notes: Option<String>,
}

#[derive(Debug, Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct ProductRow {
    pub id: i64,
    pub sku: String,
    pub name: String,
    pub category: String,
    pub brand: Option<String>,
    pub model: Option<String>,
    pub serial_number: Option<String>,
    pub cost_cents: i64,
    pub price_cents: i64,
    pub stock_qty: i64,
    pub reserved_qty: i64,
    pub available_qty: i64,
    pub min_stock: i64,
    pub active: bool,
    pub status: String,
    pub notes: Option<String>,
}

const COLS: &str = "p.id, p.sku, p.name, p.category, p.brand, p.model, p.serial_number, p.cost_cents, p.price_cents,
    p.stock_qty, p.reserved_qty, p.stock_qty - p.reserved_qty, p.min_stock, p.active, p.notes,
    CASE WHEN p.active = 0 THEN 'inactive'
         WHEN p.stock_qty - p.reserved_qty <= 0 THEN 'out'
         WHEN p.stock_qty - p.reserved_qty <= p.min_stock THEN 'low'
         ELSE 'available' END";

fn map(r: &rusqlite::Row) -> rusqlite::Result<ProductRow> {
    Ok(ProductRow {
        id: r.get(0)?,
        sku: r.get(1)?,
        name: r.get(2)?,
        category: r.get(3)?,
        brand: r.get(4)?,
        model: r.get(5)?,
        serial_number: r.get(6)?,
        cost_cents: r.get(7)?,
        price_cents: r.get(8)?,
        stock_qty: r.get(9)?,
        reserved_qty: r.get(10)?,
        available_qty: r.get(11)?,
        min_stock: r.get(12)?,
        active: r.get::<_, i64>(13)? == 1,
        notes: r.get(14)?,
        status: r.get(15)?,
    })
}

pub fn next_sku(conn: &Connection) -> AppResult<String> {
    let n: i64 = conn.query_row("SELECT COALESCE(MAX(id),0) + 1 FROM products", [], |r| r.get(0))?;
    Ok(format!("SKU-{:04}", 1000 + n))
}

pub fn get(conn: &Connection, id: i64) -> AppResult<ProductRow> {
    conn.query_row(&format!("SELECT {COLS} FROM products p WHERE p.id = ?1"), [id], map)
        .optional()?
        .ok_or_else(|| AppError::Validation("Produto não encontrado.".into()))
}

pub fn insert(conn: &Connection, p: &ProductInput, sku: &str) -> AppResult<i64> {
    conn.execute(
        "INSERT INTO products (sku, name, category, brand, model, serial_number, cost_cents, price_cents, min_stock, active, notes)
         VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11)",
        rusqlite::params![
            sku, p.name, p.category, p.brand, p.model, p.serial_number, p.cost_cents, p.price_cents,
            p.min_stock.unwrap_or(1), p.active.unwrap_or(true) as i64, p.notes
        ],
    )
    .map_err(|e| match e {
        rusqlite::Error::SqliteFailure(f, _) if f.code == rusqlite::ErrorCode::ConstraintViolation => {
            AppError::Validation("Código interno já utilizado.".into())
        }
        other => other.into(),
    })?;
    Ok(conn.last_insert_rowid())
}

pub fn update(conn: &Connection, id: i64, p: &ProductInput, sku: &str) -> AppResult<()> {
    let n = conn.execute(
        "UPDATE products SET sku=?2, name=?3, category=?4, brand=?5, model=?6, serial_number=?7, cost_cents=?8,
            price_cents=?9, min_stock=?10, active=?11, notes=?12, updated_at = strftime('%Y-%m-%dT%H:%M:%SZ','now')
         WHERE id = ?1",
        rusqlite::params![
            id, sku, p.name, p.category, p.brand, p.model, p.serial_number, p.cost_cents, p.price_cents,
            p.min_stock.unwrap_or(1), p.active.unwrap_or(true) as i64, p.notes
        ],
    )?;
    if n == 0 {
        return Err(AppError::Validation("Produto não encontrado.".into()));
    }
    Ok(())
}

pub fn add_cost_history(conn: &Connection, product_id: i64, cost: i64, reason: &str, user_id: i64) -> AppResult<()> {
    conn.execute(
        "INSERT INTO product_cost_history (product_id, cost_cents, reason, user_id) VALUES (?1,?2,?3,?4)",
        (product_id, cost, reason, user_id),
    )?;
    Ok(())
}

/// Movimentação de estoque (append-only) + atualização do saldo na mesma transação do chamador.
pub fn move_stock(
    conn: &Connection,
    product_id: i64,
    kind: &str,
    qty: i64,
    unit_cost: Option<i64>,
    reason: Option<&str>,
    ref_type: Option<&str>,
    ref_id: Option<i64>,
    user_id: i64,
) -> AppResult<()> {
    let n = conn.execute(
        "UPDATE products SET stock_qty = stock_qty + ?2, updated_at = strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id = ?1",
        (product_id, qty),
    );
    match n {
        Ok(0) => return Err(AppError::Validation("Produto não encontrado.".into())),
        Ok(_) => {}
        Err(rusqlite::Error::SqliteFailure(f, _)) if f.code == rusqlite::ErrorCode::ConstraintViolation => {
            return Err(AppError::Validation("Estoque insuficiente para a movimentação.".into()));
        }
        Err(e) => return Err(e.into()),
    }
    conn.execute(
        "INSERT INTO inventory_movements (product_id, kind, qty, unit_cost_cents, reason, ref_type, ref_id, user_id)
         VALUES (?1,?2,?3,?4,?5,?6,?7,?8)",
        rusqlite::params![product_id, kind, qty, unit_cost, reason, ref_type, ref_id, user_id],
    )?;
    Ok(())
}

/// Ajusta a quantidade reservada e registra a movimentação (sem alterar o saldo físico).
pub fn reserve(conn: &Connection, product_id: i64, delta: i64, user_id: i64) -> AppResult<()> {
    conn.execute("UPDATE products SET reserved_qty = reserved_qty + ?2 WHERE id = ?1", (product_id, delta))
        .map_err(|_| AppError::Validation("Quantidade reservada inválida.".into()))?;
    conn.execute(
        "INSERT INTO inventory_movements (product_id, kind, qty, user_id) VALUES (?1, ?2, ?3, ?4)",
        (product_id, if delta > 0 { "reserve" } else { "release" }, delta, user_id),
    )?;
    Ok(())
}

pub fn list(conn: &Connection, q: &PageQuery) -> AppResult<Page<ProductRow>> {
    let like = q.like();
    let where_sql = "WHERE (?1 IS NULL OR p.name LIKE ?1 OR p.sku LIKE ?1 OR p.brand LIKE ?1 OR p.model LIKE ?1 OR p.serial_number LIKE ?1)
        AND (?2 IS NULL OR p.category = ?2)
        AND (?3 IS NULL OR (CASE WHEN p.active = 0 THEN 'inactive'
             WHEN p.stock_qty - p.reserved_qty <= 0 THEN 'out'
             WHEN p.stock_qty - p.reserved_qty <= p.min_stock THEN 'low' ELSE 'available' END) = ?3)";
    let total: i64 = conn.query_row(
        &format!("SELECT COUNT(*) FROM products p {where_sql}"),
        rusqlite::params![like, q.category, q.status],
        |r| r.get(0),
    )?;
    let sort = pick_sort(
        &q.sort,
        &[("name", "p.name COLLATE NOCASE"), ("sku", "p.sku"), ("cost", "p.cost_cents"), ("price", "p.price_cents"), ("qty", "p.stock_qty")],
        "p.sku DESC",
    );
    let dir = if q.sort.is_some() { q.dir() } else { "" };
    let sql = format!(
        "SELECT {COLS} FROM products p {where_sql} ORDER BY {sort} {dir} LIMIT ?4 OFFSET ?5"
    );
    let mut stmt = conn.prepare(&sql)?;
    let items = stmt
        .query_map(rusqlite::params![like, q.category, q.status, q.limit(), q.offset()], map)?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Page::new(items, total, q))
}

pub fn categories(conn: &Connection) -> AppResult<Vec<String>> {
    let mut stmt = conn.prepare("SELECT DISTINCT category FROM products ORDER BY category COLLATE NOCASE")?;
    let rows = stmt.query_map([], |r| r.get(0))?.collect::<Result<Vec<String>, _>>()?;
    Ok(rows)
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct MovementRow {
    pub id: i64,
    pub kind: String,
    pub qty: i64,
    pub unit_cost_cents: Option<i64>,
    pub reason: Option<String>,
    pub username: Option<String>,
    pub created_at: String,
}

pub fn movements(conn: &Connection, product_id: i64) -> AppResult<Vec<MovementRow>> {
    let mut stmt = conn.prepare(
        "SELECT m.id, m.kind, m.qty, m.unit_cost_cents, m.reason, u.username, m.created_at
         FROM inventory_movements m LEFT JOIN users u ON u.id = m.user_id
         WHERE m.product_id = ?1 ORDER BY m.id DESC LIMIT 200",
    )?;
    let rows = stmt
        .query_map([product_id], |r| {
            Ok(MovementRow {
                id: r.get(0)?,
                kind: r.get(1)?,
                qty: r.get(2)?,
                unit_cost_cents: r.get(3)?,
                reason: r.get(4)?,
                username: r.get(5)?,
                created_at: r.get(6)?,
            })
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CostRow {
    pub cost_cents: i64,
    pub reason: String,
    pub created_at: String,
}

pub fn cost_history(conn: &Connection, product_id: i64) -> AppResult<Vec<CostRow>> {
    let mut stmt = conn.prepare(
        "SELECT cost_cents, reason, created_at FROM product_cost_history WHERE product_id = ?1 ORDER BY id DESC",
    )?;
    let rows = stmt
        .query_map([product_id], |r| Ok(CostRow { cost_cents: r.get(0)?, reason: r.get(1)?, created_at: r.get(2)? }))?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}
