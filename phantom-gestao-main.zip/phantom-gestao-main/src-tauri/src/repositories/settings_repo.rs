use chrono::{FixedOffset, NaiveDate, Utc};
use rusqlite::{Connection, OptionalExtension};

use crate::error::AppResult;

pub fn get(conn: &Connection, key: &str) -> AppResult<Option<String>> {
    Ok(conn
        .query_row("SELECT value FROM settings WHERE key = ?1", [key], |r| r.get(0))
        .optional()?)
}

pub fn get_or(conn: &Connection, key: &str, default: &str) -> AppResult<String> {
    Ok(get(conn, key)?.unwrap_or_else(|| default.to_string()))
}

pub fn get_i64(conn: &Connection, key: &str, default: i64) -> AppResult<i64> {
    Ok(get(conn, key)?.and_then(|v| v.trim().parse().ok()).unwrap_or(default))
}

pub fn get_bool(conn: &Connection, key: &str) -> AppResult<bool> {
    Ok(get(conn, key)?.is_some_and(|v| v == "true"))
}

pub fn set(conn: &Connection, key: &str, value: &str) -> AppResult<()> {
    conn.execute(
        "INSERT INTO settings (key, value) VALUES (?1, ?2)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value,
             updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')",
        (key, value),
    )?;
    Ok(())
}

pub fn with_prefix(conn: &Connection, prefix: &str) -> AppResult<Vec<(String, String)>> {
    let mut stmt = conn.prepare("SELECT key, value FROM settings WHERE key LIKE ?1 ORDER BY key")?;
    let rows = stmt
        .query_map([format!("{prefix}%")], |r| Ok((r.get(0)?, r.get(1)?)))?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

/// Data/hora local (fuso configurado) no formato AAAA-MM-DDTHH:MM:SS.
pub fn now_local(conn: &Connection) -> String {
    let off = get_i64(conn, "regional.tz_offset_hours", -3).unwrap_or(-3).clamp(-12, 14) as i32;
    let tz = FixedOffset::east_opt(off * 3600).unwrap_or_else(|| FixedOffset::east_opt(0).unwrap());
    Utc::now().with_timezone(&tz).format("%Y-%m-%dT%H:%M:%S").to_string()
}

/// "Hoje" no fuso configurado (padrão: Brasília, UTC-3).
pub fn today(conn: &Connection) -> NaiveDate {
    let off = get_i64(conn, "regional.tz_offset_hours", -3).unwrap_or(-3).clamp(-12, 14) as i32;
    let tz = FixedOffset::east_opt(off * 3600).unwrap_or_else(|| FixedOffset::east_opt(0).unwrap());
    Utc::now().with_timezone(&tz).date_naive()
}
