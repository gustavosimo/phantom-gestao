use rusqlite::{Connection, OptionalExtension};

use crate::domain::user::User;
use crate::error::AppResult;

#[allow(dead_code)]
pub struct UserRecord {
    pub id: i64,
    pub username: String,
    pub full_name: String,
    pub password_hash: String,
    pub role_id: i64,
    pub active: bool,
    pub failed_attempts: i64,
    pub locked_until: Option<String>,
}

pub fn count(conn: &Connection) -> AppResult<i64> {
    Ok(conn.query_row("SELECT COUNT(*) FROM users", [], |r| r.get(0))?)
}

pub fn find_by_username(conn: &Connection, username: &str) -> AppResult<Option<UserRecord>> {
    Ok(conn
        .query_row(
            "SELECT id, username, full_name, password_hash, role_id, active, failed_attempts, locked_until
             FROM users WHERE username = ?1",
            [username],
            |r| {
                Ok(UserRecord {
                    id: r.get(0)?,
                    username: r.get(1)?,
                    full_name: r.get(2)?,
                    password_hash: r.get(3)?,
                    role_id: r.get(4)?,
                    active: r.get::<_, i64>(5)? == 1,
                    failed_attempts: r.get(6)?,
                    locked_until: r.get(7)?,
                })
            },
        )
        .optional()?)
}

pub fn role_id_by_code(conn: &Connection, code: &str) -> AppResult<i64> {
    Ok(conn.query_row("SELECT id FROM roles WHERE code = ?1", [code], |r| r.get(0))?)
}

pub fn insert(
    conn: &Connection,
    username: &str,
    full_name: &str,
    password_hash: &str,
    role_id: i64,
) -> AppResult<i64> {
    conn.execute(
        "INSERT INTO users (username, full_name, password_hash, role_id) VALUES (?1, ?2, ?3, ?4)",
        (username, full_name, password_hash, role_id),
    )?;
    Ok(conn.last_insert_rowid())
}

pub fn register_failure(
    conn: &Connection,
    id: i64,
    max_attempts: i64,
    lock_until: &str,
) -> AppResult<i64> {
    conn.execute(
        "UPDATE users SET failed_attempts = failed_attempts + 1,
             locked_until = CASE WHEN failed_attempts + 1 >= ?2 THEN ?3 ELSE locked_until END,
             updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
         WHERE id = ?1",
        (id, max_attempts, lock_until),
    )?;
    Ok(conn.query_row("SELECT failed_attempts FROM users WHERE id = ?1", [id], |r| r.get(0))?)
}

pub fn register_success(conn: &Connection, id: i64) -> AppResult<()> {
    conn.execute(
        "UPDATE users SET failed_attempts = 0, locked_until = NULL,
             last_login_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now') WHERE id = ?1",
        [id],
    )?;
    Ok(())
}

pub fn load_user(conn: &Connection, id: i64) -> AppResult<User> {
    let (username, full_name, role_code, role_name, role_id): (String, String, String, String, i64) =
        conn.query_row(
            "SELECT u.username, u.full_name, r.code, r.name, r.id
             FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?1",
            [id],
            |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?, r.get(4)?)),
        )?;
    let mut stmt = conn.prepare(
        "SELECT p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id
         WHERE rp.role_id = ?1 ORDER BY p.code",
    )?;
    let permissions = stmt
        .query_map([role_id], |r| r.get::<_, String>(0))?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(User { id, username, full_name, role_code, role_name, permissions })
}
