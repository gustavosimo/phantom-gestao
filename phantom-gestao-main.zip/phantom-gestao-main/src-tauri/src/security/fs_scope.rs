//! Escopo de arquivos do modo web. Enquanto uma chamada web executa, a thread fica "presa" à pasta de
//! uploads: qualquer leitura de caminho fora dela é negada e escritas em disco são proibidas. Assim um
//! navegador remoto nunca lê nem grava arquivos da máquina, não importa em qual campo envie um caminho.
//! No app desktop o escopo nunca é ativado e nada muda.
use std::cell::RefCell;
use std::path::{Path, PathBuf};

use crate::error::{AppError, AppResult};

thread_local! {
    static ROOT: RefCell<Option<PathBuf>> = const { RefCell::new(None) };
}

/// Ativa o escopo na thread atual até ser descartado.
pub struct WebScope(());

impl WebScope {
    pub fn enter(root: &Path) -> Self {
        ROOT.with(|r| *r.borrow_mut() = Some(root.to_path_buf()));
        WebScope(())
    }
}

impl Drop for WebScope {
    fn drop(&mut self) {
        ROOT.with(|r| *r.borrow_mut() = None);
    }
}

/// Leitura de um caminho informado pelo chamador: no modo web só vale dentro da pasta de uploads.
pub fn check_read(path: &Path) -> AppResult<()> {
    ROOT.with(|r| match r.borrow().as_ref() {
        None => Ok(()),
        Some(root) => {
            let (Ok(root), Ok(p)) = (root.canonicalize(), path.canonicalize()) else {
                return Err(AppError::Forbidden);
            };
            if p.starts_with(&root) { Ok(()) } else { Err(AppError::Forbidden) }
        }
    })
}

/// Escrita em caminho informado pelo chamador: proibida no modo web.
pub fn deny_write() -> AppResult<()> {
    ROOT.with(|r| if r.borrow().is_some() { Err(AppError::Forbidden) } else { Ok(()) })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn scope_restricts_reads_and_writes_only_while_active() {
        let dir = std::env::temp_dir().join(format!("phantom-scope-{}", std::process::id()));
        let inside = dir.join("up");
        std::fs::create_dir_all(&inside).unwrap();
        std::fs::write(inside.join("a.pdf"), b"x").unwrap();
        std::fs::write(dir.join("fora.txt"), b"x").unwrap();

        // fora do escopo (desktop): tudo liberado
        assert!(check_read(&dir.join("fora.txt")).is_ok());
        assert!(deny_write().is_ok());

        {
            let _s = WebScope::enter(&inside);
            assert!(check_read(&inside.join("a.pdf")).is_ok());
            assert!(check_read(&dir.join("fora.txt")).is_err());
            assert!(check_read(&inside.join("..").join("fora.txt")).is_err(), "../ não escapa");
            assert!(check_read(&inside.join("nao-existe.pdf")).is_err());
            assert!(deny_write().is_err());
        }
        assert!(check_read(&dir.join("fora.txt")).is_ok(), "escopo é removido ao sair");
        assert!(deny_write().is_ok());
    }
}
