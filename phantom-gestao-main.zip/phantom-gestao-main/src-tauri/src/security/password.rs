use argon2::password_hash::rand_core::OsRng;
use argon2::password_hash::{PasswordHash, PasswordHasher, PasswordVerifier, SaltString};
use argon2::Argon2;

use crate::error::{AppError, AppResult};

pub const MIN_PASSWORD_LEN: usize = 10;

pub fn validate_strength(password: &str) -> AppResult<()> {
    let has_letter = password.chars().any(|c| c.is_alphabetic());
    let has_digit = password.chars().any(|c| c.is_ascii_digit());
    if password.chars().count() < MIN_PASSWORD_LEN || !has_letter || !has_digit {
        return Err(AppError::Validation(format!(
            "A senha deve ter ao menos {MIN_PASSWORD_LEN} caracteres, com letras e números."
        )));
    }
    Ok(())
}

pub fn hash(password: &str) -> AppResult<String> {
    let salt = SaltString::generate(&mut OsRng);
    Argon2::default()
        .hash_password(password.as_bytes(), &salt)
        .map(|h| h.to_string())
        .map_err(|e| AppError::Internal(e.to_string()))
}

pub fn verify(password: &str, phc: &str) -> bool {
    PasswordHash::new(phc)
        .map(|parsed| Argon2::default().verify_password(password.as_bytes(), &parsed).is_ok())
        .unwrap_or(false)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hash_roundtrip_and_no_plaintext() {
        let h = hash("segredo-1234").unwrap();
        assert!(h.starts_with("$argon2id$"));
        assert!(!h.contains("segredo"));
        assert!(verify("segredo-1234", &h));
        assert!(!verify("outra-senha-1", &h));
    }

    #[test]
    fn salts_differ() {
        assert_ne!(hash("segredo-1234").unwrap(), hash("segredo-1234").unwrap());
    }

    #[test]
    fn strength_rules() {
        assert!(validate_strength("curta1").is_err());
        assert!(validate_strength("somenteletrasaqui").is_err());
        assert!(validate_strength("1234567890123").is_err());
        assert!(validate_strength("senhaforte123").is_ok());
    }
}
