use std::sync::Mutex;

use crate::domain::user::User;
use crate::error::{AppError, AppResult};

/// Sessão do usuário autenticado. Vive apenas na memória do processo Rust:
/// o frontend nunca recebe nem armazena token ou credencial.
#[derive(Default)]
pub struct SessionState {
    current: Mutex<Option<User>>,
}

impl SessionState {
    pub fn set(&self, user: User) {
        if let Ok(mut g) = self.current.lock() {
            *g = Some(user);
        }
    }

    pub fn clear(&self) -> Option<User> {
        self.current.lock().ok().and_then(|mut g| g.take())
    }

    pub fn user(&self) -> AppResult<User> {
        self.current
            .lock()
            .ok()
            .and_then(|g| g.clone())
            .ok_or(AppError::Unauthenticated)
    }

    // Usado pelos comandos protegidos a partir da Fase 2.
    #[allow(dead_code)]
    pub fn require(&self, permission: &str) -> AppResult<User> {
        let user = self.user()?;
        if user.permissions.iter().any(|p| p == permission) {
            Ok(user)
        } else {
            Err(AppError::Forbidden)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn user(perms: &[&str]) -> User {
        User {
            id: 1,
            username: "a".into(),
            full_name: "A".into(),
            role_code: "viewer".into(),
            role_name: "Consulta".into(),
            permissions: perms.iter().map(|s| s.to_string()).collect(),
        }
    }

    #[test]
    fn require_checks_permission() {
        let s = SessionState::default();
        assert!(matches!(s.require("x"), Err(AppError::Unauthenticated)));
        s.set(user(&["dashboard.view"]));
        assert!(s.require("dashboard.view").is_ok());
        assert!(matches!(s.require("users.manage"), Err(AppError::Forbidden)));
        s.clear();
        assert!(s.user().is_err());
    }
}
