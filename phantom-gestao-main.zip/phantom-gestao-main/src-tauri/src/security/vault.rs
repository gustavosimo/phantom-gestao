//! Cofre de arquivos: documentos pessoais, fotos e comprovantes são gravados
//! cifrados (AES-256-GCM). A chave fica no cofre de credenciais do sistema
//! operacional (Windows Credential Manager / Keychain / Secret Service) e nunca
//! em texto puro no disco ou no banco.

use std::path::{Path, PathBuf};
use std::sync::RwLock;

use aes_gcm::aead::{Aead, KeyInit, OsRng};
use aes_gcm::{Aes256Gcm, Key, Nonce};
use aes_gcm::aead::rand_core::RngCore;
use base64::Engine;

use crate::error::{AppError, AppResult};

const SERVICE: &str = "br.com.phantomfinanceira.gestao";
const ACCOUNT: &str = "vault-key-v1";

pub struct Vault {
    dir: PathBuf,
    key: RwLock<[u8; 32]>,
}

fn load_or_create_key() -> AppResult<[u8; 32]> {
    let err = |e: keyring::Error| AppError::Internal(format!("cofre de credenciais indisponível: {e}"));
    let entry = keyring::Entry::new(SERVICE, ACCOUNT).map_err(err)?;
    match entry.get_password() {
        Ok(b64) => {
            let raw = base64::engine::general_purpose::STANDARD
                .decode(b64)
                .map_err(|e| AppError::Internal(e.to_string()))?;
            raw.try_into().map_err(|_| AppError::Internal("chave do cofre corrompida".into()))
        }
        Err(keyring::Error::NoEntry) => {
            let mut key = [0u8; 32];
            OsRng.fill_bytes(&mut key);
            entry
                .set_password(&base64::engine::general_purpose::STANDARD.encode(key))
                .map_err(err)?;
            Ok(key)
        }
        Err(e) => Err(err(e)),
    }
}

fn derive(passphrase: &str, salt: &[u8]) -> AppResult<[u8; 32]> {
    let mut out = [0u8; 32];
    argon2::Argon2::default()
        .hash_password_into(passphrase.as_bytes(), salt, &mut out)
        .map_err(|e| AppError::Internal(e.to_string()))?;
    Ok(out)
}

impl Vault {
    pub fn open(dir: &Path) -> AppResult<Self> {
        std::fs::create_dir_all(dir).map_err(|e| AppError::Internal(e.to_string()))?;
        Ok(Self { dir: dir.to_path_buf(), key: RwLock::new(load_or_create_key()?) })
    }

    #[cfg(test)]
    pub fn with_key(dir: &Path, key: [u8; 32]) -> Self {
        std::fs::create_dir_all(dir).unwrap();
        Self { dir: dir.to_path_buf(), key: RwLock::new(key) }
    }


    /// Valida a senha de um blob de chave sem alterar o cofre atual.
    pub fn import_probe(blob: &[u8], passphrase: &str) -> AppResult<()> {
        let tmp = Vault { dir: PathBuf::new(), key: RwLock::new([0u8; 32]) };
        tmp.import_key(blob, passphrase, false)
    }

    pub fn dir(&self) -> &Path {
        &self.dir
    }

    /// Exporta a chave do cofre protegida por uma senha de backup (Argon2id + AES-256-GCM).
    pub fn export_key(&self, passphrase: &str) -> AppResult<Vec<u8>> {
        let mut salt = [0u8; 16];
        OsRng.fill_bytes(&mut salt);
        let wrap = derive(passphrase, &salt)?;
        let mut nonce = [0u8; 12];
        OsRng.fill_bytes(&mut nonce);
        let key = *self.key.read().unwrap_or_else(|e| e.into_inner());
        let ct = Aes256Gcm::new(Key::<Aes256Gcm>::from_slice(&wrap))
            .encrypt(Nonce::from_slice(&nonce), key.as_slice())
            .map_err(|_| AppError::Internal("falha ao proteger a chave".into()))?;
        let mut out = salt.to_vec();
        out.extend(nonce);
        out.extend(ct);
        Ok(out)
    }

    /// Importa a chave de um backup. `persist` grava também no cofre de credenciais do sistema.
    pub fn import_key(&self, blob: &[u8], passphrase: &str, persist: bool) -> AppResult<()> {
        if blob.len() < 16 + 12 + 16 {
            return Err(AppError::Validation("Arquivo de chave do backup inválido.".into()));
        }
        let (salt, rest) = blob.split_at(16);
        let (nonce, ct) = rest.split_at(12);
        let wrap = derive(passphrase, salt)?;
        let raw = Aes256Gcm::new(Key::<Aes256Gcm>::from_slice(&wrap))
            .decrypt(Nonce::from_slice(nonce), ct)
            .map_err(|_| AppError::Validation("Senha do backup incorreta.".into()))?;
        let key: [u8; 32] = raw.try_into().map_err(|_| AppError::Validation("Chave do backup corrompida.".into()))?;
        if persist {
            let entry = keyring::Entry::new(SERVICE, ACCOUNT).map_err(|e| AppError::Internal(e.to_string()))?;
            entry
                .set_password(&base64::engine::general_purpose::STANDARD.encode(key))
                .map_err(|e| AppError::Internal(e.to_string()))?;
        }
        *self.key.write().unwrap_or_else(|e| e.into_inner()) = key;
        Ok(())
    }
    fn cipher(&self) -> Aes256Gcm {
        let key = *self.key.read().unwrap_or_else(|e| e.into_inner());
        Aes256Gcm::new(Key::<Aes256Gcm>::from_slice(&key))
    }

    pub fn encrypt(&self, plain: &[u8]) -> AppResult<Vec<u8>> {
        let mut nonce = [0u8; 12];
        OsRng.fill_bytes(&mut nonce);
        let ct = self
            .cipher()
            .encrypt(Nonce::from_slice(&nonce), plain)
            .map_err(|_| AppError::Internal("falha ao cifrar".into()))?;
        let mut out = nonce.to_vec();
        out.extend(ct);
        Ok(out)
    }

    pub fn decrypt(&self, blob: &[u8]) -> AppResult<Vec<u8>> {
        if blob.len() < 28 {
            return Err(AppError::Internal("arquivo do cofre inválido".into()));
        }
        let (nonce, ct) = blob.split_at(12);
        self.cipher()
            .decrypt(Nonce::from_slice(nonce), ct)
            .map_err(|_| AppError::Internal("falha ao decifrar (chave incorreta ou arquivo alterado)".into()))
    }

    /// Cifra e grava; devolve o nome interno aleatório do arquivo.
    pub fn store(&self, plain: &[u8]) -> AppResult<String> {
        let mut id = [0u8; 16];
        OsRng.fill_bytes(&mut id);
        let name: String = id.iter().map(|b| format!("{b:02x}")).collect::<String>() + ".bin";
        std::fs::write(self.dir.join(&name), self.encrypt(plain)?)
            .map_err(|e| AppError::Internal(e.to_string()))?;
        Ok(name)
    }

    pub fn load(&self, stored_name: &str) -> AppResult<Vec<u8>> {
        if stored_name.contains(['/', '\\']) || stored_name.contains("..") {
            return Err(AppError::Forbidden);
        }
        let blob = std::fs::read(self.dir.join(stored_name))
            .map_err(|e| AppError::Internal(format!("arquivo não encontrado: {e}")))?;
        self.decrypt(&blob)
    }

    pub fn encrypt_text(&self, s: &str) -> AppResult<String> {
        Ok(base64::engine::general_purpose::STANDARD.encode(self.encrypt(s.as_bytes())?))
    }

    #[cfg(test)]
    pub fn decrypt_text(&self, b64: &str) -> AppResult<String> {
        let raw = base64::engine::general_purpose::STANDARD
            .decode(b64)
            .map_err(|e| AppError::Internal(e.to_string()))?;
        String::from_utf8(self.decrypt(&raw)?).map_err(|e| AppError::Internal(e.to_string()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tmp(name: &str) -> PathBuf {
        let d = std::env::temp_dir().join(format!("phantom-vault-{name}-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&d);
        d
    }

    #[test]
    fn roundtrip_and_ciphertext_differs() {
        let v = Vault::with_key(&tmp("a"), [7u8; 32]);
        let name = v.store(b"CPF 123.456.789-09").unwrap();
        let raw = std::fs::read(v.dir.join(&name)).unwrap();
        assert!(!raw.windows(3).any(|w| w == b"CPF"));
        assert_eq!(v.load(&name).unwrap(), b"CPF 123.456.789-09");
    }

    #[test]
    fn tamper_and_wrong_key_fail() {
        let dir = tmp("b");
        let v = Vault::with_key(&dir, [1u8; 32]);
        let name = v.store(b"segredo").unwrap();
        assert!(Vault::with_key(&dir, [2u8; 32]).load(&name).is_err());
        let p = dir.join(&name);
        let mut raw = std::fs::read(&p).unwrap();
        *raw.last_mut().unwrap() ^= 1;
        std::fs::write(&p, raw).unwrap();
        assert!(v.load(&name).is_err());
    }

    #[test]
    fn rejects_path_traversal() {
        let v = Vault::with_key(&tmp("c"), [3u8; 32]);
        assert!(matches!(v.load("../x"), Err(AppError::Forbidden)));
    }

    #[test]
    fn key_export_import_roundtrip() {
        let a = Vault::with_key(&tmp("e"), [5u8; 32]);
        let name = a.store(b"documento").unwrap();
        let blob = a.export_key("senha-do-backup-1").unwrap();
        let b = Vault::with_key(a.dir(), [6u8; 32]);
        assert!(b.load(&name).is_err());
        assert!(b.import_key(&blob, "senha-errada-123", false).is_err());
        b.import_key(&blob, "senha-do-backup-1", false).unwrap();
        assert_eq!(b.load(&name).unwrap(), b"documento");
    }

    #[test]
    fn text_roundtrip() {
        let v = Vault::with_key(&tmp("d"), [4u8; 32]);
        assert_eq!(v.decrypt_text(&v.encrypt_text("token-abc").unwrap()).unwrap(), "token-abc");
    }
}
