use rusqlite::{Connection, OptionalExtension};
use serde::Serialize;

use crate::domain::user::User;
use crate::error::{AppError, AppResult};
use crate::security::vault::Vault;

pub const MAX_BYTES: usize = 15 * 1024 * 1024;

#[derive(Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct Attachment {
    pub id: i64,
    pub owner_type: String,
    pub owner_id: i64,
    pub kind: String,
    pub original_name: String,
    pub mime: String,
    pub size_bytes: i64,
    pub created_at: String,
}

fn mime_for(name: &str) -> AppResult<&'static str> {
    let ext = name.rsplit('.').next().unwrap_or("").to_lowercase();
    match ext.as_str() {
        "pdf" => Ok("application/pdf"),
        "png" => Ok("image/png"),
        "jpg" | "jpeg" => Ok("image/jpeg"),
        "webp" => Ok("image/webp"),
        _ => Err(AppError::Validation("Formato não suportado. Use PDF, PNG, JPG ou WEBP.".into())),
    }
}

fn map(r: &rusqlite::Row) -> rusqlite::Result<Attachment> {
    Ok(Attachment {
        id: r.get(0)?,
        owner_type: r.get(1)?,
        owner_id: r.get(2)?,
        kind: r.get(3)?,
        original_name: r.get(4)?,
        mime: r.get(5)?,
        size_bytes: r.get(6)?,
        created_at: r.get(7)?,
    })
}

const COLS: &str = "id, owner_type, owner_id, kind, original_name, mime, size_bytes, created_at";

/// PDF gerado pelo sistema com o cabeçalho institucional (logo + nome da empresa).
pub fn is_branded_pdf(bytes: &[u8]) -> bool {
    bytes.starts_with(b"%PDF") && bytes.windows(7).any(|w| w == b"/Im1 Do")
}

pub fn add_bytes(
    conn: &Connection,
    vault: &Vault,
    user: &User,
    owner_type: &str,
    owner_id: i64,
    kind: &str,
    name: &str,
    bytes: &[u8],
) -> AppResult<Attachment> {
    if bytes.is_empty() || bytes.len() > MAX_BYTES {
        return Err(AppError::Validation("Arquivo vazio ou maior que 15 MB.".into()));
    }
    let mime = mime_for(name)?;
    let stored = vault.store(bytes)?;
    conn.execute(
        "INSERT INTO attachments (owner_type, owner_id, kind, original_name, stored_name, mime, size_bytes, created_by)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
        (owner_type, owner_id, kind, name, stored, mime, bytes.len() as i64, user.id),
    )?;
    let id = conn.last_insert_rowid();
    if is_branded_pdf(bytes) {
        conn.execute("UPDATE attachments SET layout = 2 WHERE id = ?1", [id])?;
    }
    Ok(conn.query_row(&format!("SELECT {COLS} FROM attachments WHERE id = ?1"), [id], map)?)
}

pub fn add_from_path(
    conn: &Connection,
    vault: &Vault,
    user: &User,
    owner_type: &str,
    owner_id: i64,
    kind: &str,
    path: &str,
) -> AppResult<Attachment> {
    let p = std::path::Path::new(path);
    crate::security::fs_scope::check_read(p)?;
    let name = p
        .file_name()
        .and_then(|n| n.to_str())
        .ok_or_else(|| AppError::Validation("Caminho de arquivo inválido.".into()))?;
    mime_for(name)?;
    let meta = std::fs::metadata(p).map_err(|e| AppError::Validation(format!("Não foi possível ler o arquivo: {e}")))?;
    if meta.len() as usize > MAX_BYTES {
        return Err(AppError::Validation("Arquivo maior que 15 MB.".into()));
    }
    let bytes = std::fs::read(p).map_err(|e| AppError::Validation(format!("Não foi possível ler o arquivo: {e}")))?;
    add_bytes(conn, vault, user, owner_type, owner_id, kind, name, &bytes)
}

pub fn list(conn: &Connection, owner_type: &str, owner_id: i64, kind: Option<&str>) -> AppResult<Vec<Attachment>> {
    let mut stmt = conn.prepare(&format!(
        "SELECT {COLS} FROM attachments WHERE owner_type = ?1 AND owner_id = ?2 AND (?3 IS NULL OR kind = ?3) ORDER BY id"
    ))?;
    let rows = stmt.query_map((owner_type, owner_id, kind), map)?.collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

pub fn get(conn: &Connection, id: i64) -> AppResult<Attachment> {
    conn.query_row(&format!("SELECT {COLS} FROM attachments WHERE id = ?1"), [id], map)
        .optional()?
        .ok_or_else(|| AppError::Validation("Anexo não encontrado.".into()))
}

pub fn read(conn: &Connection, vault: &Vault, id: i64) -> AppResult<(Attachment, Vec<u8>)> {
    let meta = get(conn, id)?;
    let stored: String = conn.query_row("SELECT stored_name FROM attachments WHERE id = ?1", [id], |r| r.get(0))?;
    Ok((meta, vault.load(&stored)?))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::testutil::env;

    #[test]
    fn stores_encrypted_and_reads_back() {
        let e = env();
        let conn = e.db.conn().unwrap();
        let a = add_bytes(&conn, &e.vault, &e.admin, "client", 1, "rg", "rg.png", b"\x89PNGdados").unwrap();
        let (meta, bytes) = read(&conn, &e.vault, a.id).unwrap();
        assert_eq!(meta.mime, "image/png");
        assert_eq!(bytes, b"\x89PNGdados");
        assert_eq!(list(&conn, "client", 1, None).unwrap().len(), 1);
    }

    #[test]
    fn rejects_bad_extension_and_empty() {
        let e = env();
        let conn = e.db.conn().unwrap();
        assert!(add_bytes(&conn, &e.vault, &e.admin, "client", 1, "x", "a.exe", b"x").is_err());
        assert!(add_bytes(&conn, &e.vault, &e.admin, "client", 1, "x", "a.pdf", b"").is_err());
    }

    #[test]
    fn web_scope_only_allows_files_inside_upload_root() {
        let e = env();
        let conn = e.db.conn().unwrap();
        let base = std::env::temp_dir().join(format!("phantom-att-scope-{}", std::process::id()));
        let root = base.join("up");
        std::fs::create_dir_all(&root).unwrap();
        std::fs::write(root.join("ok.png"), b"\x89PNGdados").unwrap();
        std::fs::write(base.join("fora.png"), b"\x89PNGsegredo").unwrap();
        let (inside, outside) = (root.join("ok.png"), base.join("fora.png"));
        // desktop (sem escopo): qualquer caminho
        assert!(add_from_path(&conn, &e.vault, &e.admin, "client", 1, "x", outside.to_str().unwrap()).is_ok());
        let _scope = crate::security::fs_scope::WebScope::enter(&root);
        assert!(add_from_path(&conn, &e.vault, &e.admin, "client", 1, "x", inside.to_str().unwrap()).is_ok());
        assert!(matches!(add_from_path(&conn, &e.vault, &e.admin, "client", 1, "x", outside.to_str().unwrap()), Err(AppError::Forbidden)));
        let trav = root.join("..").join("fora.png");
        assert!(matches!(add_from_path(&conn, &e.vault, &e.admin, "client", 1, "x", trav.to_str().unwrap()), Err(AppError::Forbidden)));
    }
}
