use std::sync::OnceLock;

use chrono::{DateTime, Duration, SecondsFormat, Utc};

use crate::database::Database;
use crate::domain::user::{normalize_username, validate_full_name, User};
use crate::error::{AppError, AppResult};
use crate::repositories::{audit_repo, user_repo};
use crate::security::password;

pub const MAX_FAILED_ATTEMPTS: i64 = 5;
pub const LOCK_MINUTES: i64 = 15;

/// Hash descartável usado para igualar o custo de login de usuários inexistentes.
fn dummy_hash() -> &'static str {
    static H: OnceLock<String> = OnceLock::new();
    H.get_or_init(|| password::hash("phantom-dummy-1234").unwrap_or_default())
}

pub fn setup_required(db: &Database) -> AppResult<bool> {
    Ok(user_repo::count(&*db.conn()?)? == 0)
}

/// Cria o primeiro administrador. Só é permitido enquanto não há usuários.
pub fn setup_admin(db: &Database, full_name: &str, username: &str, pass: &str) -> AppResult<User> {
    let full_name = validate_full_name(full_name)?;
    let username = normalize_username(username)?;
    password::validate_strength(pass)?;
    let phc = password::hash(pass)?;

    let mut conn = db.conn()?;
    let tx = conn.transaction()?;
    if user_repo::count(&tx)? > 0 {
        return Err(AppError::AlreadyConfigured);
    }
    let role_id = user_repo::role_id_by_code(&tx, "admin")?;
    let id = user_repo::insert(&tx, &username, &full_name, &phc, role_id)?;
    audit_repo::record(&tx, Some(id), Some(&username), "setup.admin_created", Some("users"), None)?;
    let user = user_repo::load_user(&tx, id)?;
    tx.commit()?;
    Ok(user)
}

pub fn login(db: &Database, username: &str, pass: &str) -> AppResult<User> {
    login_at(db, username, pass, Utc::now())
}

pub fn login_at(db: &Database, username: &str, pass: &str, now: DateTime<Utc>) -> AppResult<User> {
    let username = username.trim().to_lowercase();
    let mut conn = db.conn()?;

    let Some(rec) = user_repo::find_by_username(&conn, &username)? else {
        password::verify(pass, dummy_hash());
        audit_repo::record(&conn, None, Some(&username), "auth.login_failed", None, Some("usuário inexistente"))?;
        return Err(AppError::InvalidCredentials);
    };

    if let Some(until) = rec.locked_until.as_deref().and_then(|s| DateTime::parse_from_rfc3339(s).ok()) {
        let until = until.with_timezone(&Utc);
        if until > now {
            let minutes = ((until - now).num_seconds() + 59) / 60;
            audit_repo::record(&conn, Some(rec.id), Some(&rec.username), "auth.login_blocked", None, None)?;
            return Err(AppError::Locked(minutes));
        }
    }

    if !password::verify(pass, &rec.password_hash) {
        let lock_until = (now + Duration::minutes(LOCK_MINUTES)).to_rfc3339_opts(SecondsFormat::Secs, true);
        let tx = conn.transaction()?;
        let attempts = user_repo::register_failure(&tx, rec.id, MAX_FAILED_ATTEMPTS, &lock_until)?;
        audit_repo::record(&tx, Some(rec.id), Some(&rec.username), "auth.login_failed", None, None)?;
        if attempts >= MAX_FAILED_ATTEMPTS {
            audit_repo::record(&tx, Some(rec.id), Some(&rec.username), "auth.account_locked", None, None)?;
        }
        tx.commit()?;
        return Err(AppError::InvalidCredentials);
    }

    if !rec.active {
        return Err(AppError::Inactive);
    }

    let tx = conn.transaction()?;
    user_repo::register_success(&tx, rec.id)?;
    audit_repo::record(&tx, Some(rec.id), Some(&rec.username), "auth.login", None, None)?;
    let user = user_repo::load_user(&tx, rec.id)?;
    tx.commit()?;
    Ok(user)
}

pub fn logout(db: &Database, user: &User) -> AppResult<()> {
    audit_repo::record(&*db.conn()?, Some(user.id), Some(&user.username), "auth.logout", None, None)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn seeded() -> Database {
        let db = Database::open_in_memory().unwrap();
        setup_admin(&db, "Ricardo Martins", "Ricardo", "senhaforte123").unwrap();
        db
    }

    #[test]
    fn setup_only_once() {
        let db = seeded();
        assert!(!setup_required(&db).unwrap());
        let again = setup_admin(&db, "Outro Nome", "outro", "senhaforte123");
        assert!(matches!(again, Err(AppError::AlreadyConfigured)));
    }

    #[test]
    fn admin_has_all_permissions_and_password_is_hashed() {
        let db = seeded();
        let u = login(&db, "RICARDO", "senhaforte123").unwrap();
        assert_eq!(u.role_code, "admin");
        assert!(u.permissions.contains(&"users.manage".to_string()));
        let hash: String = db
            .conn()
            .unwrap()
            .query_row("SELECT password_hash FROM users", [], |r| r.get(0))
            .unwrap();
        assert!(!hash.contains("senhaforte123"));
    }

    #[test]
    fn wrong_password_and_unknown_user_share_error() {
        let db = seeded();
        assert!(matches!(login(&db, "ricardo", "errada12345"), Err(AppError::InvalidCredentials)));
        assert!(matches!(login(&db, "ninguem", "errada12345"), Err(AppError::InvalidCredentials)));
    }

    #[test]
    fn locks_after_max_failures_then_unlocks() {
        let db = seeded();
        let now = Utc::now();
        for _ in 0..MAX_FAILED_ATTEMPTS {
            let _ = login_at(&db, "ricardo", "errada12345", now);
        }
        assert!(matches!(login_at(&db, "ricardo", "senhaforte123", now), Err(AppError::Locked(_))));
        let later = now + Duration::minutes(LOCK_MINUTES + 1);
        assert!(login_at(&db, "ricardo", "senhaforte123", later).is_ok());
    }

    #[test]
    fn inactive_user_cannot_login() {
        let db = seeded();
        db.conn().unwrap().execute("UPDATE users SET active = 0", []).unwrap();
        assert!(matches!(login(&db, "ricardo", "senhaforte123"), Err(AppError::Inactive)));
    }

    #[test]
    fn login_events_are_audited() {
        let db = seeded();
        let _ = login(&db, "ricardo", "errada12345");
        let u = login(&db, "ricardo", "senhaforte123").unwrap();
        logout(&db, &u).unwrap();
        let actions: Vec<String> = {
            let conn = db.conn().unwrap();
            let mut s = conn.prepare("SELECT action FROM audit_logs ORDER BY id").unwrap();
            s.query_map([], |r| r.get(0)).unwrap().map(|r| r.unwrap()).collect()
        };
        assert_eq!(
            actions,
            ["setup.admin_created", "auth.login_failed", "auth.login", "auth.logout"]
        );
    }

    /// Auxiliar de desenvolvimento (não roda nos testes normais): cria o administrador de uma pasta de dados
    /// isolada para testar o modo web no navegador sem tocar nos dados reais.
    ///
    ///   PHANTOM_DATA_DIR=C:/tmp/phantom-e2e cargo test --lib seed_dev_admin -- --ignored
    ///
    /// Usuário `e2e.admin`, senha `E2E-senha-forte-123` (valores apenas para uso local de teste).
    #[test]
    #[ignore]
    fn seed_dev_admin() {
        let dir = std::path::PathBuf::from(std::env::var("PHANTOM_DATA_DIR").expect("defina PHANTOM_DATA_DIR"));
        std::fs::create_dir_all(&dir).unwrap();
        let db = crate::database::Database::open(&dir.join("phantom.db")).unwrap();
        if setup_required(&db).unwrap() {
            setup_admin(&db, "Administrador E2E", "e2e.admin", "E2E-senha-forte-123").unwrap();
        }
    }
}
