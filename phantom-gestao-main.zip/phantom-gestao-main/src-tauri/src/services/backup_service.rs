use std::path::{Path, PathBuf};

use rusqlite::{backup::Backup, Connection, OpenFlags};
use serde::{Deserialize, Serialize};

use crate::database::{latest_version, Database};
use crate::domain::user::User;
use crate::error::{AppError, AppResult};
use crate::repositories::{audit_repo, settings_repo};
use crate::security::vault::Vault;

const MANIFEST: &str = "manifest.json";

#[derive(Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
struct Manifest {
    app: String,
    schema_version: i64,
    created_at: String,
    vault_files: usize,
}

fn io(e: std::io::Error) -> AppError {
    AppError::Internal(e.to_string())
}

fn check_pass(p: &str) -> AppResult<()> {
    if p.chars().count() < 10 {
        return Err(AppError::Validation("A senha do backup deve ter ao menos 10 caracteres.".into()));
    }
    Ok(())
}

fn copy_dir(src: &Path, dst: &Path) -> AppResult<usize> {
    std::fs::create_dir_all(dst).map_err(io)?;
    let mut n = 0;
    if src.exists() {
        for entry in std::fs::read_dir(src).map_err(io)? {
            let entry = entry.map_err(io)?;
            if entry.file_type().map_err(io)?.is_file() {
                std::fs::copy(entry.path(), dst.join(entry.file_name())).map_err(io)?;
                n += 1;
            }
        }
    }
    Ok(n)
}

/// Cria `phantom-backup-AAAAMMDD-HHMMSS` dentro de `parent` com: banco consistente (VACUUM INTO),
/// arquivos do cofre (já cifrados), chave protegida por senha e manifesto.
pub fn create(db: &Database, vault: &Vault, user: &User, parent: &Path, passphrase: &str) -> AppResult<PathBuf> {
    crate::security::fs_scope::deny_write()?;
    check_pass(passphrase)?;
    if !parent.is_dir() {
        return Err(AppError::Validation("Pasta de destino inválida.".into()));
    }
    let conn = db.conn()?;
    let stamp = chrono::Utc::now().format("%Y%m%d-%H%M%S").to_string();
    let dir = parent.join(format!("phantom-backup-{stamp}"));
    std::fs::create_dir(&dir).map_err(|e| AppError::Validation(format!("Não foi possível criar a pasta do backup: {e}")))?;
    let db_path = dir.join("phantom.db");
    conn.execute("VACUUM INTO ?1", [db_path.to_string_lossy().as_ref()])?;
    let files = copy_dir(vault.dir(), &dir.join("vault"))?;
    std::fs::write(dir.join("key.enc"), vault.export_key(passphrase)?).map_err(io)?;
    let manifest = Manifest { app: "phantom-gestao".into(), schema_version: latest_version(), created_at: stamp, vault_files: files };
    std::fs::write(dir.join(MANIFEST), serde_json::to_vec_pretty(&manifest).map_err(|e| AppError::Internal(e.to_string()))?).map_err(io)?;
    settings_repo::set(&conn, "backup.last_at", &settings_repo::now_local(&conn))?;
    audit_repo::log(&conn, user, "backup.create", "backup", 0, &dir.to_string_lossy())?;
    Ok(dir)
}

/// Verifica a integridade de um backup sem alterar nada.
pub fn verify(dir: &Path) -> AppResult<i64> {
    crate::security::fs_scope::deny_write()?;
    let m: Manifest = serde_json::from_slice(&std::fs::read(dir.join(MANIFEST)).map_err(|_| AppError::Validation("Pasta não é um backup do Phantom Gestão (manifest.json ausente).".into()))?)
        .map_err(|_| AppError::Validation("Manifesto do backup corrompido.".into()))?;
    if m.app != "phantom-gestao" {
        return Err(AppError::Validation("Backup de outro aplicativo.".into()));
    }
    if m.schema_version > latest_version() {
        return Err(AppError::Validation("Backup criado por uma versão mais nova do sistema. Atualize o aplicativo.".into()));
    }
    let src = Connection::open_with_flags(dir.join("phantom.db"), OpenFlags::SQLITE_OPEN_READ_ONLY)
        .map_err(|_| AppError::Validation("Banco do backup ausente ou ilegível.".into()))?;
    let result: String = src.query_row("PRAGMA integrity_check", [], |r| r.get(0))?;
    if result != "ok" {
        return Err(AppError::Validation(format!("Banco do backup corrompido: {result}")));
    }
    if !dir.join("key.enc").is_file() {
        return Err(AppError::Validation("Chave do cofre ausente no backup.".into()));
    }
    Ok(m.schema_version)
}

/// Restaura o backup. Antes, salva o estado atual em `safety_dir`. `persist_key` grava a chave no cofre do SO.
pub fn restore(db: &Database, vault: &Vault, backup_dir: &Path, passphrase: &str, safety_dir: &Path, persist_key: bool) -> AppResult<PathBuf> {
    crate::security::fs_scope::deny_write()?;
    check_pass(passphrase)?;
    verify(backup_dir)?;
    // valida a senha ANTES de tocar em qualquer dado atual
    let key_blob = std::fs::read(backup_dir.join("key.enc")).map_err(io)?;
    Vault::import_probe(&key_blob, passphrase)?;

    std::fs::create_dir_all(safety_dir).map_err(io)?;
    let stamp = chrono::Utc::now().format("%Y%m%d-%H%M%S").to_string();
    let safety = safety_dir.join(format!("pre-restore-{stamp}"));
    std::fs::create_dir_all(&safety).map_err(io)?;
    {
        let conn = db.conn()?;
        conn.execute("VACUUM INTO ?1", [safety.join("phantom.db").to_string_lossy().as_ref()])?;
    }
    copy_dir(vault.dir(), &safety.join("vault"))?;

    {
        let src = Connection::open_with_flags(backup_dir.join("phantom.db"), OpenFlags::SQLITE_OPEN_READ_ONLY)?;
        let mut conn = db.conn()?;
        {
            let bk = Backup::new(&src, &mut conn)?;
            bk.run_to_completion(256, std::time::Duration::from_millis(0), None)?;
        }
        conn.pragma_update(None, "foreign_keys", "ON")?;
    }
    db.migrate()?;
    // substitui os arquivos do cofre pelos do backup
    if vault.dir().exists() {
        for entry in std::fs::read_dir(vault.dir()).map_err(io)? {
            let p = entry.map_err(io)?.path();
            if p.is_file() {
                std::fs::remove_file(p).map_err(io)?;
            }
        }
    }
    copy_dir(&backup_dir.join("vault"), vault.dir())?;
    vault.import_key(&key_blob, passphrase, persist_key)?;
    Ok(safety)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::repositories::client_repo::ClientInput;
    use crate::services::{attachment_service, client_service};
    use crate::testutil::env;

    fn tmpdir(n: &str) -> PathBuf {
        let d = std::env::temp_dir().join(format!("phantom-bk-{n}-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&d);
        std::fs::create_dir_all(&d).unwrap();
        d
    }

    fn make_client(db: &Database, e: &crate::testutil::Env, name: &str, doc: &str) -> i64 {
        let mut conn = db.conn().unwrap();
        let mut c = client_service::tests::input(name, doc);
        c.status = None;
        let c: ClientInput = c;
        client_service::create(&mut conn, &e.admin, c).unwrap()
    }

    #[test]
    fn backup_and_restore_roundtrip_including_vault() {
        let e = env();
        make_client(&e.db, &e, "Antes do Backup", "529.982.247-25");
        let att = {
            let conn = e.db.conn().unwrap();
            attachment_service::add_bytes(&conn, &e.vault, &e.admin, "client", 1, "rg", "rg.png", b"imagem-sensivel").unwrap().id
        };
        let parent = tmpdir("a");
        let bk = create(&e.db, &e.vault, &e.admin, &parent, "senha-backup-123").unwrap();
        assert_eq!(verify(&bk).unwrap(), latest_version());
        // dados criados depois do backup devem desaparecer na restauração
        make_client(&e.db, &e, "Depois do Backup", "390.533.447-05");
        let safety = restore(&e.db, &e.vault, &bk, "senha-backup-123", &tmpdir("s"), false).unwrap();
        assert!(safety.join("phantom.db").is_file());
        let conn = e.db.conn().unwrap();
        let names: Vec<String> = conn.prepare("SELECT name FROM clients ORDER BY id").unwrap().query_map([], |r| r.get(0)).unwrap().map(|r| r.unwrap()).collect();
        assert_eq!(names, ["Antes do Backup"]);
        assert_eq!(attachment_service::read(&conn, &e.vault, att).unwrap().1, b"imagem-sensivel");
    }

    #[test]
    fn wrong_passphrase_changes_nothing() {
        let e = env();
        make_client(&e.db, &e, "Cliente", "529.982.247-25");
        let bk = create(&e.db, &e.vault, &e.admin, &tmpdir("b"), "senha-backup-123").unwrap();
        make_client(&e.db, &e, "Outro", "390.533.447-05");
        assert!(restore(&e.db, &e.vault, &bk, "senha-errada-999", &tmpdir("s2"), false).is_err());
        let n: i64 = e.db.conn().unwrap().query_row("SELECT COUNT(*) FROM clients", [], |r| r.get(0)).unwrap();
        assert_eq!(n, 2);
    }

    #[test]
    fn rejects_bad_inputs() {
        let e = env();
        assert!(create(&e.db, &e.vault, &e.admin, &tmpdir("c"), "curta").is_err());
        assert!(create(&e.db, &e.vault, &e.admin, Path::new("Z:/nao/existe"), "senha-backup-123").is_err());
        assert!(verify(&tmpdir("d")).is_err());
        let bk = create(&e.db, &e.vault, &e.admin, &tmpdir("e"), "senha-backup-123").unwrap();
        std::fs::write(bk.join("phantom.db"), b"nao e sqlite").unwrap();
        assert!(verify(&bk).is_err());
    }
}
