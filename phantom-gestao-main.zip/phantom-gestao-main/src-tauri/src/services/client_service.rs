use rusqlite::Connection;

use crate::domain::user::User;
use crate::domain::validation::*;
use crate::error::{AppError, AppResult};
use crate::repositories::client_repo::{self, ClientDetail, ClientInput};
use crate::repositories::{audit_repo, settings_repo};
use crate::security::vault::Vault;
use crate::services::attachment_service;

fn clean(mut c: ClientInput, existing_doc: Option<&str>) -> AppResult<(ClientInput, String)> {
    c.name = require_text(&c.name, "Nome", 120)?;
    let doc = if c.document.contains('*') {
        existing_doc
            .map(|d| d.to_string())
            .ok_or_else(|| AppError::Validation("Documento inválido.".into()))?
    } else {
        normalize_document(&c.kind, &c.document)?
    };
    c.rg = opt_text(&c.rg);
    c.profession = opt_text(&c.profession);
    c.marital_status = opt_text(&c.marital_status);
    c.notes = opt_text(&c.notes);
    c.complement = opt_text(&c.complement);
    c.street = opt_text(&c.street);
    c.number = opt_text(&c.number);
    c.district = opt_text(&c.district);
    c.city = opt_text(&c.city);
    c.state = opt_text(&c.state).map(|s| s.to_uppercase());
    if let Some(s) = &c.state {
        if s.chars().count() != 2 {
            return Err(AppError::Validation("UF deve ter 2 letras.".into()));
        }
    }
    c.zip = opt_text(&c.zip).map(|z| digits(&z));
    if let Some(z) = &c.zip {
        if z.len() != 8 {
            return Err(AppError::Validation("CEP deve ter 8 dígitos.".into()));
        }
    }
    c.email = opt_text(&c.email);
    if let Some(e) = &c.email {
        validate_email(e)?;
    }
    c.phone = match opt_text(&c.phone) { Some(p) => Some(validate_phone(&p)?), None => None };
    c.phone2 = match opt_text(&c.phone2) { Some(p) => Some(validate_phone(&p)?), None => None };
    c.birth_date = match opt_text(&c.birth_date) {
        Some(d) => {
            let date = parse_date(&d)?;
            if c.kind == "PF" && date > chrono::Utc::now().date_naive() {
                return Err(AppError::Validation("Data de nascimento no futuro.".into()));
            }
            Some(d)
        }
        None => None,
    };
    Ok((c, doc))
}

fn valid_status(s: &str) -> AppResult<()> {
    if matches!(s, "active" | "pending" | "inactive") {
        Ok(())
    } else {
        Err(AppError::Validation("Situação inválida.".into()))
    }
}

pub fn create(conn: &mut Connection, user: &User, input: ClientInput) -> AppResult<i64> {
    let (c, doc) = clean(input, None)?;
    let status = c.status.clone().unwrap_or_else(|| "pending".into());
    valid_status(&status)?;
    let tx = conn.transaction()?;
    if client_repo::exists_document(&tx, &doc, None)? {
        return Err(AppError::Validation("Já existe um cliente com este CPF/CNPJ.".into()));
    }
    let id = client_repo::insert(&tx, &c, &doc, &status, user.id)?;
    audit_repo::log(&tx, user, "client.create", "clients", id, &c.name)?;
    tx.commit()?;
    Ok(id)
}

pub fn update(conn: &mut Connection, user: &User, id: i64, input: ClientInput) -> AppResult<()> {
    let today = settings_repo::today(conn).to_string();
    let current = client_repo::get(conn, id, &today)?;
    let (c, doc) = clean(input, Some(&current.document))?;
    let status = c.status.clone().unwrap_or(current.status.clone());
    valid_status(&status)?;
    let tx = conn.transaction()?;
    if client_repo::exists_document(&tx, &doc, Some(id))? {
        return Err(AppError::Validation("Já existe um cliente com este CPF/CNPJ.".into()));
    }
    client_repo::update(&tx, id, &c, &doc, &status)?;
    audit_repo::log(&tx, user, "client.update", "clients", id, &c.name)?;
    tx.commit()?;
    Ok(())
}

/// Detalhe do cliente. Sem a permissão `clients.sensitive` o documento é mascarado.
pub fn detail(conn: &Connection, user: &User, id: i64) -> AppResult<ClientDetail> {
    let today = settings_repo::today(conn).to_string();
    let mut d = client_repo::get(conn, id, &today)?;
    if user.permissions.iter().any(|p| p == "clients.sensitive") {
        audit_repo::log(conn, user, "client.view_sensitive", "clients", id, "")?;
    } else {
        d.document = mask_document(&d.document);
        d.document_masked = true;
    }
    Ok(d)
}

pub fn set_status(conn: &mut Connection, user: &User, id: i64, status: &str) -> AppResult<()> {
    valid_status(status)?;
    let tx = conn.transaction()?;
    client_repo::set_status(&tx, id, status)?;
    audit_repo::log(&tx, user, "client.status", "clients", id, status)?;
    tx.commit()?;
    Ok(())
}

pub fn add_document(
    conn: &mut Connection,
    vault: &Vault,
    user: &User,
    client_id: i64,
    doc_type: &str,
    number: Option<String>,
    file_path: Option<String>,
    expires_at: Option<String>,
) -> AppResult<i64> {
    let doc_type = require_text(doc_type, "Tipo de documento", 60)?;
    if let Some(e) = &expires_at {
        parse_date(e)?;
    }
    let tx = conn.transaction()?;
    let att = match file_path {
        Some(p) => Some(attachment_service::add_from_path(&tx, vault, user, "client", client_id, &doc_type, &p)?.id),
        None => None,
    };
    let id = client_repo::add_document(&tx, client_id, &doc_type, opt_text(&number).as_deref(), att, expires_at.as_deref())?;
    audit_repo::log(&tx, user, "client.document_add", "clients", client_id, &doc_type)?;
    tx.commit()?;
    Ok(id)
}

#[cfg(test)]
pub(crate) mod tests {
    use super::*;
    use crate::repositories::PageQuery;
    use crate::testutil::env;

    pub fn input(name: &str, doc: &str) -> ClientInput {
        ClientInput {
            kind: "PF".into(), name: name.into(), document: doc.into(), rg: None, birth_date: None,
            profession: None, marital_status: None, email: Some("a@b.com".into()), phone: Some("(11) 98421-0012".into()),
            phone2: None, zip: None, street: None, number: None, complement: None, district: None, city: None,
            state: None, notes: None, status: Some("active".into()), contact_opt_out: None,
        }
    }

    #[test]
    fn create_validates_and_blocks_duplicates() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        assert!(create(&mut conn, &e.admin, input("Maria", "111.111.111-11")).is_err());
        let id = create(&mut conn, &e.admin, input("Maria Souza", "529.982.247-25")).unwrap();
        assert!(id > 0);
        let dup = create(&mut conn, &e.admin, input("Outra", "52998224725"));
        assert!(matches!(dup, Err(AppError::Validation(m)) if m.contains("Já existe")));
    }

    #[test]
    fn masks_without_sensitive_permission() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let id = create(&mut conn, &e.admin, input("Maria Souza", "529.982.247-25")).unwrap();
        let mut viewer = e.admin.clone();
        viewer.permissions.retain(|p| p != "clients.sensitive");
        let d = detail(&conn, &viewer, id).unwrap();
        assert!(d.document_masked && d.document.contains('*'));
        let full = detail(&conn, &e.admin, id).unwrap();
        assert_eq!(full.document, "52998224725");
    }

    #[test]
    fn update_keeps_masked_document() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let id = create(&mut conn, &e.admin, input("Maria Souza", "529.982.247-25")).unwrap();
        update(&mut conn, &e.admin, id, input("Maria S. Souza", "529.***.***-25")).unwrap();
        let d = detail(&conn, &e.admin, id).unwrap();
        assert_eq!((d.name.as_str(), d.document.as_str()), ("Maria S. Souza", "52998224725"));
    }

    #[test]
    fn list_filters_and_paginates() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        for (n, d) in [("Ana", "529.982.247-25"), ("Bruno", "390.533.447-05"), ("Carla", "168.995.350-09")] {
            create(&mut conn, &e.admin, input(n, d)).unwrap();
        }
        let today = settings_repo::today(&conn).to_string();
        let q = PageQuery { page: 1, page_size: 2, ..Default::default() };
        let p = client_repo::list(&conn, &q, &today).unwrap();
        assert_eq!((p.total, p.items.len()), (3, 2));
        let q = PageQuery { search: Some("39053344705".into()), ..Default::default() };
        assert_eq!(client_repo::list(&conn, &q, &today).unwrap().items[0].name, "Bruno");
        let q = PageQuery { status: Some("pending".into()), ..Default::default() };
        assert_eq!(client_repo::list(&conn, &q, &today).unwrap().total, 0);
    }
}
