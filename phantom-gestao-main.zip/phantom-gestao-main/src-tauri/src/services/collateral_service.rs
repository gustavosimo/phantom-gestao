use rusqlite::{Connection, OptionalExtension};
use serde::{Deserialize, Serialize};

use crate::domain::money::format_brl;
use crate::domain::user::User;
use crate::domain::validation::*;
use crate::error::{AppError, AppResult};
use crate::repositories::{audit_repo, pick_sort, settings_repo, Page, PageQuery};
use crate::security::vault::Vault;
use crate::services::contract_service::{condition_label, ref_code};
use crate::services::loan_service::require_collateral_enabled;
use crate::services::{attachment_service, payment_service, pdf::Pdf};

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CollateralInput {
    pub client_id: i64,
    pub category: String,
    pub name: String,
    pub brand: Option<String>,
    pub model: Option<String>,
    pub serial_number: Option<String>,
    pub condition: String,
    pub appraised_cents: Option<i64>,
    pub storage_location: Option<String>,
    pub custody_days: Option<i64>,
    pub notes: Option<String>,
    pub application_id: Option<i64>,
    pub photo_paths: Option<Vec<String>>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CollateralRow {
    pub id: i64,
    pub code: String,
    pub client_id: i64,
    pub client_name: String,
    pub loan_id: Option<i64>,
    pub application_id: Option<i64>,
    pub category: String,
    pub name: String,
    pub brand: Option<String>,
    pub model: Option<String>,
    pub serial_number: Option<String>,
    pub condition: String,
    pub appraised_cents: Option<i64>,
    pub linked_value_cents: Option<i64>,
    pub storage_location: Option<String>,
    pub custody_days: Option<i64>,
    pub custody_start: Option<String>,
    pub custody_due: Option<String>,
    pub days_left: Option<i64>,
    pub notes: Option<String>,
    pub status: String,
    pub display_status: String,
    pub created_at: String,
}

const COLS: &str = "a.id, 'GAR-' || printf('%04d', a.id), a.client_id, c.name, a.loan_id, a.application_id, a.category, a.name, a.brand,
    a.model, a.serial_number, a.condition, a.appraised_cents, a.linked_value_cents, a.storage_location, a.custody_days,
    a.custody_start, a.custody_due,
    CASE WHEN a.status = 'in_custody' AND a.custody_due IS NOT NULL THEN CAST(julianday(a.custody_due) - julianday(?1) AS INTEGER) END,
    a.notes, a.status,
    CASE WHEN a.status = 'in_custody' AND a.custody_due IS NOT NULL AND julianday(a.custody_due) - julianday(?1) <= 7 THEN 'near_deadline'
         WHEN a.status IN ('registered','appraising') THEN 'evaluating' ELSE a.status END,
    a.created_at";

fn map(r: &rusqlite::Row) -> rusqlite::Result<CollateralRow> {
    Ok(CollateralRow {
        id: r.get(0)?, code: r.get(1)?, client_id: r.get(2)?, client_name: r.get(3)?, loan_id: r.get(4)?,
        application_id: r.get(5)?, category: r.get(6)?, name: r.get(7)?, brand: r.get(8)?, model: r.get(9)?,
        serial_number: r.get(10)?, condition: r.get(11)?, appraised_cents: r.get(12)?, linked_value_cents: r.get(13)?,
        storage_location: r.get(14)?, custody_days: r.get(15)?, custody_start: r.get(16)?, custody_due: r.get(17)?,
        days_left: r.get(18)?, notes: r.get(19)?, status: r.get(20)?, display_status: r.get(21)?, created_at: r.get(22)?,
    })
}

pub fn get(conn: &Connection, id: i64) -> AppResult<CollateralRow> {
    let today = settings_repo::today(conn).to_string();
    conn.query_row(
        &format!("SELECT {COLS} FROM collateral_assets a JOIN clients c ON c.id = a.client_id WHERE a.id = ?2"),
        rusqlite::params![today, id],
        map,
    )
    .optional()?
    .ok_or_else(|| AppError::Validation("Garantia não encontrada.".into()))
}

pub fn list(conn: &Connection, q: &PageQuery) -> AppResult<Page<CollateralRow>> {
    let today = settings_repo::today(conn).to_string();
    let like = q.like();
    let w = "WHERE (?2 IS NULL OR a.name LIKE ?2 OR c.name LIKE ?2 OR a.serial_number LIKE ?2 OR ('GAR-' || printf('%04d', a.id)) LIKE ?2)
        AND (?3 IS NULL OR a.category = ?3)
        AND (?4 IS NULL OR (CASE WHEN a.status = 'in_custody' AND a.custody_due IS NOT NULL AND julianday(a.custody_due) - julianday(?1) <= 7 THEN 'near_deadline'
                                 WHEN a.status IN ('registered','appraising') THEN 'evaluating' ELSE a.status END) = ?4)";
    let total: i64 = conn.query_row(
        &format!("SELECT COUNT(*) FROM collateral_assets a JOIN clients c ON c.id = a.client_id {w}"),
        rusqlite::params![today, like, q.category, q.status],
        |r| r.get(0),
    )?;
    let sort = pick_sort(&q.sort, &[("name", "a.name COLLATE NOCASE"), ("value", "a.appraised_cents"), ("due", "a.custody_due")], "a.id");
    let dir = if q.sort.is_some() { q.dir() } else { "DESC" };
    let mut stmt = conn.prepare(&format!(
        "SELECT {COLS} FROM collateral_assets a JOIN clients c ON c.id = a.client_id {w} ORDER BY {sort} {dir} LIMIT ?5 OFFSET ?6"
    ))?;
    let items = stmt
        .query_map(rusqlite::params![today, like, q.category, q.status, q.limit(), q.offset()], map)?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Page::new(items, total, q))
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CollateralStats {
    pub in_custody: i64,
    pub awaiting_appraisal: i64,
    pub near_deadline: i64,
    pub redeemed_month: i64,
}

pub fn stats(conn: &Connection) -> AppResult<CollateralStats> {
    let today = settings_repo::today(conn).to_string();
    let q = |sql: &str| -> AppResult<i64> { Ok(conn.query_row(sql, [&today], |r| r.get(0))?) };
    Ok(CollateralStats {
        in_custody: q("SELECT COUNT(*) FROM collateral_assets WHERE status = 'in_custody' AND ?1 = ?1")?,
        awaiting_appraisal: q("SELECT COUNT(*) FROM collateral_assets WHERE status IN ('registered','appraising') AND ?1 = ?1")?,
        near_deadline: q("SELECT COUNT(*) FROM collateral_assets WHERE status = 'in_custody' AND custody_due IS NOT NULL AND julianday(custody_due) - julianday(?1) <= 7")?,
        redeemed_month: q("SELECT COUNT(*) FROM custody_events WHERE kind = 'redeemed' AND substr(created_at,1,7) = substr(?1,1,7)")?,
    })
}

fn event(conn: &Connection, user: &User, asset_id: i64, kind: &str, desc: &str) -> AppResult<()> {
    conn.execute(
        "INSERT INTO custody_events (asset_id, kind, description, user_id) VALUES (?1,?2,?3,?4)",
        rusqlite::params![asset_id, kind, desc, user.id],
    )?;
    Ok(())
}

pub fn create(conn: &mut Connection, vault: &Vault, user: &User, i: CollateralInput) -> AppResult<i64> {
    let name = require_text(&i.name, "Produto", 120)?;
    let category = require_text(&i.category, "Categoria", 60)?;
    if !matches!(i.condition.as_str(), "new" | "refurbished" | "used" | "damaged") {
        return Err(AppError::Validation("Estado de conservação inválido.".into()));
    }
    if i.appraised_cents.is_some_and(|v| v < 0) || i.custody_days.is_some_and(|d| !(1..=3650).contains(&d)) {
        return Err(AppError::Validation("Avaliação ou prazo de custódia inválido.".into()));
    }
    let tx = conn.transaction()?;
    let st: Option<String> = tx.query_row("SELECT status FROM clients WHERE id = ?1", [i.client_id], |r| r.get(0)).optional()?;
    if st.is_none() {
        return Err(AppError::Validation("Cliente não encontrado.".into()));
    }
    if let Some(sn) = opt_text(&i.serial_number) {
        let dup: bool = tx.query_row(
            "SELECT EXISTS(SELECT 1 FROM collateral_assets WHERE serial_number = ?1 AND status IN ('registered','appraising','approved','in_custody','legal_procedure'))",
            [&sn],
            |r| r.get(0),
        )?;
        if dup {
            return Err(AppError::Validation("Já existe garantia ativa com este número de série/IMEI.".into()));
        }
    }
    tx.execute(
        "INSERT INTO collateral_assets (client_id, application_id, category, name, brand, model, serial_number, condition, storage_location,
            custody_days, notes, status, created_by)
         VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,'registered',?12)",
        rusqlite::params![
            i.client_id, i.application_id, category, name, opt_text(&i.brand), opt_text(&i.model), opt_text(&i.serial_number),
            i.condition, opt_text(&i.storage_location), i.custody_days, opt_text(&i.notes), user.id
        ],
    )?;
    let id = tx.last_insert_rowid();
    event(&tx, user, id, "registered", "Cadastro do bem")?;
    if let Some(v) = i.appraised_cents {
        valuate_in_tx(&tx, user, id, v, Some("Avaliação inicial"))?;
    }
    for p in i.photo_paths.unwrap_or_default().iter().take(8) {
        attachment_service::add_from_path(&tx, vault, user, "collateral", id, "photo", p)?;
    }
    audit_repo::log(&tx, user, "collateral.create", "collateral_assets", id, &name)?;
    tx.commit()?;
    Ok(id)
}

fn valuate_in_tx(tx: &Connection, user: &User, id: i64, value: i64, notes: Option<&str>) -> AppResult<()> {
    if value < 0 {
        return Err(AppError::Validation("Valor de avaliação inválido.".into()));
    }
    let st: String = tx.query_row("SELECT status FROM collateral_assets WHERE id = ?1", [id], |r| r.get(0))?;
    if !matches!(st.as_str(), "registered" | "appraising" | "approved") {
        return Err(AppError::Validation("A avaliação só pode ser alterada antes da custódia.".into()));
    }
    tx.execute(
        "INSERT INTO collateral_valuations (asset_id, value_cents, notes, valued_by) VALUES (?1,?2,?3,?4)",
        rusqlite::params![id, value, notes, user.id],
    )?;
    tx.execute(
        "UPDATE collateral_assets SET appraised_cents = ?2, status = 'appraising', updated_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id = ?1",
        (id, value),
    )?;
    event(tx, user, id, "valuation", &format!("Avaliação concluída — {}", format_brl(value)))?;
    Ok(())
}

pub fn valuate(conn: &mut Connection, user: &User, id: i64, value_cents: i64, notes: Option<String>) -> AppResult<()> {
    let tx = conn.transaction()?;
    valuate_in_tx(&tx, user, id, value_cents, notes.as_deref())?;
    audit_repo::log(&tx, user, "collateral.valuation", "collateral_assets", id, &format_brl(value_cents))?;
    tx.commit()?;
    Ok(())
}

pub fn approve(conn: &mut Connection, user: &User, id: i64, approve: bool, notes: Option<String>) -> AppResult<()> {
    let tx = conn.transaction()?;
    let a = get(&tx, id)?;
    if a.status != "appraising" || a.appraised_cents.unwrap_or(0) <= 0 {
        return Err(AppError::Validation("A garantia precisa ter avaliação válida para ser aprovada ou recusada.".into()));
    }
    let note = opt_text(&notes).unwrap_or_default();
    if !approve && note.is_empty() {
        return Err(AppError::Validation("Informe o motivo da recusa.".into()));
    }
    tx.execute("UPDATE collateral_assets SET status = ?2, updated_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id = ?1", (id, if approve { "approved" } else { "rejected" }))?;
    event(&tx, user, id, if approve { "approved" } else { "rejected" }, if approve { "Garantia aprovada" } else { &note })?;
    audit_repo::log(&tx, user, if approve { "collateral.approve" } else { "collateral.reject" }, "collateral_assets", id, &note)?;
    tx.commit()?;
    Ok(())
}

/// Recebimento em custódia. Bloqueado até a habilitação regulatória; exige contrato de garantia assinado.
pub fn receive_custody(conn: &mut Connection, vault: &Vault, user: &User, id: i64, location: &str, days: i64) -> AppResult<()> {
    let location = require_text(location, "Local de custódia", 120)?;
    if !(1..=3650).contains(&days) {
        return Err(AppError::Validation("Prazo de custódia inválido.".into()));
    }
    let tx = conn.transaction()?;
    require_collateral_enabled(&tx)?;
    let a = get(&tx, id)?;
    if a.status != "approved" {
        return Err(AppError::Validation("Somente garantias aprovadas podem ser recebidas em custódia.".into()));
    }
    let signed: i64 = tx.query_row(
        "SELECT COUNT(*) FROM contracts WHERE kind='collateral' AND ref_id = ?1 AND signed_at IS NOT NULL AND status <> 'cancelled'",
        [id],
        |r| r.get(0),
    )?;
    if signed == 0 {
        return Err(AppError::Validation("O termo de garantia precisa estar gerado e assinado antes do recebimento.".into()));
    }
    let today = settings_repo::today(&tx);
    let due = today + chrono::Duration::days(days);
    tx.execute(
        "UPDATE collateral_assets SET status='in_custody', storage_location=?2, custody_days=?3, custody_start=?4, custody_due=?5,
            updated_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id=?1",
        rusqlite::params![id, location, days, today.to_string(), due.to_string()],
    )?;
    event(&tx, user, id, "received", &format!("Recebido em custódia — {location} (prazo {days} dias)"))?;
    let a2 = get(&tx, id)?;
    let bytes = receipt_term_pdf(&tx, &a2, &location, days, &today.to_string(), &due.to_string());
    attachment_service::add_bytes(&tx, vault, user, "collateral", id, "receipt_term", &format!("termo_recebimento_{}.pdf", a.code), &bytes)?;
    audit_repo::log(&tx, user, "collateral.custody", "collateral_assets", id, &location)?;
    tx.commit()?;
    Ok(())
}

pub(crate) fn receipt_term_pdf(conn: &Connection, a: &CollateralRow, location: &str, days: i64, start: &str, due: &str) -> Vec<u8> {
    let (company, cnpj) = payment_service::company_header(conn);
    let mut pdf = Pdf::new(&format!("Termo de recebimento {}", a.code));
    pdf.paragraph(&if cnpj.is_empty() { company } else { format!("{company} — CNPJ {cnpj}") }, 9.0, true);
    pdf.space(8.0);
    pdf.heading(&format!("TERMO DE RECEBIMENTO {}", a.code));
    pdf.rule();
    write_item(&mut pdf, a);
    pdf.key_value("Local de custódia", location);
    pdf.key_value("Recebido em", &crate::domain::money::br_date(start));
    pdf.key_value("Prazo de custódia", &format!("{days} dias (até {})", crate::domain::money::br_date(due)));
    pdf.space(30.0);
    pdf.columns(&["____________________________________", "____________________________________"], 9.0);
    pdf.columns(&["Responsável pelo recebimento", "Proprietário(a)"], 8.0);
    pdf.finish()
}

pub(crate) fn return_term_pdf(conn: &Connection, a: &CollateralRow, kind: &str, note: &str, date: &str) -> Vec<u8> {
    let (company, cnpj) = payment_service::company_header(conn);
    let mut pdf = Pdf::new(&format!("Termo de devolução {}", a.code));
    pdf.paragraph(&if cnpj.is_empty() { company } else { format!("{company} — CNPJ {cnpj}") }, 9.0, true);
    pdf.space(8.0);
    pdf.heading(&format!("TERMO DE {} {}", if kind == "redeemed" { "RESGATE" } else { "DEVOLUÇÃO" }, a.code));
    pdf.rule();
    write_item(&mut pdf, a);
    pdf.key_value("Data", &crate::domain::money::br_date(date));
    pdf.key_value("Observação", note);
    pdf.space(30.0);
    pdf.columns(&["____________________________________", "____________________________________"], 9.0);
    pdf.columns(&["Responsável pela entrega", "Proprietário(a)"], 8.0);
    pdf.finish()
}

fn write_item(pdf: &mut Pdf, a: &CollateralRow) {
    pdf.key_value("Proprietário", &a.client_name);
    pdf.key_value("Bem", &a.name);
    pdf.key_value("Marca / Modelo", &format!("{} {}", a.brand.clone().unwrap_or_default(), a.model.clone().unwrap_or_default()));
    pdf.key_value("Série / IMEI", a.serial_number.as_deref().unwrap_or("—"));
    pdf.key_value("Estado", condition_label(&a.condition));
    pdf.key_value("Avaliação", &a.appraised_cents.map(format_brl).unwrap_or("—".into()));
    pdf.key_value("Contrato vinculado", &a.loan_id.map(|l| ref_code("loan", l)).unwrap_or("—".into()));
}

pub fn extend(conn: &mut Connection, user: &User, id: i64, extra_days: i64, reason: &str) -> AppResult<()> {
    let reason = require_text(reason, "Motivo", 200)?;
    if !(1..=3650).contains(&extra_days) {
        return Err(AppError::Validation("Prazo inválido.".into()));
    }
    let tx = conn.transaction()?;
    let a = get(&tx, id)?;
    if a.status != "in_custody" {
        return Err(AppError::Validation("Somente garantias em custódia podem ter o prazo prorrogado.".into()));
    }
    let due = chrono::NaiveDate::parse_from_str(a.custody_due.as_deref().unwrap_or(""), "%Y-%m-%d")
        .map_err(|_| AppError::Internal("prazo de custódia ausente".into()))?;
    let new_due = due + chrono::Duration::days(extra_days);
    tx.execute("UPDATE collateral_assets SET custody_due = ?2 WHERE id = ?1", (id, new_due.to_string()))?;
    event(&tx, user, id, "extended", &format!("Prazo prorrogado em {extra_days} dias (até {new_due}) — {reason}"))?;
    audit_repo::log(&tx, user, "collateral.extend", "collateral_assets", id, &reason)?;
    tx.commit()?;
    Ok(())
}

/// Resgate (cliente quitou) ou devolução (sem resgate, p.ex. contrato cancelado). Gera o termo de devolução.
pub fn release(conn: &mut Connection, vault: &Vault, user: &User, id: i64, kind: &str, note: &str) -> AppResult<()> {
    if !matches!(kind, "redeemed" | "returned") {
        return Err(AppError::Validation("Tipo de baixa inválido.".into()));
    }
    let note = require_text(note, "Observação", 300)?;
    let tx = conn.transaction()?;
    let a = get(&tx, id)?;
    if !matches!(a.status.as_str(), "in_custody" | "legal_procedure") {
        return Err(AppError::Validation("Apenas garantias em custódia podem ser resgatadas ou devolvidas.".into()));
    }
    if kind == "redeemed" {
        if let Some(l) = a.loan_id {
            let st: String = tx.query_row("SELECT status FROM loans WHERE id = ?1", [l], |r| r.get(0))?;
            if st != "paid_off" {
                return Err(AppError::Validation("O resgate exige a quitação do empréstimo vinculado.".into()));
            }
        }
    }
    tx.execute("UPDATE collateral_assets SET status = ?2, updated_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id = ?1", (id, kind))?;
    event(&tx, user, id, kind, &format!("{} — {note}", if kind == "redeemed" { "Resgatada pelo cliente" } else { "Devolvida ao cliente" }))?;
    let today = settings_repo::today(&tx);
    let bytes = return_term_pdf(&tx, &a, kind, &note, &today.to_string());
    attachment_service::add_bytes(&tx, vault, user, "collateral", id, "return_term", &format!("termo_{}_{}.pdf", kind, a.code), &bytes)?;
    audit_repo::log(&tx, user, &format!("collateral.{kind}"), "collateral_assets", id, &note)?;
    tx.commit()?;
    Ok(())
}

/// Registra que o procedimento legal cabível foi iniciado. Não há apropriação nem venda automática:
/// o sistema apenas documenta o estado e exige referência ao procedimento.
pub fn mark_legal_procedure(conn: &mut Connection, user: &User, id: i64, reference: &str) -> AppResult<()> {
    let reference = require_text(reference, "Referência do procedimento", 300)?;
    if reference.chars().count() < 10 {
        return Err(AppError::Validation("Descreva o procedimento legal adotado (mín. 10 caracteres).".into()));
    }
    let tx = conn.transaction()?;
    let a = get(&tx, id)?;
    if a.status != "in_custody" || a.days_left.is_none_or(|d| d >= 0) {
        return Err(AppError::Validation("O procedimento só pode ser registrado após o vencimento do prazo de custódia.".into()));
    }
    tx.execute("UPDATE collateral_assets SET status='legal_procedure' WHERE id = ?1", [id])?;
    event(&tx, user, id, "legal_procedure", &format!("Procedimento legal registrado — {reference}"))?;
    audit_repo::log(&tx, user, "collateral.legal_procedure", "collateral_assets", id, &reference)?;
    tx.commit()?;
    Ok(())
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct EventRow {
    pub id: i64,
    pub kind: String,
    pub description: String,
    pub username: Option<String>,
    pub created_at: String,
}

pub fn events(conn: &Connection, id: i64) -> AppResult<Vec<EventRow>> {
    let mut stmt = conn.prepare(
        "SELECT e.id, e.kind, e.description, u.username, e.created_at FROM custody_events e LEFT JOIN users u ON u.id = e.user_id
         WHERE e.asset_id = ?1 ORDER BY e.id",
    )?;
    let rows = stmt
        .query_map([id], |r| Ok(EventRow { id: r.get(0)?, kind: r.get(1)?, description: r.get(2)?, username: r.get(3)?, created_at: r.get(4)? }))?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::services::contract_service;
    use crate::services::loan_service::tests::*;
    use crate::testutil::{env, Env};

    fn input(client: i64) -> CollateralInput {
        CollateralInput {
            client_id: client, category: "Eletrônicos".into(), name: "Notebook Dell Inspiron 15".into(), brand: Some("Dell".into()),
            model: Some("Inspiron 15".into()), serial_number: Some("SN-884921".into()), condition: "refurbished".into(),
            appraised_cents: Some(240_000), storage_location: None, custody_days: Some(30), notes: None, application_id: None,
            photo_paths: None,
        }
    }

    fn approved(conn: &mut Connection, e: &Env, client: i64) -> i64 {
        let id = create(conn, &e.vault, &e.admin, input(client)).unwrap();
        approve(conn, &e.admin, id, true, None).unwrap();
        id
    }

    #[test]
    fn registration_valuation_and_duplicate_serial() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Mariana", "529.982.247-25");
        let id = create(&mut conn, &e.vault, &e.admin, input(c)).unwrap();
        let a = get(&conn, id).unwrap();
        assert_eq!((a.status.as_str(), a.display_status.as_str(), a.code.as_str()), ("appraising", "evaluating", "GAR-0001"));
        assert!(create(&mut conn, &e.vault, &e.admin, input(c)).unwrap_err().to_string().contains("série"));
        valuate(&mut conn, &e.admin, id, 250_000, Some("Reavaliado".into())).unwrap();
        assert_eq!(get(&conn, id).unwrap().appraised_cents, Some(250_000));
        assert_eq!(events(&conn, id).unwrap().len(), 3);
    }

    #[test]
    fn custody_is_blocked_until_regulatory_enablement_and_needs_signed_term() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Mariana", "529.982.247-25");
        let id = approved(&mut conn, &e, c);
        let err = receive_custody(&mut conn, &e.vault, &e.admin, id, "Cofre — Matriz", 30).unwrap_err();
        assert!(err.to_string().contains("bloqueada"));
        settings_repo::set(&conn, "collateral.enabled", "true").unwrap();
        assert!(receive_custody(&mut conn, &e.vault, &e.admin, id, "Cofre — Matriz", 30).unwrap_err().to_string().contains("assinado"));
        for t in contract_service::templates(&conn).unwrap() {
            contract_service::approve_template(&mut conn, &e.admin, t.id, "Jurídico").unwrap();
        }
        let k = contract_service::generate(&mut conn, &e.vault, &e.admin, "collateral", id, None).unwrap();
        contract_service::sign(&mut conn, &e.admin, k, "Mariana", None).unwrap();
        receive_custody(&mut conn, &e.vault, &e.admin, id, "Cofre — Matriz", 30).unwrap();
        let a = get(&conn, id).unwrap();
        assert_eq!((a.status.as_str(), a.days_left), ("in_custody", Some(30)));
        assert_eq!(attachment_service::list(&conn, "collateral", id, Some("receipt_term")).unwrap().len(), 1);
    }

    fn in_custody(conn: &mut Connection, e: &Env, client: i64) -> i64 {
        let id = approved(conn, e, client);
        settings_repo::set(conn, "collateral.enabled", "true").unwrap();
        conn.execute(
            "INSERT INTO contracts (number, kind, client_id, ref_type, ref_id, signed_at, status) VALUES ('CTR-T-COL','collateral',?1,'collateral',?2,'2024-01-01','active')",
            (client, id),
        ).unwrap();
        receive_custody(conn, &e.vault, &e.admin, id, "Cofre", 30).unwrap();
        id
    }

    #[test]
    fn deadline_display_and_extension() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Mariana", "529.982.247-25");
        let id = in_custody(&mut conn, &e, c);
        let soon = (crate::testutil::today() + chrono::Duration::days(3)).to_string();
        conn.execute("UPDATE collateral_assets SET custody_due = ?2 WHERE id = ?1", (id, soon)).unwrap();
        assert_eq!(get(&conn, id).unwrap().display_status, "near_deadline");
        assert_eq!(stats(&conn).unwrap().near_deadline, 1);
        extend(&mut conn, &e.admin, id, 30, "Cliente pediu mais prazo").unwrap();
        assert_eq!(get(&conn, id).unwrap().display_status, "in_custody");
    }

    #[test]
    fn redeem_requires_paid_loan_and_return_always_possible() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Mariana", "529.982.247-25");
        let id = in_custody(&mut conn, &e, c);
        let loan = active_loan(&mut conn, &e, c, 100_000, 1);
        conn.execute("UPDATE collateral_assets SET loan_id = ?2 WHERE id = ?1", (id, loan)).unwrap();
        assert!(release(&mut conn, &e.vault, &e.admin, id, "redeemed", "Cliente quitou").is_err());
        let inst = crate::repositories::loan_repo::installments(&conn, loan, false).unwrap()[0].clone();
        payment_service::pay_installment(&mut conn, &e.admin, inst.id, inst.amount_cents, "pix", None).unwrap();
        release(&mut conn, &e.vault, &e.admin, id, "redeemed", "Cliente quitou").unwrap();
        assert_eq!(get(&conn, id).unwrap().status, "redeemed");
        assert_eq!(stats(&conn).unwrap().redeemed_month, 1);
        assert!(release(&mut conn, &e.vault, &e.admin, id, "returned", "de novo").is_err());
    }

    #[test]
    fn legal_procedure_only_after_deadline_and_never_touches_stock() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Mariana", "529.982.247-25");
        let id = in_custody(&mut conn, &e, c);
        assert!(mark_legal_procedure(&mut conn, &e.admin, id, "Notificação extrajudicial nº 123").is_err());
        let past = (crate::testutil::today() - chrono::Duration::days(2)).to_string();
        conn.execute("UPDATE collateral_assets SET custody_due = ?2 WHERE id = ?1", (id, past)).unwrap();
        assert!(mark_legal_procedure(&mut conn, &e.admin, id, "curto").is_err());
        mark_legal_procedure(&mut conn, &e.admin, id, "Notificação extrajudicial nº 123").unwrap();
        assert_eq!(get(&conn, id).unwrap().status, "legal_procedure");
        let products: i64 = conn.query_row("SELECT COUNT(*) FROM products", [], |r| r.get(0)).unwrap();
        assert_eq!(products, 0);
    }
}
