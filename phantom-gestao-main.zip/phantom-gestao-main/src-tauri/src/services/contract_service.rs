use std::collections::HashMap;

use rusqlite::{Connection, OptionalExtension};
use serde::{Deserialize, Serialize};

use crate::domain::money::{format_bp, format_brl};
use crate::domain::user::User;
use crate::domain::validation::*;
use crate::error::{AppError, AppResult};
use crate::repositories::{audit_repo, loan_repo, settings_repo, Page, PageQuery};
use crate::security::vault::Vault;
use crate::services::pdf::Pdf;
use crate::services::{attachment_service, payment_service};

/// Versão atual do layout dos PDFs de contrato (cabeçalho institucional).
pub const CURRENT_LAYOUT: i64 = 2;

pub const KINDS: [&str; 4] = ["loan", "collateral", "sale", "purchase"];

#[derive(Debug, Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct TemplateRow {
    pub id: i64,
    pub kind: String,
    pub name: String,
    pub body: String,
    pub version: i64,
    pub legal_status: String,
    pub approved_by: Option<String>,
    pub approved_at: Option<String>,
    pub active: bool,
    pub updated_at: String,
}

fn tmap(r: &rusqlite::Row) -> rusqlite::Result<TemplateRow> {
    Ok(TemplateRow {
        id: r.get(0)?, kind: r.get(1)?, name: r.get(2)?, body: r.get(3)?, version: r.get(4)?, legal_status: r.get(5)?,
        approved_by: r.get(6)?, approved_at: r.get(7)?, active: r.get::<_, i64>(8)? == 1, updated_at: r.get(9)?,
    })
}

const TCOLS: &str = "id, kind, name, body, version, legal_status, approved_by, approved_at, active, updated_at";

pub fn templates(conn: &Connection) -> AppResult<Vec<TemplateRow>> {
    let mut stmt = conn.prepare(&format!("SELECT {TCOLS} FROM contract_templates ORDER BY kind, id"))?;
    let rows = stmt.query_map([], tmap)?.collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

fn template(conn: &Connection, id: i64) -> AppResult<TemplateRow> {
    conn.query_row(&format!("SELECT {TCOLS} FROM contract_templates WHERE id = ?1"), [id], tmap)
        .optional()?
        .ok_or_else(|| AppError::Validation("Modelo não encontrado.".into()))
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TemplateInput {
    pub id: Option<i64>,
    pub kind: String,
    pub name: String,
    pub body: String,
    pub active: Option<bool>,
}

/// Variáveis disponíveis nos modelos: (nome, descrição, tipos). Lista vazia = todos os tipos.
pub const VARIABLES: &[(&str, &str, &[&str])] = &[
    ("empresa", "Razão social da empresa", &[]),
    ("empresa_documento", "CNPJ da empresa", &[]),
    ("cliente_nome", "Nome do cliente", &[]),
    ("cliente_documento", "CPF/CNPJ do cliente", &[]),
    ("cliente_endereco", "Endereço do cliente", &[]),
    ("contrato_numero", "Número do contrato", &[]),
    ("data", "Data do contrato", &[]),
    ("emprestimo_numero", "Nº do empréstimo", &["loan", "collateral"]),
    ("valor", "Valor da operação", &["loan", "sale", "purchase"]),
    ("prazo", "Prazo (parcelas)", &["loan"]),
    ("taxa_mensal", "Taxa de juros mensal", &["loan"]),
    ("cet_anual", "CET anual", &["loan"]),
    ("parcela", "Valor da parcela", &["loan"]),
    ("total_pagar", "Total a pagar", &["loan"]),
    ("primeiro_vencimento", "Primeiro vencimento", &["loan"]),
    ("garantia_codigo", "Código da garantia", &["collateral"]),
    ("bem_descricao", "Descrição do bem", &["collateral"]),
    ("bem_serie", "Série / IMEI do bem", &["collateral"]),
    ("bem_condicao", "Estado de conservação", &["collateral"]),
    ("bem_avaliacao", "Valor de avaliação do bem", &["collateral"]),
    ("local_custodia", "Local de custódia", &["collateral"]),
    ("prazo_custodia", "Prazo de custódia", &["collateral"]),
    ("venda_codigo", "Código da venda", &["sale"]),
    ("compra_codigo", "Código da compra", &["purchase"]),
    ("produto", "Produto comprado", &["purchase"]),
    ("vendedor_nome", "Nome do vendedor", &["purchase"]),
];

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct VariableInfo {
    pub key: String,
    pub label: String,
    pub common: bool,
}

pub fn variables_for(kind: &str) -> Vec<VariableInfo> {
    VARIABLES
        .iter()
        .filter(|(_, _, kinds)| kinds.is_empty() || kinds.contains(&kind))
        .map(|(k, l, kinds)| VariableInfo { key: (*k).into(), label: (*l).into(), common: kinds.is_empty() })
        .collect()
}

fn sample_vars(conn: &Connection, kind: &str) -> HashMap<String, String> {
    let (company, cnpj) = payment_service::company_header(conn);
    let mut v = HashMap::new();
    for info in variables_for(kind) {
        let sample = match info.key.as_str() {
            "empresa" => company.clone(),
            "empresa_documento" => if cnpj.is_empty() { "00.000.000/0001-00".into() } else { cnpj.clone() },
            "cliente_nome" => "Maria da Silva Exemplo".into(),
            "cliente_documento" => "123.456.789-09".into(),
            "cliente_endereco" => "Rua Exemplo, 100, Centro, São Paulo, SP".into(),
            "contrato_numero" => "CTR-2026-00000".into(),
            "data" => "01/01/2026".into(),
            "emprestimo_numero" => "#1".into(),
            "valor" => "R$ 10.000,00".into(),
            "prazo" => "12 parcelas".into(),
            "taxa_mensal" => "2,40% ao mês".into(),
            "cet_anual" => "32,92% ao ano".into(),
            "parcela" => "R$ 969,18".into(),
            "total_pagar" => "R$ 11.630,16".into(),
            "primeiro_vencimento" => "01/02/2026".into(),
            "garantia_codigo" => "GAR-0001".into(),
            "bem_descricao" => "Notebook — Eletrônicos Dell Inspiron 15".into(),
            "bem_serie" => "SN-000000".into(),
            "bem_condicao" => "Seminovo".into(),
            "bem_avaliacao" => "R$ 2.400,00".into(),
            "local_custodia" => "Cofre — Matriz".into(),
            "prazo_custodia" => "30 dias".into(),
            "venda_codigo" => "VEN-001".into(),
            "compra_codigo" => "COM-0001".into(),
            "produto" => "Smartphone".into(),
            "vendedor_nome" => "João Exemplo".into(),
            _ => "…".into(),
        };
        v.insert(info.key, sample);
    }
    v
}

/// Verifica se o texto só usa variáveis válidas para o tipo (o erro lista as desconhecidas).
pub fn validate_body(conn: &Connection, kind: &str, body: &str) -> AppResult<String> {
    render(body, &sample_vars(conn, kind))
}

/// PDF de pré-visualização com dados fictícios (não é gravado).
pub fn preview_pdf(conn: &Connection, kind: &str, body: &str) -> AppResult<Vec<u8>> {
    if !KINDS.contains(&kind) {
        return Err(AppError::Validation("Tipo de modelo inválido.".into()));
    }
    let text = validate_body(conn, kind, body)?;
    Ok(build_pdf(conn, "Pré-visualização do modelo", "CTR-0000-00000", 1, &text, &payment_service::company_header(conn)))
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TemplateVersion {
    pub version: i64,
    pub body: String,
    pub legal_status: String,
    pub approved_by: Option<String>,
    pub saved_at: String,
}

pub fn template_versions(conn: &Connection, id: i64) -> AppResult<Vec<TemplateVersion>> {
    let mut stmt = conn.prepare("SELECT version, body, legal_status, approved_by, saved_at FROM contract_template_versions WHERE template_id = ?1 ORDER BY version DESC")?;
    let rows = stmt
        .query_map([id], |r| Ok(TemplateVersion { version: r.get(0)?, body: r.get(1)?, legal_status: r.get(2)?, approved_by: r.get(3)?, saved_at: r.get(4)? }))?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

/// Salva um modelo. Qualquer alteração de conteúdo gera nova versão e exige nova aprovação jurídica.
pub fn save_template(conn: &mut Connection, user: &User, i: TemplateInput) -> AppResult<i64> {
    if !KINDS.contains(&i.kind.as_str()) {
        return Err(AppError::Validation("Tipo de modelo inválido.".into()));
    }
    let name = require_text(&i.name, "Nome do modelo", 120)?;
    let body = require_text(&i.body, "Texto do modelo", 50_000)?;
    validate_body(conn, &i.kind, &body)?;
    let tx = conn.transaction()?;
    let id = match i.id {
        Some(id) => {
            let cur = template(&tx, id)?;
            let changed = cur.body != body || cur.kind != i.kind;
            let version = if changed { cur.version + 1 } else { cur.version };
            tx.execute(
                "UPDATE contract_templates SET kind=?2, name=?3, body=?4, version=?5, active=?6,
                    legal_status = CASE WHEN ?7 = 1 THEN 'draft' ELSE legal_status END,
                    approved_by = CASE WHEN ?7 = 1 THEN NULL ELSE approved_by END,
                    approved_at = CASE WHEN ?7 = 1 THEN NULL ELSE approved_at END,
                    updated_by=?8, updated_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id=?1",
                rusqlite::params![id, i.kind, name, body, version, i.active.unwrap_or(cur.active) as i64, changed as i64, user.id],
            )?;
            if changed {
                tx.execute(
                    "INSERT INTO contract_template_versions (template_id, version, body, legal_status, saved_by) VALUES (?1,?2,?3,'draft',?4)",
                    (id, version, &body, user.id),
                )?;
            }
            id
        }
        None => {
            tx.execute(
                "INSERT INTO contract_templates (kind, name, body, active, updated_by) VALUES (?1,?2,?3,?4,?5)",
                rusqlite::params![i.kind, name, body, i.active.unwrap_or(true) as i64, user.id],
            )?;
            let id = tx.last_insert_rowid();
            tx.execute(
                "INSERT INTO contract_template_versions (template_id, version, body, legal_status, saved_by) VALUES (?1,1,?2,'draft',?3)",
                (id, &body, user.id),
            )?;
            id
        }
    };
    audit_repo::log(&tx, user, "contract.template_save", "contract_templates", id, &name)?;
    tx.commit()?;
    Ok(id)
}

pub fn approve_template(conn: &mut Connection, user: &User, id: i64, approver: &str) -> AppResult<()> {
    let approver = require_text(approver, "Responsável jurídico", 120)?;
    let tx = conn.transaction()?;
    let t = template(&tx, id)?;
    tx.execute(
        "UPDATE contract_templates SET legal_status='approved', approved_by=?2, approved_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id=?1",
        (id, &approver),
    )?;
    tx.execute(
        "UPDATE contract_template_versions SET legal_status='approved', approved_by=?3 WHERE template_id=?1 AND version=?2",
        (id, t.version, &approver),
    )?;
    audit_repo::log(&tx, user, "contract.template_approve", "contract_templates", id, &format!("v{} por {approver}", t.version))?;
    tx.commit()?;
    Ok(())
}

fn render(body: &str, vars: &HashMap<String, String>) -> AppResult<String> {
    let mut out = String::with_capacity(body.len());
    let mut missing = vec![];
    let mut rest = body;
    while let Some(start) = rest.find('{') {
        out.push_str(&rest[..start]);
        match rest[start..].find('}') {
            Some(end) => {
                let key = &rest[start + 1..start + end];
                match vars.get(key) {
                    Some(v) => out.push_str(&v.replace('*', "\u{E000}")),
                    None => {
                        missing.push(key.to_string());
                        out.push_str(&rest[start..=start + end]);
                    }
                }
                rest = &rest[start + end + 1..];
            }
            None => {
                out.push_str(&rest[start..]);
                rest = "";
            }
        }
    }
    out.push_str(rest);
    if missing.is_empty() {
        Ok(out)
    } else {
        Err(AppError::Validation(format!("O modelo usa variáveis desconhecidas: {}.", missing.join(", "))))
    }
}

fn client_vars(conn: &Connection, client_id: i64, v: &mut HashMap<String, String>) -> AppResult<()> {
    let today = settings_repo::today(conn).to_string();
    let c = crate::repositories::client_repo::get(conn, client_id, &today)?;
    let addr = [c.street.clone(), c.number.clone(), c.district.clone(), c.city.clone(), c.state.clone()]
        .into_iter().flatten().collect::<Vec<_>>().join(", ");
    v.insert("cliente_nome".into(), c.name);
    v.insert("cliente_documento".into(), format_document(&c.document));
    v.insert("cliente_endereco".into(), if addr.is_empty() { "—".into() } else { addr });
    Ok(())
}

pub fn ref_code(kind: &str, id: i64) -> String {
    match kind {
        "loan" => format!("#{id}"),
        "collateral" => format!("GAR-{id:04}"),
        "sale" => format!("VEN-{id:03}"),
        _ => format!("COM-{id:04}"),
    }
}

fn variables(conn: &Connection, kind: &str, ref_id: i64, number: &str) -> AppResult<(HashMap<String, String>, i64)> {
    let mut v: HashMap<String, String> = HashMap::new();
    let (company, cnpj) = payment_service::company_header(conn);
    v.insert("empresa".into(), company);
    v.insert("empresa_documento".into(), if cnpj.is_empty() { "—".into() } else { cnpj });
    v.insert("data".into(), crate::domain::money::br_date(&settings_repo::today(conn).to_string()));
    v.insert("contrato_numero".into(), number.to_string());
    let client_id: i64;
    match kind {
        "loan" => {
            let today = settings_repo::today(conn).to_string();
            let l = loan_repo::get_loan(conn, ref_id, &today)?;
            let (rate, cet, first): (i64, Option<i64>, String) =
                conn.query_row("SELECT rate_bp, cet_annual_bp, first_due_date FROM loans WHERE id=?1", [ref_id], |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?)))?;
            let insts = loan_repo::installments(conn, ref_id, false)?;
            let total: i64 = insts.iter().map(|i| i.amount_cents).sum();
            v.insert("emprestimo_numero".into(), format!("#{ref_id}"));
            v.insert("valor".into(), format_brl(l.principal_cents));
            v.insert("prazo".into(), format!("{} parcelas", l.term_months));
            v.insert("taxa_mensal".into(), format!("{}% ao mês", format_bp(rate)));
            v.insert("cet_anual".into(), cet.map(|c| format!("{}% ao ano", format_bp(c))).unwrap_or("—".into()));
            v.insert("parcela".into(), insts.first().map(|i| format_brl(i.amount_cents)).unwrap_or("—".into()));
            v.insert("total_pagar".into(), format_brl(total));
            v.insert("primeiro_vencimento".into(), crate::domain::money::br_date(&first));
            client_id = l.client_id;
        }
        "collateral" => {
            let (cid, cat, name, brand, model, serial, cond, appraised, loc, days, loan): (i64, String, String, Option<String>, Option<String>, Option<String>, String, Option<i64>, Option<String>, Option<i64>, Option<i64>) =
                conn.query_row(
                    "SELECT client_id, category, name, brand, model, serial_number, condition, appraised_cents, storage_location, custody_days, loan_id FROM collateral_assets WHERE id=?1",
                    [ref_id],
                    |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?, r.get(4)?, r.get(5)?, r.get(6)?, r.get(7)?, r.get(8)?, r.get(9)?, r.get(10)?)),
                ).map_err(|_| AppError::Validation("Garantia não encontrada.".into()))?;
            v.insert("garantia_codigo".into(), ref_code("collateral", ref_id));
            v.insert("bem_descricao".into(), format!("{name} — {cat} {} {}", brand.unwrap_or_default(), model.unwrap_or_default()).trim().to_string());
            v.insert("bem_serie".into(), serial.unwrap_or("—".into()));
            v.insert("bem_condicao".into(), condition_label(&cond).into());
            v.insert("bem_avaliacao".into(), appraised.map(format_brl).unwrap_or("—".into()));
            v.insert("local_custodia".into(), loc.unwrap_or("—".into()));
            v.insert("prazo_custodia".into(), days.map(|d| format!("{d} dias")).unwrap_or("—".into()));
            v.insert("emprestimo_numero".into(), loan.map(|l| format!("#{l}")).unwrap_or("—".into()));
            client_id = cid;
        }
        "sale" => {
            let s = crate::repositories::commerce_repo::get_sale(conn, ref_id)?;
            v.insert("venda_codigo".into(), s.code.clone());
            v.insert("valor".into(), format_brl(s.total_cents));
            client_id = s.client_id.ok_or_else(|| AppError::Validation("Venda sem cliente identificado não gera contrato.".into()))?;
        }
        _ => {
            let p = crate::repositories::commerce_repo::get_purchase(conn, ref_id)?;
            v.insert("compra_codigo".into(), ref_code("purchase", ref_id));
            v.insert("produto".into(), p.product_name);
            v.insert("valor".into(), format_brl(p.amount_cents));
            v.insert("vendedor_nome".into(), p.seller_name);
            client_id = p.seller_client_id.ok_or_else(|| AppError::Validation("Compra sem vendedor cadastrado não gera contrato.".into()))?;
        }
    }
    client_vars(conn, client_id, &mut v)?;
    Ok((v, client_id))
}

pub fn condition_label(c: &str) -> &'static str {
    match c {
        "new" => "Novo",
        "refurbished" => "Seminovo",
        "used" => "Usado",
        "damaged" => "Danificado",
        _ => "—",
    }
}

fn next_number(conn: &Connection) -> AppResult<String> {
    let year = settings_repo::today(conn).format("%Y").to_string();
    let seq: i64 = conn.query_row(
        "SELECT COALESCE(MAX(CAST(substr(number, 10) AS INTEGER)), 0) + 1 FROM contracts WHERE number LIKE ?1",
        [format!("CTR-{year}-%")],
        |r| r.get(0),
    )?;
    Ok(format!("CTR-{year}-{seq:05}"))
}

fn build_pdf(conn: &Connection, title: &str, number: &str, version: i64, text: &str, company: &(String, String)) -> Vec<u8> {
    let mut pdf = Pdf::new(title);
    pdf.paragraph(&if company.1.is_empty() { company.0.clone() } else { format!("{} — CNPJ {}", company.0, company.1) }, 9.0, true);
    pdf.paragraph(&format!("{number} · versão {version}"), 8.0, false);
    pdf.space(6.0);
    for id in image_ids(text) {
        if let Ok(data) = conn.query_row("SELECT data FROM template_images WHERE id=?1", [id], |r| r.get::<_, Vec<u8>>(0)) {
            pdf.add_image(id, data);
        }
    }
    pdf.markup(text);
    pdf.finish()
}

/// Ids referenciados por `[img:ID ...]` no texto.
fn image_ids(text: &str) -> Vec<i64> {
    let mut out = vec![];
    for line in text.lines() {
        if let Some(i) = line.find("[img:") {
            let rest = &line[i + 5..];
            let digits: String = rest.chars().take_while(char::is_ascii_digit).collect();
            if let Ok(id) = digits.parse::<i64>() {
                if !out.contains(&id) {
                    out.push(id);
                }
            }
        }
    }
    out
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TemplateImage {
    pub id: i64,
    pub name: String,
    pub width: i64,
    pub height: i64,
    /// JPEG em base64 (miniatura e uso na pré-visualização).
    pub data_base64: String,
}

const MAX_IMAGE_BYTES: usize = 2 * 1024 * 1024;

pub fn list_images(conn: &Connection) -> AppResult<Vec<TemplateImage>> {
    use base64::Engine;
    let mut st = conn.prepare("SELECT id, name, width, height, data FROM template_images ORDER BY id DESC")?;
    let rows = st.query_map([], |r| {
        let data: Vec<u8> = r.get(4)?;
        Ok(TemplateImage { id: r.get(0)?, name: r.get(1)?, width: r.get(2)?, height: r.get(3)?, data_base64: base64::engine::general_purpose::STANDARD.encode(data) })
    })?;
    Ok(rows.collect::<Result<_, _>>()?)
}

pub fn add_image(conn: &mut Connection, user: &User, name: &str, data: Vec<u8>) -> AppResult<i64> {
    let name = name.trim();
    if name.is_empty() {
        return Err(AppError::Validation("Informe um nome para a imagem.".into()));
    }
    if data.len() > MAX_IMAGE_BYTES {
        return Err(AppError::Validation("Imagem maior que 2 MB.".into()));
    }
    let mut probe = Pdf::new("x");
    if !probe.add_image(0, data.clone()) {
        return Err(AppError::Validation("Arquivo de imagem inválido: use JPEG (RGB ou tons de cinza).".into()));
    }
    let (w, h) = crate::services::pdf::jpeg_size(&data).unwrap_or((0, 0));
    let tx = conn.transaction()?;
    tx.execute("INSERT INTO template_images (name, data, width, height) VALUES (?1,?2,?3,?4)", rusqlite::params![name, data, w, h])?;
    let id = tx.last_insert_rowid();
    audit_repo::log(&tx, user, "contract.image_add", "template_images", id, name)?;
    tx.commit()?;
    Ok(id)
}

pub fn delete_image(conn: &mut Connection, user: &User, id: i64) -> AppResult<()> {
    let tx = conn.transaction()?;
    let n = tx.execute("DELETE FROM template_images WHERE id=?1", [id])?;
    if n == 0 {
        return Err(AppError::Validation("Imagem não encontrada.".into()));
    }
    audit_repo::log(&tx, user, "contract.image_delete", "template_images", id, "")?;
    tx.commit()?;
    Ok(())
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ContractRow {
    pub id: i64,
    pub number: String,
    pub kind: String,
    pub ref_id: i64,
    pub ref_code: String,
    pub client_id: Option<i64>,
    pub client_name: Option<String>,
    pub status: String,
    pub display_status: String,
    pub signed_at: Option<String>,
    pub signed_by_name: Option<String>,
    pub attachment_id: Option<i64>,
    pub created_at: String,
    pub version: i64,
}

fn cmap(r: &rusqlite::Row) -> rusqlite::Result<ContractRow> {
    let kind: String = r.get(2)?;
    let ref_id: i64 = r.get(3)?;
    Ok(ContractRow {
        id: r.get(0)?, number: r.get(1)?, ref_code: ref_code(&kind, ref_id), kind, ref_id,
        client_id: r.get(4)?, client_name: r.get(5)?, status: r.get(6)?, display_status: r.get(7)?,
        signed_at: r.get(8)?, signed_by_name: r.get(9)?, attachment_id: r.get(10)?, created_at: r.get(11)?, version: r.get(12)?,
    })
}

const CCOLS: &str = "k.id, k.number, k.kind, k.ref_id, k.client_id, c.name, k.status,
    CASE WHEN k.status = 'cancelled' THEN 'cancelled'
         WHEN k.kind = 'loan' AND (SELECT status FROM loans WHERE id = k.ref_id) = 'paid_off' THEN 'paid_off'
         WHEN k.kind = 'loan' AND EXISTS (SELECT 1 FROM loan_installments i WHERE i.loan_id = k.ref_id AND i.status IN ('open','partial') AND i.due_date < ?1) THEN 'late'
         WHEN k.kind = 'sale' THEN 'completed'
         WHEN k.status = 'pending_signature' THEN 'pending_signature'
         ELSE 'active' END,
    k.signed_at, k.signed_by_name, k.attachment_id, k.created_at,
    COALESCE((SELECT MAX(version) FROM contract_versions v WHERE v.contract_id = k.id), 1)";

pub fn get(conn: &Connection, id: i64) -> AppResult<ContractRow> {
    let today = settings_repo::today(conn).to_string();
    conn.query_row(
        &format!("SELECT {CCOLS} FROM contracts k LEFT JOIN clients c ON c.id = k.client_id WHERE k.id = ?2"),
        rusqlite::params![today, id],
        cmap,
    )
    .optional()?
    .ok_or_else(|| AppError::Validation("Contrato não encontrado.".into()))
}

pub fn list(conn: &Connection, q: &PageQuery) -> AppResult<Page<ContractRow>> {
    let today = settings_repo::today(conn).to_string();
    let like = q.like();
    let w = "WHERE (?2 IS NULL OR k.number LIKE ?2 OR c.name LIKE ?2)";
    let total: i64 = conn.query_row(
        &format!("SELECT COUNT(*) FROM contracts k LEFT JOIN clients c ON c.id = k.client_id {w}"),
        rusqlite::params![today, like],
        |r| r.get(0),
    )?;
    let mut stmt = conn.prepare(&format!(
        "SELECT {CCOLS} FROM contracts k LEFT JOIN clients c ON c.id = k.client_id {w} ORDER BY k.id DESC LIMIT ?3 OFFSET ?4"
    ))?;
    let items = stmt
        .query_map(rusqlite::params![today, like, q.limit(), q.offset()], cmap)?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Page::new(items, total, q))
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct VersionRow {
    pub version: i64,
    pub attachment_id: i64,
    pub file_name: String,
    pub reason: Option<String>,
    pub created_at: String,
}

pub fn versions(conn: &Connection, contract_id: i64) -> AppResult<Vec<VersionRow>> {
    let mut stmt = conn.prepare(
        "SELECT v.version, v.attachment_id, a.original_name, v.reason, v.created_at FROM contract_versions v
         JOIN attachments a ON a.id = v.attachment_id WHERE v.contract_id = ?1 ORDER BY v.version DESC",
    )?;
    let rows = stmt
        .query_map([contract_id], |r| Ok(VersionRow { version: r.get(0)?, attachment_id: r.get(1)?, file_name: r.get(2)?, reason: r.get(3)?, created_at: r.get(4)? }))?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

/// Gera o contrato (ou uma nova versão, se ainda não assinado) a partir do modelo aprovado pelo jurídico.
pub fn generate(conn: &mut Connection, vault: &Vault, user: &User, kind: &str, ref_id: i64, reason: Option<String>) -> AppResult<i64> {
    if !KINDS.contains(&kind) {
        return Err(AppError::Validation("Tipo de contrato inválido.".into()));
    }
    let tx = conn.transaction()?;
    let tpl: TemplateRow = tx
        .query_row(
            &format!("SELECT {TCOLS} FROM contract_templates WHERE kind = ?1 AND active = 1 AND legal_status = 'approved' ORDER BY id DESC LIMIT 1"),
            [kind],
            tmap,
        )
        .optional()?
        .ok_or_else(|| AppError::Validation("Não há modelo aprovado pelo responsável jurídico para este tipo de contrato (Configurações › Documentos).".into()))?;
    let existing: Option<(i64, Option<String>, String)> = tx
        .query_row(
            "SELECT id, signed_at, number FROM contracts WHERE ref_type = ?1 AND ref_id = ?2 AND status <> 'cancelled' ORDER BY id DESC LIMIT 1",
            (kind, ref_id),
            |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?)),
        )
        .optional()?;
    let (contract_id, number, version) = match existing {
        Some((_, Some(_), _)) => return Err(AppError::Validation("O contrato já foi assinado; cancele-o formalmente antes de gerar outro.".into())),
        Some((id, None, number)) => {
            let v: i64 = tx.query_row("SELECT COALESCE(MAX(version),0)+1 FROM contract_versions WHERE contract_id=?1", [id], |r| r.get(0))?;
            (id, number, v)
        }
        None => (0, next_number(&tx)?, 1),
    };
    let (vars, client_id) = variables(&tx, kind, ref_id, &number)?;
    let text = render(&tpl.body, &vars)?;
    let bytes = build_pdf(&tx, &format!("Contrato {number}"), &number, version, &text, &payment_service::company_header(&tx));
    let contract_id = if contract_id == 0 {
        tx.execute(
            "INSERT INTO contracts (number, kind, client_id, ref_type, ref_id, template_id, template_version, created_by) VALUES (?1,?2,?3,?4,?5,?6,?7,?8)",
            rusqlite::params![number, kind, client_id, kind, ref_id, tpl.id, tpl.version, user.id],
        )?;
        tx.last_insert_rowid()
    } else {
        tx.execute("UPDATE contracts SET template_id=?2, template_version=?3 WHERE id=?1", (contract_id, tpl.id, tpl.version))?;
        contract_id
    };
    let att = attachment_service::add_bytes(&tx, vault, user, "contract", contract_id, "contract", &format!("{}_v{}.pdf", number.to_lowercase(), version), &bytes)?;
    tx.execute(
        "INSERT INTO contract_versions (contract_id, version, attachment_id, reason, created_by, layout) VALUES (?1,?2,?3,?4,?5,?6)",
        rusqlite::params![contract_id, version, att.id, opt_text(&reason), user.id, CURRENT_LAYOUT],
    )?;
    tx.execute("UPDATE contracts SET attachment_id = ?2 WHERE id = ?1", (contract_id, att.id))?;
    audit_repo::log(&tx, user, "contract.generate", "contracts", contract_id, &format!("{number} v{version}"))?;
    tx.commit()?;
    Ok(contract_id)
}

/// Atualiza o layout de contratos gerados antes do cabeçalho institucional. Cria uma NOVA versão do PDF
/// (as anteriores ficam no histórico), usando o texto exato do modelo aprovado na época e a data original;
/// assinatura e demais registros do contrato não são alterados. Idempotente.
pub fn refresh_layouts(conn: &mut Connection, vault: &Vault) -> AppResult<usize> {
    let pending: Vec<(i64, String, String, String, i64, i64, i64)> = {
        let mut stmt = conn.prepare(
            "SELECT k.id, k.kind, k.number, k.created_at, k.ref_id, k.template_id, COALESCE(k.template_version, 1)
             FROM contracts k WHERE k.status <> 'cancelled' AND k.template_id IS NOT NULL
               AND COALESCE((SELECT MAX(layout) FROM contract_versions v WHERE v.contract_id = k.id), 0) < ?1",
        )?;
        let rows = stmt.query_map([CURRENT_LAYOUT], |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?, r.get(4)?, r.get(5)?, r.get(6)?)))?.collect::<Result<Vec<_>, _>>()?;
        rows
    };
    let Some(admin_id) = conn.query_row("SELECT id FROM users ORDER BY id LIMIT 1", [], |r| r.get::<_, i64>(0)).optional()? else {
        return Ok(0);
    };
    let admin = crate::repositories::user_repo::load_user(conn, admin_id)?;
    let mut done = 0;
    for (id, kind, number, created_at, ref_id, tpl_id, tpl_version) in pending {
        let tx = conn.transaction()?;
        let body: Option<String> = tx
            .query_row("SELECT body FROM contract_template_versions WHERE template_id = ?1 AND version = ?2", (tpl_id, tpl_version), |r| r.get(0))
            .optional()?;
        let Some(body) = body else { continue };
        let Ok((mut vars, _)) = variables(&tx, &kind, ref_id, &number) else { continue };
        vars.insert("data".into(), crate::domain::money::br_date(&created_at));
        let Ok(text) = render(&body, &vars) else { continue };
        let version: i64 = tx.query_row("SELECT COALESCE(MAX(version),0)+1 FROM contract_versions WHERE contract_id=?1", [id], |r| r.get(0))?;
        let bytes = build_pdf(&tx, &format!("Contrato {number}"), &number, version, &text, &payment_service::company_header(&tx));
        let att = attachment_service::add_bytes(&tx, vault, &admin, "contract", id, "contract", &format!("{}_v{}.pdf", number.to_lowercase(), version), &bytes)?;
        tx.execute(
            "INSERT INTO contract_versions (contract_id, version, attachment_id, reason, created_by, layout) VALUES (?1,?2,?3,'Atualização do layout institucional (logo e nome da empresa)',?4,?5)",
            rusqlite::params![id, version, att.id, admin.id, CURRENT_LAYOUT],
        )?;
        tx.execute("UPDATE contracts SET attachment_id = ?2 WHERE id = ?1", (id, att.id))?;
        audit_repo::record(&tx, None, Some("sistema"), "contract.layout_refresh", Some("contracts"), Some(&format!("{number} v{version}")))?;
        tx.commit()?;
        done += 1;
    }
    Ok(done)
}

/// Registro de assinatura (manuscrita ou eletrônica realizada fora do sistema).
pub fn sign(conn: &mut Connection, user: &User, id: i64, signer: &str, note: Option<String>) -> AppResult<()> {
    let signer = require_text(signer, "Nome de quem assinou", 120)?;
    let tx = conn.transaction()?;
    let k = get(&tx, id)?;
    if k.signed_at.is_some() {
        return Err(AppError::Validation("Contrato já assinado.".into()));
    }
    if k.status == "cancelled" {
        return Err(AppError::Validation("Contrato cancelado.".into()));
    }
    tx.execute(
        "UPDATE contracts SET signed_at=strftime('%Y-%m-%dT%H:%M:%SZ','now'), signed_by_name=?2, signature_note=?3, status='active' WHERE id=?1",
        rusqlite::params![id, signer, opt_text(&note)],
    )?;
    audit_repo::log(&tx, user, "contract.sign", "contracts", id, &signer)?;
    tx.commit()?;
    Ok(())
}

pub fn cancel(conn: &mut Connection, user: &User, id: i64, reason: &str) -> AppResult<()> {
    let reason = require_text(reason, "Motivo", 200)?;
    let tx = conn.transaction()?;
    let k = get(&tx, id)?;
    if k.kind == "loan" {
        let st = loan_repo::loan_status(&tx, k.ref_id)?;
        if st != "pending_disbursement" {
            return Err(AppError::Validation("Contratos de empréstimos já desembolsados não podem ser cancelados.".into()));
        }
    }
    tx.execute("UPDATE contracts SET status='cancelled' WHERE id=?1", [id])?;
    audit_repo::log(&tx, user, "contract.cancel", "contracts", id, &reason)?;
    tx.commit()?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::services::loan_service::tests::*;
    use crate::testutil::env;

    pub fn approve_default_templates(conn: &mut Connection, e: &crate::testutil::Env) {
        for t in templates(conn).unwrap() {
            approve_template(conn, &e.admin, t.id, "Dra. Ana Jurídico").unwrap();
        }
    }

    #[test]
    fn renders_variables_and_reports_unknown() {
        let mut v = HashMap::new();
        v.insert("a".to_string(), "X".to_string());
        assert_eq!(render("olá {a}!", &v).unwrap(), "olá X!");
        assert!(render("olá {b}", &v).unwrap_err().to_string().contains("b"));
    }

    #[test]
    fn requires_legally_approved_template() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Mariana Souza", "529.982.247-25");
        let loan = approved_loan_enabled(&mut conn, &e, c);
        let err = generate(&mut conn, &e.vault, &e.admin, "loan", loan, None).unwrap_err();
        assert!(err.to_string().contains("aprovado pelo responsável jurídico"));
        approve_default_templates(&mut conn, &e);
        assert!(generate(&mut conn, &e.vault, &e.admin, "loan", loan, None).is_ok());
    }

    fn approved_loan_enabled(conn: &mut Connection, e: &crate::testutil::Env, c: i64) -> i64 {
        enable_credit(conn);
        approved_loan(conn, e, c, 1_000_000, 6)
    }

    #[test]
    fn numbering_versions_and_signature() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        approve_default_templates(&mut conn, &e);
        let c = new_client(&mut conn, &e, "Mariana Souza", "529.982.247-25");
        let loan = approved_loan_enabled(&mut conn, &e, c);
        let k1 = generate(&mut conn, &e.vault, &e.admin, "loan", loan, None).unwrap();
        let k1b = generate(&mut conn, &e.vault, &e.admin, "loan", loan, Some("Correção de endereço".into())).unwrap();
        assert_eq!(k1, k1b);
        assert_eq!(versions(&conn, k1).unwrap().len(), 2);
        let row = get(&conn, k1).unwrap();
        assert!(row.number.starts_with("CTR-") && row.number.ends_with("-00001"));
        assert_eq!(row.display_status, "pending_signature");
        sign(&mut conn, &e.admin, k1, "Mariana Souza", Some("Assinatura física".into())).unwrap();
        assert!(sign(&mut conn, &e.admin, k1, "x", None).is_err());
        assert!(generate(&mut conn, &e.vault, &e.admin, "loan", loan, None).is_err());
        assert_eq!(get(&conn, k1).unwrap().display_status, "active");
        let c2 = new_client(&mut conn, &e, "João", "390.533.447-05");
        let loan2 = approved_loan(&mut conn, &e, c2, 500_000, 5);
        let k2 = generate(&mut conn, &e.vault, &e.admin, "loan", loan2, None).unwrap();
        assert!(get(&conn, k2).unwrap().number.ends_with("-00002"));
    }

    #[test]
    fn refresh_adds_branded_version_to_old_signed_contracts_once() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        approve_default_templates(&mut conn, &e);
        let c = new_client(&mut conn, &e, "Mariana Souza", "529.982.247-25");
        let loan = approved_loan_enabled(&mut conn, &e, c);
        let k = generate(&mut conn, &e.vault, &e.admin, "loan", loan, None).unwrap();
        sign(&mut conn, &e.admin, k, "Mariana Souza", None).unwrap();
        // simula contrato antigo, anterior ao cabeçalho institucional
        conn.execute("UPDATE contract_versions SET layout = 1", []).unwrap();
        assert_eq!(refresh_layouts(&mut conn, &e.vault).unwrap(), 1);
        assert_eq!(refresh_layouts(&mut conn, &e.vault).unwrap(), 0);
        let row = get(&conn, k).unwrap();
        assert_eq!((row.version, row.display_status.as_str()), (2, "active"));
        assert!(row.signed_at.is_some());
        let (_, bytes) = attachment_service::read(&conn, &e.vault, row.attachment_id.unwrap()).unwrap();
        assert!(String::from_utf8_lossy(&bytes).contains("/Im1 Do"));
        assert_eq!(versions(&conn, k).unwrap().len(), 2);
    }

    #[test]
    fn template_change_resets_legal_approval_and_versions() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let t = templates(&conn).unwrap().into_iter().find(|t| t.kind == "loan").unwrap();
        approve_template(&mut conn, &e.admin, t.id, "Dr. João").unwrap();
        let same = TemplateInput { id: Some(t.id), kind: "loan".into(), name: "Novo nome".into(), body: t.body.clone(), active: None };
        save_template(&mut conn, &e.admin, same).unwrap();
        assert_eq!(template(&conn, t.id).unwrap().legal_status, "approved");
        let edited = TemplateInput { id: Some(t.id), kind: "loan".into(), name: "Novo nome".into(), body: format!("{} extra", t.body), active: None };
        save_template(&mut conn, &e.admin, edited).unwrap();
        let after = template(&conn, t.id).unwrap();
        assert_eq!((after.legal_status.as_str(), after.version), ("draft", t.version + 1));
    }

    #[test]
    fn variables_are_validated_per_kind_and_preview_renders() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let bad = TemplateInput { id: None, kind: "sale".into(), name: "Venda X".into(), body: "Valor {valor} parcela {parcela}".into(), active: None };
        assert!(save_template(&mut conn, &e.admin, bad).unwrap_err().to_string().contains("parcela"));
        let ok = TemplateInput { id: None, kind: "loan".into(), name: "Empréstimo X".into(), body: "# TÍTULO\nOlá {cliente_nome}, valor {valor}.".into(), active: None };
        let id = save_template(&mut conn, &e.admin, ok).unwrap();
        assert_eq!(template_versions(&conn, id).unwrap().len(), 1);
        let pdf = preview_pdf(&conn, "loan", "# CONTRATO\nCliente {cliente_nome}").unwrap();
        let text = String::from_utf8_lossy(&pdf).to_string();
        assert!(pdf.starts_with(b"%PDF") && text.contains("/Im1 Do"));
        assert!(preview_pdf(&conn, "loan", "{inexistente}").is_err());
        assert!(variables_for("loan").iter().any(|v| v.key == "cet_anual"));
        assert!(!variables_for("sale").iter().any(|v| v.key == "cet_anual"));
    }

    #[test]
    fn starter_templates_are_drafts_and_render_without_unknown_vars() {
        let e = env();
        let conn = e.db.conn().unwrap();
        let ts = templates(&conn).unwrap();
        assert_eq!(ts.len(), 4);
        assert!(ts.iter().all(|t| t.legal_status == "draft"));
    }
}
