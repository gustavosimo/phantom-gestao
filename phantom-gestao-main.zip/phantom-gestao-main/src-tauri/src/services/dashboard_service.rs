use chrono::{Datelike, Duration, NaiveDate};
use rusqlite::Connection;
use serde::{Deserialize, Serialize};

use crate::domain::loan::{last_day_of_month, month_start};
use crate::domain::validation::parse_date;
use crate::error::{AppError, AppResult};
use crate::repositories::settings_repo;

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Period {
    /// today | 7d | 30d | custom
    pub kind: String,
    pub from: Option<String>,
    pub to: Option<String>,
}

pub fn resolve(conn: &Connection, p: &Period) -> AppResult<(NaiveDate, NaiveDate)> {
    let today = settings_repo::today(conn);
    Ok(match p.kind.as_str() {
        "today" => (today, today),
        "7d" => (today - Duration::days(6), today),
        "30d" => (today - Duration::days(29), today),
        "quarter" => (today - Duration::days(89), today),
        "year" => (today - Duration::days(364), today),
        "custom" => {
            let f = parse_date(p.from.as_deref().unwrap_or(""))?;
            let t = parse_date(p.to.as_deref().unwrap_or(""))?;
            if f > t {
                return Err(AppError::Validation("Período inválido: a data inicial é posterior à final.".into()));
            }
            if (t - f).num_days() > 730 {
                return Err(AppError::Validation("Período máximo de 2 anos.".into()));
            }
            (f, t)
        }
        _ => return Err(AppError::Validation("Período inválido.".into())),
    })
}

fn q1(conn: &Connection, sql: &str, p: impl rusqlite::Params) -> AppResult<i64> {
    // datas gravadas em UTC (created_at) são convertidas para o fuso configurado
    let off = settings_repo::get_i64(conn, "regional.tz_offset_hours", -3)?;
    let sql = sql.replace("{OFF}", &format!("{off:+} hours"));
    Ok(conn.query_row(&sql, p, |r| r.get::<_, Option<i64>>(0))?.unwrap_or(0))
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Delta {
    pub value: i64,
    pub previous: i64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Dashboard {
    pub from: String,
    pub to: String,
    // cartões principais
    pub portfolio_cents: i64,
    pub received: Delta,
    pub overdue_cents: i64,
    pub overdue_count: i64,
    pub new_clients: Delta,
    // indicadores
    pub active_loans: i64,
    pub outstanding_cents: i64,
    pub receivable_cents: i64,
    pub collateral_in_custody: i64,
    pub sales_month_cents: i64,
    pub received_today_cents: i64,
    pub due_soon_count: i64,
    pub due_soon_cents: i64,
    pub pending: Pending,
    pub series: Vec<SeriesPoint>,
    pub series_granularity: String,
    pub recent: Vec<RecentOp>,
    pub notifications: Vec<NoticeRow>,
    pub unread_notifications: i64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Pending {
    pub applications_in_analysis: i64,
    pub contracts_pending_signature: i64,
    pub collateral_awaiting_appraisal: i64,
    pub purchases_pending: i64,
    pub payments_pending: i64,
    pub clients_without_documents: i64,
}

impl Pending {
    #[cfg(test)]
    pub fn total(&self) -> i64 {
        self.applications_in_analysis + self.contracts_pending_signature + self.collateral_awaiting_appraisal
            + self.purchases_pending + self.payments_pending + self.clients_without_documents
    }
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SeriesPoint {
    pub label: String,
    pub received_cents: i64,
    pub forecast_cents: i64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RecentOp {
    pub client_name: String,
    pub kind: String,
    pub amount_cents: i64,
    pub occurred_at: String,
    pub status: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct NoticeRow {
    pub id: i64,
    pub kind: String,
    pub severity: String,
    pub title: String,
    pub body: Option<String>,
    pub created_at: String,
}

/// Entradas líquidas de caixa de recebimentos (exclui suprimentos/sangrias e saídas de compras/desembolsos).
fn received_between(conn: &Connection, from: &str, to: &str) -> AppResult<i64> {
    q1(
        conn,
        "SELECT SUM(amount_cents) FROM cash_movements WHERE kind='in' AND category NOT IN ('Suprimento') AND substr(occurred_at,1,10) BETWEEN ?1 AND ?2",
        (from, to),
    )
}

pub fn month_label(d: NaiveDate) -> &'static str {
    ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"][d.month0() as usize]
}

pub fn series(conn: &Connection, from: NaiveDate, to: NaiveDate, monthly: bool) -> AppResult<Vec<SeriesPoint>> {
    let mut out = vec![];
    if monthly {
        let mut cur = month_start(to);
        let mut months = vec![];
        for _ in 0..6 {
            months.push(cur);
            cur = month_start(cur - Duration::days(1));
        }
        months.reverse();
        for m in months {
            let (a, b) = (m.to_string(), last_day_of_month(m.year(), m.month()).to_string());
            out.push(SeriesPoint {
                label: month_label(m).into(),
                received_cents: received_between(conn, &a, &b)?,
                forecast_cents: q1(conn, "SELECT SUM(amount_cents) FROM loan_installments WHERE status <> 'renegotiated' AND due_date BETWEEN ?1 AND ?2", (&a, &b))?
                    + q1(conn, "SELECT SUM(amount_cents) FROM payments WHERE status='pending' AND direction='in' AND due_date BETWEEN ?1 AND ?2", (&a, &b))?,
            });
        }
    } else {
        let mut d = from;
        while d <= to {
            let s = d.to_string();
            out.push(SeriesPoint {
                label: format!("{:02}/{:02}", d.day(), d.month()),
                received_cents: received_between(conn, &s, &s)?,
                forecast_cents: q1(conn, "SELECT SUM(amount_cents) FROM loan_installments WHERE status <> 'renegotiated' AND due_date = ?1", [&s])?
                    + q1(conn, "SELECT SUM(amount_cents) FROM payments WHERE status='pending' AND direction='in' AND due_date = ?1", [&s])?,
            });
            d += Duration::days(1);
        }
    }
    Ok(out)
}

pub fn load(conn: &Connection, p: &Period) -> AppResult<Dashboard> {
    let (from, to) = resolve(conn, p)?;
    let today = settings_repo::today(conn);
    let t = today.to_string();
    let len = (to - from).num_days() + 1;
    let (pf, pt) = (from - Duration::days(len), from - Duration::days(1));
    let (f, tt, pfs, pts) = (from.to_string(), to.to_string(), pf.to_string(), pt.to_string());

    let monthly = !matches!(p.kind.as_str(), "today" | "7d") && len > 31 || p.kind == "30d";
    let (sf, st) = match p.kind.as_str() {
        "today" => (today - Duration::days(6), today),
        _ => (from, to),
    };
    let outstanding = q1(conn, "SELECT SUM(i.amount_cents - i.paid_cents) FROM loan_installments i JOIN loans l ON l.id=i.loan_id WHERE i.status IN ('open','partial') AND l.status='active'", [])?;
    let pending_receivables = q1(conn, "SELECT SUM(amount_cents) FROM payments WHERE status='pending' AND direction='in'", [])?;
    let (od_cents, od_count): (i64, i64) = conn.query_row(
        "SELECT COALESCE(SUM(i.amount_cents - i.paid_cents),0), COUNT(*) FROM loan_installments i JOIN loans l ON l.id=i.loan_id
         WHERE i.status IN ('open','partial') AND l.status='active' AND i.due_date < ?1",
        [&t],
        |r| Ok((r.get(0)?, r.get(1)?)),
    )?;
    let (soon_n, soon_c): (i64, i64) = conn.query_row(
        "SELECT COUNT(*), COALESCE(SUM(i.amount_cents - i.paid_cents),0) FROM loan_installments i JOIN loans l ON l.id=i.loan_id
         WHERE i.status IN ('open','partial') AND l.status='active' AND i.due_date BETWEEN ?1 AND date(?1,'+7 days')",
        [&t],
        |r| Ok((r.get(0)?, r.get(1)?)),
    )?;
    let ms = month_start(today).to_string();
    let pending = Pending {
        applications_in_analysis: q1(conn, "SELECT COUNT(*) FROM credit_applications WHERE status IN ('draft','analysis','approved')", [])?,
        contracts_pending_signature: q1(conn, "SELECT COUNT(*) FROM contracts WHERE status='pending_signature'", [])?,
        collateral_awaiting_appraisal: q1(conn, "SELECT COUNT(*) FROM collateral_assets WHERE status IN ('registered','appraising')", [])?,
        purchases_pending: q1(conn, "SELECT COUNT(*) FROM purchases WHERE status='pending'", [])?,
        payments_pending: q1(conn, "SELECT COUNT(*) FROM payments WHERE status='pending' AND due_date < ?1", [&t])?,
        clients_without_documents: q1(conn, "SELECT COUNT(*) FROM clients c WHERE c.status='pending' AND NOT EXISTS (SELECT 1 FROM client_documents d WHERE d.client_id=c.id)", [])?,
    };
    let recent: Vec<RecentOp> = {
        let off = settings_repo::get_i64(conn, "regional.tz_offset_hours", -3)?;
        let recent_sql = "SELECT * FROM (
                SELECT COALESCE(c.name,'—'), 'loan', l.principal_cents, l.contracted_at, l.status FROM loans l JOIN clients c ON c.id=l.client_id
                UNION ALL SELECT COALESCE(c.name,'Consumidor final'), 'sale', s.total_cents, date(s.created_at,'{OFF}'), s.status FROM sales s LEFT JOIN clients c ON c.id=s.client_id
                UNION ALL SELECT c.name, 'collateral', COALESCE(a.appraised_cents,0), date(a.created_at,'{OFF}'), a.status FROM collateral_assets a JOIN clients c ON c.id=a.client_id
                UNION ALL SELECT COALESCE(c.name,p.party_name,'—'), 'payment', p.amount_cents, COALESCE(p.paid_at, date(p.created_at,'{OFF}')),
                    CASE WHEN p.status='pending' AND p.due_date < ?1 THEN 'overdue' ELSE p.status END
                    FROM payments p LEFT JOIN clients c ON c.id=p.client_id WHERE p.origin_type IN ('loan','receivable','payable') AND p.reversal_of_id IS NULL
             ) ORDER BY 4 DESC LIMIT 6"
            .replace("{OFF}", &format!("{off:+} hours"));
        let mut stmt = conn.prepare(&recent_sql)?;
        stmt.query_map([&t], |r| Ok(RecentOp { client_name: r.get(0)?, kind: r.get(1)?, amount_cents: r.get(2)?, occurred_at: r.get(3)?, status: r.get(4)? }))?
            .collect::<Result<Vec<_>, _>>()?
    };
    let notifications: Vec<NoticeRow> = {
        let mut stmt = conn.prepare("SELECT id, kind, severity, title, body, created_at FROM notifications ORDER BY (read_at IS NULL) DESC, created_at DESC, id DESC LIMIT 5")?;
        stmt.query_map([], |r| Ok(NoticeRow { id: r.get(0)?, kind: r.get(1)?, severity: r.get(2)?, title: r.get(3)?, body: r.get(4)?, created_at: r.get(5)? }))?
            .collect::<Result<Vec<_>, _>>()?
    };
    Ok(Dashboard {
        from: f.clone(),
        to: tt.clone(),
        portfolio_cents: q1(conn, "SELECT SUM(principal_cents) FROM loans WHERE status='active'", [])?,
        received: Delta { value: received_between(conn, &f, &tt)?, previous: received_between(conn, &pfs, &pts)? },
        overdue_cents: od_cents,
        overdue_count: od_count,
        new_clients: Delta {
            value: q1(conn, "SELECT COUNT(*) FROM clients WHERE date(created_at,'{OFF}') BETWEEN ?1 AND ?2", (&f, &tt))?,
            previous: q1(conn, "SELECT COUNT(*) FROM clients WHERE date(created_at,'{OFF}') BETWEEN ?1 AND ?2", (&pfs, &pts))?,
        },
        active_loans: q1(conn, "SELECT COUNT(*) FROM loans WHERE status='active'", [])?,
        outstanding_cents: outstanding,
        receivable_cents: outstanding + pending_receivables,
        collateral_in_custody: q1(conn, "SELECT COUNT(*) FROM collateral_assets WHERE status='in_custody'", [])?,
        sales_month_cents: q1(conn, "SELECT SUM(total_cents) FROM sales WHERE status <> 'cancelled' AND date(created_at,'{OFF}') >= ?1", [&ms])?,
        received_today_cents: received_between(conn, &t, &t)?,
        due_soon_count: soon_n,
        due_soon_cents: soon_c,
        unread_notifications: q1(conn, "SELECT COUNT(*) FROM notifications WHERE read_at IS NULL", [])?,
        pending,
        series: series(conn, sf, st, monthly)?,
        series_granularity: if monthly { "month".into() } else { "day".into() },
        recent,
        notifications,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::repositories::loan_repo;
    use crate::services::loan_service::tests::*;
    use crate::services::payment_service;
    use crate::testutil::env;

    fn p(kind: &str) -> Period {
        Period { kind: kind.into(), from: None, to: None }
    }

    #[test]
    fn empty_database_yields_zeroes() {
        let e = env();
        let conn = e.db.conn().unwrap();
        let d = load(&conn, &p("30d")).unwrap();
        assert_eq!((d.portfolio_cents, d.active_loans, d.overdue_count, d.pending.total()), (0, 0, 0, 0));
        assert_eq!(d.series.len(), 6);
        assert!(d.recent.is_empty());
    }

    #[test]
    fn indicators_come_from_real_data() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Mariana Souza", "529.982.247-25");
        let loan = active_loan(&mut conn, &e, c, 1_000_000, 4);
        let insts = loan_repo::installments(&conn, loan, false).unwrap();
        payment_service::pay_installment(&mut conn, &e.admin, insts[0].id, insts[0].amount_cents, "pix", None).unwrap();
        let past = (Utc_today() - Duration::days(4)).to_string();
        conn.execute("UPDATE loan_installments SET due_date=?2 WHERE id=?1", (insts[1].id, past)).unwrap();
        let d = load(&conn, &p("30d")).unwrap();
        assert_eq!(d.active_loans, 1);
        assert_eq!(d.portfolio_cents, 1_000_000);
        assert_eq!(d.received.value, insts[0].amount_cents);
        assert_eq!(d.received_today_cents, insts[0].amount_cents);
        assert_eq!((d.overdue_count, d.overdue_cents), (1, insts[1].amount_cents));
        let total_rest: i64 = insts[1..].iter().map(|i| i.amount_cents).sum();
        assert_eq!(d.outstanding_cents, total_rest);
        assert_eq!(d.new_clients.value, 1);
        assert!(d.recent.iter().any(|r| r.kind == "loan"));
        let daily = load(&conn, &p("7d")).unwrap();
        assert_eq!((daily.series.len(), daily.series_granularity.as_str()), (7, "day"));
    }

    #[allow(non_snake_case)]
    fn Utc_today() -> NaiveDate {
        crate::testutil::today()
    }

    #[test]
    fn custom_period_validation() {
        let e = env();
        let conn = e.db.conn().unwrap();
        let bad = Period { kind: "custom".into(), from: Some("2024-05-10".into()), to: Some("2024-05-01".into()) };
        assert!(load(&conn, &bad).is_err());
        let ok = Period { kind: "custom".into(), from: Some("2024-05-01".into()), to: Some("2024-05-10".into()) };
        assert_eq!(load(&conn, &ok).unwrap().series.len(), 10);
        assert!(load(&conn, &p("x")).is_err());
    }
}
