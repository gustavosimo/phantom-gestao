//! Dados de demonstração — compilado SOMENTE em builds de desenvolvimento (debug).
//! Nunca existe no instalador de produção. Os registros são criados pelos mesmos serviços
//! de negócio usados pela aplicação, e identificados com "[DEMO]" nas observações.

use chrono::{Duration, Months, NaiveDate};
use rusqlite::Connection;

use crate::domain::user::User;
use crate::error::{AppError, AppResult};
use crate::repositories::client_repo::ClientInput;
use crate::repositories::product_repo::ProductInput;
use crate::repositories::{loan_repo, settings_repo};
use crate::security::vault::Vault;
use crate::services::collateral_service::{self, CollateralInput};
use crate::services::loan_service::{self, ApplicationInput};
use crate::services::payment_service::{self, ManualPaymentInput};
use crate::services::purchase_service::{self, PurchaseInput};
use crate::services::sale_service::{self, SaleInput, SaleItemInput};
use crate::services::{client_service, contract_service, notification_service, product_service};

fn cpf(base: u64) -> String {
    let d: Vec<u32> = format!("{base:09}").chars().filter_map(|c| c.to_digit(10)).collect();
    let dv = |nums: &[u32], start: u32| {
        let s: u32 = nums.iter().enumerate().map(|(i, n)| n * (start - i as u32)).sum();
        let r = s % 11;
        if r < 2 { 0 } else { 11 - r }
    };
    let d1 = dv(&d, 10);
    let mut all = d.clone();
    all.push(d1);
    let d2 = dv(&all, 11);
    all.push(d2);
    all.iter().map(|n| n.to_string()).collect()
}

fn cnpj(base: u64) -> String {
    let d: Vec<u32> = format!("{base:012}").chars().filter_map(|c| c.to_digit(10)).collect();
    let dv = |nums: &[u32], w: &[u32]| {
        let s: u32 = nums.iter().zip(w).map(|(n, w)| n * w).sum();
        let r = s % 11;
        if r < 2 { 0 } else { 11 - r }
    };
    let d1 = dv(&d, &[5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]);
    let mut all = d.clone();
    all.push(d1);
    let d2 = dv(&all, &[6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]);
    all.push(d2);
    all.iter().map(|n| n.to_string()).collect()
}

fn client(conn: &mut Connection, user: &User, kind: &str, name: &str, doc: String, phone: &str, email: &str, status: &str, city: &str) -> AppResult<i64> {
    client_service::create(
        conn,
        user,
        ClientInput {
            kind: kind.into(), name: name.into(), document: doc, rg: None, birth_date: if kind == "PF" { Some("1988-04-12".into()) } else { None },
            profession: Some("Comerciante".into()), marital_status: None, email: Some(email.into()), phone: Some(phone.into()), phone2: None,
            zip: Some("01310100".into()), street: Some("Av. Paulista".into()), number: Some("1200".into()), complement: None,
            district: Some("Bela Vista".into()), city: Some(city.into()), state: Some("SP".into()),
            notes: Some("[DEMO] Registro de demonstração".into()), status: Some(status.into()), contact_opt_out: None,
        },
    )
}

fn product(conn: &mut Connection, user: &User, name: &str, cat: &str, cost: i64, price: i64, qty: i64) -> AppResult<i64> {
    let id = product_service::create(
        conn,
        user,
        ProductInput {
            sku: None, name: name.into(), category: cat.into(), brand: None, model: None, serial_number: None, cost_cents: cost,
            price_cents: price, min_stock: Some(2), active: Some(true), notes: Some("[DEMO]".into()),
        },
    )?;
    if qty > 0 {
        product_service::adjust_stock(conn, user, id, qty, "Estoque inicial (demonstração)")?;
    }
    Ok(id)
}

fn shift(d: NaiveDate, months: i32) -> NaiveDate {
    if months >= 0 { d.checked_add_months(Months::new(months as u32)).unwrap_or(d) } else { d.checked_sub_months(Months::new((-months) as u32)).unwrap_or(d) }
}

/// Cria um empréstimo completo: aprovação, contrato assinado, desembolso, parcelas pagas e datas realinhadas.
fn loan(conn: &mut Connection, vault: &Vault, user: &User, client_id: i64, amount: i64, term: u32, purpose: &str, paid: u32, next_due_in_days: i64, disburse: bool) -> AppResult<i64> {
    let today = settings_repo::today(conn);
    let app = loan_service::create_application(conn, user, ApplicationInput {
        client_id, amount_cents: amount, term_months: term, rate_bp: Some(240), purpose: Some(purpose.into()),
        first_due_date: (today + Duration::days(30)).to_string(), collateral_id: None,
    })?;
    loan_service::analyze(conn, user, app, Some("[DEMO] análise automática de regras".into()))?;
    loan_service::decide(conn, user, app, true, "[DEMO] aprovado")?;
    let id = loan_service::contract(conn, user, app)?;
    let k = contract_service::generate(conn, vault, user, "loan", id, None)?;
    contract_service::sign(conn, user, k, "Cliente (demonstração)", None)?;
    if !disburse {
        return Ok(id);
    }
    loan_service::disburse(conn, user, id, "pix")?;
    let insts = loan_repo::installments(conn, id, false)?;
    for i in insts.iter().take(paid as usize) {
        payment_service::pay_installment(conn, user, i.id, i.amount_cents, "pix", None)?;
    }
    // realinha o calendário: a parcela (paid+1) vence em `next_due_in_days`
    let anchor = today + Duration::days(next_due_in_days);
    for i in &insts {
        let due = shift(anchor, i.number as i32 - (paid as i32 + 1));
        conn.execute("UPDATE loan_installments SET due_date = ?2 WHERE id = ?1", (i.id, due.to_string()))?;
    }
    let first = shift(anchor, -(paid as i32));
    conn.execute("UPDATE loans SET first_due_date = ?2, contracted_at = ?3, disbursed_at = ?3 WHERE id = ?1", (id, first.to_string(), shift(first, -1).to_string()))?;
    Ok(id)
}

#[allow(clippy::too_many_arguments)]
fn collateral(conn: &mut Connection, vault: &Vault, user: &User, client_id: i64, loan_id: Option<i64>, cat: &str, name: &str, brand: &str, model: &str, serial: &str, cond: &str, value: Option<i64>, custody_left: Option<i64>) -> AppResult<i64> {
    let id = collateral_service::create(conn, vault, user, CollateralInput {
        client_id, category: cat.into(), name: name.into(), brand: Some(brand.into()), model: Some(model.into()), serial_number: Some(serial.into()),
        condition: cond.into(), appraised_cents: value, storage_location: None, custody_days: Some(30), notes: Some("[DEMO]".into()),
        application_id: None, photo_paths: None,
    })?;
    if let Some(left) = custody_left {
        collateral_service::approve(conn, user, id, true, None)?;
        let k = contract_service::generate(conn, vault, user, "collateral", id, None)?;
        contract_service::sign(conn, user, k, "Cliente (demonstração)", None)?;
        collateral_service::receive_custody(conn, vault, user, id, "Cofre — Matriz", 30)?;
        let due = settings_repo::today(conn) + Duration::days(left);
        conn.execute("UPDATE collateral_assets SET custody_due = ?2, loan_id = ?3, linked_value_cents = (SELECT principal_cents FROM loans WHERE id = ?3) WHERE id = ?1", rusqlite::params![id, due.to_string(), loan_id])?;
    }
    Ok(id)
}

pub fn run(conn: &mut Connection, vault: &Vault, user: &User) -> AppResult<()> {
    let existing: i64 = conn.query_row("SELECT COUNT(*) FROM clients", [], |r| r.get(0))?;
    if existing > 0 {
        return Err(AppError::Validation("Já existem clientes cadastrados. Os dados de demonstração só podem ser carregados em uma base vazia.".into()));
    }
    for (k, v) in [
        ("company.name", "Phantom Financeira Ltda. [DEMO]"), ("company.document", "11.222.333/0001-81"), ("company.email", "contato@phantomfinanceira.com.br"),
        ("company.phone", "(11) 4000-5000"), ("company.address", "Av. Faria Lima, 2000 — São Paulo/SP"),
        ("credit.enabled", "true"), ("collateral.enabled", "true"),
        ("regulatory.credit_note", "[DEMO] habilitado apenas para demonstração — sem validação regulatória real"),
        ("regulatory.collateral_note", "[DEMO] habilitado apenas para demonstração — sem validação regulatória real"),
        ("regulatory.credit_by", "demo"), ("regulatory.collateral_by", "demo"),
    ] {
        settings_repo::set(conn, k, v)?;
    }
    for t in contract_service::templates(conn)? {
        contract_service::approve_template(conn, user, t.id, "Demonstração (sem validade jurídica)")?;
    }

    let mariana = client(conn, user, "PF", "Mariana Souza", cpf(123_456_789), "(11) 98421-0012", "mariana.souza@email.com", "active", "São Paulo")?;
    let joao = client(conn, user, "PF", "João Pereira", cpf(456_123_789), "(21) 99812-3344", "joao.pereira@email.com", "active", "Rio de Janeiro")?;
    let carla = client(conn, user, "PJ", "Carla Nogueira Ltda", cnpj(12_345_678_0001), "(31) 98765-4321", "contato@carlanogueira.com.br", "active", "Belo Horizonte")?;
    let felipe = client(conn, user, "PF", "Felipe Araújo", cpf(789_123_456), "(41) 99000-1122", "felipe.araujo@email.com", "active", "Curitiba")?;
    let beatriz = client(conn, user, "PF", "Beatriz Lima", cpf(321_654_987), "(11) 97654-3210", "beatriz.lima@email.com", "active", "São Paulo")?;
    let rodrigo = client(conn, user, "PJ", "Rodrigo Dias ME", cnpj(98_765_432_0001), "(51) 98888-7766", "rodrigo@diasme.com.br", "inactive", "Porto Alegre")?;
    client_service::add_document(conn, vault, user, mariana, "RG", Some("12.345.678-9".into()), None, None)?;
    client_service::add_document(conn, vault, user, carla, "Contrato social", None, None, None)?;

    let samsung = product(conn, user, "Smartphone Samsung A54", "Eletrônicos", 145_000, 234_000, 8)?;
    product(conn, user, "Notebook Lenovo Ideapad", "Eletrônicos", 210_000, 320_000, 3)?;
    let casio = product(conn, user, "Relógio Casio G-Shock", "Acessórios", 32_000, 58_000, 6)?;
    let violao = product(conn, user, "Violão Yamaha F310", "Instrumentos", 68_000, 110_000, 5)?;
    let bike = product(conn, user, "Bicicleta Caloi Elite", "Esportes", 75_000, 110_000, 2)?;
    product(conn, user, "Smart TV LG 50 pol", "Eletrônicos", 190_000, 280_000, 6)?;

    let l1 = loan(conn, vault, user, mariana, 1_500_000, 12, "Capital de giro", 6, 10, true)?;
    loan(conn, vault, user, joao, 850_000, 10, "Reforma", 0, 30, false)?;
    let l3 = loan(conn, vault, user, carla, 4_200_000, 18, "Expansão", 8, -11, true)?;
    let l4 = loan(conn, vault, user, felipe, 520_000, 12, "Pessoal", 0, 30, true)?;
    payment_service::settle_loan(conn, user, l4, "transfer", None)?;
    loan(conn, vault, user, beatriz, 1_500_000, 8, "Capital de giro", 0, 20, true)?;
    let _ = rodrigo;

    collateral(conn, vault, user, mariana, Some(l1), "Eletrônicos", "Notebook Dell Inspiron", "Dell", "Inspiron 15", "SN-884921", "refurbished", Some(240_000), Some(30))?;
    collateral(conn, vault, user, carla, Some(l3), "Joias", "Relógio Rolex Submariner", "Rolex", "Submariner", "RX-90210", "used", Some(1_850_000), Some(12))?;
    collateral(conn, vault, user, beatriz, None, "Joias", "Anel de Ouro 18k", "—", "Solitário", "AN-1180", "used", Some(320_000), Some(3))?;
    collateral(conn, vault, user, felipe, None, "Eletrônicos", "Smartphone iPhone 13", "Apple", "iPhone 13", "IMEI-3566", "used", None, None)?;
    collateral(conn, vault, user, rodrigo, None, "Instrumentos", "Violão Taylor 214ce", "Taylor", "214ce", "TY-214", "used", None, None)?;

    sale_service::create(conn, user, SaleInput { client_id: Some(joao), items: vec![SaleItemInput { product_id: samsung, qty: 1 }], discount_cents: 0, payment_method: "card".into(), idempotency_key: None })?;
    sale_service::create(conn, user, SaleInput { client_id: None, items: vec![SaleItemInput { product_id: samsung, qty: 1 }, SaleItemInput { product_id: casio, qty: 2 }], discount_cents: 15_000, payment_method: "pix".into(), idempotency_key: None })?;

    for (seller, product_name, cat, total, method, confirm, existing) in [
        ("Loja Ágil Usados", "Notebook Dell Inspiron 15", "Eletrônicos", 210_000, "pix", true, None),
        ("Tech Center SP", "Smartphone Samsung A54", "Eletrônicos", 145_000, "transfer", true, Some(samsung)),
        ("Relojoaria Central", "Relógio Casio G-Shock", "Acessórios", 32_000, "cash", false, Some(casio)),
        ("Música & Cia", "Violão Yamaha F310", "Instrumentos", 68_000, "pix", true, Some(violao)),
        ("Esporte Total", "Bicicleta Caloi Elite", "Esportes", 75_000, "boleto", false, Some(bike)),
    ] {
        purchase_service::register(conn, vault, user, PurchaseInput {
            seller_client_id: None, seller_name: Some(seller.into()), seller_document: None, product_id: existing, product_name: if existing.is_some() { None } else { Some(product_name.into()) },
            category: if existing.is_some() { None } else { Some(cat.into()) }, brand: None, model: None, serial_number: None, sale_price_cents: Some(total * 3 / 2), qty: Some(1),
            amount_cents: total, valuation_cents: None, payment_method: method.into(), confirm,
            due_date: Some((settings_repo::today(conn) + Duration::days(15)).to_string()), origin_proof: Some("Nota fiscal do fornecedor (demonstração)".into()),
            purchased_at: None, notes: Some("[DEMO]".into()), receipt_path: None,
        })?;
    }
    payment_service::register_manual(conn, user, ManualPaymentInput {
        client_id: None, party_name: Some("Imobiliária Central".into()), direction: "out".into(), description: "Aluguel da sede [DEMO]".into(),
        amount_cents: 450_000, method: "transfer".into(), due_date: Some((settings_repo::today(conn) + Duration::days(5)).to_string()), confirm: false, idempotency_key: None,
    })?;
    payment_service::register_manual(conn, user, ManualPaymentInput {
        client_id: Some(joao), party_name: None, direction: "in".into(), description: "Serviço avulso [DEMO]".into(),
        amount_cents: 65_000, method: "pix".into(), due_date: Some((settings_repo::today(conn) - Duration::days(3)).to_string()), confirm: false, idempotency_key: None,
    })?;
    notification_service::run_rules(conn)?;
    crate::repositories::audit_repo::log(conn, user, "demo.seed", "system", 0, "Dados de demonstração carregados (build de desenvolvimento)")?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::repositories::{payment_repo, PageQuery};
    use crate::services::{dashboard_service, report_service};
    use crate::testutil::env;

    #[test]
    fn demo_dataset_loads_through_business_services_and_feeds_every_module() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        run(&mut conn, &e.vault, &e.admin).unwrap();
        assert!(run(&mut conn, &e.vault, &e.admin).is_err());
        let today = settings_repo::today(&conn).to_string();
        let loans = loan_repo::list_loans(&conn, &PageQuery::default(), &today).unwrap();
        assert_eq!(loans.total, 5);
        let late = PageQuery { status: Some("late".into()), ..Default::default() };
        assert_eq!(loan_repo::list_loans(&conn, &late, &today).unwrap().total, 1);
        let d = dashboard_service::load(&conn, &dashboard_service::Period { kind: "30d".into(), from: None, to: None }).unwrap();
        assert!(d.active_loans >= 3 && d.overdue_count == 1 && d.collateral_in_custody == 3);
        assert!(d.sales_month_cents > 0 && !d.recent.is_empty() && !d.notifications.is_empty());
        assert!(payment_repo::cash_summary(&conn).unwrap().unreconciled_count > 0);
        let o = report_service::overview(&conn, &dashboard_service::Period { kind: "30d".into(), from: None, to: None }).unwrap();
        assert!(o.new_contracts.value >= 3);
        let stats = collateral_service::stats(&conn).unwrap();
        assert_eq!((stats.in_custody, stats.awaiting_appraisal), (3, 2));
    }

    #[test]
    fn generated_cpf_and_cnpj_are_valid() {
        assert!(crate::domain::validation::is_valid_cpf(&cpf(123_456_789)));
        assert!(crate::domain::validation::is_valid_cnpj(&cnpj(12_345_678_0001)));
    }
}


/// Auxiliar de desenvolvimento (ignorado nos testes normais): cria administrador + dados de demonstração
/// numa pasta de dados isolada, para inspecionar telas no navegador sem tocar nos dados reais.
///
///   PHANTOM_DATA_DIR=C:/tmp/phantom-e2e2 cargo test --lib seed_dev_demo -- --ignored
#[cfg(test)]
mod dev_seed {
    use super::*;
    use crate::database::Database;
    use crate::services::auth_service;

    #[test]
    #[ignore]
    fn seed_dev_demo() {
        let dir = std::path::PathBuf::from(std::env::var("PHANTOM_DATA_DIR").expect("defina PHANTOM_DATA_DIR"));
        std::fs::create_dir_all(&dir).unwrap();
        let db = Database::open(&dir.join("phantom.db")).unwrap();
        let vault = Vault::open(&dir.join("vault")).unwrap();
        let admin = if auth_service::setup_required(&db).unwrap() {
            auth_service::setup_admin(&db, "Administrador E2E", "e2e.admin", "E2E-senha-forte-123").unwrap()
        } else {
            auth_service::login(&db, "e2e.admin", "E2E-senha-forte-123").unwrap()
        };
        let mut conn = db.conn().unwrap();
        run(&mut conn, &vault, &admin).unwrap();
    }
}
