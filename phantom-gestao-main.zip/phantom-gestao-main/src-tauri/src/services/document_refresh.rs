//! Atualiza PDFs gerados antes do cabeçalho institucional (logo + nome da empresa).
//! Os arquivos antigos são preservados (tipo renomeado para `*_v1`); o novo passa a ser o exibido.

use rusqlite::Connection;

use crate::domain::user::User;
use crate::domain::validation::parse_date;
use crate::error::AppResult;
use crate::repositories::{audit_repo, user_repo};
use crate::security::vault::Vault;
use crate::services::{attachment_service, collateral_service, payment_service, purchase_service, report_service, sale_service};

type Regen = fn(&mut Connection, &Vault, &User, i64) -> AppResult<attachment_service::Attachment>;

struct Old {
    id: i64,
    owner_id: i64,
    name: String,
    created_at: String,
}

fn old_pdfs(conn: &Connection, owner: &str, kind: &str) -> AppResult<Vec<Old>> {
    let mut stmt = conn.prepare(
        "SELECT id, owner_id, original_name, created_at FROM attachments
         WHERE owner_type = ?1 AND kind = ?2 AND mime = 'application/pdf' AND layout < 2 ORDER BY id",
    )?;
    let rows = stmt
        .query_map((owner, kind), |r| Ok(Old { id: r.get(0)?, owner_id: r.get(1)?, name: r.get(2)?, created_at: r.get(3)? }))?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

fn retire(conn: &Connection, id: i64, kind: &str) -> AppResult<()> {
    conn.execute("UPDATE attachments SET kind = ?2 WHERE id = ?1", (id, format!("{kind}_v1")))?;
    Ok(())
}

/// Regenera recibos, comprovantes, termos de custódia e relatórios em PDF com o layout atual. Idempotente.
pub fn refresh_all(conn: &mut Connection, vault: &Vault) -> AppResult<usize> {
    let Some(admin_id) = conn.query_row("SELECT id FROM users ORDER BY id LIMIT 1", [], |r| r.get::<_, i64>(0)).ok() else {
        return Ok(0);
    };
    let admin = user_repo::load_user(conn, admin_id)?;
    let mut n = 0;

    let receipts: [(&str, Regen); 3] = [
        ("payment", payment_service::receipt),
        ("sale", sale_service::receipt),
        ("purchase", purchase_service::receipt),
    ];
    for (owner, regen) in receipts {
        for old in old_pdfs(conn, owner, "receipt")? {
            retire(conn, old.id, "receipt")?;
            if regen(conn, vault, &admin, old.owner_id).is_ok() {
                n += 1;
            } else {
                conn.execute("UPDATE attachments SET kind = 'receipt' WHERE id = ?1", [old.id])?;
            }
        }
    }

    for old in old_pdfs(conn, "collateral", "receipt_term")? {
        let Ok(a) = collateral_service::get(conn, old.owner_id) else { continue };
        let (Some(loc), Some(days), Some(start), Some(due)) =
            (a.storage_location.clone(), a.custody_days, a.custody_start.clone(), a.custody_due.clone())
        else {
            continue;
        };
        let bytes = collateral_service::receipt_term_pdf(conn, &a, &loc, days, &start, &due);
        retire(conn, old.id, "receipt_term")?;
        attachment_service::add_bytes(conn, vault, &admin, "collateral", old.owner_id, "receipt_term", &format!("termo_recebimento_{}.pdf", a.code), &bytes)?;
        n += 1;
    }
    for old in old_pdfs(conn, "collateral", "return_term")? {
        let Ok(a) = collateral_service::get(conn, old.owner_id) else { continue };
        let kind = if old.name.contains("redeemed") { "redeemed" } else { "returned" };
        let desc: String = conn
            .query_row("SELECT description FROM custody_events WHERE asset_id = ?1 AND kind = ?2 ORDER BY id DESC LIMIT 1", (old.owner_id, kind), |r| r.get(0))
            .unwrap_or_default();
        let note = desc.split(" — ").nth(1).unwrap_or(&desc).to_string();
        let date = &old.created_at[..10.min(old.created_at.len())];
        let bytes = collateral_service::return_term_pdf(conn, &a, kind, &note, date);
        retire(conn, old.id, "return_term")?;
        attachment_service::add_bytes(conn, vault, &admin, "collateral", old.owner_id, "return_term", &format!("termo_{kind}_{}.pdf", a.code), &bytes)?;
        n += 1;
    }

    // relatórios PDF: refeitos para o mesmo tipo e período
    let reports: Vec<(i64, String, String, i64)> = {
        let mut stmt = conn.prepare(
            "SELECT g.id, g.report_type, g.period_label, g.attachment_id FROM generated_reports g
             JOIN attachments a ON a.id = g.attachment_id WHERE g.format = 'pdf' AND a.layout < 2",
        )?;
        let rows = stmt.query_map([], |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?)))?.collect::<Result<Vec<_>, _>>()?;
        rows
    };
    for (gid, rtype, label, old_att) in reports {
        let mut parts = label.split(" a ");
        let (Some(f), Some(t)) = (parts.next(), parts.next()) else { continue };
        let (Ok(from), Ok(to)) = (parse_date(f), parse_date(t)) else { continue };
        let Ok(data) = report_service::build(conn, &rtype, from, to) else { continue };
        let bytes = report_service::to_pdf(conn, &data, &label);
        let name: String = conn.query_row("SELECT original_name FROM attachments WHERE id = ?1", [old_att], |r| r.get(0))?;
        retire(conn, old_att, "report")?;
        let new_att = report_service::add_report_bytes(conn, vault, &admin, &name, "pdf", &bytes)?;
        conn.execute("UPDATE generated_reports SET attachment_id = ?2 WHERE id = ?1", (gid, new_att))?;
        n += 1;
    }

    if n > 0 {
        audit_repo::record(conn, None, Some("sistema"), "documents.layout_refresh", Some("attachments"), Some(&format!("{n} documento(s)")))?;
    }
    Ok(n)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::services::dashboard_service::Period;
    use crate::services::demo_seed;
    use crate::testutil::env;

    #[test]
    fn every_generated_pdf_carries_the_branded_header_after_refresh() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        demo_seed::run(&mut conn, &e.vault, &e.admin).unwrap();
        let pid: i64 = conn.query_row("SELECT id FROM payments WHERE status='confirmed' LIMIT 1", [], |r| r.get(0)).unwrap();
        payment_service::receipt(&mut conn, &e.vault, &e.admin, pid).unwrap();
        let sid: i64 = conn.query_row("SELECT id FROM sales LIMIT 1", [], |r| r.get(0)).unwrap();
        sale_service::receipt(&mut conn, &e.vault, &e.admin, sid).unwrap();
        let prid: i64 = conn.query_row("SELECT id FROM purchases WHERE status='confirmed' LIMIT 1", [], |r| r.get(0)).unwrap();
        purchase_service::receipt(&mut conn, &e.vault, &e.admin, prid).unwrap();
        report_service::export(
            &mut conn,
            &e.vault,
            &e.admin,
            report_service::ExportInput { report_type: "cashflow".into(), period: Period { kind: "30d".into(), from: None, to: None }, format: "pdf".into() },
        )
        .unwrap();
        // simula uma base antiga: nenhum PDF possui o cabeçalho institucional
        conn.execute("UPDATE attachments SET layout = 1 WHERE mime = 'application/pdf'", []).unwrap();

        let n = refresh_all(&mut conn, &e.vault).unwrap();
        assert!(n >= 6, "atualizados: {n}");
        assert_eq!(refresh_all(&mut conn, &e.vault).unwrap(), 0);

        let mut stmt = conn
            .prepare("SELECT id, kind FROM attachments WHERE mime = 'application/pdf' AND kind NOT LIKE '%_v1' AND kind <> 'contract' AND kind <> 'proof'")
            .unwrap();
        let rows: Vec<(i64, String)> = stmt.query_map([], |r| Ok((r.get(0)?, r.get(1)?))).unwrap().map(|r| r.unwrap()).collect();
        assert!(rows.len() >= 6);
        for (id, kind) in rows {
            let (_, bytes) = attachment_service::read(&conn, &e.vault, id).unwrap();
            let text = String::from_utf8_lossy(&bytes);
            assert!(text.contains("/Im1 Do"), "{kind} sem logo");
            assert!(text.contains("FINANCEIRA"), "{kind} sem nome");
        }
    }
}
