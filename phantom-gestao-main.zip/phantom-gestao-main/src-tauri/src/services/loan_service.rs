use chrono::NaiveDate;
use rusqlite::{Connection, OptionalExtension};
use serde::{Deserialize, Serialize};

use crate::domain::loan::{build_schedule, simulate, LoanParams, Simulation};
use crate::domain::money::format_brl;
use crate::domain::user::User;
use crate::domain::validation::*;
use crate::error::{AppError, AppResult};
use crate::repositories::loan_repo::{self, InstallmentRow, LoanRow};
use crate::repositories::payment_repo::{self, NewPayment};
use crate::repositories::{audit_repo, settings_repo};
use crate::services::payment_service::{self, InstallmentDue};

pub const CREDIT_BLOCKED: &str = "Operação bloqueada: o crédito ainda não foi habilitado. A habilitação exige validação do enquadramento jurídico, das autorizações e da modalidade operacional da empresa (Configurações › Regras Financeiras).";
pub const COLLATERAL_BLOCKED: &str = "Operação bloqueada: operações com garantias ainda não foram habilitadas. A habilitação exige validação regulatória (Configurações › Regras Financeiras).";

pub fn require_credit_enabled(conn: &Connection) -> AppResult<()> {
    if settings_repo::get_bool(conn, "credit.enabled")? { Ok(()) } else { Err(AppError::Validation(CREDIT_BLOCKED.into())) }
}

pub fn require_collateral_enabled(conn: &Connection) -> AppResult<()> {
    if settings_repo::get_bool(conn, "collateral.enabled")? { Ok(()) } else { Err(AppError::Validation(COLLATERAL_BLOCKED.into())) }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SimulationInput {
    pub amount_cents: i64,
    pub term_months: u32,
    pub rate_bp: Option<i64>,
    pub first_due_date: String,
}

pub fn simulation(conn: &Connection, i: &SimulationInput) -> AppResult<Simulation> {
    let max_term = settings_repo::get_i64(conn, "loan.max_term_months", 60);
    let max_amount = settings_repo::get_i64(conn, "loan.max_amount_cents", 5_000_000);
    let (max_term, max_amount) = (max_term?, max_amount?);
    if i.amount_cents <= 0 || i.amount_cents > max_amount {
        return Err(AppError::Validation(format!("Valor deve estar entre R$ 0,01 e {}.", format_brl(max_amount))));
    }
    if i.term_months == 0 || i.term_months as i64 > max_term {
        return Err(AppError::Validation(format!("Prazo deve ser de 1 a {max_term} parcelas.")));
    }
    let rate_bp = match i.rate_bp {
        Some(r) => r,
        None => settings_repo::get_i64(conn, "loan.default_rate_bp", 240)?,
    };
    if !(0..=2000).contains(&rate_bp) {
        return Err(AppError::Validation("Taxa de juros fora do intervalo permitido (0% a 20% a.m.).".into()));
    }
    let first_due = parse_date(&i.first_due_date)?;
    let today = settings_repo::today(conn);
    if first_due <= today {
        return Err(AppError::Validation("O primeiro vencimento deve ser posterior a hoje.".into()));
    }
    simulate(&LoanParams {
        principal_cents: i.amount_cents,
        term_months: i.term_months,
        rate_bp,
        first_due,
        fee_bp: settings_repo::get_i64(conn, "loan.origination_fee_bp", 0)?,
        iof_bp: settings_repo::get_i64(conn, "loan.iof_bp", 0)?,
    })
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ApplicationInput {
    pub client_id: i64,
    pub amount_cents: i64,
    pub term_months: u32,
    pub rate_bp: Option<i64>,
    pub purpose: Option<String>,
    pub first_due_date: String,
    pub collateral_id: Option<i64>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ApplicationRow {
    pub id: i64,
    pub client_id: i64,
    pub client_name: String,
    pub amount_cents: i64,
    pub term_months: i64,
    pub rate_bp: i64,
    pub purpose: Option<String>,
    pub first_due_date: String,
    pub collateral_id: Option<i64>,
    pub status: String,
    pub analysis_notes: Option<String>,
    pub analysis: Option<serde_json::Value>,
    pub decision_notes: Option<String>,
    pub decided_at: Option<String>,
    pub loan_id: Option<i64>,
    pub created_at: String,
}

fn app_map(r: &rusqlite::Row) -> rusqlite::Result<ApplicationRow> {
    let analysis: Option<String> = r.get(10)?;
    Ok(ApplicationRow {
        id: r.get(0)?,
        client_id: r.get(1)?,
        client_name: r.get(2)?,
        amount_cents: r.get(3)?,
        term_months: r.get(4)?,
        rate_bp: r.get(5)?,
        purpose: r.get(6)?,
        first_due_date: r.get(7)?,
        collateral_id: r.get(8)?,
        status: r.get(9)?,
        analysis: analysis.and_then(|s| serde_json::from_str(&s).ok()),
        analysis_notes: r.get(11)?,
        decision_notes: r.get(12)?,
        decided_at: r.get(13)?,
        loan_id: r.get(14)?,
        created_at: r.get(15)?,
    })
}

const ACOLS: &str = "a.id, a.client_id, c.name, a.amount_cents, a.term_months, a.rate_bp, a.purpose, a.first_due_date, a.collateral_id,
    a.status, a.analysis_json, a.analysis_notes, a.decision_notes, a.decided_at,
    (SELECT l.id FROM loans l WHERE l.application_id = a.id LIMIT 1), a.created_at";

pub fn get_application(conn: &Connection, id: i64) -> AppResult<ApplicationRow> {
    conn.query_row(
        &format!("SELECT {ACOLS} FROM credit_applications a JOIN clients c ON c.id = a.client_id WHERE a.id = ?1"),
        [id],
        app_map,
    )
    .optional()?
    .ok_or_else(|| AppError::Validation("Solicitação não encontrada.".into()))
}

pub fn list_applications(conn: &Connection, status: Option<&str>) -> AppResult<Vec<ApplicationRow>> {
    let mut stmt = conn.prepare(&format!(
        "SELECT {ACOLS} FROM credit_applications a JOIN clients c ON c.id = a.client_id
         WHERE (?1 IS NULL OR a.status = ?1) AND a.status NOT IN ('cancelled') ORDER BY a.id DESC LIMIT 100"
    ))?;
    let rows = stmt.query_map([status], app_map)?.collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

fn validate_app(conn: &Connection, i: &ApplicationInput) -> AppResult<()> {
    simulation(conn, &SimulationInput {
        amount_cents: i.amount_cents, term_months: i.term_months, rate_bp: i.rate_bp, first_due_date: i.first_due_date.clone(),
    })?;
    let status: Option<String> = conn.query_row("SELECT status FROM clients WHERE id = ?1", [i.client_id], |r| r.get(0)).optional()?;
    match status.as_deref() {
        None => Err(AppError::Validation("Cliente não encontrado.".into())),
        Some("inactive") => Err(AppError::Validation("Cliente inativo.".into())),
        _ => Ok(()),
    }
}

pub fn create_application(conn: &mut Connection, user: &User, i: ApplicationInput) -> AppResult<i64> {
    validate_app(conn, &i)?;
    let rate = match i.rate_bp {
        Some(r) => r,
        None => settings_repo::get_i64(conn, "loan.default_rate_bp", 240)?,
    };
    let tx = conn.transaction()?;
    tx.execute(
        "INSERT INTO credit_applications (client_id, amount_cents, term_months, rate_bp, purpose, first_due_date, collateral_id, created_by)
         VALUES (?1,?2,?3,?4,?5,?6,?7,?8)",
        rusqlite::params![i.client_id, i.amount_cents, i.term_months, rate, opt_text(&i.purpose), i.first_due_date, i.collateral_id, user.id],
    )?;
    let id = tx.last_insert_rowid();
    audit_repo::log(&tx, user, "credit.application_create", "credit_applications", id, &format_brl(i.amount_cents))?;
    tx.commit()?;
    Ok(id)
}

pub fn update_application(conn: &mut Connection, user: &User, id: i64, i: ApplicationInput) -> AppResult<()> {
    validate_app(conn, &i)?;
    let rate = match i.rate_bp {
        Some(r) => r,
        None => settings_repo::get_i64(conn, "loan.default_rate_bp", 240)?,
    };
    let tx = conn.transaction()?;
    let cur = get_application(&tx, id)?;
    if !matches!(cur.status.as_str(), "draft" | "analysis") {
        return Err(AppError::Validation("Solicitação não pode mais ser alterada.".into()));
    }
    tx.execute(
        "UPDATE credit_applications SET client_id=?2, amount_cents=?3, term_months=?4, rate_bp=?5, purpose=?6, first_due_date=?7,
            collateral_id=?8, status='draft', analysis_json=NULL, updated_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id=?1",
        rusqlite::params![id, i.client_id, i.amount_cents, i.term_months, rate, opt_text(&i.purpose), i.first_due_date, i.collateral_id],
    )?;
    audit_repo::log(&tx, user, "credit.application_update", "credit_applications", id, "")?;
    tx.commit()?;
    Ok(())
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Check {
    pub key: String,
    pub label: String,
    pub ok: bool,
    pub required: bool,
    pub detail: String,
}

fn check(key: &str, label: &str, ok: bool, required: bool, detail: impl Into<String>) -> Check {
    Check { key: key.into(), label: label.into(), ok, required, detail: detail.into() }
}

/// Análise cadastral determinística (sem IA): verifica regras objetivas sobre o cliente e a exposição.
pub fn analyze(conn: &mut Connection, user: &User, id: i64, notes: Option<String>) -> AppResult<serde_json::Value> {
    let tx = conn.transaction()?;
    let app = get_application(&tx, id)?;
    if !matches!(app.status.as_str(), "draft" | "analysis") {
        return Err(AppError::Validation("Solicitação já foi decidida.".into()));
    }
    let today = settings_repo::today(&tx).to_string();
    let client = crate::repositories::client_repo::get(&tx, app.client_id, &today)?;
    let docs: i64 = tx.query_row("SELECT COUNT(*) FROM client_documents WHERE client_id = ?1", [app.client_id], |r| r.get(0))?;
    let overdue: i64 = tx.query_row(
        "SELECT COUNT(*) FROM loan_installments i JOIN loans l ON l.id = i.loan_id
         WHERE l.client_id = ?1 AND i.status IN ('open','partial') AND i.due_date < ?2",
        (app.client_id, &today),
        |r| r.get(0),
    )?;
    let exposure: i64 = tx.query_row(
        "SELECT COALESCE(SUM(i.amount_cents - i.paid_cents),0) FROM loan_installments i JOIN loans l ON l.id = i.loan_id
         WHERE l.client_id = ?1 AND i.status IN ('open','partial')",
        [app.client_id],
        |r| r.get(0),
    )?;
    let max_amount = settings_repo::get_i64(&tx, "loan.max_amount_cents", 5_000_000)?;
    let checks = vec![
        check("status", "Cadastro ativo", client.status == "active", true, if client.status == "active" { "Cliente verificado".to_string() } else { format!("Situação atual: {}", client.status) }),
        check("contact", "Contato informado", client.phone.is_some() || client.email.is_some(), true, "Telefone ou e-mail"),
        check("address", "Endereço informado", client.street.is_some() && client.city.is_some(), false, "Logradouro e cidade"),
        check("documents", "Documentos anexados", docs > 0, false, format!("{docs} documento(s)")),
        check("overdue", "Sem parcelas em atraso", overdue == 0, true, format!("{overdue} parcela(s) em atraso")),
        check("exposure", "Exposição dentro do limite", exposure + app.amount_cents <= max_amount, true, format!("Saldo atual {} + solicitado {}", format_brl(exposure), format_brl(app.amount_cents))),
    ];
    let blocking = checks.iter().any(|c| c.required && !c.ok);
    let result = serde_json::json!({ "checks": checks, "exposureCents": exposure, "blocking": blocking });
    tx.execute(
        "UPDATE credit_applications SET status='analysis', analysis_json=?2, analysis_notes=?3, analyzed_by=?4,
            updated_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id=?1",
        rusqlite::params![id, result.to_string(), opt_text(&notes), user.id],
    )?;
    audit_repo::log(&tx, user, "credit.analysis", "credit_applications", id, if blocking { "com pendências" } else { "sem pendências" })?;
    tx.commit()?;
    Ok(result)
}

pub fn decide(conn: &mut Connection, user: &User, id: i64, approve: bool, notes: &str) -> AppResult<()> {
    let notes = require_text(notes, "Parecer", 500)?;
    let tx = conn.transaction()?;
    let app = get_application(&tx, id)?;
    if app.status != "analysis" {
        return Err(AppError::Validation("A solicitação precisa estar em análise para ser decidida.".into()));
    }
    if approve && app.analysis.as_ref().and_then(|a| a.get("blocking")).and_then(|b| b.as_bool()).unwrap_or(true) {
        return Err(AppError::Validation("Há pendências obrigatórias na análise cadastral. Regularize e analise novamente.".into()));
    }
    tx.execute(
        "UPDATE credit_applications SET status=?2, decided_by=?3, decided_at=strftime('%Y-%m-%dT%H:%M:%SZ','now'), decision_notes=?4 WHERE id=?1",
        rusqlite::params![id, if approve { "approved" } else { "rejected" }, user.id, notes],
    )?;
    audit_repo::log(&tx, user, if approve { "credit.approved" } else { "credit.rejected" }, "credit_applications", id, &notes)?;
    tx.commit()?;
    Ok(())
}

pub fn cancel_application(conn: &mut Connection, user: &User, id: i64) -> AppResult<()> {
    let tx = conn.transaction()?;
    let app = get_application(&tx, id)?;
    if matches!(app.status.as_str(), "contracted" | "cancelled") {
        return Err(AppError::Validation("Solicitação não pode ser cancelada.".into()));
    }
    tx.execute("UPDATE credit_applications SET status='cancelled' WHERE id=?1", [id])?;
    audit_repo::log(&tx, user, "credit.application_cancel", "credit_applications", id, "")?;
    tx.commit()?;
    Ok(())
}

/// Contratação: gera o empréstimo e o cronograma. Bloqueada até a habilitação regulatória do crédito.
pub fn contract(conn: &mut Connection, user: &User, application_id: i64) -> AppResult<i64> {
    let tx = conn.transaction()?;
    require_credit_enabled(&tx)?;
    let app = get_application(&tx, application_id)?;
    if app.status != "approved" {
        return Err(AppError::Validation("Somente solicitações aprovadas podem ser contratadas.".into()));
    }
    if app.collateral_id.is_some() {
        require_collateral_enabled(&tx)?;
    }
    let first_due = parse_date(&app.first_due_date)?;
    let today = settings_repo::today(&tx);
    if first_due <= today {
        return Err(AppError::Validation("O primeiro vencimento já passou. Atualize a solicitação.".into()));
    }
    let sim = simulate(&LoanParams {
        principal_cents: app.amount_cents, term_months: app.term_months as u32, rate_bp: app.rate_bp, first_due,
        fee_bp: settings_repo::get_i64(&tx, "loan.origination_fee_bp", 0)?, iof_bp: settings_repo::get_i64(&tx, "loan.iof_bp", 0)?,
    })?;
    tx.execute(
        "INSERT INTO loans (application_id, client_id, principal_cents, term_months, rate_bp, fee_cents, cet_annual_bp, first_due_date,
            status, contracted_at, purpose, created_by)
         VALUES (?1,?2,?3,?4,?5,?6,?7,?8,'pending_disbursement',?9,?10,?11)",
        rusqlite::params![
            application_id, app.client_id, app.amount_cents, app.term_months, app.rate_bp, sim.fees_cents, sim.cet_annual_bp,
            app.first_due_date, today.to_string(), app.purpose, user.id
        ],
    )?;
    let loan_id = tx.last_insert_rowid();
    for s in &sim.schedule {
        loan_repo::insert_installment(&tx, loan_id, s.number, &s.due_date.to_string(), s.amount_cents, s.principal_cents, s.interest_cents)?;
    }
    if let Some(cid) = app.collateral_id {
        tx.execute(
            "UPDATE collateral_assets SET loan_id = ?2, linked_value_cents = ?3, updated_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id = ?1",
            (cid, loan_id, app.amount_cents),
        )?;
    }
    tx.execute("UPDATE credit_applications SET status='contracted' WHERE id=?1", [application_id])?;
    audit_repo::log(&tx, user, "loan.contracted", "loans", loan_id, &format_brl(app.amount_cents))?;
    tx.commit()?;
    Ok(loan_id)
}

/// Registro do desembolso (saída de caixa). Bloqueado até a habilitação regulatória.
pub fn disburse(conn: &mut Connection, user: &User, loan_id: i64, method: &str) -> AppResult<()> {
    let tx = conn.transaction()?;
    require_credit_enabled(&tx)?;
    if payment_service::METHODS.iter().all(|m| *m != method) {
        return Err(AppError::Validation("Forma de pagamento inválida.".into()));
    }
    let (status, principal, fee, client_id): (String, i64, i64, i64) = tx.query_row(
        "SELECT status, principal_cents, fee_cents, client_id FROM loans WHERE id = ?1",
        [loan_id],
        |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?)),
    )?;
    if status != "pending_disbursement" {
        return Err(AppError::Validation("O empréstimo já foi desembolsado ou encerrado.".into()));
    }
    let signed: i64 = tx.query_row(
        "SELECT COUNT(*) FROM contracts WHERE ref_type = 'loan' AND ref_id = ?1 AND signed_at IS NOT NULL AND status <> 'cancelled'",
        [loan_id],
        |r| r.get(0),
    )?;
    if signed == 0 {
        return Err(AppError::Validation("O contrato do empréstimo precisa estar gerado e assinado antes do desembolso.".into()));
    }
    let net = principal - fee;
    let today = settings_repo::today(&tx).to_string();
    let desc = format!("Desembolso · Contrato #{loan_id}");
    let pid = payment_repo::insert(&tx, &NewPayment {
        client_id: Some(client_id), party_name: None, direction: "out", origin_type: "loan", origin_id: Some(loan_id),
        description: Some(&desc), amount_cents: net, method, status: "confirmed", due_date: None, paid_at: Some(&today),
        idempotency_key: Some(&format!("disbursement-{loan_id}")), user_id: user.id,
    })?;
    payment_repo::insert_cash(&tx, "out", net, method, "Empréstimos", Some(&desc), Some(pid), &settings_repo::now_local(&tx), user.id)?;
    tx.execute(
        "UPDATE loans SET status='active', disbursed_at=?2, disbursed_by=?3, disbursement_payment_id=?4 WHERE id=?1",
        rusqlite::params![loan_id, today, user.id, pid],
    )?;
    audit_repo::log(&tx, user, "loan.disbursed", "loans", loan_id, &format_brl(net))?;
    tx.commit()?;
    Ok(())
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RenegotiationInput {
    pub loan_id: i64,
    pub new_term_months: u32,
    pub new_rate_bp: Option<i64>,
    pub first_due_date: String,
    pub reason: String,
}

/// Renegociação: capitaliza o saldo devedor (incluindo encargos de atraso) e gera novo cronograma.
/// As parcelas antigas ficam preservadas com status `renegotiated`.
pub fn renegotiate(conn: &mut Connection, user: &User, i: RenegotiationInput) -> AppResult<i64> {
    let reason = require_text(&i.reason, "Motivo da renegociação", 300)?;
    let tx = conn.transaction()?;
    require_credit_enabled(&tx)?;
    if loan_repo::loan_status(&tx, i.loan_id)? != "active" {
        return Err(AppError::Validation("Apenas empréstimos ativos podem ser renegociados.".into()));
    }
    let today = settings_repo::today(&tx);
    let first_due = parse_date(&i.first_due_date)?;
    if first_due <= today {
        return Err(AppError::Validation("O primeiro vencimento deve ser posterior a hoje.".into()));
    }
    let max_term = settings_repo::get_i64(&tx, "loan.max_term_months", 60)?;
    if i.new_term_months == 0 || i.new_term_months as i64 > max_term {
        return Err(AppError::Validation("Prazo inválido.".into()));
    }
    let rate = match i.new_rate_bp {
        Some(r) => r,
        None => settings_repo::get_i64(&tx, "loan.default_rate_bp", 240)?,
    };
    if !(0..=2000).contains(&rate) {
        return Err(AppError::Validation("Taxa de juros fora do intervalo permitido.".into()));
    }
    let open = loan_repo::open_installments(&tx, i.loan_id)?;
    if open.is_empty() {
        return Err(AppError::Validation("Não há saldo a renegociar.".into()));
    }
    let mut balance = 0;
    for inst in &open {
        balance += payment_service::installment_due(&tx, inst, today)?.total_due_cents;
    }
    let sched = build_schedule(balance, i.new_term_months, rate, first_due)?;
    tx.execute("UPDATE loan_installments SET status='renegotiated' WHERE loan_id = ?1 AND status IN ('open','partial')", [i.loan_id])?;
    for s in &sched {
        loan_repo::insert_installment(&tx, i.loan_id, s.number, &s.due_date.to_string(), s.amount_cents, s.principal_cents, s.interest_cents)?;
    }
    tx.execute(
        "INSERT INTO loan_renegotiations (loan_id, balance_cents, new_term_months, new_rate_bp, first_due_date, reason, created_by)
         VALUES (?1,?2,?3,?4,?5,?6,?7)",
        rusqlite::params![i.loan_id, balance, i.new_term_months, rate, i.first_due_date, reason, user.id],
    )?;
    let id = tx.last_insert_rowid();
    audit_repo::log(&tx, user, "loan.renegotiated", "loans", i.loan_id, &format!("{} em {}x · {reason}", format_brl(balance), i.new_term_months))?;
    tx.commit()?;
    Ok(id)
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct InstallmentView {
    #[serde(flatten)]
    pub row: InstallmentRow,
    pub display_status: String,
    pub due: Option<InstallmentDue>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct LoanDetail {
    pub loan: LoanRow,
    pub rate_bp: i64,
    pub cet_annual_bp: Option<i64>,
    pub fee_cents: i64,
    pub first_due_date: String,
    pub disbursed_at: Option<String>,
    pub purpose: Option<String>,
    pub installments: Vec<InstallmentView>,
    pub paid_cents: i64,
    pub scheduled_cents: i64,
    pub final_due_date: Option<String>,
    pub next_installment_id: Option<i64>,
    pub renegotiations: i64,
    pub contract_id: Option<i64>,
    pub contract_signed: bool,
}

pub fn detail(conn: &Connection, id: i64) -> AppResult<LoanDetail> {
    let today = settings_repo::today(conn);
    let loan = loan_repo::get_loan(conn, id, &today.to_string())?;
    let (rate_bp, cet, fee, first_due, disbursed_at, purpose): (i64, Option<i64>, i64, String, Option<String>, Option<String>) = conn.query_row(
        "SELECT rate_bp, cet_annual_bp, fee_cents, first_due_date, disbursed_at, purpose FROM loans WHERE id = ?1",
        [id],
        |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?, r.get(4)?, r.get(5)?)),
    )?;
    let rows = loan_repo::installments(conn, id, false)?;
    let mut next = None;
    let mut views = vec![];
    for r in rows {
        let open = matches!(r.status.as_str(), "open" | "partial");
        let overdue = open && r.due() < today;
        let display = if r.status == "paid" {
            "paid"
        } else if overdue {
            "overdue"
        } else if open && next.is_none() {
            next = Some(r.id);
            "next"
        } else if r.status == "partial" {
            "partial"
        } else {
            "open"
        };
        let due = if open { Some(payment_service::installment_due(conn, &r, today)?) } else { None };
        views.push(InstallmentView { display_status: display.into(), due, row: r });
    }
    if next.is_none() {
        next = views.iter().find(|v| v.display_status == "overdue").map(|v| v.row.id);
    }
    let paid: i64 = views.iter().map(|v| v.row.paid_cents).sum();
    let scheduled: i64 = views.iter().map(|v| v.row.amount_cents).sum();
    let final_due = views.last().map(|v| v.row.due_date.clone());
    let contract: Option<(i64, Option<String>)> = conn
        .query_row(
            "SELECT id, signed_at FROM contracts WHERE ref_type='loan' AND ref_id=?1 AND status <> 'cancelled' ORDER BY id DESC LIMIT 1",
            [id],
            |r| Ok((r.get(0)?, r.get(1)?)),
        )
        .optional()?;
    Ok(LoanDetail {
        loan, rate_bp, cet_annual_bp: cet, fee_cents: fee, first_due_date: first_due, disbursed_at, purpose,
        installments: views, paid_cents: paid, scheduled_cents: scheduled, final_due_date: final_due,
        next_installment_id: next,
        renegotiations: conn.query_row("SELECT COUNT(*) FROM loan_renegotiations WHERE loan_id = ?1", [id], |r| r.get(0))?,
        contract_id: contract.as_ref().map(|c| c.0),
        contract_signed: contract.is_some_and(|c| c.1.is_some()),
    })
}

/// Parcelas vencidas ou a vencer para cobrança.
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CollectionRow {
    pub installment_id: i64,
    pub loan_id: i64,
    pub client_id: i64,
    pub client_name: String,
    pub number: i64,
    pub total_installments: i64,
    pub remaining_cents: i64,
    pub due_date: String,
    pub days_late: i64,
    pub days_to_due: i64,
    pub contact_opt_out: bool,
}

pub fn collection_rows(conn: &Connection, scope: &str) -> AppResult<Vec<CollectionRow>> {
    let today = settings_repo::today(conn);
    let t = today.to_string();
    let mut stmt = conn.prepare(
        "SELECT i.id, l.id, c.id, c.name, i.number,
            (SELECT COUNT(*) FROM loan_installments x WHERE x.loan_id = l.id AND x.status <> 'renegotiated'),
            i.amount_cents - i.paid_cents, i.due_date, c.contact_opt_out
         FROM loan_installments i JOIN loans l ON l.id = i.loan_id JOIN clients c ON c.id = l.client_id
         WHERE i.status IN ('open','partial') AND l.status = 'active'
           AND CASE ?2 WHEN 'overdue' THEN i.due_date < ?1
                       WHEN 'upcoming' THEN i.due_date BETWEEN ?1 AND date(?1,'+7 days')
                       ELSE 1 END
         ORDER BY i.due_date",
    )?;
    let rows = stmt
        .query_map((&t, scope), |r| {
            let due: String = r.get(7)?;
            let d = NaiveDate::parse_from_str(&due, "%Y-%m-%d").unwrap_or(today);
            Ok(CollectionRow {
                installment_id: r.get(0)?, loan_id: r.get(1)?, client_id: r.get(2)?, client_name: r.get(3)?, number: r.get(4)?,
                total_installments: r.get(5)?, remaining_cents: r.get(6)?, due_date: due,
                days_late: (today - d).num_days().max(0), days_to_due: (d - today).num_days().max(0),
                contact_opt_out: r.get::<_, i64>(8)? == 1,
            })
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

#[cfg(test)]
pub(crate) mod tests {
    use super::*;
    use crate::repositories::{loan_repo, PageQuery};
    use crate::services::client_service;
    use crate::testutil::{env, Env};

    pub fn new_client(conn: &mut Connection, e: &Env, name: &str, doc: &str) -> i64 {
        let mut c = client_service::tests::input(name, doc);
        c.street = Some("Av. Paulista".into());
        c.city = Some("São Paulo".into());
        client_service::create(conn, &e.admin, c).unwrap()
    }

    pub fn enable_credit(conn: &Connection) {
        settings_repo::set(conn, "credit.enabled", "true").unwrap();
    }

    fn future(days: i64) -> String {
        (crate::testutil::today() + chrono::Duration::days(days)).to_string()
    }

    pub fn app_input(client: i64, amount: i64, term: u32) -> ApplicationInput {
        ApplicationInput {
            client_id: client, amount_cents: amount, term_months: term, rate_bp: Some(240),
            purpose: Some("Capital de giro".into()), first_due_date: future(30), collateral_id: None,
        }
    }

    /// Fluxo completo até empréstimo pendente de desembolso.
    pub fn approved_loan(conn: &mut Connection, e: &Env, client: i64, amount: i64, term: u32) -> i64 {
        let app = create_application(conn, &e.admin, app_input(client, amount, term)).unwrap();
        analyze(conn, &e.admin, app, None).unwrap();
        decide(conn, &e.admin, app, true, "Aprovado conforme análise").unwrap();
        contract(conn, &e.admin, app).unwrap()
    }

    /// Desembolsa pulando a exigência de contrato assinado (testada à parte).
    pub fn active_loan(conn: &mut Connection, e: &Env, client: i64, amount: i64, term: u32) -> i64 {
        enable_credit(conn);
        let id = approved_loan(conn, e, client, amount, term);
        conn.execute(
            "INSERT INTO contracts (number, kind, client_id, ref_type, ref_id, signed_at, status) VALUES (?1,'loan',?2,'loan',?3,'2024-01-01','active')",
            rusqlite::params![format!("CTR-T-{id}"), client, id],
        ).unwrap();
        disburse(conn, &e.admin, id, "pix").unwrap();
        id
    }

    #[test]
    fn credit_is_blocked_until_regulatory_enablement() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Mariana Souza", "529.982.247-25");
        let app = create_application(&mut conn, &e.admin, app_input(c, 1_500_000, 12)).unwrap();
        analyze(&mut conn, &e.admin, app, None).unwrap();
        decide(&mut conn, &e.admin, app, true, "Ok").unwrap();
        let err = contract(&mut conn, &e.admin, app).unwrap_err();
        assert!(err.to_string().contains("bloqueada"));
        assert!(disburse(&mut conn, &e.admin, 1, "pix").is_err());
        enable_credit(&conn);
        assert!(contract(&mut conn, &e.admin, app).is_ok());
    }

    #[test]
    fn disbursement_requires_signed_contract_and_moves_cash() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        enable_credit(&conn);
        let c = new_client(&mut conn, &e, "Mariana Souza", "529.982.247-25");
        let loan = approved_loan(&mut conn, &e, c, 1_000_000, 10);
        assert!(disburse(&mut conn, &e.admin, loan, "pix").unwrap_err().to_string().contains("assinado"));
        let c2 = new_client(&mut conn, &e, "João", "390.533.447-05");
        let id = active_loan(&mut conn, &e, c2, 1_000_000, 10);
        assert_eq!(payment_repo::cash_summary(&conn).unwrap().balance_cents, -1_000_000);
        assert!(disburse(&mut conn, &e.admin, id, "pix").is_err());
    }

    #[test]
    fn analysis_blocks_inactive_or_overdue_clients() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Felipe", "529.982.247-25");
        client_service::set_status(&mut conn, &e.admin, c, "pending").unwrap();
        let app = create_application(&mut conn, &e.admin, app_input(c, 100_000, 3)).unwrap();
        let r = analyze(&mut conn, &e.admin, app, None).unwrap();
        assert_eq!(r["blocking"], true);
        assert!(decide(&mut conn, &e.admin, app, true, "tentativa").is_err());
        assert!(decide(&mut conn, &e.admin, app, false, "Recusado: cadastro pendente").is_ok());
        assert_eq!(get_application(&conn, app).unwrap().status, "rejected");
    }

    #[test]
    fn simulation_validates_bounds() {
        let e = env();
        let conn = e.db.conn().unwrap();
        let ok = SimulationInput { amount_cents: 1_500_000, term_months: 12, rate_bp: None, first_due_date: future(30) };
        let s = simulation(&conn, &ok).unwrap();
        assert_eq!(s.schedule.len(), 12);
        assert!(simulation(&conn, &SimulationInput { amount_cents: 0, ..ok.clone() }).is_err());
        assert!(simulation(&conn, &SimulationInput { term_months: 999, ..ok.clone() }).is_err());
        assert!(simulation(&conn, &SimulationInput { first_due_date: "2000-01-01".into(), ..ok }).is_err());
    }

    #[test]
    fn installment_payment_partial_full_and_idempotent() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Mariana Souza", "529.982.247-25");
        let loan = active_loan(&mut conn, &e, c, 1_200_000, 12);
        let insts = loan_repo::installments(&conn, loan, false).unwrap();
        let first = &insts[0];
        // parcial
        let p1 = payment_service::pay_installment(&mut conn, &e.admin, first.id, 50_000, "pix", Some("k1".into())).unwrap();
        let again = payment_service::pay_installment(&mut conn, &e.admin, first.id, 50_000, "pix", Some("k1".into())).unwrap();
        assert_eq!(p1, again);
        let r = loan_repo::installment(&conn, first.id).unwrap();
        assert_eq!((r.paid_cents, r.status.as_str()), (50_000, "partial"));
        // restante
        let rest = first.amount_cents - 50_000;
        payment_service::pay_installment(&mut conn, &e.admin, first.id, rest, "pix", None).unwrap();
        assert_eq!(loan_repo::installment(&conn, first.id).unwrap().status, "paid");
        assert!(payment_service::pay_installment(&mut conn, &e.admin, first.id, 100, "pix", None).is_err());
        // excesso
        assert!(payment_service::pay_installment(&mut conn, &e.admin, insts[1].id, insts[1].amount_cents + 1, "pix", None).is_err());
    }

    #[test]
    fn overdue_payment_requires_charges_and_records_allocation() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Carla", "529.982.247-25");
        let loan = active_loan(&mut conn, &e, c, 1_000_000, 4);
        let inst = loan_repo::installments(&conn, loan, false).unwrap()[0].clone();
        let past = (crate::testutil::today() - chrono::Duration::days(11)).to_string();
        conn.execute("UPDATE loan_installments SET due_date = ?2 WHERE id = ?1", (inst.id, &past)).unwrap();
        let inst = loan_repo::installment(&conn, inst.id).unwrap();
        let due = payment_service::installment_due(&conn, &inst, settings_repo::today(&conn)).unwrap();
        assert!(due.charges.fee_cents > 0 && due.charges.days_late >= 10);
        assert!(payment_service::pay_installment(&mut conn, &e.admin, inst.id, due.charges.total() - 1, "cash", None).is_err());
        let pid = payment_service::pay_installment(&mut conn, &e.admin, inst.id, due.total_due_cents, "cash", None).unwrap();
        let (fee, principal): (i64, i64) = conn
            .query_row("SELECT fee_cents, principal_cents FROM payment_allocations WHERE payment_id = ?1", [pid], |r| Ok((r.get(0)?, r.get(1)?)))
            .unwrap();
        assert_eq!(fee, due.charges.fee_cents);
        assert_eq!(principal, inst.amount_cents);
        assert_eq!(loan_repo::installment(&conn, inst.id).unwrap().status, "paid");
    }

    #[test]
    fn reversal_restores_installment_and_loan_status() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Beatriz", "529.982.247-25");
        let loan = active_loan(&mut conn, &e, c, 100_000, 1);
        let inst = loan_repo::installments(&conn, loan, false).unwrap()[0].clone();
        let pid = payment_service::pay_installment(&mut conn, &e.admin, inst.id, inst.amount_cents, "pix", None).unwrap();
        assert_eq!(loan_repo::loan_status(&conn, loan).unwrap(), "paid_off");
        payment_service::reverse(&mut conn, &e.admin, pid, "Pagamento lançado no contrato errado").unwrap();
        assert_eq!(loan_repo::loan_status(&conn, loan).unwrap(), "active");
        assert_eq!(loan_repo::installment(&conn, inst.id).unwrap().paid_cents, 0);
    }

    #[test]
    fn settle_pays_everything_and_closes_loan() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Rodrigo", "529.982.247-25");
        let loan = active_loan(&mut conn, &e, c, 300_000, 3);
        let before = payment_repo::cash_summary(&conn).unwrap().balance_cents;
        payment_service::settle_loan(&mut conn, &e.admin, loan, "transfer", None).unwrap();
        let d = detail(&conn, loan).unwrap();
        assert_eq!(d.loan.status, "paid_off");
        assert_eq!(d.paid_cents, d.scheduled_cents);
        assert_eq!(payment_repo::cash_summary(&conn).unwrap().balance_cents - before, d.scheduled_cents);
    }

    #[test]
    fn renegotiation_preserves_history_and_rebuilds_schedule() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Paulo", "529.982.247-25");
        let loan = active_loan(&mut conn, &e, c, 600_000, 6);
        let first = loan_repo::installments(&conn, loan, false).unwrap()[0].clone();
        payment_service::pay_installment(&mut conn, &e.admin, first.id, first.amount_cents, "pix", None).unwrap();
        let remaining: i64 = loan_repo::open_installments(&conn, loan).unwrap().iter().map(|i| i.remaining()).sum();
        renegotiate(&mut conn, &e.admin, RenegotiationInput {
            loan_id: loan, new_term_months: 10, new_rate_bp: Some(150), first_due_date: future(45), reason: "Reestruturação".into(),
        }).unwrap();
        let all = loan_repo::installments(&conn, loan, true).unwrap();
        assert_eq!(all.iter().filter(|i| i.status == "renegotiated").count(), 5);
        let open = loan_repo::open_installments(&conn, loan).unwrap();
        assert_eq!(open.len(), 10);
        assert_eq!(open.iter().map(|i| i.principal_cents).sum::<i64>(), remaining);
        assert_eq!(detail(&conn, loan).unwrap().renegotiations, 1);
    }

    #[test]
    fn list_and_collection_filters() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Vanessa Lima", "529.982.247-25");
        let loan = active_loan(&mut conn, &e, c, 200_000, 2);
        let today = settings_repo::today(&conn).to_string();
        let q = PageQuery { search: Some("Vanessa".into()), ..Default::default() };
        assert_eq!(loan_repo::list_loans(&conn, &q, &today).unwrap().total, 1);
        let past = (crate::testutil::today() - chrono::Duration::days(5)).to_string();
        let first = loan_repo::installments(&conn, loan, false).unwrap()[0].id;
        conn.execute("UPDATE loan_installments SET due_date=?2 WHERE id=?1", (first, past)).unwrap();
        let q = PageQuery { status: Some("late".into()), ..Default::default() };
        assert_eq!(loan_repo::list_loans(&conn, &q, &today).unwrap().total, 1);
        assert_eq!(collection_rows(&conn, "overdue").unwrap().len(), 1);
        assert!(collection_rows(&conn, "overdue").unwrap()[0].days_late >= 5);
    }
}
