pub mod attachment_service;
pub mod auth_service;
pub mod backup_service;
pub mod client_service;
pub mod collateral_service;
pub mod contract_service;
pub mod document_refresh;
pub mod dashboard_service;
#[cfg(debug_assertions)]
pub mod demo_seed;
pub mod loan_service;
pub mod notification_service;
pub mod payment_service;
#[cfg(test)]
mod perf_tests;
pub mod report_service;
pub mod pdf;
pub mod product_service;
pub mod purchase_service;
pub mod sale_service;
pub mod settings_service;
pub mod user_service;
