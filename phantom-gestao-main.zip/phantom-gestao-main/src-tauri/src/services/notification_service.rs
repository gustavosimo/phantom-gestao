use chrono::{Datelike, FixedOffset, Timelike, Utc};
use rusqlite::Connection;
use serde::{Deserialize, Serialize};

use crate::domain::money::format_brl;
use crate::domain::user::User;
use crate::domain::validation::*;
use crate::error::{AppError, AppResult};
use crate::repositories::{audit_repo, settings_repo, Page, PageQuery};

/// Regras de automação baseadas em agendamento (sem IA). Idempotente: cada aviso tem uma chave de deduplicação.
pub fn run_rules(conn: &Connection) -> AppResult<usize> {
    let today = settings_repo::today(conn);
    let t = today.to_string();
    let soon_days = settings_repo::get_i64(conn, "notifications.due_soon_days", 7)?;
    let coll_days = settings_repo::get_i64(conn, "notifications.collateral_days", 7)?;
    let mut created = 0usize;
    let mut add = |kind: &str, cat: &str, sev: &str, title: String, body: String, entity: Option<(&str, i64)>, key: String| -> AppResult<()> {
        let n = conn.execute(
            "INSERT OR IGNORE INTO notifications (kind, category, severity, title, body, entity_type, entity_id, dedupe_key)
             VALUES (?1,?2,?3,?4,?5,?6,?7,?8)",
            rusqlite::params![kind, cat, sev, title, body, entity.map(|e| e.0), entity.map(|e| e.1), key],
        )?;
        created += n;
        Ok(())
    };

    // vencimentos de hoje
    let (n, total): (i64, i64) = conn.query_row(
        "SELECT COUNT(*), COALESCE(SUM(i.amount_cents - i.paid_cents),0) FROM loan_installments i JOIN loans l ON l.id = i.loan_id
         WHERE i.status IN ('open','partial') AND l.status = 'active' AND i.due_date = ?1",
        [&t],
        |r| Ok((r.get(0)?, r.get(1)?)),
    )?;
    if n > 0 {
        add("due_today", "due", "warning", format!("{n} parcela{} vence{} hoje", if n > 1 { "s" } else { "" }, if n > 1 { "m" } else { "" }),
            format!("Total a receber hoje: {}. Acompanhe em Cobranças.", format_brl(total)), None, format!("due_today:{t}"))?;
    }
    // vencendo em breve
    let (n, total): (i64, i64) = conn.query_row(
        "SELECT COUNT(*), COALESCE(SUM(i.amount_cents - i.paid_cents),0) FROM loan_installments i JOIN loans l ON l.id = i.loan_id
         WHERE i.status IN ('open','partial') AND l.status = 'active' AND i.due_date > ?1 AND i.due_date <= date(?1, '+' || ?2 || ' days')",
        (&t, soon_days),
        |r| Ok((r.get(0)?, r.get(1)?)),
    )?;
    if n > 0 {
        add("due_soon", "due", "info", format!("{n} parcela{} vence{} nos próximos {soon_days} dias", if n > 1 { "s" } else { "" }, if n > 1 { "m" } else { "" }),
            format!("Total previsto: {}.", format_brl(total)), None, format!("due_soon:{t}"))?;
    }
    // atrasadas
    let overdue: Vec<(String, i64)> = {
        let mut stmt = conn.prepare(
            "SELECT c.name, i.amount_cents - i.paid_cents FROM loan_installments i JOIN loans l ON l.id = i.loan_id JOIN clients c ON c.id = l.client_id
             WHERE i.status IN ('open','partial') AND l.status = 'active' AND i.due_date < ?1 ORDER BY i.due_date",
        )?;
        stmt.query_map([&t], |r| Ok((r.get(0)?, r.get(1)?)))?.collect::<Result<Vec<_>, _>>()?
    };
    if !overdue.is_empty() {
        let total: i64 = overdue.iter().map(|o| o.1).sum();
        let more = overdue.len() - 1;
        add("overdue", "alert", "error", format!("{} parcela{} em atraso", overdue.len(), if overdue.len() > 1 { "s" } else { "" }),
            format!("Ação de cobrança recomendada para {}{} — {} em aberto.", overdue[0].0,
                if more > 0 { format!(" e mais {more} cliente{}", if more > 1 { "s" } else { "" }) } else { String::new() }, format_brl(total)),
            None, format!("overdue:{t}"))?;
    }
    // garantias com prazo próximo
    let near: Vec<(i64, String, String)> = {
        let mut stmt = conn.prepare(
            "SELECT id, name, custody_due FROM collateral_assets WHERE status = 'in_custody' AND custody_due IS NOT NULL
             AND custody_due <= date(?1, '+' || ?2 || ' days')",
        )?;
        stmt.query_map((&t, coll_days), |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?)))?.collect::<Result<Vec<_>, _>>()?
    };
    for (id, name, due) in near {
        add("collateral_deadline", "alert", "error", format!("Garantia GAR-{id:04} com prazo próximo"),
            format!("{name} — prazo de custódia até {due}."), Some(("collateral", id)), format!("collateral_deadline:{id}:{due}"))?;
    }
    // aguardando avaliação
    let appraisal: Vec<(i64, String, String)> = {
        let mut stmt = conn.prepare(
            "SELECT a.id, a.name, c.name FROM collateral_assets a JOIN clients c ON c.id = a.client_id WHERE a.status IN ('registered','appraising')",
        )?;
        stmt.query_map([], |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?)))?.collect::<Result<Vec<_>, _>>()?
    };
    for (id, name, client) in appraisal {
        add("collateral_appraisal", "pending", "info", format!("Garantia nº GAR-{id:04} aguardando avaliação"),
            format!("Produto: {name} — cliente {client}."), Some(("collateral", id)), format!("collateral_appraisal:{id}"))?;
    }
    // contratos pendentes de assinatura
    let contracts: Vec<(i64, String)> = {
        let mut stmt = conn.prepare("SELECT id, number FROM contracts WHERE status = 'pending_signature'")?;
        stmt.query_map([], |r| Ok((r.get(0)?, r.get(1)?)))?.collect::<Result<Vec<_>, _>>()?
    };
    for (id, number) in contracts {
        add("contract_pending", "pending", "warning", format!("Contrato {number} aguardando assinatura"),
            "Registre a assinatura em Contratos.".into(), Some(("contract", id)), format!("contract_pending:{id}"))?;
    }
    // documentos pendentes
    let docs: Vec<(i64, String)> = {
        let mut stmt = conn.prepare(
            "SELECT c.id, c.name FROM clients c WHERE c.status = 'pending' AND NOT EXISTS (SELECT 1 FROM client_documents d WHERE d.client_id = c.id)",
        )?;
        stmt.query_map([], |r| Ok((r.get(0)?, r.get(1)?)))?.collect::<Result<Vec<_>, _>>()?
    };
    for (id, name) in docs {
        add("document_pending", "pending", "warning", format!("Documentos pendentes — {name}"),
            "Cadastro pendente sem documentos anexados.".into(), Some(("client", id)), format!("document_pending:{id}"))?;
    }
    // pagamentos confirmados e quitações (últimas 48h)
    let pays: Vec<(i64, String, i64, Option<String>)> = {
        let mut stmt = conn.prepare(
            "SELECT p.id, COALESCE(c.name, p.party_name, '—'), p.amount_cents, p.description FROM payments p LEFT JOIN clients c ON c.id = p.client_id
             WHERE p.status = 'confirmed' AND p.direction = 'in' AND p.origin_type = 'loan' AND p.reversal_of_id IS NULL
               AND p.created_at >= strftime('%Y-%m-%dT%H:%M:%SZ','now','-2 days')",
        )?;
        stmt.query_map([], |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?)))?.collect::<Result<Vec<_>, _>>()?
    };
    for (id, client, amount, desc) in pays {
        add("payment_confirmed", "payment", "success", "Pagamento confirmado".into(),
            format!("{client} — {} ({}).", format_brl(amount), desc.unwrap_or_default()), Some(("payment", id)), format!("payment:{id}"))?;
    }
    let paid_off: Vec<(i64, String)> = {
        let mut stmt = conn.prepare(
            "SELECT l.id, c.name FROM loans l JOIN clients c ON c.id = l.client_id WHERE l.status = 'paid_off' AND l.paid_off_at >= date(?1,'-7 days')",
        )?;
        stmt.query_map([&t], |r| Ok((r.get(0)?, r.get(1)?)))?.collect::<Result<Vec<_>, _>>()?
    };
    for (id, client) in paid_off {
        add("loan_paid_off", "payment", "success", format!("Operação quitada — contrato #{id}"),
            format!("{client} quitou o empréstimo."), Some(("loan", id)), format!("paid_off:{id}"))?;
    }
    let redeemed: Vec<(i64, String)> = {
        let mut stmt = conn.prepare(
            "SELECT id, name FROM collateral_assets WHERE status IN ('redeemed','returned') AND updated_at >= strftime('%Y-%m-%dT%H:%M:%SZ','now','-7 days')",
        )?;
        stmt.query_map([], |r| Ok((r.get(0)?, r.get(1)?)))?.collect::<Result<Vec<_>, _>>()?
    };
    for (id, name) in redeemed {
        add("collateral_redeemed", "info", "success", "Garantia resgatada".into(), format!("{name} devolvida ao cliente."),
            Some(("collateral", id)), format!("redeemed:{id}"))?;
    }
    let week = today.iso_week();
    let new_clients: i64 = conn.query_row("SELECT COUNT(*) FROM clients WHERE created_at >= date(?1,'-7 days')", [&t], |r| r.get(0))?;
    if new_clients > 0 {
        add("new_clients", "info", "info", format!("{new_clients} novo{} cliente{} esta semana", if new_clients > 1 { "s" } else { "" }, if new_clients > 1 { "s" } else { "" }),
            "Acompanhe os cadastros recentes no módulo de Clientes.".into(), None, format!("new_clients:{}-{}", week.year(), week.week()))?;
    }

    // lembretes automáticos (tarefas para a equipe)
    let reminders: [(&str, &str, &str, &str); 3] = [
        ("collections.whatsapp_3d_before", "i.due_date = date(?1,'+3 days')", "Enviar WhatsApp de lembrete (vence em 3 dias)", "wa3"),
        ("collections.email_on_due", "i.due_date = ?1", "Enviar e-mail de vencimento (vence hoje)", "mail0"),
        ("collections.call_after_5d", "i.due_date = date(?1,'-5 days')", "Ligar para o cliente (5 dias de atraso)", "call5"),
    ];
    for (setting, cond, label, tag) in reminders {
        if !settings_repo::get_bool(conn, setting)? {
            continue;
        }
        let rows: Vec<(i64, String, i64, i64)> = {
            let mut stmt = conn.prepare(&format!(
                "SELECT i.id, c.name, i.number, i.amount_cents - i.paid_cents FROM loan_installments i JOIN loans l ON l.id = i.loan_id
                 JOIN clients c ON c.id = l.client_id WHERE i.status IN ('open','partial') AND l.status='active' AND c.contact_opt_out = 0 AND {cond}"
            ))?;
            stmt.query_map([&t], |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?)))?.collect::<Result<Vec<_>, _>>()?
        };
        for (id, client, number, rem) in rows {
            add("task", "pending", "info", format!("{label} — {client}"), format!("Parcela {number} · {}", format_brl(rem)),
                Some(("installment", id)), format!("task:{tag}:{id}"))?;
        }
    }
    Ok(created)
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct NotificationRow {
    pub id: i64,
    pub kind: String,
    pub category: String,
    pub severity: String,
    pub title: String,
    pub body: Option<String>,
    pub entity_type: Option<String>,
    pub entity_id: Option<i64>,
    pub read: bool,
    pub created_at: String,
}

/// `status`: unread | alert | due | payment | pending | all
pub fn list(conn: &Connection, q: &PageQuery) -> AppResult<Page<NotificationRow>> {
    let (unread, cat): (Option<i64>, Option<&str>) = match q.status.as_deref() {
        Some("unread") => (Some(1), None),
        Some(c @ ("alert" | "due" | "payment" | "pending")) => (None, Some(c)),
        _ => (None, None),
    };
    let w = "WHERE (?1 IS NULL OR read_at IS NULL) AND (?2 IS NULL OR category = ?2)";
    let total: i64 = conn.query_row(&format!("SELECT COUNT(*) FROM notifications {w}"), rusqlite::params![unread, cat], |r| r.get(0))?;
    let mut stmt = conn.prepare(&format!(
        "SELECT id, kind, category, severity, title, body, entity_type, entity_id, read_at IS NOT NULL, created_at FROM notifications {w}
         ORDER BY created_at DESC, id DESC LIMIT ?3 OFFSET ?4"
    ))?;
    let items = stmt
        .query_map(rusqlite::params![unread, cat, q.limit(), q.offset()], |r| {
            Ok(NotificationRow {
                id: r.get(0)?, kind: r.get(1)?, category: r.get(2)?, severity: r.get(3)?, title: r.get(4)?, body: r.get(5)?,
                entity_type: r.get(6)?, entity_id: r.get(7)?, read: r.get::<_, i64>(8)? == 1, created_at: r.get(9)?,
            })
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Page::new(items, total, q))
}

pub fn unread_count(conn: &Connection) -> AppResult<i64> {
    Ok(conn.query_row("SELECT COUNT(*) FROM notifications WHERE read_at IS NULL", [], |r| r.get(0))?)
}

pub fn mark_read(conn: &Connection, id: i64) -> AppResult<()> {
    conn.execute("UPDATE notifications SET read_at = strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id = ?1 AND read_at IS NULL", [id])?;
    Ok(())
}

pub fn mark_all_read(conn: &Connection, user: &User) -> AppResult<()> {
    conn.execute("UPDATE notifications SET read_at = strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE read_at IS NULL", [])?;
    audit_repo::log(conn, user, "notification.mark_all_read", "notifications", 0, "")?;
    Ok(())
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DeliveryStat {
    pub channel: String,
    pub total: i64,
    pub ok: i64,
    pub failed: i64,
    pub blocked: i64,
}

pub fn delivery_stats(conn: &Connection) -> AppResult<Vec<DeliveryStat>> {
    let mut stmt = conn.prepare(
        "SELECT channel, COUNT(*), SUM(status IN ('sent','answered')), SUM(status IN ('failed','no_answer')), SUM(status = 'blocked')
         FROM collection_events GROUP BY channel ORDER BY channel",
    )?;
    let rows = stmt
        .query_map([], |r| {
            Ok(DeliveryStat { channel: r.get(0)?, total: r.get(1)?, ok: r.get::<_, Option<i64>>(2)?.unwrap_or(0), failed: r.get::<_, Option<i64>>(3)?.unwrap_or(0), blocked: r.get::<_, Option<i64>>(4)?.unwrap_or(0) })
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

// ---------------------------------------------------------------- cobrança

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ContactInput {
    pub installment_id: i64,
    pub channel: String,
    /// sent | attempted | failed | answered | no_answer
    pub status: String,
    pub message: Option<String>,
}

#[derive(Serialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct ContactResult {
    pub event_id: i64,
    pub url: Option<String>,
}

fn local_now(conn: &Connection) -> chrono::DateTime<FixedOffset> {
    let off = settings_repo::get_i64(conn, "regional.tz_offset_hours", -3).unwrap_or(-3).clamp(-12, 14) as i32;
    Utc::now().with_timezone(&FixedOffset::east_opt(off * 3600).unwrap_or_else(|| FixedOffset::east_opt(0).unwrap()))
}

/// Política de cobrança não abusiva: respeita opt-out, janela de horário, domingos e limites por dia/semana.
pub fn check_contact_policy(conn: &Connection, client_id: i64, now: chrono::DateTime<FixedOffset>) -> AppResult<()> {
    let opt_out: i64 = conn.query_row("SELECT contact_opt_out FROM clients WHERE id = ?1", [client_id], |r| r.get(0))?;
    if opt_out == 1 {
        return Err(AppError::Validation("Cliente optou por não receber contatos de cobrança (LGPD).".into()));
    }
    let start = settings_repo::get_i64(conn, "collections.quiet_start_hour", 8)?;
    let end = settings_repo::get_i64(conn, "collections.quiet_end_hour", 20)?;
    let hour = now.hour() as i64;
    if hour < start || hour >= end {
        return Err(AppError::Validation(format!("Fora da janela de contato permitida ({start}h às {end}h).")));
    }
    if now.weekday() == chrono::Weekday::Sun && !settings_repo::get_bool(conn, "collections.allow_sunday")? {
        return Err(AppError::Validation("Contatos de cobrança não são permitidos aos domingos.".into()));
    }
    let day = now.date_naive().to_string();
    let per_day = settings_repo::get_i64(conn, "collections.max_per_client_day", 2)?;
    let per_week = settings_repo::get_i64(conn, "collections.max_per_client_week", 4)?;
    let count = |since: &str| -> AppResult<i64> {
        Ok(conn.query_row(
            "SELECT COUNT(*) FROM collection_events WHERE client_id = ?1 AND status <> 'blocked' AND substr(created_at,1,10) >= ?2",
            (client_id, since),
            |r| r.get(0),
        )?)
    };
    if count(&day)? >= per_day {
        return Err(AppError::Validation(format!("Limite de {per_day} contato(s) por dia para este cliente atingido.")));
    }
    let week_ago = (now.date_naive() - chrono::Duration::days(6)).to_string();
    if count(&week_ago)? >= per_week {
        return Err(AppError::Validation(format!("Limite de {per_week} contato(s) por semana para este cliente atingido.")));
    }
    Ok(())
}

pub fn render_message(conn: &Connection, channel: &str, installment_id: i64) -> AppResult<String> {
    let today = settings_repo::today(conn);
    let (client, number, total, amount, due, loan_id): (String, i64, i64, i64, String, i64) = conn
        .query_row(
            "SELECT c.name, i.number, (SELECT COUNT(*) FROM loan_installments x WHERE x.loan_id = l.id AND x.status <> 'renegotiated'),
                    i.amount_cents - i.paid_cents, i.due_date, l.id
             FROM loan_installments i JOIN loans l ON l.id = i.loan_id JOIN clients c ON c.id = l.client_id WHERE i.id = ?1",
            [installment_id],
            |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?, r.get(4)?, r.get(5)?)),
        )
        .map_err(|_| AppError::Validation("Parcela não encontrada.".into()))?;
    let overdue = chrono::NaiveDate::parse_from_str(&due, "%Y-%m-%d").is_ok_and(|d| d < today);
    let code = match (channel, overdue) {
        ("email", true) => "overdue_email",
        ("email", false) => "due_email",
        (_, true) => "overdue_notice",
        (_, false) => "due_reminder",
    };
    let body: String = conn.query_row("SELECT body FROM notification_templates WHERE code = ?1 AND active = 1", [code], |r| r.get(0))
        .map_err(|_| AppError::Validation("Modelo de mensagem inativo ou inexistente.".into()))?;
    Ok(body
        .replace("{nome}", client.split_whitespace().next().unwrap_or(&client))
        .replace("{parcela}", &format!("{number}/{total}"))
        .replace("{contrato}", &format!("#{loan_id}"))
        .replace("{valor}", &format_brl(amount))
        .replace("{vencimento}", &due))
}

fn percent_encode(s: &str) -> String {
    let mut out = String::new();
    for b in s.bytes() {
        if b.is_ascii_alphanumeric() || matches!(b, b'-' | b'_' | b'.' | b'~') {
            out.push(b as char);
        } else {
            out.push_str(&format!("%{b:02X}"));
        }
    }
    out
}

/// Registra a tentativa de contato (histórico de envios/falhas) e devolve o link externo, se houver.
pub fn register_contact(conn: &mut Connection, user: &User, i: ContactInput) -> AppResult<ContactResult> {
    register_contact_at(conn, user, i, None)
}

pub fn register_contact_at(conn: &mut Connection, user: &User, i: ContactInput, now: Option<chrono::DateTime<FixedOffset>>) -> AppResult<ContactResult> {
    if !matches!(i.channel.as_str(), "whatsapp" | "email" | "call") {
        return Err(AppError::Validation("Canal inválido.".into()));
    }
    if !matches!(i.status.as_str(), "sent" | "attempted" | "failed" | "answered" | "no_answer") {
        return Err(AppError::Validation("Resultado inválido.".into()));
    }
    let tx = conn.transaction()?;
    let (client_id, phone, email): (i64, Option<String>, Option<String>) = tx
        .query_row(
            "SELECT c.id, c.phone, c.email FROM loan_installments i JOIN loans l ON l.id = i.loan_id JOIN clients c ON c.id = l.client_id WHERE i.id = ?1",
            [i.installment_id],
            |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?)),
        )
        .map_err(|_| AppError::Validation("Parcela não encontrada.".into()))?;
    let now = now.unwrap_or_else(|| local_now(&tx));
    if let Err(e) = check_contact_policy(&tx, client_id, now) {
        tx.execute(
            "INSERT INTO collection_events (client_id, installment_id, channel, status, mode, error, user_id) VALUES (?1,?2,?3,'blocked','manual',?4,?5)",
            rusqlite::params![client_id, i.installment_id, i.channel, e.to_string(), user.id],
        )?;
        tx.commit()?;
        return Err(e);
    }
    let message = match i.channel.as_str() {
        "call" => opt_text(&i.message),
        ch => Some(opt_text(&i.message).unwrap_or(render_message(&tx, ch, i.installment_id)?)),
    };
    let url = match i.channel.as_str() {
        "whatsapp" => {
            let p = phone.ok_or_else(|| AppError::Validation("Cliente sem telefone cadastrado.".into()))?;
            Some(format!("https://wa.me/55{}?text={}", digits(&p), percent_encode(message.as_deref().unwrap_or(""))))
        }
        "email" => {
            let m = email.ok_or_else(|| AppError::Validation("Cliente sem e-mail cadastrado.".into()))?;
            Some(format!("mailto:{m}?subject={}&body={}", percent_encode("Aviso de parcela"), percent_encode(message.as_deref().unwrap_or(""))))
        }
        _ => None,
    };
    tx.execute(
        "INSERT INTO collection_events (client_id, installment_id, channel, status, mode, message, user_id) VALUES (?1,?2,?3,?4,'manual',?5,?6)",
        rusqlite::params![client_id, i.installment_id, i.channel, i.status, message, user.id],
    )?;
    let id = tx.last_insert_rowid();
    audit_repo::log(&tx, user, "collection.contact", "collection_events", id, &format!("{} · {}", i.channel, i.status))?;
    tx.commit()?;
    Ok(ContactResult { event_id: id, url })
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ContactEventRow {
    pub id: i64,
    pub client_name: String,
    pub channel: String,
    pub status: String,
    pub error: Option<String>,
    pub message: Option<String>,
    pub username: Option<String>,
    pub created_at: String,
}

pub fn contact_history(conn: &Connection, client_id: Option<i64>, limit: i64) -> AppResult<Vec<ContactEventRow>> {
    let mut stmt = conn.prepare(
        "SELECT e.id, c.name, e.channel, e.status, e.error, e.message, u.username, e.created_at FROM collection_events e
         JOIN clients c ON c.id = e.client_id LEFT JOIN users u ON u.id = e.user_id
         WHERE (?1 IS NULL OR e.client_id = ?1) ORDER BY e.id DESC LIMIT ?2",
    )?;
    let rows = stmt
        .query_map(rusqlite::params![client_id, limit], |r| {
            Ok(ContactEventRow { id: r.get(0)?, client_name: r.get(1)?, channel: r.get(2)?, status: r.get(3)?, error: r.get(4)?, message: r.get(5)?, username: r.get(6)?, created_at: r.get(7)? })
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::repositories::loan_repo;
    use crate::services::loan_service::tests::*;
    use crate::testutil::env;

    fn at(hour: u32, day_offset: i64) -> chrono::DateTime<FixedOffset> {
        // 2024-10-08 é uma terça-feira
        let d = chrono::NaiveDate::from_ymd_opt(2024, 10, 8).unwrap() + chrono::Duration::days(day_offset);
        d.and_hms_opt(hour, 0, 0).unwrap().and_local_timezone(FixedOffset::east_opt(-3 * 3600).unwrap()).unwrap()
    }

    fn setup() -> (crate::testutil::Env, i64, i64) {
        let e = env();
        let (cid, inst) = {
            let mut conn = e.db.conn().unwrap();
            let c = new_client(&mut conn, &e, "Felipe Araújo", "529.982.247-25");
            let loan = active_loan(&mut conn, &e, c, 100_000, 3);
            (c, loan_repo::installments(&conn, loan, false).unwrap()[0].id)
        };
        (e, cid, inst)
    }

    #[test]
    fn rules_are_idempotent_and_cover_overdue_and_pending_items() {
        let (e, _c, inst) = setup();
        let conn = e.db.conn().unwrap();
        let past = (crate::testutil::today() - chrono::Duration::days(6)).to_string();
        conn.execute("UPDATE loan_installments SET due_date=?2 WHERE id=?1", (inst, past)).unwrap();
        let first = run_rules(&conn).unwrap();
        assert!(first >= 2, "created {first}");
        assert_eq!(run_rules(&conn).unwrap(), 0);
        let q = PageQuery { status: Some("alert".into()), ..Default::default() };
        let alerts = list(&conn, &q).unwrap();
        assert!(alerts.items.iter().any(|n| n.kind == "overdue" && n.title.contains("em atraso")));
        assert!(unread_count(&conn).unwrap() >= 2);
        mark_read(&conn, alerts.items[0].id).unwrap();
        let q = PageQuery { status: Some("unread".into()), ..Default::default() };
        assert!(list(&conn, &q).unwrap().items.iter().all(|n| !n.read));
        mark_all_read(&conn, &e.admin).unwrap();
        assert_eq!(unread_count(&conn).unwrap(), 0);
    }

    #[test]
    fn reminder_tasks_follow_settings() {
        let (e, _c, inst) = setup();
        let conn = e.db.conn().unwrap();
        let in3 = (crate::testutil::today() + chrono::Duration::days(3)).to_string();
        conn.execute("UPDATE loan_installments SET due_date=?2 WHERE id=?1", (inst, in3)).unwrap();
        run_rules(&conn).unwrap();
        let tasks = |c: &Connection| -> i64 { c.query_row("SELECT COUNT(*) FROM notifications WHERE kind='task'", [], |r| r.get(0)).unwrap() };
        assert_eq!(tasks(&conn), 1);
        conn.execute("DELETE FROM notifications", []).unwrap();
        settings_repo::set(&conn, "collections.whatsapp_3d_before", "false").unwrap();
        run_rules(&conn).unwrap();
        assert_eq!(tasks(&conn), 0);
    }

    #[test]
    fn policy_blocks_quiet_hours_sunday_optout_and_limits() {
        let (e, cid, inst) = setup();
        let mut conn = e.db.conn().unwrap();
        let input = |ch: &str| ContactInput { installment_id: inst, channel: ch.into(), status: "sent".into(), message: None };
        assert!(register_contact_at(&mut conn, &e.admin, input("whatsapp"), Some(at(7, 0))).unwrap_err().to_string().contains("janela"));
        assert!(register_contact_at(&mut conn, &e.admin, input("whatsapp"), Some(at(21, 0))).is_err());
        assert!(register_contact_at(&mut conn, &e.admin, input("whatsapp"), Some(at(10, 5))).unwrap_err().to_string().contains("domingos"));
        let ok = register_contact_at(&mut conn, &e.admin, input("whatsapp"), Some(at(10, 0))).unwrap();
        assert!(ok.url.unwrap().starts_with("https://wa.me/5511984210012?text="));
        register_contact_at(&mut conn, &e.admin, input("email"), Some(at(11, 0))).unwrap();
        assert!(register_contact_at(&mut conn, &e.admin, input("call"), Some(at(12, 0))).unwrap_err().to_string().contains("por dia"));
        conn.execute("UPDATE clients SET contact_opt_out = 1 WHERE id = ?1", [cid]).unwrap();
        assert!(register_contact_at(&mut conn, &e.admin, input("call"), Some(at(10, 1))).unwrap_err().to_string().contains("optou"));
        let hist = contact_history(&conn, Some(cid), 50).unwrap();
        assert!(hist.iter().any(|h| h.status == "blocked") && hist.iter().filter(|h| h.status == "sent").count() == 2);
        let stats = delivery_stats(&conn).unwrap();
        assert!(stats.iter().any(|s| s.channel == "whatsapp" && s.ok == 1 && s.blocked >= 1));
    }

    #[test]
    fn message_uses_template_variables() {
        let (e, _c, inst) = setup();
        let conn = e.db.conn().unwrap();
        let m = render_message(&conn, "whatsapp", inst).unwrap();
        assert!(m.contains("Felipe") && m.contains("1/3") && m.contains("R$"));
        assert!(!m.contains('{'));
    }
}
