use chrono::NaiveDate;
use rusqlite::Connection;
use serde::{Deserialize, Serialize};

use crate::domain::loan::{late_charges, LateCharges};
use crate::domain::money::format_brl;
use crate::domain::user::User;
use crate::domain::validation::{opt_text, parse_date, require_text};
use crate::error::{AppError, AppResult};
use crate::repositories::loan_repo::{self, InstallmentRow};
use crate::repositories::payment_repo::{self, NewPayment};
use crate::repositories::{audit_repo, settings_repo};
use crate::security::vault::Vault;
use crate::services::{attachment_service, pdf::Pdf};

pub const METHODS: [&str; 5] = ["cash", "pix", "card", "transfer", "boleto"];

pub fn method_label(m: &str) -> &'static str {
    match m {
        "cash" => "Dinheiro",
        "pix" => "Pix",
        "card" => "Cartão",
        "transfer" => "Transferência",
        "boleto" => "Boleto",
        _ => "—",
    }
}

fn check_method(m: &str) -> AppResult<()> {
    if METHODS.contains(&m) { Ok(()) } else { Err(AppError::Validation("Forma de pagamento inválida.".into())) }
}

fn category_for(origin: &str) -> &'static str {
    match origin {
        "loan" => "Empréstimos",
        "sale" => "Vendas",
        "purchase" => "Compras",
        "payable" => "Contas a pagar",
        "receivable" => "Contas a receber",
        "collateral" => "Garantias",
        _ => "Outros",
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ManualPaymentInput {
    pub client_id: Option<i64>,
    pub party_name: Option<String>,
    pub direction: String,
    pub description: String,
    pub amount_cents: i64,
    pub method: String,
    pub due_date: Option<String>,
    pub confirm: bool,
    pub idempotency_key: Option<String>,
}

/// Registra e (opcionalmente) confirma uma conta a pagar/receber avulsa.
pub fn register_manual(conn: &mut Connection, user: &User, i: ManualPaymentInput) -> AppResult<i64> {
    check_method(&i.method)?;
    if i.amount_cents <= 0 {
        return Err(AppError::Validation("Valor deve ser maior que zero.".into()));
    }
    if !matches!(i.direction.as_str(), "in" | "out") {
        return Err(AppError::Validation("Tipo de lançamento inválido.".into()));
    }
    let desc = require_text(&i.description, "Descrição", 200)?;
    if i.client_id.is_none() && opt_text(&i.party_name).is_none() {
        return Err(AppError::Validation("Informe o cliente ou o nome do favorecido.".into()));
    }
    if let Some(d) = &i.due_date {
        parse_date(d)?;
    }
    if !i.confirm && i.due_date.is_none() {
        return Err(AppError::Validation("Lançamentos pendentes precisam de vencimento.".into()));
    }
    let tx = conn.transaction()?;
    if let Some(k) = &i.idempotency_key {
        if let Some(existing) = payment_repo::find_by_key(&tx, k)? {
            return Ok(existing);
        }
    }
    let today = settings_repo::today(&tx).to_string();
    let origin = if i.direction == "in" { "receivable" } else { "payable" };
    let party = opt_text(&i.party_name);
    let id = payment_repo::insert(
        &tx,
        &NewPayment {
            client_id: i.client_id,
            party_name: party.as_deref(),
            direction: &i.direction,
            origin_type: origin,
            origin_id: None,
            description: Some(&desc),
            amount_cents: i.amount_cents,
            method: &i.method,
            status: if i.confirm { "confirmed" } else { "pending" },
            due_date: i.due_date.as_deref(),
            paid_at: if i.confirm { Some(&today) } else { None },
            idempotency_key: i.idempotency_key.as_deref(),
            user_id: user.id,
        },
    )?;
    if i.confirm {
        payment_repo::insert_cash(&tx, &i.direction, i.amount_cents, &i.method, category_for(origin), Some(&desc), Some(id), &settings_repo::now_local(&tx), user.id)?;
    }
    audit_repo::log(&tx, user, "payment.register", "payments", id, &format!("{} {}", i.direction, format_brl(i.amount_cents)))?;
    tx.commit()?;
    Ok(id)
}

pub fn confirm(conn: &mut Connection, user: &User, id: i64, method: Option<String>) -> AppResult<()> {
    let tx = conn.transaction()?;
    let today = settings_repo::today(&tx).to_string();
    let p = payment_repo::get(&tx, id, &today)?;
    if p.status != "pending" && p.status != "overdue" {
        return Err(AppError::Validation("Apenas lançamentos pendentes podem ser confirmados.".into()));
    }
    let m = method.unwrap_or(p.method.clone());
    check_method(&m)?;
    tx.execute(
        "UPDATE payments SET status='confirmed', paid_at=?2, method=?3, confirmed_by=?4 WHERE id=?1 AND status='pending'",
        rusqlite::params![id, today, m, user.id],
    )?;
    payment_repo::insert_cash(&tx, &p.direction, p.amount_cents, &m, category_for(&p.origin_type), p.description.as_deref(), Some(id), &settings_repo::now_local(&tx), user.id)?;
    audit_repo::log(&tx, user, "payment.confirm", "payments", id, &format_brl(p.amount_cents))?;
    tx.commit()?;
    Ok(())
}

/// Estorno: preserva o lançamento original (status `reversed`) e cria um lançamento inverso ligado a ele.
pub fn reverse(conn: &mut Connection, user: &User, id: i64, reason: &str) -> AppResult<i64> {
    let reason = require_text(reason, "Motivo do estorno", 200)?;
    let tx = conn.transaction()?;
    let id = reverse_in_tx(&tx, user, id, &reason, false)?;
    tx.commit()?;
    Ok(id)
}

/// Núcleo do estorno, reutilizado por cancelamentos de venda/compra (`internal = true` ignora a trava por origem).
pub fn reverse_in_tx(tx: &Connection, user: &User, id: i64, reason: &str, internal: bool) -> AppResult<i64> {
    let today = settings_repo::today(tx).to_string();
    let p = payment_repo::get(tx, id, &today)?;
    if p.status != "confirmed" {
        return Err(AppError::Validation("Somente pagamentos confirmados podem ser estornados.".into()));
    }
    if p.reversal_of_id.is_some() {
        return Err(AppError::Validation("Um estorno não pode ser estornado.".into()));
    }
    if !internal && matches!(p.origin_type.as_str(), "sale" | "purchase") {
        return Err(AppError::Validation("Cancele a venda/compra de origem para estornar este pagamento.".into()));
    }
    if !internal && p.origin_type == "loan" && p.direction == "out" {
        return Err(AppError::Validation("O desembolso não pode ser estornado por aqui.".into()));
    }
    // desfaz alocações em parcelas
    let allocs: Vec<(i64, i64)> = {
        let mut stmt = tx.prepare("SELECT installment_id, principal_cents FROM payment_allocations WHERE payment_id = ?1")?;
        stmt.query_map([id], |r| Ok((r.get(0)?, r.get(1)?)))?.collect::<Result<Vec<_>, _>>()?
    };
    let mut loan_ids = vec![];
    for (inst_id, principal) in &allocs {
        let inst = loan_repo::installment(tx, *inst_id)?;
        loan_repo::apply_paid(tx, *inst_id, -principal, None, None, &today)?;
        if !loan_ids.contains(&inst.loan_id) {
            loan_ids.push(inst.loan_id);
        }
    }
    for lid in loan_ids {
        if loan_repo::loan_status(tx, lid)? == "paid_off" {
            loan_repo::set_loan_status(tx, lid, "active", None)?;
        }
    }
    let opposite = if p.direction == "in" { "out" } else { "in" };
    let rid = payment_repo::insert(
        tx,
        &NewPayment {
            client_id: p.client_id,
            party_name: None,
            direction: opposite,
            origin_type: &p.origin_type,
            origin_id: p.origin_id,
            description: Some(&format!("Estorno de {} — {}", p.code, reason)),
            amount_cents: p.amount_cents,
            method: &p.method,
            status: "confirmed",
            due_date: None,
            paid_at: Some(&today),
            idempotency_key: None,
            user_id: user.id,
        },
    )?;
    tx.execute(
        "UPDATE payments SET reversal_of_id = ?2, reversal_reason = ?3 WHERE id = ?1",
        rusqlite::params![rid, id, reason],
    )?;
    tx.execute("UPDATE payments SET status = 'reversed', reversal_reason = ?2 WHERE id = ?1", (id, reason))?;
    payment_repo::insert_cash(tx, opposite, p.amount_cents, &p.method, category_for(&p.origin_type), Some(&format!("Estorno de {}", p.code)), Some(rid), &settings_repo::now_local(&tx), user.id)?;
    audit_repo::log(tx, user, "payment.reverse", "payments", id, reason)?;
    Ok(rid)
}

#[derive(Debug, Serialize, Clone)]
#[serde(rename_all = "camelCase")]
pub struct InstallmentDue {
    pub installment_id: i64,
    pub remaining_cents: i64,
    pub charges: LateCharges,
    pub total_due_cents: i64,
}

pub fn installment_due(conn: &Connection, inst: &InstallmentRow, as_of: NaiveDate) -> AppResult<InstallmentDue> {
    let fee_bp = settings_repo::get_i64(conn, "loan.late_fee_bp", 200)?;
    let mora_bp = settings_repo::get_i64(conn, "loan.late_interest_month_bp", 100)?;
    let ch = late_charges(inst.remaining(), inst.due(), as_of, inst.late_fee_applied, inst.through(), fee_bp, mora_bp);
    Ok(InstallmentDue {
        installment_id: inst.id,
        remaining_cents: inst.remaining(),
        total_due_cents: inst.remaining() + ch.total(),
        charges: ch,
    })
}

/// Baixa uma parcela (total ou parcial). Encargos de atraso são pagos primeiro e devem ser cobertos integralmente.
/// Retorna o id do pagamento. Idempotente por `idempotency_key`.
pub fn pay_installment(
    conn: &mut Connection,
    user: &User,
    installment_id: i64,
    amount_cents: i64,
    method: &str,
    idempotency_key: Option<String>,
) -> AppResult<i64> {
    check_method(method)?;
    if amount_cents <= 0 {
        return Err(AppError::Validation("Valor deve ser maior que zero.".into()));
    }
    let tx = conn.transaction()?;
    if let Some(k) = &idempotency_key {
        if let Some(existing) = payment_repo::find_by_key(&tx, k)? {
            return Ok(existing);
        }
    }
    let today = settings_repo::today(&tx);
    let inst = loan_repo::installment(&tx, installment_id)?;
    let status = loan_repo::loan_status(&tx, inst.loan_id)?;
    if status != "active" {
        return Err(AppError::Validation("O empréstimo não está ativo para recebimentos.".into()));
    }
    if !matches!(inst.status.as_str(), "open" | "partial") {
        return Err(AppError::Validation("Parcela já quitada ou renegociada.".into()));
    }
    let due = installment_due(&tx, &inst, today)?;
    if amount_cents > due.total_due_cents {
        return Err(AppError::Validation(format!("Valor excede o devido ({}).", format_brl(due.total_due_cents))));
    }
    if amount_cents < due.charges.total() {
        return Err(AppError::Validation(format!(
            "O pagamento deve cobrir ao menos os encargos de atraso ({}).",
            format_brl(due.charges.total())
        )));
    }
    let principal = amount_cents - due.charges.total();
    let (client_id, loan_n): (i64, i64) =
        tx.query_row("SELECT client_id, id FROM loans WHERE id = ?1", [inst.loan_id], |r| Ok((r.get(0)?, r.get(1)?)))?;
    let total_inst: i64 = tx.query_row(
        "SELECT COUNT(*) FROM loan_installments WHERE loan_id = ?1 AND status <> 'renegotiated'",
        [inst.loan_id],
        |r| r.get(0),
    )?;
    let desc = format!("Parcela {}/{} · Contrato #{}", inst.number, total_inst, loan_n);
    let today_s = today.to_string();
    let pid = payment_repo::insert(
        &tx,
        &NewPayment {
            client_id: Some(client_id),
            party_name: None,
            direction: "in",
            origin_type: "loan",
            origin_id: Some(inst.loan_id),
            description: Some(&desc),
            amount_cents,
            method,
            status: "confirmed",
            due_date: Some(&inst.due_date),
            paid_at: Some(&today_s),
            idempotency_key: idempotency_key.as_deref(),
            user_id: user.id,
        },
    )?;
    tx.execute(
        "INSERT INTO payment_allocations (payment_id, installment_id, principal_cents, fee_cents, interest_cents) VALUES (?1,?2,?3,?4,?5)",
        rusqlite::params![pid, installment_id, principal, due.charges.fee_cents, due.charges.interest_cents],
    )?;
    let fee_flag = if due.charges.fee_cents > 0 { Some(true) } else { None };
    let through = if due.charges.days_late > 0 { Some(today_s.as_str()) } else { None };
    loan_repo::apply_paid(&tx, installment_id, principal, fee_flag, through, &today_s)?;
    payment_repo::insert_cash(&tx, "in", amount_cents, method, "Empréstimos", Some(&desc), Some(pid), &settings_repo::now_local(&tx), user.id)?;
    if loan_repo::count_open(&tx, inst.loan_id)? == 0 {
        loan_repo::set_loan_status(&tx, inst.loan_id, "paid_off", Some(&today_s))?;
        audit_repo::log(&tx, user, "loan.paid_off", "loans", inst.loan_id, "")?;
    }
    audit_repo::log(&tx, user, "payment.installment", "payments", pid, &format!("{desc}: {}", format_brl(amount_cents)))?;
    tx.commit()?;
    Ok(pid)
}

/// Quitação antecipada ou total: baixa todas as parcelas em aberto em um único pagamento.
pub fn settle_loan(conn: &mut Connection, user: &User, loan_id: i64, method: &str, idempotency_key: Option<String>) -> AppResult<i64> {
    check_method(method)?;
    let tx = conn.transaction()?;
    if let Some(k) = &idempotency_key {
        if let Some(existing) = payment_repo::find_by_key(&tx, k)? {
            return Ok(existing);
        }
    }
    if loan_repo::loan_status(&tx, loan_id)? != "active" {
        return Err(AppError::Validation("O empréstimo não está ativo.".into()));
    }
    let today = settings_repo::today(&tx);
    let today_s = today.to_string();
    let open = loan_repo::open_installments(&tx, loan_id)?;
    if open.is_empty() {
        return Err(AppError::Validation("Não há parcelas em aberto.".into()));
    }
    let dues: Vec<InstallmentDue> = open.iter().map(|i| installment_due(&tx, i, today)).collect::<AppResult<_>>()?;
    let total: i64 = dues.iter().map(|d| d.total_due_cents).sum();
    let client_id: i64 = tx.query_row("SELECT client_id FROM loans WHERE id = ?1", [loan_id], |r| r.get(0))?;
    let desc = format!("Quitação · Contrato #{loan_id}");
    let pid = payment_repo::insert(
        &tx,
        &NewPayment {
            client_id: Some(client_id), party_name: None, direction: "in", origin_type: "loan", origin_id: Some(loan_id),
            description: Some(&desc), amount_cents: total, method, status: "confirmed", due_date: None,
            paid_at: Some(&today_s), idempotency_key: idempotency_key.as_deref(), user_id: user.id,
        },
    )?;
    for (inst, due) in open.iter().zip(&dues) {
        tx.execute(
            "INSERT INTO payment_allocations (payment_id, installment_id, principal_cents, fee_cents, interest_cents) VALUES (?1,?2,?3,?4,?5)",
            rusqlite::params![pid, inst.id, due.remaining_cents, due.charges.fee_cents, due.charges.interest_cents],
        )?;
        let through = if due.charges.days_late > 0 { Some(today_s.as_str()) } else { None };
        loan_repo::apply_paid(&tx, inst.id, due.remaining_cents, Some(due.charges.fee_cents > 0 || inst.late_fee_applied), through, &today_s)?;
    }
    payment_repo::insert_cash(&tx, "in", total, method, "Empréstimos", Some(&desc), Some(pid), &settings_repo::now_local(&tx), user.id)?;
    loan_repo::set_loan_status(&tx, loan_id, "paid_off", Some(&today_s))?;
    audit_repo::log(&tx, user, "loan.settled", "loans", loan_id, &format_brl(total))?;
    tx.commit()?;
    Ok(pid)
}

pub fn manual_cash(conn: &mut Connection, user: &User, kind: &str, amount: i64, method: &str, description: &str) -> AppResult<i64> {
    check_method(method)?;
    if !matches!(kind, "in" | "out") || amount <= 0 {
        return Err(AppError::Validation("Lançamento de caixa inválido.".into()));
    }
    let d = require_text(description, "Descrição", 200)?;
    let tx = conn.transaction()?;
    let id = payment_repo::insert_cash(&tx, kind, amount, method, if kind == "in" { "Suprimento" } else { "Sangria" }, Some(&d), None, &settings_repo::now_local(&tx), user.id)?;
    audit_repo::log(&tx, user, "cash.manual", "cash_movements", id, &format!("{kind} {}", format_brl(amount)))?;
    tx.commit()?;
    Ok(id)
}

pub fn reconcile(conn: &mut Connection, user: &User, ids: &[i64], value: bool) -> AppResult<()> {
    let tx = conn.transaction()?;
    for id in ids {
        tx.execute(
            "UPDATE cash_movements SET reconciled = ?2, reconciled_at = CASE WHEN ?2 = 1 THEN ?3 END,
                reconciled_by = CASE WHEN ?2 = 1 THEN ?4 END WHERE id = ?1",
            rusqlite::params![id, value as i64, settings_repo::now_local(&tx), user.id],
        )?;
    }
    audit_repo::log(&tx, user, "cash.reconcile", "cash_movements", ids.first().copied().unwrap_or(0), &format!("{} lançamentos, {}", ids.len(), value))?;
    tx.commit()?;
    Ok(())
}

pub fn company_header(conn: &Connection) -> (String, String) {
    let name = settings_repo::get_or(conn, "company.name", "").unwrap_or_default();
    let doc = settings_repo::get_or(conn, "company.document", "").unwrap_or_default();
    (if name.is_empty() { "Phantom Financeira".into() } else { name }, doc)
}

/// Gera (uma vez) o recibo em PDF do pagamento e o guarda cifrado.
pub fn receipt(conn: &mut Connection, vault: &Vault, user: &User, payment_id: i64) -> AppResult<attachment_service::Attachment> {
    let tx = conn.transaction()?;
    if let Some(a) = attachment_service::list(&tx, "payment", payment_id, Some("receipt"))?.into_iter().next() {
        return Ok(a);
    }
    let today = settings_repo::today(&tx).to_string();
    let p = payment_repo::get(&tx, payment_id, &today)?;
    if p.status != "confirmed" && p.status != "reversed" {
        return Err(AppError::Validation("Recibo disponível apenas para pagamentos confirmados.".into()));
    }
    let (company, cnpj) = company_header(&tx);
    let mut pdf = Pdf::new(&format!("Recibo {}", p.code));
    pdf.heading(&company);
    if !cnpj.is_empty() {
        pdf.paragraph(&format!("CNPJ {cnpj}"), 9.0, false);
    }
    pdf.space(8.0);
    pdf.heading(&format!("RECIBO {}", p.code));
    pdf.rule();
    pdf.key_value("Tipo", if p.direction == "in" { "Recebimento" } else { "Pagamento" });
    pdf.key_value("Cliente / Favorecido", p.client_name.as_deref().unwrap_or("—"));
    pdf.key_value("Descrição", p.description.as_deref().unwrap_or("—"));
    pdf.key_value("Valor", &format_brl(p.amount_cents));
    pdf.key_value("Forma de pagamento", method_label(&p.method));
    pdf.key_value("Data", &p.paid_at.as_deref().map(crate::domain::money::br_date).unwrap_or("—".into()));
    pdf.key_value("Emitido por", &user.full_name);
    pdf.space(24.0);
    pdf.paragraph("Documento de controle interno. Não substitui documento fiscal.", 8.0, false);
    let a = attachment_service::add_bytes(&tx, vault, user, "payment", payment_id, "receipt", &format!("recibo_{}.pdf", p.code), &pdf.finish())?;
    tx.commit()?;
    Ok(a)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::testutil::env;

    fn manual(dir: &str, amount: i64, confirm: bool, key: Option<&str>) -> ManualPaymentInput {
        ManualPaymentInput {
            client_id: None, party_name: Some("Fornecedor X".into()), direction: dir.into(),
            description: "Aluguel".into(), amount_cents: amount, method: "pix".into(),
            due_date: Some("2099-01-10".into()), confirm, idempotency_key: key.map(|s| s.to_string()),
        }
    }

    fn balance(conn: &Connection) -> i64 {
        payment_repo::cash_summary(conn).unwrap().balance_cents
    }

    #[test]
    fn confirmed_payment_moves_cash_and_pending_does_not() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        register_manual(&mut conn, &e.admin, manual("in", 50_000, true, None)).unwrap();
        assert_eq!(balance(&conn), 50_000);
        let pend = register_manual(&mut conn, &e.admin, manual("out", 20_000, false, None)).unwrap();
        assert_eq!(balance(&conn), 50_000);
        confirm(&mut conn, &e.admin, pend, None).unwrap();
        assert_eq!(balance(&conn), 30_000);
        assert!(confirm(&mut conn, &e.admin, pend, None).is_err());
    }

    #[test]
    fn idempotency_key_prevents_duplicates() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let a = register_manual(&mut conn, &e.admin, manual("in", 10_000, true, Some("k1"))).unwrap();
        let b = register_manual(&mut conn, &e.admin, manual("in", 10_000, true, Some("k1"))).unwrap();
        assert_eq!(a, b);
        assert_eq!(balance(&conn), 10_000);
    }

    #[test]
    fn reversal_keeps_history_and_restores_cash() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let id = register_manual(&mut conn, &e.admin, manual("in", 10_000, true, None)).unwrap();
        let r = reverse(&mut conn, &e.admin, id, "Lançamento em duplicidade").unwrap();
        assert_eq!(balance(&conn), 0);
        let today = settings_repo::today(&conn).to_string();
        assert_eq!(payment_repo::get(&conn, id, &today).unwrap().status, "reversed");
        assert_eq!(payment_repo::get(&conn, r, &today).unwrap().reversal_of_id, Some(id));
        assert!(reverse(&mut conn, &e.admin, id, "de novo").is_err());
        assert!(reverse(&mut conn, &e.admin, r, "estorno do estorno").is_err());
        let rows: i64 = conn.query_row("SELECT COUNT(*) FROM payments", [], |r| r.get(0)).unwrap();
        assert_eq!(rows, 2);
    }

    #[test]
    fn validates_inputs() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        assert!(register_manual(&mut conn, &e.admin, manual("in", 0, true, None)).is_err());
        let mut m = manual("in", 100, true, None);
        m.method = "bitcoin".into();
        assert!(register_manual(&mut conn, &e.admin, m).is_err());
        let mut m = manual("in", 100, false, None);
        m.due_date = None;
        assert!(register_manual(&mut conn, &e.admin, m).is_err());
    }

    #[test]
    fn reconcile_and_manual_cash() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = manual_cash(&mut conn, &e.admin, "in", 5_000, "cash", "Suprimento inicial").unwrap();
        assert_eq!(payment_repo::cash_summary(&conn).unwrap().unreconciled_count, 1);
        reconcile(&mut conn, &e.admin, &[c], true).unwrap();
        assert_eq!(payment_repo::cash_summary(&conn).unwrap().unreconciled_count, 0);
        assert!(conn.execute("DELETE FROM cash_movements", []).is_err());
    }

    #[test]
    fn receipt_is_generated_once() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let id = register_manual(&mut conn, &e.admin, manual("in", 10_000, true, None)).unwrap();
        let a = receipt(&mut conn, &e.vault, &e.admin, id).unwrap();
        let b = receipt(&mut conn, &e.vault, &e.admin, id).unwrap();
        assert_eq!(a.id, b.id);
        let (_, bytes) = attachment_service::read(&conn, &e.vault, a.id).unwrap();
        assert!(bytes.starts_with(b"%PDF"));
    }
}
