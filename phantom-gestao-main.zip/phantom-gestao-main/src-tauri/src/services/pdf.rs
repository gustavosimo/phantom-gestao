//! Gerador mínimo de PDF (A4, Helvetica) sem dependências externas. Suficiente
//! para contratos, recibos, comprovantes e relatórios tabulares.

const PAGE_W: f32 = 595.0;
const PAGE_H: f32 = 842.0;
const MARGIN: f32 = 50.0;

use std::collections::HashMap;

/// Emblema oficial (JPEG 256x256) embutido nos documentos.
const LOGO_JPEG: &[u8] = include_bytes!("../../assets/phantom-mark.jpg");
const LOGO_SIZE: f32 = 54.0;

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Align {
    Left,
    Center,
    Right,
    Justify,
}

/// Trecho de texto com estilo inline.
#[derive(Clone, Debug, PartialEq)]
pub struct Run {
    pub text: String,
    pub bold: bool,
    pub italic: bool,
}

/// Marcação inline: `**negrito**` e `*itálico*` (valores variáveis escapam `*` com U+E000).
pub fn parse_runs(s: &str) -> Vec<Run> {
    let mut runs = vec![];
    let (mut bold, mut italic) = (false, false);
    let mut cur = String::new();
    let chars: Vec<char> = s.chars().collect();
    let mut i = 0;
    let flush = |cur: &mut String, runs: &mut Vec<Run>, bold: bool, italic: bool| {
        if !cur.is_empty() {
            runs.push(Run { text: std::mem::take(cur).replace('\u{E000}', "*"), bold, italic });
        }
    };
    while i < chars.len() {
        if chars[i] == '*' && chars.get(i + 1) == Some(&'*') {
            flush(&mut cur, &mut runs, bold, italic);
            bold = !bold;
            i += 2;
        } else if chars[i] == '*' {
            flush(&mut cur, &mut runs, bold, italic);
            italic = !italic;
            i += 1;
        } else {
            cur.push(chars[i]);
            i += 1;
        }
    }
    flush(&mut cur, &mut runs, bold, italic);
    runs
}

fn base_char(c: char) -> char {
    match c {
        'á' | 'à' | 'â' | 'ã' | 'ä' => 'a',
        'é' | 'è' | 'ê' | 'ë' => 'e',
        'í' | 'ì' | 'î' | 'ï' => 'i',
        'ó' | 'ò' | 'ô' | 'õ' | 'ö' => 'o',
        'ú' | 'ù' | 'û' | 'ü' => 'u',
        'ç' => 'c',
        'Á' | 'À' | 'Â' | 'Ã' | 'Ä' => 'A',
        'É' | 'È' | 'Ê' | 'Ë' => 'E',
        'Í' | 'Ì' | 'Î' | 'Ï' => 'I',
        'Ó' | 'Ò' | 'Ô' | 'Õ' | 'Ö' => 'O',
        'Ú' | 'Ù' | 'Û' | 'Ü' => 'U',
        'Ç' => 'C',
        c => c,
    }
}

/// Larguras Helvetica / Helvetica-Bold (tabelas AFM, em 1/1000 de em) para quebra de linha e alinhamento.
fn glyph_width(c: char, bold: bool) -> f32 {
    let c = base_char(c);
    let lower = "abcdefghijklmnopqrstuvwxyz";
    let upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    let (lw, uw): ([u16; 26], [u16; 26]) = if bold {
        (
            [556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611, 611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500],
            [722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611],
        )
    } else {
        (
            [556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500],
            [667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611],
        )
    };
    let w: u16 = if let Some(i) = lower.find(c) {
        lw[i]
    } else if let Some(i) = upper.find(c) {
        uw[i]
    } else {
        match c {
            ' ' | '.' | ',' | ':' | ';' | '!' | '/' => 278,
            '(' | ')' | '-' | '[' | ']' => 333,
            '0'..='9' => 556,
            '—' => 1000,
            '–' => 556,
            '•' => 350,
            '°' | 'º' | 'ª' => 365,
            '%' => 889,
            '$' | '?' | '#' => 556,
            '*' => 389,
            _ => 556,
        }
    };
    f32::from(w) / 1000.0
}

fn text_width(s: &str, size: f32, bold: bool) -> f32 {
    s.chars().map(|c| glyph_width(c, bold)).sum::<f32>() * size
}

struct Word {
    text: String,
    bold: bool,
    italic: bool,
}

/// Imagem JPEG do usuário (passada direto ao PDF com DCTDecode).
pub struct JpegImg {
    data: Vec<u8>,
    w: u32,
    h: u32,
    comps: u8,
}

/// Lê dimensões e componentes de um JPEG (marcador SOFn). `None` se inválido ou não suportado (CMYK).
fn parse_jpeg(b: &[u8]) -> Option<(u32, u32, u8)> {
    if b.len() < 4 || b[0] != 0xFF || b[1] != 0xD8 {
        return None;
    }
    let mut i = 2;
    while i + 9 < b.len() {
        if b[i] != 0xFF {
            i += 1;
            continue;
        }
        let m = b[i + 1];
        if m == 0xFF {
            i += 1;
            continue;
        }
        if (0xD0..=0xD9).contains(&m) || m == 0x01 {
            i += 2;
            continue;
        }
        let len = usize::from(b[i + 2]) << 8 | usize::from(b[i + 3]);
        if matches!(m, 0xC0..=0xC3 | 0xC5..=0xC7 | 0xC9..=0xCB | 0xCD..=0xCF) {
            let h = u32::from(b[i + 5]) << 8 | u32::from(b[i + 6]);
            let w = u32::from(b[i + 7]) << 8 | u32::from(b[i + 8]);
            let comps = b[i + 9];
            return if w > 0 && h > 0 && (comps == 1 || comps == 3) { Some((w, h, comps)) } else { None };
        }
        i += 2 + len;
    }
    None
}

/// Largura e altura (px) de um JPEG válido.
pub fn jpeg_size(b: &[u8]) -> Option<(u32, u32)> {
    parse_jpeg(b).map(|(w, h, _)| (w, h))
}

pub struct Pdf {
    assets: HashMap<i64, JpegImg>,
    used: Vec<i64>,
    footer: Vec<String>,
    bottom: f32,
    logo: bool,
    title: String,
    pages: Vec<String>,
    cur: String,
    y: f32,
}

fn winansi(s: &str) -> Vec<u8> {
    let mut out = Vec::with_capacity(s.len());
    for ch in s.chars() {
        let b = match ch {
            '—' => 0x97,
            '–' => 0x96,
            '•' => 0x95,
            '“' => 0x93,
            '”' => 0x94,
            '‘' => 0x91,
            '’' => 0x92,
            '€' => 0x80,
            c if (c as u32) < 0x100 => c as u32 as u8,
            _ => b'?',
        };
        match b {
            0x0A | 0x0D | 0x09 => out.push(b' '),
            _ => out.push(b),
        }
    }
    out
}

fn text_cmd(font: &str, size: f32, x: f32, y: f32, s: &str) -> String {
    // Bytes WinAnsi codificados como escapes octais para manter o arquivo ASCII.
    let mut lit = String::new();
    for b in winansi(s) {
        if (0x20..0x80).contains(&b) && !matches!(b, b'(' | b')' | b'\\') {
            lit.push(b as char);
        } else {
            lit.push_str(&format!("\\{:03o}", b));
        }
    }
    format!("BT /{font} {size:.1} Tf {x:.1} {y:.1} Td ({lit}) Tj ET\n")
}

fn approx_width(s: &str, size: f32) -> f32 {
    s.chars().count() as f32 * size * 0.52
}

impl Pdf {
    pub fn new(title: &str) -> Self {
        let mut pdf = Self { assets: HashMap::new(), used: vec![], footer: vec![], bottom: MARGIN, logo: true, title: title.to_string(), pages: vec![], cur: String::new(), y: PAGE_H - MARGIN };
        pdf.header();
        pdf
    }

    /// Cabeçalho institucional: emblema oficial + "PHANTOM / FINANCEIRA / ANÁLISE DE CRÉDITO".
    fn header(&mut self) {
        let x = MARGIN + LOGO_SIZE + 14.0;
        let top = PAGE_H - MARGIN;
        self.cur.push_str(&format!("q {LOGO_SIZE} 0 0 {LOGO_SIZE} {MARGIN:.1} {:.1} cm /Im1 Do Q
", top - LOGO_SIZE));
        let spaced = |font: &str, size: f32, tc: f32, y: f32, text: &str| -> String {
            let mut lit = String::new();
            for b in winansi(text) {
                if (0x20..0x80).contains(&b) && !matches!(b, b'(' | b')' | b'\\') {
                    lit.push(b as char);
                } else {
                    lit.push_str(&format!("\\{:03o}", b));
                }
            }
            format!("BT /{font} {size:.1} Tf {tc:.2} Tc {x:.1} {y:.1} Td ({lit}) Tj 0 Tc ET
")
        };
        self.cur.push_str(&spaced("F2", 24.0, 1.2, top - 22.0, "PHANTOM"));
        self.cur.push_str(&spaced("F2", 10.0, 5.0, top - 38.0, "FINANCEIRA"));
        self.cur.push_str(&spaced("F2", 8.5, 1.8, top - 51.0, "ANÁLISE DE CRÉDITO"));
        self.cur.push_str(&format!(
            "0.6 w {MARGIN:.1} {y:.1} m {x2:.1} {y:.1} l S
",
            y = top - LOGO_SIZE - 8.0,
            x2 = PAGE_W - MARGIN
        ));
        self.y = top - LOGO_SIZE - 22.0;
    }

    fn ensure(&mut self, need: f32) {
        if self.y - need < self.bottom {
            self.new_page();
        }
    }

    fn new_page(&mut self) {
        if !self.cur.is_empty() {
            self.pages.push(std::mem::take(&mut self.cur));
        }
        self.y = PAGE_H - MARGIN;
    }

    pub fn heading(&mut self, s: &str) {
        self.ensure(34.0);
        self.cur.push_str(&text_cmd("F2", 16.0, MARGIN, self.y - 16.0, s));
        self.y -= 28.0;
    }

    pub fn subheading(&mut self, s: &str) {
        self.ensure(26.0);
        self.cur.push_str(&text_cmd("F2", 11.0, MARGIN, self.y - 11.0, s));
        self.y -= 20.0;
    }

    pub fn space(&mut self, h: f32) {
        self.y -= h;
    }

    /// Parágrafo com quebra automática de linha.
    pub fn paragraph(&mut self, s: &str, size: f32, bold: bool) {
        let font = if bold { "F2" } else { "F1" };
        let max_w = PAGE_W - 2.0 * MARGIN;
        for raw in s.split('\n') {
            let mut line = String::new();
            let mut lines: Vec<String> = vec![];
            for word in raw.split_whitespace() {
                let trial = if line.is_empty() { word.to_string() } else { format!("{line} {word}") };
                if approx_width(&trial, size) > max_w && !line.is_empty() {
                    lines.push(std::mem::take(&mut line));
                    line = word.to_string();
                } else {
                    line = trial;
                }
            }
            lines.push(line);
            for l in lines {
                self.ensure(size + 4.0);
                self.cur.push_str(&text_cmd(font, size, MARGIN, self.y - size, &l));
                self.y -= size + 4.0;
            }
        }
    }

    /// Linha em colunas (ex.: rótulos de assinatura): cada coluna começa em `x` fixo.
    pub fn columns(&mut self, cells: &[&str], size: f32) {
        self.ensure(size + 4.0);
        let step = (PAGE_W - 2.0 * MARGIN) / cells.len().max(1) as f32;
        for (i, c) in cells.iter().enumerate() {
            self.cur.push_str(&text_cmd("F1", size, MARGIN + step * i as f32, self.y - size, c));
        }
        self.y -= size + 4.0;
    }

    pub fn key_value(&mut self, k: &str, v: &str) {
        self.ensure(16.0);
        self.cur.push_str(&text_cmd("F2", 10.0, MARGIN, self.y - 10.0, k));
        self.cur.push_str(&text_cmd("F1", 10.0, MARGIN + 170.0, self.y - 10.0, v));
        self.y -= 15.0;
    }

    pub fn rule(&mut self) {
        self.ensure(8.0);
        self.cur.push_str(&format!(
            "0.6 w {MARGIN:.1} {y:.1} m {x2:.1} {y:.1} l S\n",
            y = self.y - 3.0,
            x2 = PAGE_W - MARGIN
        ));
        self.y -= 8.0;
    }

    /// Tabela com larguras proporcionais; textos longos são truncados.
    pub fn table(&mut self, header: &[&str], rows: &[Vec<String>], weights: &[f32]) {
        let total_w = PAGE_W - 2.0 * MARGIN;
        let sum: f32 = weights.iter().sum();
        let widths: Vec<f32> = weights.iter().map(|w| w / sum * total_w).collect();
        let draw = |pdf: &mut Pdf, cells: Vec<String>, bold: bool| {
            pdf.ensure(16.0);
            let mut x = MARGIN;
            for (i, c) in cells.iter().enumerate() {
                let max_chars = (widths[i] / (9.0 * 0.52)).floor() as usize;
                let mut t: String = c.chars().take(max_chars.max(1)).collect();
                if c.chars().count() > max_chars && max_chars > 1 {
                    t.pop();
                    t.push('…');
                }
                pdf.cur.push_str(&text_cmd(if bold { "F2" } else { "F1" }, 9.0, x, pdf.y - 9.0, &t));
                x += widths[i];
            }
            pdf.y -= 14.0;
        };
        draw(self, header.iter().map(|s| s.to_string()).collect(), true);
        self.rule();
        for r in rows {
            if self.y - 16.0 < self.bottom {
                self.new_page();
                draw(self, header.iter().map(|s| s.to_string()).collect(), true);
                self.rule();
            }
            draw(self, r.clone(), false);
        }
    }

    /// Parágrafo rico: estilos inline, alinhamento (inclusive justificado), recuo e marcador de lista.
    pub fn rich(&mut self, runs: &[Run], size: f32, align: Align, indent: f32, bullet: Option<&str>) {
        let max_w = PAGE_W - 2.0 * MARGIN - indent;
        let mut words: Vec<Word> = vec![];
        for r in runs {
            for w in r.text.split_whitespace() {
                words.push(Word { text: w.to_string(), bold: r.bold, italic: r.italic });
            }
        }
        if words.is_empty() {
            self.space(size);
            return;
        }
        let space_w = |bold: bool| glyph_width(' ', bold) * size;
        let mut lines: Vec<Vec<usize>> = vec![vec![]];
        let mut width = 0.0;
        for (i, w) in words.iter().enumerate() {
            let ww = text_width(&w.text, size, w.bold);
            let add = if lines.last().unwrap().is_empty() { ww } else { space_w(w.bold) + ww };
            if width + add > max_w && !lines.last().unwrap().is_empty() {
                lines.push(vec![i]);
                width = ww;
            } else {
                lines.last_mut().unwrap().push(i);
                width += add;
            }
        }
        let last = lines.len() - 1;
        for (li, line) in lines.iter().enumerate() {
            self.ensure(size * 1.4);
            let ws: f32 = line.iter().map(|&i| text_width(&words[i].text, size, words[i].bold)).sum();
            let gaps = line.len().saturating_sub(1) as f32;
            let natural = ws + gaps * space_w(false);
            let (mut x, gap) = match align {
                Align::Left => (MARGIN + indent, space_w(false)),
                Align::Center => (MARGIN + indent + (max_w - natural) / 2.0, space_w(false)),
                Align::Right => (MARGIN + indent + max_w - natural, space_w(false)),
                Align::Justify if li != last && gaps > 0.0 => (MARGIN + indent, (max_w - ws) / gaps),
                Align::Justify => (MARGIN + indent, space_w(false)),
            };
            let y = self.y - size;
            if li == 0 {
                if let Some(b) = bullet {
                    self.cur.push_str(&text_cmd("F1", size, MARGIN + indent - 14.0, y, b));
                }
            }
            for &i in line {
                let w = &words[i];
                let font = match (w.bold, w.italic) {
                    (false, false) => "F1",
                    (true, false) => "F2",
                    (false, true) => "F3",
                    (true, true) => "F4",
                };
                self.cur.push_str(&text_cmd(font, size, x, y, &w.text));
                x += text_width(&w.text, size, w.bold) + gap;
            }
            self.y -= size * 1.38;
        }
        self.y -= 3.0;
    }

    /// Registra uma imagem JPEG (id do modelo) para uso com `[img:ID]`. Retorna false se inválida.
    pub fn add_image(&mut self, id: i64, data: Vec<u8>) -> bool {
        match parse_jpeg(&data) {
            Some((w, h, comps)) => {
                self.assets.insert(id, JpegImg { data, w, h, comps });
                true
            }
            None => false,
        }
    }

    /// Rodapé extra (acima do rodapé padrão do sistema), em todas as páginas.
    pub fn set_footer(&mut self, lines: Vec<String>) {
        self.bottom = MARGIN + 11.0 * lines.len() as f32;
        self.footer = lines;
    }

    /// Imagem no fluxo do texto: `pct` = largura em % da área útil.
    pub fn image(&mut self, id: i64, pct: f32, align: Align) {
        let Some(img) = self.assets.get(&id) else {
            self.rich(&[Run { text: format!("[imagem {id} não encontrada]"), bold: false, italic: true }], 9.0, Align::Left, 0.0, None);
            return;
        };
        let area = PAGE_W - 2.0 * MARGIN;
        let w = (area * pct.clamp(5.0, 100.0) / 100.0).min(area);
        let mut h = w * img.h as f32 / img.w as f32;
        let mut w = w;
        let max_h = PAGE_H - 2.0 * MARGIN - 60.0;
        if h > max_h {
            w *= max_h / h;
            h = max_h;
        }
        self.ensure(h + 6.0);
        let x = match align {
            Align::Center => MARGIN + (area - w) / 2.0,
            Align::Right => MARGIN + area - w,
            _ => MARGIN,
        };
        let n = match self.used.iter().position(|u| *u == id) {
            Some(i) => i,
            None => {
                self.used.push(id);
                self.used.len() - 1
            }
        };
        self.cur.push_str(&format!("q {w:.1} 0 0 {h:.1} {x:.1} {:.1} cm /Img{} Do Q\n", self.y - h, n + 1));
        self.y -= h + 8.0;
    }

    /// Tabela com bordas, células com quebra de linha e estilos inline; `header` destaca a 1ª linha.
    pub fn grid(&mut self, rows: &[Vec<String>], header: bool) {
        let cols = rows.iter().map(Vec::len).max().unwrap_or(0);
        if cols == 0 {
            return;
        }
        let (size, pad, lh) = (9.0_f32, 4.0_f32, 11.5_f32);
        let cw = (PAGE_W - 2.0 * MARGIN) / cols as f32;
        for (ri, row) in rows.iter().enumerate() {
            let head = header && ri == 0;
            // quebra cada célula em linhas de palavras com fonte
            let mut cells: Vec<Vec<Vec<(String, &'static str)>>> = vec![];
            for ci in 0..cols {
                let text = row.get(ci).map(String::as_str).unwrap_or("");
                let mut words: Vec<(String, bool, bool)> = vec![];
                for r in parse_runs(text) {
                    for w in r.text.split_whitespace() {
                        words.push((w.to_string(), r.bold || head, r.italic));
                    }
                }
                let mut lines: Vec<Vec<(String, &'static str)>> = vec![vec![]];
                let mut width = 0.0;
                for (w, b, it) in words {
                    let ww = text_width(&w, size, b);
                    let sp = glyph_width(' ', b) * size;
                    let add = if lines.last().unwrap().is_empty() { ww } else { sp + ww };
                    if width + add > cw - 2.0 * pad && !lines.last().unwrap().is_empty() {
                        lines.push(vec![]);
                        width = ww;
                    } else {
                        width += add;
                    }
                    let font = match (b, it) {
                        (false, false) => "F1",
                        (true, false) => "F2",
                        (false, true) => "F3",
                        (true, true) => "F4",
                    };
                    lines.last_mut().unwrap().push((w, font));
                }
                cells.push(lines);
            }
            let nlines = cells.iter().map(Vec::len).max().unwrap_or(1).max(1);
            let h = nlines as f32 * lh + 2.0 * pad;
            self.ensure(h);
            let top = self.y;
            for (ci, lines) in cells.iter().enumerate() {
                let x = MARGIN + cw * ci as f32;
                if head {
                    self.cur.push_str(&format!("0.92 g {x:.1} {:.1} {cw:.1} {h:.1} re f 0 g\n", top - h));
                }
                self.cur.push_str(&format!("0.5 w 0.55 G {x:.1} {:.1} {cw:.1} {h:.1} re S 0 G\n", top - h));
                for (li, line) in lines.iter().enumerate() {
                    let y = top - pad - size - lh * li as f32 + 1.5;
                    let mut cx = x + pad;
                    for (w, font) in line {
                        self.cur.push_str(&text_cmd(font, size, cx, y, w));
                        cx += text_width(w, size, *font == "F2" || *font == "F4") + glyph_width(' ', false) * size;
                    }
                }
            }
            self.y -= h;
        }
        self.y -= 8.0;
    }

    pub fn page_break(&mut self) {
        self.new_page();
    }

    /// Renderiza texto com marcação simples (usada nos modelos de contrato):
    /// `# ` título · `## ` subtítulo · `- ` / `1. ` listas · `> ` recuo · `---` linha · `[quebra]` nova página ·
    /// prefixos `[c]` centro, `[d]` direita, `[j]` justificado, `[p]` fonte pequena, `[g]` fonte grande ·
    /// `**negrito**`, `*itálico*` · colunas separadas por 3+ espaços.
    pub fn markup(&mut self, text: &str) {
        // Diretivas: `[cabecalho] texto` (após o cabeçalho institucional) e `[rodape] texto` (todas as páginas).
        let mut head_lines: Vec<&str> = vec![];
        let mut foot_lines: Vec<String> = vec![];
        let mut body: Vec<&str> = vec![];
        for raw in text.lines() {
            let t = raw.trim();
            if let Some(h) = t.strip_prefix("[cabecalho]") {
                head_lines.push(h.trim());
            } else if let Some(f) = t.strip_prefix("[rodape]") {
                foot_lines.push(parse_runs(f.trim()).iter().map(|r| r.text.as_str()).collect::<String>());
            } else {
                body.push(raw);
            }
        }
        if !foot_lines.is_empty() {
            self.set_footer(foot_lines.into_iter().take(3).collect());
        }
        if !head_lines.is_empty() {
            for h in head_lines {
                self.rich(&parse_runs(h), 9.0, Align::Center, 0.0, None);
            }
            self.rule();
        }
        let mut table: Vec<Vec<String>> = vec![];
        let mut table_header = false;
        for raw in body.into_iter().chain(std::iter::once("")) {
            let tl = raw.trim();
            if tl.starts_with('|') && tl.ends_with('|') && tl.len() > 1 {
                let cells: Vec<String> = tl[1..tl.len() - 1].split('|').map(|c| c.trim().to_string()).collect();
                if cells.iter().all(|c| !c.is_empty() && c.chars().all(|ch| ch == '-' || ch == ':')) {
                    table_header = table.len() == 1;
                } else {
                    table.push(cells);
                }
                continue;
            }
            if !table.is_empty() {
                self.grid(&table, table_header);
                table.clear();
                table_header = false;
            }
            let mut line = raw.trim_end();
            if line.trim().is_empty() {
                self.space(6.0);
                continue;
            }
            if line.trim() == "[quebra]" {
                self.page_break();
                continue;
            }
            if line.trim() == "---" {
                self.rule();
                continue;
            }
            let (mut align, mut size) = (Align::Left, 10.0);
            loop {
                let t = line.trim_start();
                if let Some(r) = t.strip_prefix("[c]") { align = Align::Center; line = r; }
                else if let Some(r) = t.strip_prefix("[d]") { align = Align::Right; line = r; }
                else if let Some(r) = t.strip_prefix("[j]") { align = Align::Justify; line = r; }
                else if let Some(r) = t.strip_prefix("[p]") { size = 8.5; line = r; }
                else if let Some(r) = t.strip_prefix("[g]") { size = 12.5; line = r; }
                else { line = t; break; }
            }
            let line = line.trim_start();
            if let Some(spec) = line.strip_prefix("[img:").and_then(|r| r.strip_suffix(']')) {
                let mut it = spec.split_whitespace();
                if let Some(id) = it.next().and_then(|v| v.parse::<i64>().ok()) {
                    let pct = it.next().and_then(|v| v.trim_end_matches('%').parse::<f32>().ok()).unwrap_or(40.0);
                    self.image(id, pct, align);
                    continue;
                }
            }
            if let Some(h) = line.strip_prefix("## ") {
                let runs = vec![Run { text: h.to_string(), bold: true, italic: false }];
                self.space(2.0);
                self.rich(&runs, 11.5, align, 0.0, None);
            } else if let Some(h) = line.strip_prefix("# ") {
                let runs = vec![Run { text: h.to_string(), bold: true, italic: false }];
                self.space(2.0);
                self.rich(&runs, 16.0, align, 0.0, None);
            } else if let Some(item) = line.strip_prefix("- ") {
                self.rich(&parse_runs(item), size, align, 18.0, Some("•"));
            } else if let Some((n, item)) = line.split_once(". ").filter(|(n, _)| !n.is_empty() && n.len() <= 3 && n.chars().all(|c| c.is_ascii_digit())) {
                self.rich(&parse_runs(item), size, align, 18.0, Some(&format!("{n}.")));
            } else if let Some(q) = line.strip_prefix("> ") {
                self.rich(&parse_runs(q), size, align, 24.0, None);
            } else if line.contains("   ") {
                let cells: Vec<&str> = line.split("   ").map(str::trim).filter(|c| !c.is_empty()).collect();
                self.columns(&cells, size);
            } else {
                self.rich(&parse_runs(line), size, align, 0.0, None);
            }
        }
    }

    pub fn finish(mut self) -> Vec<u8> {
        if !self.cur.is_empty() || self.pages.is_empty() {
            self.pages.push(std::mem::take(&mut self.cur));
        }
        let n = self.pages.len();
        // objetos: 1 catálogo, 2 páginas, 3 F1, 4 F2, 5 info, depois (página, conteúdo) por página
        let mut objs: Vec<Vec<u8>> = vec![];
        objs.push(b"<< /Type /Catalog /Pages 2 0 R >>".to_vec());
        let base = 9;
        let kids: String = (0..n).map(|i| format!("{} 0 R", base + i * 2)).collect::<Vec<_>>().join(" ");
        objs.push(format!("<< /Type /Pages /Kids [{kids}] /Count {n} >>").into_bytes());
        objs.push(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>".to_vec());
        objs.push(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>".to_vec());
        let mut title = String::new();
        for b in winansi(&self.title) {
            title.push_str(&format!("\\{:03o}", b));
        }
        objs.push(format!("<< /Title ({title}) /Producer (Phantom Gestao) >>").into_bytes());
        if self.logo {
            let mut img = format!(
                "<< /Type /XObject /Subtype /Image /Width 256 /Height 256 /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length {} >>
stream
",
                LOGO_JPEG.len()
            )
            .into_bytes();
            img.extend(LOGO_JPEG);
            img.extend(b"
endstream");
            objs.push(img);
        }
        objs.push(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique /Encoding /WinAnsiEncoding >>".to_vec());
        objs.push(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-BoldOblique /Encoding /WinAnsiEncoding >>".to_vec());
        let img_base = base + 2 * n;
        let xobj = {
            let mut x = String::from("/XObject << ");
            if self.logo {
                x.push_str("/Im1 6 0 R ");
            }
            for k in 0..self.used.len() {
                x.push_str(&format!("/Img{} {} 0 R ", k + 1, img_base + k));
            }
            x.push_str(">>");
            x
        };
        for (i, content) in self.pages.iter().enumerate() {
            let mut footer = String::new();
            let nf = self.footer.len();
            for (k, line) in self.footer.iter().enumerate() {
                footer.push_str(&text_cmd("F1", 8.0, MARGIN, 28.0 + 11.0 * (nf - k) as f32, line));
            }
            footer.push_str(&text_cmd("F1", 8.0, MARGIN, 28.0, &format!("Phantom Gestão — página {} de {}", i + 1, n)));
            let stream = format!("{content}{footer}");
            objs.push(
                format!(
                    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {PAGE_W} {PAGE_H}] /Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 7 0 R /F4 8 0 R >> {} >> /Contents {} 0 R >>",
                    xobj,
                    base + 1 + i * 2
                )
                .into_bytes(),
            );
            let mut s = format!("<< /Length {} >>\nstream\n", stream.len()).into_bytes();
            s.extend(stream.as_bytes());
            s.extend(b"endstream");
            objs.push(s);
        }
        for id in &self.used {
            let im = &self.assets[id];
            let cs = if im.comps == 1 { "/DeviceGray" } else { "/DeviceRGB" };
            let mut o = format!(
                "<< /Type /XObject /Subtype /Image /Width {} /Height {} /ColorSpace {cs} /BitsPerComponent 8 /Filter /DCTDecode /Length {} >>\nstream\n",
                im.w,
                im.h,
                im.data.len()
            )
            .into_bytes();
            o.extend(&im.data);
            o.extend(b"\nendstream");
            objs.push(o);
        }
        let mut out = b"%PDF-1.4\n".to_vec();
        let mut offsets = vec![];
        for (i, o) in objs.iter().enumerate() {
            offsets.push(out.len());
            out.extend(format!("{} 0 obj\n", i + 1).as_bytes());
            out.extend(o);
            out.extend(b"\nendobj\n");
        }
        let xref = out.len();
        out.extend(format!("xref\n0 {}\n0000000000 65535 f \n", objs.len() + 1).as_bytes());
        for off in offsets {
            out.extend(format!("{off:010} 00000 n \n").as_bytes());
        }
        out.extend(
            format!("trailer\n<< /Size {} /Root 1 0 R /Info 5 0 R >>\nstartxref\n{xref}\n%%EOF\n", objs.len() + 1)
                .as_bytes(),
        );
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn produces_valid_structure() {
        let mut p = Pdf::new("Contrato");
        p.heading("CONTRATO Nº 1042 — Empréstimo");
        p.paragraph(&"Texto longo de cláusula (com parênteses) e acentuação. ".repeat(40), 10.0, false);
        let bytes = p.finish();
        let s = String::from_utf8_lossy(&bytes);
        assert!(s.starts_with("%PDF-1.4"));
        assert!(s.trim_end().ends_with("%%EOF"));
        assert!(s.contains("/Count 1") || s.contains("/Count 2"));
        assert!(s.contains("xref"));
    }

    #[test]
    fn renders_tables_footer_header_note_and_images() {
        let mut p = Pdf::new("Doc");
        assert!(p.add_image(7, include_bytes!("../../assets/phantom-mark.jpg").to_vec()));
        p.markup("[cabecalho] Linha extra do cabeçalho\n[rodape] Rodapé do modelo — CNPJ 00\n| Item | Valor |\n|---|---|\n| **Taxa** | R$ 10,00 com texto longo para quebrar dentro da célula da tabela |\n| Outro | R$ 5,00 |\n[c] [img:7 30%]\n[img:99]");
        let b = p.finish();
        let s = String::from_utf8_lossy(&b);
        assert!(s.contains("/Img1 ") && s.contains("/Subtype /Image"), "imagem do usuário");
        assert!(s.contains(" re S"), "bordas da tabela");
        assert!(s.contains("0.92 g"), "cabeçalho da tabela");
        assert!(s.contains("Rodap"), "rodapé extra");
    }

    #[test]
    fn rejects_invalid_images() {
        let mut p = Pdf::new("Doc");
        assert!(!p.add_image(1, vec![1, 2, 3]));
    }

    #[test]
    fn parses_inline_styles() {
        let r = parse_runs("Olá **negrito** e *itálico* normal");
        assert_eq!(r.iter().filter(|x| x.bold).count(), 1);
        assert_eq!(r.iter().filter(|x| x.italic).count(), 1);
        assert_eq!(r[1].text, "negrito");
        let esc = parse_runs("Nome com \u{E000} asterisco");
        assert_eq!(esc[0].text, "Nome com * asterisco");
    }

    #[test]
    fn markup_renders_lists_alignment_and_page_breaks() {
        let mut p = Pdf::new("Doc");
        p.markup("# Título\n[c] centralizado\n[d] à direita\n[j] justificado com bastante texto para ocupar mais de uma linha do documento de teste, repetindo palavras. Mais palavras para quebrar a linha uma ou duas vezes no PDF final.\n- item um\n1. primeiro\n> recuado\n**negrito** e *itálico*\n---\n[quebra]\nNova página");
        let b = p.finish();
        let s = String::from_utf8_lossy(&b);
        assert!(s.contains("/Count 2"), "quebra de página");
        assert!(s.contains("/F2 ") && s.contains("/F3 "), "estilos de fonte");
        assert!(s.contains("\\225"), "marcador de lista");
    }

    #[test]
    fn embeds_logo_image() {
        let mut p = Pdf::new("Contrato");
        p.heading("CONTRATO");
        let b = p.finish();
        let s = String::from_utf8_lossy(&b);
        assert!(s.contains("/Subtype /Image") && s.contains("/DCTDecode") && s.contains("/Im1 6 0 R"));
        assert!(b.windows(2).any(|w| w == [0xFF, 0xD8]), "JPEG embutido");
        assert!(s.contains("/Kids [9 0 R]"));
    }

    #[test]
    fn paginates_long_tables() {
        let mut p = Pdf::new("Relatório");
        let rows: Vec<Vec<String>> = (0..200).map(|i| vec![format!("linha {i}"), "R$ 1,00".into()]).collect();
        p.table(&["Item", "Valor"], &rows, &[3.0, 1.0]);
        let s = String::from_utf8_lossy(&p.finish()).to_string();
        let count: usize = s.split("/Count ").nth(1).unwrap().split(' ').next().unwrap().parse().unwrap();
        assert!(count >= 3);
    }

    #[test]
    fn escapes_special_chars() {
        let cmd = text_cmd("F1", 10.0, 0.0, 0.0, "a(b)c\\ é");
        assert!(cmd.contains("a\\050b\\051c\\134 \\351"));
    }
}



