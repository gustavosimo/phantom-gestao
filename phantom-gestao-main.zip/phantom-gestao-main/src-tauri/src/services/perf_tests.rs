//! Testes de desempenho com volume alto de dados (consultas reais, banco em memória).

use std::time::Instant;

use crate::repositories::{client_repo, loan_repo, payment_repo, PageQuery};
use crate::services::dashboard_service::{self, Period};
use crate::services::report_service;
use crate::testutil::env;

const CLIENTS: i64 = 20_000;
const LOANS_PER_5_CLIENTS: i64 = 1;
const INSTALLMENTS_PER_LOAN: i64 = 12;

fn ms(t: Instant) -> u128 {
    t.elapsed().as_millis()
}

#[test]
fn lists_and_dashboard_stay_fast_with_large_dataset() {
    let e = env();
    let conn = e.db.conn().unwrap();
    conn.execute_batch("BEGIN;").unwrap();
    {
        let mut c = conn.prepare("INSERT INTO clients (kind, name, document, status, phone) VALUES ('PF', ?1, ?2, 'active', '11999990000')").unwrap();
        for i in 1..=CLIENTS {
            c.execute((format!("Cliente Número {i:05}"), format!("{i:011}"))).unwrap();
        }
        let mut l = conn.prepare("INSERT INTO loans (client_id, principal_cents, term_months, rate_bp, first_due_date, status, contracted_at) VALUES (?1, 1000000, 12, 240, '2026-01-10', 'active', '2025-12-10')").unwrap();
        let mut i = conn.prepare("INSERT INTO loan_installments (loan_id, number, due_date, amount_cents, principal_cents, interest_cents, status) VALUES (?1, ?2, date('2026-01-10', '+' || (?2 - 1) || ' months'), 100000, 80000, 20000, 'open')").unwrap();
        let mut loan_id = 0;
        for client in (1..=CLIENTS).step_by((5 / LOANS_PER_5_CLIENTS) as usize) {
            l.execute([client]).unwrap();
            loan_id += 1;
            for n in 1..=INSTALLMENTS_PER_LOAN {
                i.execute((loan_id, n)).unwrap();
            }
        }
        let mut p = conn.prepare("INSERT INTO payments (client_id, direction, origin_type, amount_cents, method, status, paid_at) VALUES (?1, 'in', 'receivable', 5000, 'pix', 'confirmed', '2026-06-01')").unwrap();
        let mut cm = conn.prepare("INSERT INTO cash_movements (kind, amount_cents, method, category, occurred_at) VALUES ('in', 5000, 'pix', 'Contas a receber', '2026-06-01T10:00:00')").unwrap();
        for client in 1..=CLIENTS {
            p.execute([client]).unwrap();
            cm.execute([]).unwrap();
        }
    }
    conn.execute_batch("COMMIT;").unwrap();

    let today = "2026-06-15";
    let t = Instant::now();
    let q = PageQuery { page: 1, page_size: 20, search: Some("Número 1999".into()), ..Default::default() };
    let page = client_repo::list(&conn, &q, today).unwrap();
    let (t_clients, found) = (ms(t), page.total);
    assert!(found > 0);

    let t = Instant::now();
    let loans = loan_repo::list_loans(&conn, &PageQuery { page: 1, page_size: 20, ..Default::default() }, today).unwrap();
    let t_loans = ms(t);
    assert_eq!(loans.total, CLIENTS / 5);

    let t = Instant::now();
    let pays = payment_repo::list(&conn, &PageQuery { page: 1, page_size: 20, ..Default::default() }, &Default::default(), today).unwrap();
    let t_pay = ms(t);
    assert_eq!(pays.total, CLIENTS);

    let t = Instant::now();
    let d = dashboard_service::load(&conn, &Period { kind: "30d".into(), from: None, to: None }).unwrap();
    let t_dash = ms(t);
    assert_eq!(d.active_loans, CLIENTS / 5);

    let t = Instant::now();
    let _ = report_service::overview(&conn, &Period { kind: "year".into(), from: None, to: None }).unwrap();
    let t_rep = ms(t);

    println!("desempenho (ms): clientes={t_clients} emprestimos={t_loans} pagamentos={t_pay} dashboard={t_dash} relatorio={t_rep}");
    // limites generosos (build de depuração); em produção as consultas são ordens de grandeza menores
    assert!(t_clients < 1500, "lista de clientes lenta: {t_clients} ms");
    assert!(t_loans < 3000, "lista de empréstimos lenta: {t_loans} ms");
    assert!(t_pay < 1500, "lista de pagamentos lenta: {t_pay} ms");
    assert!(t_dash < 4000, "dashboard lento: {t_dash} ms");
    assert!(t_rep < 4000, "relatório lento: {t_rep} ms");
}
