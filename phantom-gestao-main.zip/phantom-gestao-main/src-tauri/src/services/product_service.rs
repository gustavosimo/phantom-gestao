use rusqlite::Connection;

use crate::domain::user::User;
use crate::domain::validation::{opt_text, require_text};
use crate::error::{AppError, AppResult};
use crate::repositories::audit_repo;
use crate::repositories::product_repo::{self, ProductInput};

fn clean(mut p: ProductInput) -> AppResult<ProductInput> {
    p.name = require_text(&p.name, "Nome do produto", 120)?;
    p.category = require_text(&p.category, "Categoria", 60)?;
    p.brand = opt_text(&p.brand);
    p.model = opt_text(&p.model);
    p.serial_number = opt_text(&p.serial_number);
    p.notes = opt_text(&p.notes);
    if p.cost_cents < 0 || p.price_cents < 0 || p.min_stock.is_some_and(|m| m < 0) {
        return Err(AppError::Validation("Valores não podem ser negativos.".into()));
    }
    Ok(p)
}

pub fn create(conn: &mut Connection, user: &User, input: ProductInput) -> AppResult<i64> {
    let p = clean(input)?;
    let tx = conn.transaction()?;
    let sku = match opt_text(&p.sku) {
        Some(s) => s.to_uppercase(),
        None => product_repo::next_sku(&tx)?,
    };
    let id = product_repo::insert(&tx, &p, &sku)?;
    product_repo::add_cost_history(&tx, id, p.cost_cents, "Cadastro inicial", user.id)?;
    audit_repo::log(&tx, user, "product.create", "products", id, &sku)?;
    tx.commit()?;
    Ok(id)
}

pub fn update(conn: &mut Connection, user: &User, id: i64, input: ProductInput) -> AppResult<()> {
    let p = clean(input)?;
    let tx = conn.transaction()?;
    let current = product_repo::get(&tx, id)?;
    let sku = opt_text(&p.sku).map(|s| s.to_uppercase()).unwrap_or(current.sku.clone());
    product_repo::update(&tx, id, &p, &sku)?;
    if p.cost_cents != current.cost_cents {
        product_repo::add_cost_history(&tx, id, p.cost_cents, "Alteração manual de custo", user.id)?;
    }
    audit_repo::log(&tx, user, "product.update", "products", id, &sku)?;
    tx.commit()?;
    Ok(())
}

/// Ajuste manual (entrada/saída) com justificativa obrigatória.
pub fn adjust_stock(conn: &mut Connection, user: &User, id: i64, delta: i64, reason: &str) -> AppResult<()> {
    if delta == 0 {
        return Err(AppError::Validation("Informe uma quantidade diferente de zero.".into()));
    }
    let reason = require_text(reason, "Justificativa", 200)?;
    let tx = conn.transaction()?;
    let p = product_repo::get(&tx, id)?;
    if p.stock_qty + delta < p.reserved_qty {
        return Err(AppError::Validation("Estoque ficaria abaixo da quantidade reservada.".into()));
    }
    product_repo::move_stock(&tx, id, "adjustment", delta, None, Some(&reason), None, None, user.id)?;
    audit_repo::log(&tx, user, "product.stock_adjust", "products", id, &format!("{delta:+}: {reason}"))?;
    tx.commit()?;
    Ok(())
}

/// Inventário: informa a contagem física; a diferença vira movimentação.
pub fn count_inventory(conn: &mut Connection, user: &User, id: i64, counted: i64, note: &str) -> AppResult<i64> {
    if counted < 0 {
        return Err(AppError::Validation("Contagem inválida.".into()));
    }
    let tx = conn.transaction()?;
    let p = product_repo::get(&tx, id)?;
    if counted < p.reserved_qty {
        return Err(AppError::Validation("Contagem menor que a quantidade reservada.".into()));
    }
    let diff = counted - p.stock_qty;
    if diff != 0 {
        product_repo::move_stock(&tx, id, "inventory", diff, None, Some(note), None, None, user.id)?;
    }
    audit_repo::log(&tx, user, "product.inventory", "products", id, &format!("contado={counted} diff={diff}"))?;
    tx.commit()?;
    Ok(diff)
}

pub fn reserve(conn: &mut Connection, user: &User, id: i64, delta: i64) -> AppResult<()> {
    let tx = conn.transaction()?;
    let p = product_repo::get(&tx, id)?;
    if delta > 0 && p.available_qty < delta {
        return Err(AppError::Validation("Sem estoque disponível para reservar.".into()));
    }
    if delta < 0 && p.reserved_qty + delta < 0 {
        return Err(AppError::Validation("Reserva insuficiente para liberar.".into()));
    }
    product_repo::reserve(&tx, id, delta, user.id)?;
    audit_repo::log(&tx, user, "product.reserve", "products", id, &delta.to_string())?;
    tx.commit()?;
    Ok(())
}

#[cfg(test)]
pub(crate) mod tests {
    use super::*;
    use crate::testutil::env;

    pub fn pinput(name: &str, cost: i64, price: i64) -> ProductInput {
        ProductInput {
            sku: None, name: name.into(), category: "Eletrônicos".into(), brand: None, model: None,
            serial_number: None, cost_cents: cost, price_cents: price, min_stock: Some(2), active: None, notes: None,
        }
    }

    #[test]
    fn create_generates_sku_and_cost_history() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let id = create(&mut conn, &e.admin, pinput("Smartphone", 145_000, 234_000)).unwrap();
        let p = product_repo::get(&conn, id).unwrap();
        assert!(p.sku.starts_with("SKU-"));
        assert_eq!(product_repo::cost_history(&conn, id).unwrap().len(), 1);
        update(&mut conn, &e.admin, id, pinput("Smartphone", 150_000, 234_000)).unwrap();
        assert_eq!(product_repo::cost_history(&conn, id).unwrap().len(), 2);
    }

    #[test]
    fn stock_adjust_and_status() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let id = create(&mut conn, &e.admin, pinput("Relógio", 1_000, 2_000)).unwrap();
        assert_eq!(product_repo::get(&conn, id).unwrap().status, "out");
        adjust_stock(&mut conn, &e.admin, id, 8, "Entrada inicial").unwrap();
        assert_eq!(product_repo::get(&conn, id).unwrap().status, "available");
        adjust_stock(&mut conn, &e.admin, id, -6, "Perda").unwrap();
        assert_eq!(product_repo::get(&conn, id).unwrap().status, "low");
        assert!(adjust_stock(&mut conn, &e.admin, id, -3, "Erro").is_err());
        assert!(adjust_stock(&mut conn, &e.admin, id, 1, "  ").is_err());
        assert_eq!(product_repo::movements(&conn, id).unwrap().len(), 2);
    }

    #[test]
    fn inventory_count_records_difference() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let id = create(&mut conn, &e.admin, pinput("Violão", 1_000, 2_000)).unwrap();
        adjust_stock(&mut conn, &e.admin, id, 5, "Entrada").unwrap();
        assert_eq!(count_inventory(&mut conn, &e.admin, id, 4, "Contagem").unwrap(), -1);
        assert_eq!(product_repo::get(&conn, id).unwrap().stock_qty, 4);
    }

    #[test]
    fn reserved_cannot_exceed_available() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let id = create(&mut conn, &e.admin, pinput("TV", 1_000, 2_000)).unwrap();
        adjust_stock(&mut conn, &e.admin, id, 3, "Entrada").unwrap();
        reserve(&mut conn, &e.admin, id, 2).unwrap();
        assert!(reserve(&mut conn, &e.admin, id, 2).is_err());
        assert_eq!(product_repo::get(&conn, id).unwrap().available_qty, 1);
        reserve(&mut conn, &e.admin, id, -2).unwrap();
    }
}
