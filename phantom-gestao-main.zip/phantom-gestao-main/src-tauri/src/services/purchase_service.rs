use rusqlite::Connection;
use serde::Deserialize;

use crate::domain::money::{format_brl, round_cents};
use crate::domain::user::User;
use crate::domain::validation::*;
use crate::error::{AppError, AppResult};
use crate::repositories::payment_repo::{self, NewPayment};
use crate::repositories::product_repo::{self, ProductInput};
use crate::repositories::{audit_repo, commerce_repo, settings_repo};
use crate::security::vault::Vault;
use crate::services::payment_service::{self, method_label};
use crate::services::{attachment_service, pdf::Pdf};
use rust_decimal::Decimal;

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PurchaseInput {
    pub seller_client_id: Option<i64>,
    pub seller_name: Option<String>,
    pub seller_document: Option<String>,
    pub product_id: Option<i64>,
    pub product_name: Option<String>,
    pub category: Option<String>,
    pub brand: Option<String>,
    pub model: Option<String>,
    pub serial_number: Option<String>,
    pub sale_price_cents: Option<i64>,
    pub qty: Option<i64>,
    pub amount_cents: i64,
    pub valuation_cents: Option<i64>,
    pub payment_method: String,
    pub confirm: bool,
    pub due_date: Option<String>,
    pub origin_proof: Option<String>,
    pub purchased_at: Option<String>,
    pub notes: Option<String>,
    pub receipt_path: Option<String>,
}

fn unit_cost(total: i64, qty: i64) -> i64 {
    round_cents(Decimal::from(total) / Decimal::from(qty))
}

fn stock_in(tx: &Connection, user: &User, purchase_id: i64, product_id: i64, qty: i64, total: i64) -> AppResult<()> {
    let uc = unit_cost(total, qty);
    product_repo::move_stock(tx, product_id, "purchase", qty, Some(uc), Some("Entrada por compra"), Some("purchase"), Some(purchase_id), user.id)?;
    tx.execute("UPDATE products SET cost_cents = ?2 WHERE id = ?1", (product_id, uc))?;
    product_repo::add_cost_history(tx, product_id, uc, &format!("Compra #{purchase_id}"), user.id)?;
    Ok(())
}

pub fn register(conn: &mut Connection, vault: &Vault, user: &User, i: PurchaseInput) -> AppResult<i64> {
    if payment_service::METHODS.iter().all(|m| *m != i.payment_method) {
        return Err(AppError::Validation("Forma de pagamento inválida.".into()));
    }
    let qty = i.qty.unwrap_or(1);
    if qty <= 0 || i.amount_cents <= 0 {
        return Err(AppError::Validation("Quantidade e valor pago devem ser positivos.".into()));
    }
    if i.valuation_cents.is_some_and(|v| v < 0) {
        return Err(AppError::Validation("Avaliação inválida.".into()));
    }
    let proof = require_text(i.origin_proof.as_deref().unwrap_or(""), "Comprovante de procedência", 300)?;
    let tx = conn.transaction()?;
    let today = settings_repo::today(&tx).to_string();
    let purchased_at = i.purchased_at.clone().unwrap_or(today.clone());
    parse_date(&purchased_at)?;
    if !i.confirm {
        parse_date(i.due_date.as_deref().ok_or_else(|| AppError::Validation("Compras pendentes precisam de vencimento.".into()))?)?;
    }

    // vendedor
    let (seller_client_id, seller_name, seller_doc) = if let Some(cid) = i.seller_client_id {
        let (n, d): (String, String) = tx
            .query_row("SELECT name, document FROM clients WHERE id = ?1", [cid], |r| Ok((r.get(0)?, r.get(1)?)))
            .map_err(|_| AppError::Validation("Vendedor (cliente) não encontrado.".into()))?;
        (Some(cid), n, Some(d))
    } else {
        let n = require_text(i.seller_name.as_deref().unwrap_or(""), "Vendedor", 120)?;
        let d = match opt_text(&i.seller_document) {
            Some(raw) => {
                let dg = digits(&raw);
                if !(is_valid_cpf(&dg) || is_valid_cnpj(&dg)) {
                    return Err(AppError::Validation("CPF/CNPJ do vendedor inválido.".into()));
                }
                Some(dg)
            }
            None => None,
        };
        (None, n, d)
    };

    // produto (existente ou novo)
    let (product_id, product_name, category) = match i.product_id {
        Some(pid) => {
            let p = product_repo::get(&tx, pid)?;
            (pid, p.name, p.category)
        }
        None => {
            let name = require_text(i.product_name.as_deref().unwrap_or(""), "Produto", 120)?;
            let cat = require_text(i.category.as_deref().unwrap_or(""), "Categoria", 60)?;
            let pid = product_repo::insert(
                &tx,
                &ProductInput {
                    sku: None, name: name.clone(), category: cat.clone(), brand: opt_text(&i.brand), model: opt_text(&i.model),
                    serial_number: opt_text(&i.serial_number), cost_cents: unit_cost(i.amount_cents, qty),
                    price_cents: i.sale_price_cents.unwrap_or(0), min_stock: Some(1), active: Some(true), notes: None,
                },
                &product_repo::next_sku(&tx)?,
            )?;
            (pid, name, cat)
        }
    };

    tx.execute(
        "INSERT INTO purchases (seller_client_id, seller_name, seller_document, product_id, product_name, category, qty,
            amount_cents, valuation_cents, payment_method, status, origin_proof, purchased_at, notes, created_by)
         VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15)",
        rusqlite::params![
            seller_client_id, seller_name, seller_doc, product_id, product_name, category, qty, i.amount_cents,
            i.valuation_cents, i.payment_method, if i.confirm { "confirmed" } else { "pending" }, proof, purchased_at,
            opt_text(&i.notes), user.id
        ],
    )?;
    let pur_id = tx.last_insert_rowid();
    let desc = format!("Compra #{pur_id} · {product_name}");
    let pay_id = payment_repo::insert(
        &tx,
        &NewPayment {
            client_id: seller_client_id, party_name: if seller_client_id.is_none() { Some(&seller_name) } else { None },
            direction: "out", origin_type: "purchase", origin_id: Some(pur_id), description: Some(&desc),
            amount_cents: i.amount_cents, method: &i.payment_method, status: if i.confirm { "confirmed" } else { "pending" },
            due_date: if i.confirm { None } else { i.due_date.as_deref() }, paid_at: if i.confirm { Some(&today) } else { None },
            idempotency_key: None, user_id: user.id,
        },
    )?;
    tx.execute("UPDATE purchases SET payment_id = ?2 WHERE id = ?1", (pur_id, pay_id))?;
    if i.confirm {
        payment_repo::insert_cash(&tx, "out", i.amount_cents, &i.payment_method, "Compras", Some(&desc), Some(pay_id), &settings_repo::now_local(&tx), user.id)?;
        stock_in(&tx, user, pur_id, product_id, qty, i.amount_cents)?;
    }
    if let Some(path) = opt_text(&i.receipt_path) {
        attachment_service::add_from_path(&tx, vault, user, "purchase", pur_id, "proof", &path)?;
    }
    audit_repo::log(&tx, user, "purchase.register", "purchases", pur_id, &format!("{product_name} {}", format_brl(i.amount_cents)))?;
    tx.commit()?;
    Ok(pur_id)
}

pub fn confirm(conn: &mut Connection, user: &User, id: i64) -> AppResult<()> {
    let tx = conn.transaction()?;
    let p = commerce_repo::get_purchase(&tx, id)?;
    if p.status != "pending" {
        return Err(AppError::Validation("Apenas compras pendentes podem ser confirmadas.".into()));
    }
    if let Some(pay) = p.payment_id {
        let today = settings_repo::today(&tx).to_string();
        tx.execute(
            "UPDATE payments SET status='confirmed', paid_at=?2, confirmed_by=?3 WHERE id=?1 AND status='pending'",
            rusqlite::params![pay, today, user.id],
        )?;
        payment_repo::insert_cash(&tx, "out", p.amount_cents, &p.payment_method, "Compras", Some(&format!("Compra #{id}")), Some(pay), &settings_repo::now_local(&tx), user.id)?;
    }
    tx.execute("UPDATE purchases SET status='confirmed' WHERE id = ?1", [id])?;
    stock_in(&tx, user, id, p.product_id, p.qty, p.amount_cents)?;
    audit_repo::log(&tx, user, "purchase.confirm", "purchases", id, "")?;
    tx.commit()?;
    Ok(())
}

pub fn cancel(conn: &mut Connection, user: &User, id: i64, reason: &str) -> AppResult<()> {
    let reason = require_text(reason, "Motivo", 200)?;
    let tx = conn.transaction()?;
    let p = commerce_repo::get_purchase(&tx, id)?;
    match p.status.as_str() {
        "cancelled" => return Err(AppError::Validation("Compra já cancelada.".into())),
        "confirmed" => {
            let prod = product_repo::get(&tx, p.product_id)?;
            if prod.available_qty < p.qty {
                return Err(AppError::Validation("Itens já vendidos ou reservados: não é possível cancelar a compra.".into()));
            }
            product_repo::move_stock(&tx, p.product_id, "adjustment", -p.qty, None, Some(&format!("Cancelamento da compra #{id}")), Some("purchase"), Some(id), user.id)?;
            if let Some(pay) = p.payment_id {
                payment_service::reverse_in_tx(&tx, user, pay, &reason, true)?;
            }
        }
        _ => {
            if let Some(pay) = p.payment_id {
                tx.execute("UPDATE payments SET status='reversed', reversal_reason=?2 WHERE id=?1 AND status='pending'", (pay, &reason))?;
            }
        }
    }
    tx.execute("UPDATE purchases SET status='cancelled' WHERE id = ?1", [id])?;
    audit_repo::log(&tx, user, "purchase.cancel", "purchases", id, &reason)?;
    tx.commit()?;
    Ok(())
}

pub fn receipt(conn: &mut Connection, vault: &Vault, user: &User, id: i64) -> AppResult<attachment_service::Attachment> {
    let tx = conn.transaction()?;
    if let Some(a) = attachment_service::list(&tx, "purchase", id, Some("receipt"))?.into_iter().next() {
        return Ok(a);
    }
    let p = commerce_repo::get_purchase(&tx, id)?;
    if p.status != "confirmed" {
        return Err(AppError::Validation("Comprovante disponível apenas para compras confirmadas.".into()));
    }
    let (company, cnpj) = payment_service::company_header(&tx);
    let mut pdf = Pdf::new(&format!("Comprovante de compra #{id}"));
    pdf.heading(&company);
    if !cnpj.is_empty() {
        pdf.paragraph(&format!("CNPJ {cnpj}"), 9.0, false);
    }
    pdf.space(8.0);
    pdf.heading(&format!("COMPROVANTE DE COMPRA #{id}"));
    pdf.rule();
    pdf.key_value("Vendedor", &p.seller_name);
    if let Some(d) = &p.seller_document {
        pdf.key_value("Documento", &format_document(d));
    }
    pdf.key_value("Produto", &p.product_name);
    pdf.key_value("Categoria", &p.category);
    pdf.key_value("Quantidade", &p.qty.to_string());
    pdf.key_value("Valor pago", &format_brl(p.amount_cents));
    if let Some(v) = p.valuation_cents {
        pdf.key_value("Avaliação", &format_brl(v));
    }
    pdf.key_value("Forma de pagamento", method_label(&p.payment_method));
    pdf.key_value("Data da aquisição", &crate::domain::money::br_date(&p.purchased_at));
    pdf.key_value("Procedência", p.origin_proof.as_deref().unwrap_or("—"));
    pdf.space(30.0);
    pdf.columns(&["____________________________________", "____________________________________"], 9.0);
    pdf.columns(&["Vendedor", "Responsável pela compra"], 8.0);
    let a = attachment_service::add_bytes(&tx, vault, user, "purchase", id, "receipt", &format!("compra_{id}.pdf"), &pdf.finish())?;
    tx.commit()?;
    Ok(a)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::repositories::PageQuery;
    use crate::testutil::env;

    pub fn pur(name: &str, total: i64, qty: i64, confirm: bool) -> PurchaseInput {
        PurchaseInput {
            seller_client_id: None, seller_name: Some("Loja Ágil".into()), seller_document: None, product_id: None,
            product_name: Some(name.into()), category: Some("Eletrônicos".into()), brand: None, model: None,
            serial_number: None, sale_price_cents: Some(300_000), qty: Some(qty), amount_cents: total,
            valuation_cents: None, payment_method: "pix".into(), confirm, due_date: Some("2099-01-01".into()),
            origin_proof: Some("Nota fiscal 123".into()), purchased_at: None, notes: None, receipt_path: None,
        }
    }

    #[test]
    fn confirmed_purchase_enters_stock_and_pays_out() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let id = register(&mut conn, &e.vault, &e.admin, pur("Notebook", 400_000, 2, true)).unwrap();
        let p = commerce_repo::get_purchase(&conn, id).unwrap();
        let prod = product_repo::get(&conn, p.product_id).unwrap();
        assert_eq!((prod.stock_qty, prod.cost_cents), (2, 200_000));
        assert_eq!(payment_repo::cash_summary(&conn).unwrap().balance_cents, -400_000);
        assert_eq!(product_repo::cost_history(&conn, prod.id).unwrap().len(), 1);
    }

    #[test]
    fn pending_purchase_waits_for_confirmation() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let id = register(&mut conn, &e.vault, &e.admin, pur("Violão", 80_000, 1, false)).unwrap();
        let p = commerce_repo::get_purchase(&conn, id).unwrap();
        assert_eq!(product_repo::get(&conn, p.product_id).unwrap().stock_qty, 0);
        assert_eq!(payment_repo::cash_summary(&conn).unwrap().balance_cents, 0);
        confirm(&mut conn, &e.admin, id).unwrap();
        assert_eq!(product_repo::get(&conn, p.product_id).unwrap().stock_qty, 1);
        assert_eq!(payment_repo::cash_summary(&conn).unwrap().balance_cents, -80_000);
        assert!(confirm(&mut conn, &e.admin, id).is_err());
    }

    #[test]
    fn requires_origin_proof_and_valid_seller_document() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let mut a = pur("X", 100, 1, true);
        a.origin_proof = None;
        assert!(register(&mut conn, &e.vault, &e.admin, a).is_err());
        let mut b = pur("X", 100, 1, true);
        b.seller_document = Some("123.456.789-00".into());
        assert!(register(&mut conn, &e.vault, &e.admin, b).is_err());
    }

    #[test]
    fn cancel_reverses_stock_and_payment() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let id = register(&mut conn, &e.vault, &e.admin, pur("TV", 250_000, 1, true)).unwrap();
        let pid = commerce_repo::get_purchase(&conn, id).unwrap().product_id;
        cancel(&mut conn, &e.admin, id, "Desistência").unwrap();
        assert_eq!(product_repo::get(&conn, pid).unwrap().stock_qty, 0);
        assert_eq!(payment_repo::cash_summary(&conn).unwrap().balance_cents, 0);
        assert!(cancel(&mut conn, &e.admin, id, "x").is_err());
        let q = PageQuery { status: Some("cancelled".into()), ..Default::default() };
        assert_eq!(commerce_repo::list_purchases(&conn, &q).unwrap().total, 1);
    }

    #[test]
    fn receipt_pdf_for_confirmed_only() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let pend = register(&mut conn, &e.vault, &e.admin, pur("A", 100, 1, false)).unwrap();
        assert!(receipt(&mut conn, &e.vault, &e.admin, pend).is_err());
        let ok = register(&mut conn, &e.vault, &e.admin, pur("B", 100, 1, true)).unwrap();
        assert!(receipt(&mut conn, &e.vault, &e.admin, ok).is_ok());
    }
}
