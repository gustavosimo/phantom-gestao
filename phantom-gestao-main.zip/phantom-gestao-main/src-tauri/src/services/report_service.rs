use chrono::NaiveDate;
use rusqlite::Connection;
use serde::{Deserialize, Serialize};

use crate::domain::money::{format_bp, format_brl};
use crate::domain::user::User;
use crate::error::{AppError, AppResult};
use crate::repositories::{audit_repo, settings_repo};
use crate::security::vault::Vault;
use crate::services::dashboard_service::{resolve, series, Period, SeriesPoint};
use crate::services::pdf::Pdf;
use crate::services::payment_service;

fn q1(conn: &Connection, sql: &str, p: impl rusqlite::Params) -> AppResult<i64> {
    // datas gravadas em UTC (created_at) são convertidas para o fuso configurado
    let off = settings_repo::get_i64(conn, "regional.tz_offset_hours", -3)?;
    let sql = sql.replace("{OFF}", &format!("{off:+} hours"));
    Ok(conn.query_row(&sql, p, |r| r.get::<_, Option<i64>>(0))?.unwrap_or(0))
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Kpi {
    pub value: i64,
    pub previous: i64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct OpShare {
    pub label: String,
    pub count: i64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Overview {
    pub from: String,
    pub to: String,
    pub revenue: Kpi,
    pub new_contracts: Kpi,
    pub avg_ticket_cents: Kpi,
    /// inadimplência em centésimos de ponto percentual (320 = 3,20%)
    pub delinquency_bp: Kpi,
    pub revenue_series: Vec<SeriesPoint>,
    pub operations: Vec<OpShare>,
}

/// Receita = juros e encargos recebidos de empréstimos + margem bruta das vendas no período.
fn revenue(conn: &Connection, from: &str, to: &str) -> AppResult<i64> {
    let interest = q1(
        conn,
        "SELECT SUM(a.interest_cents + a.fee_cents + (a.principal_cents * i.interest_cents / i.amount_cents))
         FROM payment_allocations a JOIN payments p ON p.id = a.payment_id JOIN loan_installments i ON i.id = a.installment_id
         WHERE p.status = 'confirmed' AND p.paid_at BETWEEN ?1 AND ?2",
        (from, to),
    )?;
    let margin = q1(
        conn,
        "SELECT SUM((it.unit_price_cents - it.unit_cost_cents) * (it.qty - it.returned_qty)) FROM sale_items it JOIN sales s ON s.id = it.sale_id
         WHERE s.status <> 'cancelled' AND date(s.created_at,'{OFF}') BETWEEN ?1 AND ?2",
        (from, to),
    )?;
    Ok(interest + margin)
}

fn delinquency(conn: &Connection, today: &str) -> AppResult<i64> {
    let open = q1(conn, "SELECT SUM(i.amount_cents - i.paid_cents) FROM loan_installments i JOIN loans l ON l.id=i.loan_id WHERE i.status IN ('open','partial') AND l.status='active'", [])?;
    let late = q1(conn, "SELECT SUM(i.amount_cents - i.paid_cents) FROM loan_installments i JOIN loans l ON l.id=i.loan_id WHERE i.status IN ('open','partial') AND l.status='active' AND i.due_date < ?1", [today])?;
    Ok(if open == 0 { 0 } else { late * 10_000 / open })
}

pub fn overview(conn: &Connection, p: &Period) -> AppResult<Overview> {
    let (from, to) = resolve(conn, p)?;
    let len = (to - from).num_days() + 1;
    let (pf, pt) = (from - chrono::Duration::days(len), from - chrono::Duration::days(1));
    let (f, t, pfs, pts) = (from.to_string(), to.to_string(), pf.to_string(), pt.to_string());
    let today = settings_repo::today(conn).to_string();
    let contracts = |a: &str, b: &str| q1(conn, "SELECT COUNT(*) FROM loans WHERE contracted_at BETWEEN ?1 AND ?2", (a, b));
    let ticket = |a: &str, b: &str| q1(conn, "SELECT CAST(AVG(principal_cents) AS INTEGER) FROM loans WHERE contracted_at BETWEEN ?1 AND ?2", (a, b));
    let ops = |sql: &str| q1(conn, sql, (&f, &t));
    let operations = vec![
        OpShare { label: "Empréstimos".into(), count: ops("SELECT COUNT(*) FROM loans WHERE contracted_at BETWEEN ?1 AND ?2")? },
        OpShare { label: "Vendas".into(), count: ops("SELECT COUNT(*) FROM sales WHERE status <> 'cancelled' AND date(created_at,'{OFF}') BETWEEN ?1 AND ?2")? },
        OpShare { label: "Garantias".into(), count: ops("SELECT COUNT(*) FROM collateral_assets WHERE date(created_at,'{OFF}') BETWEEN ?1 AND ?2")? },
        OpShare { label: "Compras".into(), count: ops("SELECT COUNT(*) FROM purchases WHERE status <> 'cancelled' AND purchased_at BETWEEN ?1 AND ?2")? },
    ];
    let monthly = (to - from).num_days() > 31;
    Ok(Overview {
        from: f.clone(),
        to: t.clone(),
        revenue: Kpi { value: revenue(conn, &f, &t)?, previous: revenue(conn, &pfs, &pts)? },
        new_contracts: Kpi { value: contracts(&f, &t)?, previous: contracts(&pfs, &pts)? },
        avg_ticket_cents: Kpi { value: ticket(&f, &t)?, previous: ticket(&pfs, &pts)? },
        delinquency_bp: Kpi { value: delinquency(conn, &today)?, previous: 0 },
        revenue_series: series(conn, from, to, monthly)?,
        operations,
    })
}

// ------------------------------------------------------------------ relatórios

pub struct ReportData {
    pub title: String,
    pub columns: Vec<String>,
    pub rows: Vec<Vec<String>>,
    pub summary: Vec<(String, String)>,
}

pub const REPORT_TYPES: [(&str, &str); 11] = [
    ("loans", "Empréstimos"),
    ("installments", "Parcelas"),
    ("delinquency", "Inadimplência por cliente"),
    ("collateral", "Garantias"),
    ("stock", "Estoque"),
    ("purchases", "Compras"),
    ("sales", "Vendas"),
    ("receipts", "Recebimentos"),
    ("expenses", "Despesas"),
    ("cashflow", "Fluxo de caixa"),
    ("profitability", "Lucratividade"),
];

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ReportType {
    pub code: String,
    pub label: String,
}

pub fn types() -> Vec<ReportType> {
    REPORT_TYPES.iter().map(|(c, l)| ReportType { code: (*c).into(), label: (*l).into() }).collect()
}

fn rows_of(conn: &Connection, sql: &str, p: impl rusqlite::Params, n: usize) -> AppResult<Vec<Vec<String>>> {
    let off = settings_repo::get_i64(conn, "regional.tz_offset_hours", -3)?;
    let sql = sql.replace("{OFF}", &format!("{off:+} hours"));
    let mut stmt = conn.prepare(&sql)?;
    let rows = stmt
        .query_map(p, |r| {
            let mut v = Vec::with_capacity(n);
            for i in 0..n {
                let val: rusqlite::types::Value = r.get(i)?;
                v.push(match val {
                    rusqlite::types::Value::Null => "—".into(),
                    rusqlite::types::Value::Integer(i) => i.to_string(),
                    rusqlite::types::Value::Real(f) => f.to_string(),
                    rusqlite::types::Value::Text(s) => crate::domain::money::br_date(&s),
                    rusqlite::types::Value::Blob(_) => "—".into(),
                });
            }
            Ok(v)
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

/// Converte as colunas indicadas (centavos) para "R$ 0,00".
fn money_cols(rows: &mut [Vec<String>], cols: &[usize]) {
    for r in rows.iter_mut() {
        for c in cols {
            if let Ok(v) = r[*c].parse::<i64>() {
                r[*c] = format_brl(v);
            }
        }
    }
}

fn sum_col(rows: &[Vec<String>], c: usize) -> i64 {
    rows.iter().filter_map(|r| r[c].parse::<i64>().ok()).sum()
}

pub fn build(conn: &Connection, code: &str, from: NaiveDate, to: NaiveDate) -> AppResult<ReportData> {
    let (f, t) = (from.to_string(), to.to_string());
    let today = settings_repo::today(conn).to_string();
    let d = |cols: &[&str]| cols.iter().map(|s| s.to_string()).collect::<Vec<_>>();
    let (title, columns, rows, summary): (&str, Vec<String>, Vec<Vec<String>>, Vec<(String, String)>) = match code {
        "loans" => {
            let mut rows = rows_of(conn, "SELECT '#' || l.id, c.name, l.principal_cents, l.term_months, l.rate_bp, l.contracted_at, l.status,
                COALESCE((SELECT SUM(i.amount_cents - i.paid_cents) FROM loan_installments i WHERE i.loan_id=l.id AND i.status IN ('open','partial')),0)
                FROM loans l JOIN clients c ON c.id=l.client_id WHERE l.contracted_at BETWEEN ?1 AND ?2 ORDER BY l.id", (&f, &t), 8)?;
            let (p, s, n) = (sum_col(&rows, 2), sum_col(&rows, 7), rows.len());
            for r in rows.iter_mut() {
                r[4] = format!("{}% a.m.", format_bp(r[4].parse().unwrap_or(0)));
            }
            money_cols(&mut rows, &[2, 7]);
            ("Relatório de Empréstimos", d(&["Contrato", "Cliente", "Valor", "Parcelas", "Taxa", "Contratação", "Status", "Saldo devedor"]), rows,
                vec![("Contratos".into(), n.to_string()), ("Total emprestado".into(), format_brl(p)), ("Saldo devedor".into(), format_brl(s))])
        }
        "installments" => {
            let mut rows = rows_of(conn, "SELECT '#' || l.id, c.name, i.number, i.due_date, i.amount_cents, i.paid_cents, i.status
                FROM loan_installments i JOIN loans l ON l.id=i.loan_id JOIN clients c ON c.id=l.client_id
                WHERE i.status <> 'renegotiated' AND i.due_date BETWEEN ?1 AND ?2 ORDER BY i.due_date, i.id", (&f, &t), 7)?;
            let (a, p) = (sum_col(&rows, 4), sum_col(&rows, 5));
            money_cols(&mut rows, &[4, 5]);
            ("Relatório de Parcelas", d(&["Contrato", "Cliente", "Parcela", "Vencimento", "Valor", "Pago", "Status"]), rows,
                vec![("Previsto".into(), format_brl(a)), ("Recebido".into(), format_brl(p))])
        }
        "delinquency" => {
            let mut rows = rows_of(conn, "SELECT c.name, COUNT(*), SUM(i.amount_cents - i.paid_cents), MIN(i.due_date), CAST(julianday(?1) - julianday(MIN(i.due_date)) AS INTEGER)
                FROM loan_installments i JOIN loans l ON l.id=i.loan_id JOIN clients c ON c.id=l.client_id
                WHERE i.status IN ('open','partial') AND l.status='active' AND i.due_date < ?1 GROUP BY c.id ORDER BY 3 DESC", [&today], 5)?;
            let s = sum_col(&rows, 2);
            money_cols(&mut rows, &[2]);
            ("Inadimplência por Cliente", d(&["Cliente", "Parcelas em atraso", "Valor em atraso", "Venc. mais antigo", "Dias de atraso"]), rows,
                vec![("Total em atraso".into(), format_brl(s))])
        }
        "collateral" => {
            let mut rows = rows_of(conn, "SELECT 'GAR-' || printf('%04d', a.id), a.name, c.name, a.category, a.appraised_cents, a.custody_due, a.status
                FROM collateral_assets a JOIN clients c ON c.id=a.client_id WHERE date(a.created_at,'{OFF}') BETWEEN ?1 AND ?2 ORDER BY a.id", (&f, &t), 7)?;
            let s = sum_col(&rows, 4);
            money_cols(&mut rows, &[4]);
            ("Relatório de Garantias", d(&["Código", "Bem", "Cliente", "Categoria", "Avaliação", "Prazo", "Status"]), rows, vec![("Total avaliado".into(), format_brl(s))])
        }
        "stock" => {
            let mut rows = rows_of(conn, "SELECT sku, name, category, stock_qty, reserved_qty, cost_cents, price_cents, stock_qty * cost_cents FROM products WHERE active = 1 ORDER BY name", [], 8)?;
            let (q, v) = (sum_col(&rows, 3), sum_col(&rows, 7));
            money_cols(&mut rows, &[5, 6, 7]);
            ("Posição de Estoque", d(&["Código", "Produto", "Categoria", "Qtd", "Reservado", "Custo", "Preço", "Valor em estoque"]), rows,
                vec![("Itens em estoque".into(), q.to_string()), ("Valor total (custo)".into(), format_brl(v))])
        }
        "purchases" => {
            let mut rows = rows_of(conn, "SELECT 'COM-' || printf('%04d', id), purchased_at, seller_name, product_name, qty, amount_cents, payment_method, status
                FROM purchases WHERE purchased_at BETWEEN ?1 AND ?2 ORDER BY id", (&f, &t), 8)?;
            let s: i64 = rows.iter().filter(|r| r[7] != "cancelled").filter_map(|r| r[5].parse::<i64>().ok()).sum();
            money_cols(&mut rows, &[5]);
            ("Relatório de Compras", d(&["Código", "Data", "Vendedor", "Produto", "Qtd", "Valor", "Pagamento", "Status"]), rows, vec![("Total comprado".into(), format_brl(s))])
        }
        "sales" => {
            let mut rows = rows_of(conn, "SELECT 'VEN-' || printf('%03d', s.id), date(s.created_at,'{OFF}'), COALESCE(c.name,'Consumidor final'), s.subtotal_cents, s.discount_cents, s.total_cents, s.payment_method, s.status
                FROM sales s LEFT JOIN clients c ON c.id=s.client_id WHERE date(s.created_at,'{OFF}') BETWEEN ?1 AND ?2 ORDER BY s.id", (&f, &t), 8)?;
            let s: i64 = rows.iter().filter(|r| r[7] != "cancelled").filter_map(|r| r[5].parse::<i64>().ok()).sum();
            money_cols(&mut rows, &[3, 4, 5]);
            ("Relatório de Vendas", d(&["Código", "Data", "Cliente", "Subtotal", "Desconto", "Total", "Pagamento", "Status"]), rows, vec![("Total vendido (exclui canceladas)".into(), format_brl(s))])
        }
        "receipts" => {
            let mut rows = rows_of(conn, "SELECT 'PAG-' || printf('%04d', p.id), p.paid_at, COALESCE(c.name,p.party_name,'—'), p.origin_type, p.amount_cents, p.method
                FROM payments p LEFT JOIN clients c ON c.id=p.client_id WHERE p.direction='in' AND p.status='confirmed' AND p.paid_at BETWEEN ?1 AND ?2 ORDER BY p.paid_at, p.id", (&f, &t), 6)?;
            let s = sum_col(&rows, 4);
            money_cols(&mut rows, &[4]);
            ("Relatório de Recebimentos", d(&["ID", "Data", "Cliente", "Origem", "Valor", "Forma"]), rows, vec![("Total recebido".into(), format_brl(s))])
        }
        "expenses" => {
            let mut rows = rows_of(conn, "SELECT 'PAG-' || printf('%04d', p.id), COALESCE(p.paid_at, p.due_date), COALESCE(c.name,p.party_name,'—'), p.origin_type, COALESCE(p.description,'—'), p.amount_cents, p.status
                FROM payments p LEFT JOIN clients c ON c.id=p.client_id WHERE p.direction='out' AND p.status IN ('confirmed','pending') AND p.origin_type IN ('payable','other','purchase')
                AND COALESCE(p.paid_at, p.due_date) BETWEEN ?1 AND ?2 ORDER BY 2", (&f, &t), 7)?;
            let s = sum_col(&rows, 5);
            money_cols(&mut rows, &[5]);
            ("Relatório de Despesas", d(&["ID", "Data", "Favorecido", "Origem", "Descrição", "Valor", "Status"]), rows, vec![("Total de despesas".into(), format_brl(s))])
        }
        "cashflow" => {
            let mut rows = rows_of(conn, "SELECT substr(occurred_at,1,10), SUM(CASE WHEN kind='in' THEN amount_cents ELSE 0 END), SUM(CASE WHEN kind='out' THEN amount_cents ELSE 0 END),
                SUM(CASE WHEN kind='in' THEN amount_cents ELSE -amount_cents END) FROM cash_movements WHERE substr(occurred_at,1,10) BETWEEN ?1 AND ?2 GROUP BY 1 ORDER BY 1", (&f, &t), 4)?;
            let (i, o) = (sum_col(&rows, 1), sum_col(&rows, 2));
            money_cols(&mut rows, &[1, 2, 3]);
            ("Fluxo de Caixa", d(&["Data", "Entradas", "Saídas", "Saldo do dia"]), rows,
                vec![("Entradas".into(), format_brl(i)), ("Saídas".into(), format_brl(o)), ("Resultado".into(), format_brl(i - o))])
        }
        "profitability" => {
            let interest = revenue(conn, &f, &t)?;
            let margin = q1(conn, "SELECT SUM((it.unit_price_cents - it.unit_cost_cents) * (it.qty - it.returned_qty)) FROM sale_items it JOIN sales s ON s.id=it.sale_id WHERE s.status <> 'cancelled' AND date(s.created_at,'{OFF}') BETWEEN ?1 AND ?2", (&f, &t))?;
            let expenses = q1(conn, "SELECT SUM(amount_cents) FROM payments WHERE direction='out' AND status='confirmed' AND origin_type IN ('payable','other') AND paid_at BETWEEN ?1 AND ?2", (&f, &t))?;
            let rows = vec![
                vec!["Juros e encargos recebidos".into(), format_brl(interest - margin)],
                vec!["Margem bruta de vendas".into(), format_brl(margin)],
                vec!["(-) Despesas pagas".into(), format_brl(expenses)],
                vec!["Resultado do período".into(), format_brl(interest - expenses)],
            ];
            ("Lucratividade", d(&["Item", "Valor"]), rows, vec![])
        }
        _ => return Err(AppError::Validation("Tipo de relatório inválido.".into())),
    };
    Ok(ReportData { title: title.into(), columns, rows, summary })
}

pub fn to_csv(r: &ReportData) -> String {
    let esc = |s: &str| {
        let safe = if s.starts_with(['=', '+', '-', '@']) && s.len() > 1 && !s.starts_with("-R$") { format!("'{s}") } else { s.to_string() };
        if safe.contains([';', '"', '\n']) { format!("\"{}\"", safe.replace('"', "\"\"")) } else { safe }
    };
    let mut out = String::from("\u{feff}");
    out.push_str(&r.columns.iter().map(|c| esc(c)).collect::<Vec<_>>().join(";"));
    out.push_str("\r\n");
    for row in &r.rows {
        out.push_str(&row.iter().map(|c| esc(c)).collect::<Vec<_>>().join(";"));
        out.push_str("\r\n");
    }
    for (k, v) in &r.summary {
        out.push_str(&format!("{};{}\r\n", esc(k), esc(v)));
    }
    out
}

pub fn to_pdf(conn: &Connection, r: &ReportData, period: &str) -> Vec<u8> {
    let (company, _) = payment_service::company_header(conn);
    let mut pdf = Pdf::new(&r.title);
    pdf.heading(&format!("{company} — {}", r.title));
    pdf.paragraph(&format!("Período: {period}"), 9.0, false);
    pdf.space(6.0);
    for (k, v) in &r.summary {
        pdf.key_value(k, v);
    }
    pdf.space(8.0);
    let cols: Vec<&str> = r.columns.iter().map(|s| s.as_str()).collect();
    let weights = vec![1.0; cols.len()];
    pdf.table(&cols, &r.rows, &weights);
    pdf.finish()
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ExportInput {
    pub report_type: String,
    pub period: Period,
    /// pdf | csv
    pub format: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct GeneratedReport {
    pub id: i64,
    pub title: String,
    pub period_label: String,
    pub format: String,
    pub attachment_id: i64,
    pub file_name: String,
    pub created_at: String,
}

pub fn export(conn: &mut Connection, vault: &Vault, user: &User, i: ExportInput) -> AppResult<GeneratedReport> {
    if !matches!(i.format.as_str(), "pdf" | "csv") {
        return Err(AppError::Validation("Formato inválido (PDF ou CSV).".into()));
    }
    let (from, to) = resolve(conn, &i.period)?;
    let data = build(conn, &i.report_type, from, to)?;
    let label = format!("{} a {}", from, to);
    let bytes = if i.format == "pdf" { to_pdf(conn, &data, &label) } else { to_csv(&data).into_bytes() };
    let tx = conn.transaction()?;
    let today = settings_repo::today(&tx);
    let file_name = format!("{}_{}.{}", i.report_type, today.format("%Y%m%d"), i.format);
    // CSV não é um formato aceito por anexos de documentos; relatórios usam extensão própria no cofre
    let att = add_report_bytes(&tx, vault, user, &file_name, &i.format, &bytes)?;
    tx.execute(
        "INSERT INTO generated_reports (report_type, title, period_label, format, attachment_id, created_by) VALUES (?1,?2,?3,?4,?5,?6)",
        rusqlite::params![i.report_type, data.title, label, i.format, att, user.id],
    )?;
    let id = tx.last_insert_rowid();
    audit_repo::log(&tx, user, "report.export", "generated_reports", id, &format!("{} {}", data.title, i.format))?;
    let created: String = tx.query_row("SELECT created_at FROM generated_reports WHERE id=?1", [id], |r| r.get(0))?;
    tx.commit()?;
    Ok(GeneratedReport { id, title: data.title, period_label: label, format: i.format, attachment_id: att, file_name, created_at: created })
}

pub(crate) fn add_report_bytes(conn: &Connection, vault: &Vault, user: &User, name: &str, format: &str, bytes: &[u8]) -> AppResult<i64> {
    let stored = vault.store(bytes)?;
    let mime = if format == "pdf" { "application/pdf" } else { "text/csv" };
    conn.execute(
        "INSERT INTO attachments (owner_type, owner_id, kind, original_name, stored_name, mime, size_bytes, created_by) VALUES ('report',0,'report',?1,?2,?3,?4,?5)",
        rusqlite::params![name, stored, mime, bytes.len() as i64, user.id],
    )?;
    let id = conn.last_insert_rowid();
    if crate::services::attachment_service::is_branded_pdf(bytes) {
        conn.execute("UPDATE attachments SET layout = 2 WHERE id = ?1", [id])?;
    }
    Ok(id)
}

pub fn generated(conn: &Connection, limit: i64) -> AppResult<Vec<GeneratedReport>> {
    let mut stmt = conn.prepare(
        "SELECT g.id, g.title, g.period_label, g.format, g.attachment_id, a.original_name, g.created_at FROM generated_reports g
         JOIN attachments a ON a.id = g.attachment_id ORDER BY g.id DESC LIMIT ?1",
    )?;
    let rows = stmt
        .query_map([limit], |r| {
            Ok(GeneratedReport { id: r.get(0)?, title: r.get(1)?, period_label: r.get(2)?, format: r.get(3)?, attachment_id: r.get(4)?, file_name: r.get(5)?, created_at: r.get(6)? })
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

/// Pré-visualização na tela (limitada).
pub fn preview(conn: &Connection, code: &str, p: &Period) -> AppResult<serde_json::Value> {
    let (from, to) = resolve(conn, p)?;
    let d = build(conn, code, from, to)?;
    let total = d.rows.len();
    Ok(serde_json::json!({
        "title": d.title, "columns": d.columns, "rows": d.rows.into_iter().take(200).collect::<Vec<_>>(),
        "summary": d.summary, "total": total
    }))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::repositories::loan_repo;
    use crate::services::attachment_service;
    use crate::services::loan_service::tests::*;
    use crate::testutil::env;

    fn p() -> Period {
        Period { kind: "30d".into(), from: None, to: None }
    }

    #[test]
    fn all_eleven_reports_build_on_empty_and_populated_data() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let (from, to) = resolve(&conn, &p()).unwrap();
        for (code, _) in REPORT_TYPES {
            let r = build(&conn, code, from, to).unwrap();
            assert!(!r.columns.is_empty(), "{code}");
        }
        let c = new_client(&mut conn, &e, "Mariana Souza", "529.982.247-25");
        let loan = active_loan(&mut conn, &e, c, 1_000_000, 4);
        let inst = loan_repo::installments(&conn, loan, false).unwrap()[0].clone();
        payment_service::pay_installment(&mut conn, &e.admin, inst.id, inst.amount_cents, "pix", None).unwrap();
        for (code, _) in REPORT_TYPES {
            build(&conn, code, from, to).unwrap();
        }
        let loans = build(&conn, "loans", from, to).unwrap();
        assert_eq!(loans.rows.len(), 1);
        assert!(loans.rows[0][2].starts_with("R$ 10.000,00"));
        assert!(build(&conn, "nope", from, to).is_err());
    }

    #[test]
    fn overview_revenue_counts_interest_only() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let c = new_client(&mut conn, &e, "Mariana Souza", "529.982.247-25");
        let loan = active_loan(&mut conn, &e, c, 1_000_000, 4);
        let insts = loan_repo::installments(&conn, loan, false).unwrap();
        payment_service::pay_installment(&mut conn, &e.admin, insts[0].id, insts[0].amount_cents, "pix", None).unwrap();
        let o = overview(&conn, &p()).unwrap();
        // principal devolvido não é receita: apenas a parcela de juros embutida
        assert_eq!(o.revenue.value, insts[0].interest_cents);
        assert_eq!(o.new_contracts.value, 1);
        assert_eq!(o.avg_ticket_cents.value, 1_000_000);
        assert_eq!(o.operations[0].count, 1);
    }

    #[test]
    fn csv_escapes_formulas_and_separators() {
        let r = ReportData {
            title: "t".into(), columns: vec!["a".into(), "b".into()],
            rows: vec![vec!["=SOMA(A1)".into(), "x;y".into()], vec!["-R$ 5,00".into(), "ok".into()]], summary: vec![],
        };
        let csv = to_csv(&r);
        assert!(csv.starts_with('\u{feff}'));
        assert!(csv.contains("'=SOMA(A1);\"x;y\""));
        assert!(csv.contains("-R$ 5,00;ok"));
    }

    #[test]
    fn export_stores_encrypted_file_and_lists_it() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        for fmt in ["pdf", "csv"] {
            let g = export(&mut conn, &e.vault, &e.admin, ExportInput { report_type: "cashflow".into(), period: p(), format: fmt.into() }).unwrap();
            let (_, bytes) = attachment_service::read(&conn, &e.vault, g.attachment_id).unwrap();
            if fmt == "pdf" { assert!(bytes.starts_with(b"%PDF")) } else { assert!(bytes.starts_with("\u{feff}".as_bytes())) }
        }
        assert_eq!(generated(&conn, 10).unwrap().len(), 2);
        assert!(export(&mut conn, &e.vault, &e.admin, ExportInput { report_type: "cashflow".into(), period: p(), format: "xlsx".into() }).is_err());
    }
}
