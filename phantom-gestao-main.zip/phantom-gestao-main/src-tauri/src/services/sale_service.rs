use std::collections::HashMap;

use rusqlite::Connection;
use serde::{Deserialize, Serialize};

use crate::domain::money::{format_brl, round_cents};
use crate::domain::user::User;
use crate::domain::validation::require_text;
use crate::error::{AppError, AppResult};
use crate::repositories::payment_repo::{self, NewPayment};
use crate::repositories::{audit_repo, commerce_repo, product_repo, settings_repo};
use crate::security::vault::Vault;
use crate::services::payment_service::{self, method_label};
use crate::services::{attachment_service, pdf::Pdf};
use rust_decimal::Decimal;

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaleItemInput {
    pub product_id: i64,
    pub qty: i64,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaleInput {
    pub client_id: Option<i64>,
    pub items: Vec<SaleItemInput>,
    pub discount_cents: i64,
    pub payment_method: String,
    pub idempotency_key: Option<String>,
}

fn has(user: &User, perm: &str) -> bool {
    user.permissions.iter().any(|p| p == perm)
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SaleResult {
    pub id: i64,
    pub code: String,
}

/// Finalização de venda: preços e custos vêm sempre do banco; estoque, pagamento e caixa
/// são atualizados na mesma transação.
pub fn create(conn: &mut Connection, user: &User, input: SaleInput) -> AppResult<SaleResult> {
    if payment_service::METHODS.iter().all(|m| *m != input.payment_method) {
        return Err(AppError::Validation("Forma de pagamento inválida.".into()));
    }
    if input.items.is_empty() {
        return Err(AppError::Validation("Adicione ao menos um produto ao carrinho.".into()));
    }
    if input.discount_cents < 0 {
        return Err(AppError::Validation("Desconto inválido.".into()));
    }
    let tx = conn.transaction()?;
    if let Some(k) = &input.idempotency_key {
        if let Some(pid) = payment_repo::find_by_key(&tx, k)? {
            let sale_id: i64 = tx.query_row("SELECT origin_id FROM payments WHERE id = ?1", [pid], |r| r.get(0))?;
            return Ok(SaleResult { id: sale_id, code: format!("VEN-{:03}", sale_id) });
        }
    }
    // consolida quantidades por produto
    let mut wanted: Vec<(i64, i64)> = vec![];
    let mut seen: HashMap<i64, usize> = HashMap::new();
    for it in &input.items {
        if it.qty <= 0 {
            return Err(AppError::Validation("Quantidade inválida no carrinho.".into()));
        }
        match seen.get(&it.product_id) {
            Some(i) => wanted[*i].1 += it.qty,
            None => {
                seen.insert(it.product_id, wanted.len());
                wanted.push((it.product_id, it.qty));
            }
        }
    }
    let mut lines = vec![];
    let mut subtotal = 0i64;
    for (pid, qty) in &wanted {
        let p = product_repo::get(&tx, *pid)?;
        if !p.active {
            return Err(AppError::Validation(format!("Produto inativo: {}.", p.name)));
        }
        if p.available_qty < *qty {
            return Err(AppError::Validation(format!("Estoque insuficiente de {} (disponível: {}).", p.name, p.available_qty)));
        }
        subtotal += p.price_cents * qty;
        lines.push((p, *qty));
    }
    if input.discount_cents > subtotal {
        return Err(AppError::Validation("Desconto maior que o subtotal.".into()));
    }
    let max_pct = settings_repo::get_i64(&tx, "sales.max_discount_pct", 10)?;
    let max_discount = round_cents(Decimal::from(subtotal) * Decimal::from(max_pct) / Decimal::from(100));
    if input.discount_cents > max_discount && !has(user, "sales.discount") {
        return Err(AppError::Validation(format!(
            "Desconto acima do limite de {max_pct}% ({}). Requer autorização de gerente.",
            format_brl(max_discount)
        )));
    }
    let total = subtotal - input.discount_cents;
    if let Some(cid) = input.client_id {
        let status: Option<String> = tx.query_row("SELECT status FROM clients WHERE id = ?1", [cid], |r| r.get(0)).ok();
        match status.as_deref() {
            None => return Err(AppError::Validation("Cliente não encontrado.".into())),
            Some("inactive") => return Err(AppError::Validation("Cliente inativo.".into())),
            _ => {}
        }
    }
    tx.execute(
        "INSERT INTO sales (client_id, subtotal_cents, discount_cents, total_cents, payment_method, status, created_by)
         VALUES (?1,?2,?3,?4,?5,'completed',?6)",
        rusqlite::params![input.client_id, subtotal, input.discount_cents, total, input.payment_method, user.id],
    )?;
    let sale_id = tx.last_insert_rowid();
    for (p, qty) in &lines {
        tx.execute(
            "INSERT INTO sale_items (sale_id, product_id, product_name, qty, unit_price_cents, unit_cost_cents) VALUES (?1,?2,?3,?4,?5,?6)",
            rusqlite::params![sale_id, p.id, p.name, qty, p.price_cents, p.cost_cents],
        )?;
        product_repo::move_stock(&tx, p.id, "sale", -qty, Some(p.cost_cents), Some("Venda"), Some("sale"), Some(sale_id), user.id)?;
    }
    let today = settings_repo::today(&tx).to_string();
    let desc = format!("Venda VEN-{:03}", sale_id);
    let pay = payment_repo::insert(
        &tx,
        &NewPayment {
            client_id: input.client_id, party_name: None, direction: "in", origin_type: "sale", origin_id: Some(sale_id),
            description: Some(&desc), amount_cents: total.max(1), method: &input.payment_method, status: "confirmed",
            due_date: None, paid_at: Some(&today), idempotency_key: input.idempotency_key.as_deref(), user_id: user.id,
        },
    );
    let pay = match pay {
        Ok(p) => p,
        Err(e) => return Err(e),
    };
    if total > 0 {
        payment_repo::insert_cash(&tx, "in", total, &input.payment_method, "Vendas", Some(&desc), Some(pay), &settings_repo::now_local(&tx), user.id)?;
    }
    tx.execute("UPDATE sales SET payment_id = ?2 WHERE id = ?1", (sale_id, pay))?;
    audit_repo::log(&tx, user, "sale.create", "sales", sale_id, &format!("{} · desc {}", format_brl(total), format_brl(input.discount_cents)))?;
    tx.commit()?;
    Ok(SaleResult { id: sale_id, code: format!("VEN-{:03}", sale_id) })
}

/// Cancela a venda por completo: devolve itens ao estoque e estorna o pagamento (histórico preservado).
pub fn cancel(conn: &mut Connection, user: &User, id: i64, reason: &str) -> AppResult<()> {
    let reason = require_text(reason, "Motivo", 200)?;
    let tx = conn.transaction()?;
    let sale = commerce_repo::get_sale(&tx, id)?;
    if sale.status == "cancelled" {
        return Err(AppError::Validation("Venda já cancelada.".into()));
    }
    for it in commerce_repo::sale_items(&tx, id)? {
        let back = it.qty - it.returned_qty;
        if back > 0 {
            product_repo::move_stock(&tx, it.product_id, "return", back, Some(it.unit_cost_cents), Some(&format!("Cancelamento VEN-{id:03}")), Some("sale"), Some(id), user.id)?;
            tx.execute("UPDATE sale_items SET returned_qty = qty WHERE id = ?1", [it.id])?;
        }
    }
    // reembolsos parciais anteriores já saíram do caixa; estorna apenas o restante
    let refunded: i64 = tx.query_row("SELECT COALESCE(SUM(amount_cents),0) FROM sale_returns WHERE sale_id = ?1", [id], |r| r.get(0))?;
    if let Some(pay) = sale.payment_id {
        if refunded == 0 {
            payment_service::reverse_in_tx(&tx, user, pay, &reason, true)?;
        } else {
            let rest = sale.total_cents - refunded;
            if rest > 0 {
                payment_repo::insert(&tx, &NewPayment {
                    client_id: sale.client_id, party_name: None, direction: "out", origin_type: "sale", origin_id: Some(id),
                    description: Some(&format!("Estorno parcial restante {}", sale.code)), amount_cents: rest,
                    method: &sale.payment_method, status: "confirmed", due_date: None,
                    paid_at: Some(&settings_repo::today(&tx).to_string()), idempotency_key: None, user_id: user.id,
                })?;
                payment_repo::insert_cash(&tx, "out", rest, &sale.payment_method, "Vendas", Some(&format!("Cancelamento {}", sale.code)), None, &settings_repo::now_local(&tx), user.id)?;
            }
        }
    }
    tx.execute("UPDATE sales SET status='cancelled', cancel_reason=?2 WHERE id=?1", (id, &reason))?;
    audit_repo::log(&tx, user, "sale.cancel", "sales", id, &reason)?;
    tx.commit()?;
    Ok(())
}

/// Devolução parcial de um item: repõe estoque e reembolsa proporcionalmente (desconto rateado).
pub fn return_item(conn: &mut Connection, user: &User, sale_id: i64, item_id: i64, qty: i64, reason: &str) -> AppResult<i64> {
    let reason = require_text(reason, "Motivo", 200)?;
    if qty <= 0 {
        return Err(AppError::Validation("Quantidade inválida.".into()));
    }
    let tx = conn.transaction()?;
    let sale = commerce_repo::get_sale(&tx, sale_id)?;
    if sale.status == "cancelled" {
        return Err(AppError::Validation("Venda cancelada.".into()));
    }
    let item = commerce_repo::sale_items(&tx, sale_id)?
        .into_iter()
        .find(|i| i.id == item_id)
        .ok_or_else(|| AppError::Validation("Item não encontrado na venda.".into()))?;
    if qty > item.qty - item.returned_qty {
        return Err(AppError::Validation("Quantidade maior que a disponível para devolução.".into()));
    }
    let gross = item.unit_price_cents * qty;
    let refund = if sale.subtotal_cents == 0 {
        0
    } else {
        round_cents(Decimal::from(gross) * Decimal::from(sale.total_cents) / Decimal::from(sale.subtotal_cents))
    };
    product_repo::move_stock(&tx, item.product_id, "return", qty, Some(item.unit_cost_cents), Some(&reason), Some("sale"), Some(sale_id), user.id)?;
    tx.execute("UPDATE sale_items SET returned_qty = returned_qty + ?2 WHERE id = ?1", (item_id, qty))?;
    let today = settings_repo::today(&tx).to_string();
    let pay = if refund > 0 {
        let p = payment_repo::insert(&tx, &NewPayment {
            client_id: sale.client_id, party_name: None, direction: "out", origin_type: "sale", origin_id: Some(sale_id),
            description: Some(&format!("Devolução {} · {}", sale.code, item.product_name)), amount_cents: refund,
            method: &sale.payment_method, status: "confirmed", due_date: None, paid_at: Some(&today),
            idempotency_key: None, user_id: user.id,
        })?;
        payment_repo::insert_cash(&tx, "out", refund, &sale.payment_method, "Vendas", Some(&format!("Devolução {}", sale.code)), Some(p), &settings_repo::now_local(&tx), user.id)?;
        Some(p)
    } else {
        None
    };
    tx.execute(
        "INSERT INTO sale_returns (sale_id, sale_item_id, qty, amount_cents, reason, payment_id, created_by) VALUES (?1,?2,?3,?4,?5,?6,?7)",
        rusqlite::params![sale_id, item_id, qty, refund, reason, pay, user.id],
    )?;
    let all_back: i64 = tx.query_row("SELECT COUNT(*) FROM sale_items WHERE sale_id = ?1 AND returned_qty < qty", [sale_id], |r| r.get(0))?;
    tx.execute(
        "UPDATE sales SET status = ?2 WHERE id = ?1",
        (sale_id, if all_back == 0 { "cancelled" } else { "partially_returned" }),
    )?;
    audit_repo::log(&tx, user, "sale.return", "sales", sale_id, &format!("{} x{qty} {}", item.product_name, format_brl(refund)))?;
    tx.commit()?;
    Ok(refund)
}

pub fn receipt(conn: &mut Connection, vault: &Vault, user: &User, id: i64) -> AppResult<attachment_service::Attachment> {
    let tx = conn.transaction()?;
    if let Some(a) = attachment_service::list(&tx, "sale", id, Some("receipt"))?.into_iter().next() {
        return Ok(a);
    }
    let s = commerce_repo::get_sale(&tx, id)?;
    let items = commerce_repo::sale_items(&tx, id)?;
    let (company, cnpj) = payment_service::company_header(&tx);
    let mut pdf = Pdf::new(&format!("Comprovante {}", s.code));
    pdf.heading(&company);
    if !cnpj.is_empty() {
        pdf.paragraph(&format!("CNPJ {cnpj}"), 9.0, false);
    }
    pdf.space(8.0);
    pdf.heading(&format!("COMPROVANTE DE VENDA {}", s.code));
    pdf.rule();
    pdf.key_value("Cliente", s.client_name.as_deref().unwrap_or("Consumidor final"));
    pdf.key_value("Data", &crate::domain::money::br_date(&s.created_at));
    pdf.key_value("Pagamento", method_label(&s.payment_method));
    pdf.space(8.0);
    let rows: Vec<Vec<String>> = items
        .iter()
        .map(|i| vec![i.product_name.clone(), i.qty.to_string(), format_brl(i.unit_price_cents), format_brl(i.unit_price_cents * i.qty)])
        .collect();
    pdf.table(&["Produto", "Qtd", "Unitário", "Total"], &rows, &[5.0, 1.0, 2.0, 2.0]);
    pdf.rule();
    pdf.key_value("Subtotal", &format_brl(s.subtotal_cents));
    pdf.key_value("Desconto", &format!("- {}", format_brl(s.discount_cents)));
    pdf.key_value("TOTAL", &format_brl(s.total_cents));
    pdf.space(16.0);
    pdf.paragraph("Documento de controle interno. A emissão fiscal depende da configuração de integração fiscal da empresa.", 8.0, false);
    let a = attachment_service::add_bytes(&tx, vault, user, "sale", id, "receipt", &format!("venda_{}.pdf", s.code), &pdf.finish())?;
    tx.commit()?;
    Ok(a)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::services::product_service;
    use crate::testutil::env;

    fn stocked(conn: &mut Connection, e: &crate::testutil::Env, name: &str, cost: i64, price: i64, qty: i64) -> i64 {
        let id = product_service::create(conn, &e.admin, product_service::tests::pinput(name, cost, price)).unwrap();
        product_service::adjust_stock(conn, &e.admin, id, qty, "Entrada").unwrap();
        id
    }

    fn sale(items: Vec<(i64, i64)>, discount: i64) -> SaleInput {
        SaleInput {
            client_id: None,
            items: items.into_iter().map(|(p, q)| SaleItemInput { product_id: p, qty: q }).collect(),
            discount_cents: discount, payment_method: "pix".into(), idempotency_key: None,
        }
    }

    #[test]
    fn sale_updates_stock_cash_and_uses_db_prices() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let a = stocked(&mut conn, &e, "Samsung", 145_000, 234_000, 8);
        let b = stocked(&mut conn, &e, "G-Shock", 32_000, 58_000, 4);
        let r = create(&mut conn, &e.admin, sale(vec![(a, 1), (b, 2)], 15_000)).unwrap();
        let s = commerce_repo::get_sale(&conn, r.id).unwrap();
        assert_eq!((s.subtotal_cents, s.discount_cents, s.total_cents), (350_000, 15_000, 335_000));
        assert_eq!(product_repo::get(&conn, a).unwrap().stock_qty, 7);
        assert_eq!(product_repo::get(&conn, b).unwrap().stock_qty, 2);
        assert_eq!(payment_repo::cash_summary(&conn).unwrap().balance_cents, 335_000);
    }

    #[test]
    fn blocks_oversell_and_excess_discount() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let a = stocked(&mut conn, &e, "TV", 100_000, 200_000, 1);
        assert!(create(&mut conn, &e.admin, sale(vec![(a, 2)], 0)).is_err());
        assert!(create(&mut conn, &e.admin, sale(vec![], 0)).is_err());
        let mut op = e.admin.clone();
        op.permissions.retain(|p| p != "sales.discount");
        assert!(create(&mut conn, &op, sale(vec![(a, 1)], 30_000)).is_err());
        assert!(create(&mut conn, &op, sale(vec![(a, 1)], 20_000)).is_ok());
        assert_eq!(product_repo::get(&conn, a).unwrap().stock_qty, 0);
    }

    #[test]
    fn idempotency_prevents_double_sale() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let a = stocked(&mut conn, &e, "Bike", 100, 200, 5);
        let mut s = sale(vec![(a, 1)], 0);
        s.idempotency_key = Some("sale-1".into());
        let r1 = create(&mut conn, &e.admin, s.clone()).unwrap();
        let r2 = create(&mut conn, &e.admin, s).unwrap();
        assert_eq!(r1.id, r2.id);
        assert_eq!(product_repo::get(&conn, a).unwrap().stock_qty, 4);
    }

    #[test]
    fn cancel_restocks_and_reverses_payment() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let a = stocked(&mut conn, &e, "Violão", 68_000, 110_000, 5);
        let r = create(&mut conn, &e.admin, sale(vec![(a, 2)], 0)).unwrap();
        cancel(&mut conn, &e.admin, r.id, "Cliente desistiu").unwrap();
        assert_eq!(product_repo::get(&conn, a).unwrap().stock_qty, 5);
        assert_eq!(payment_repo::cash_summary(&conn).unwrap().balance_cents, 0);
        assert!(cancel(&mut conn, &e.admin, r.id, "x").is_err());
    }

    #[test]
    fn partial_return_refunds_proportionally() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let a = stocked(&mut conn, &e, "Fone", 5_000, 10_000, 10);
        let r = create(&mut conn, &e.admin, sale(vec![(a, 4)], 4_000)).unwrap(); // subtotal 40.000, total 36.000
        let item = commerce_repo::sale_items(&conn, r.id).unwrap()[0].id;
        let refund = return_item(&mut conn, &e.admin, r.id, item, 1, "Defeito").unwrap();
        assert_eq!(refund, 9_000);
        assert_eq!(commerce_repo::get_sale(&conn, r.id).unwrap().status, "partially_returned");
        assert!(return_item(&mut conn, &e.admin, r.id, item, 4, "x").is_err());
        assert_eq!(payment_repo::cash_summary(&conn).unwrap().balance_cents, 27_000);
        // cancelar após devolução parcial devolve o restante
        cancel(&mut conn, &e.admin, r.id, "Cancelar resto").unwrap();
        assert_eq!(payment_repo::cash_summary(&conn).unwrap().balance_cents, 0);
        assert_eq!(product_repo::get(&conn, a).unwrap().stock_qty, 10);
    }

    #[test]
    fn receipt_pdf() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let a = stocked(&mut conn, &e, "Cabo", 100, 300, 5);
        let r = create(&mut conn, &e.admin, sale(vec![(a, 2)], 0)).unwrap();
        let att = receipt(&mut conn, &e.vault, &e.admin, r.id).unwrap();
        assert!(attachment_service::read(&conn, &e.vault, att.id).unwrap().1.starts_with(b"%PDF"));
    }
}
