use rusqlite::Connection;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

use crate::domain::user::User;
use crate::domain::validation::*;
use crate::error::{AppError, AppResult};
use crate::repositories::{audit_repo, settings_repo};
use crate::security::vault::Vault;

/// Todas as configurações não sensíveis (segredos ficam em `secrets`, cifrados).
pub fn all(conn: &Connection) -> AppResult<BTreeMap<String, String>> {
    Ok(settings_repo::with_prefix(conn, "")?.into_iter().collect())
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CompanyInput {
    pub name: String,
    pub document: String,
    pub email: String,
    pub phone: String,
    pub address: String,
}

pub fn save_company(conn: &mut Connection, user: &User, i: CompanyInput) -> AppResult<()> {
    let name = require_text(&i.name, "Razão social", 120)?;
    let doc = if i.document.trim().is_empty() { String::new() } else { format_document(&normalize_document("PJ", &i.document)?) };
    if !i.email.trim().is_empty() {
        validate_email(&i.email)?;
    }
    let phone = if i.phone.trim().is_empty() { String::new() } else { i.phone.trim().to_string() };
    if !phone.is_empty() {
        validate_phone(&phone)?;
    }
    let tx = conn.transaction()?;
    for (k, v) in [("company.name", name.as_str()), ("company.document", &doc), ("company.email", i.email.trim()), ("company.phone", &phone), ("company.address", i.address.trim())] {
        settings_repo::set(&tx, k, v)?;
    }
    audit_repo::log(&tx, user, "settings.company", "settings", 0, &name)?;
    tx.commit()?;
    Ok(())
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RegionalInput {
    pub date_format: String,
    pub tz_offset_hours: i64,
}

pub fn save_regional(conn: &mut Connection, user: &User, i: RegionalInput) -> AppResult<()> {
    if !matches!(i.date_format.as_str(), "DD/MM/AAAA" | "AAAA-MM-DD") {
        return Err(AppError::Validation("Formato de data inválido.".into()));
    }
    if !(-12..=14).contains(&i.tz_offset_hours) {
        return Err(AppError::Validation("Fuso horário inválido.".into()));
    }
    let tx = conn.transaction()?;
    settings_repo::set(&tx, "regional.date_format", &i.date_format)?;
    settings_repo::set(&tx, "regional.tz_offset_hours", &i.tz_offset_hours.to_string())?;
    audit_repo::log(&tx, user, "settings.regional", "settings", 0, &format!("{} UTC{:+}", i.date_format, i.tz_offset_hours))?;
    tx.commit()?;
    Ok(())
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct FinancialRules {
    pub default_rate_bp: i64,
    pub origination_fee_bp: i64,
    pub iof_bp: i64,
    pub late_fee_bp: i64,
    pub late_interest_month_bp: i64,
    pub max_term_months: i64,
    pub max_amount_cents: i64,
    pub max_discount_pct: i64,
}

pub fn save_financial_rules(conn: &mut Connection, user: &User, r: FinancialRules) -> AppResult<()> {
    let checks = [
        ("Taxa padrão", r.default_rate_bp, 0, 2000),
        ("Tarifa de cadastro", r.origination_fee_bp, 0, 2000),
        ("IOF", r.iof_bp, 0, 1000),
        ("Multa por atraso", r.late_fee_bp, 0, 1000),
        ("Juros de mora", r.late_interest_month_bp, 0, 500),
        ("Prazo máximo", r.max_term_months, 1, 120),
        ("Desconto máximo (%)", r.max_discount_pct, 0, 100),
    ];
    for (label, v, lo, hi) in checks {
        if !(lo..=hi).contains(&v) {
            return Err(AppError::Validation(format!("{label} fora do intervalo permitido ({lo} a {hi}).")));
        }
    }
    if r.max_amount_cents <= 0 {
        return Err(AppError::Validation("Valor máximo deve ser positivo.".into()));
    }
    let tx = conn.transaction()?;
    for (k, v) in [
        ("loan.default_rate_bp", r.default_rate_bp), ("loan.origination_fee_bp", r.origination_fee_bp), ("loan.iof_bp", r.iof_bp),
        ("loan.late_fee_bp", r.late_fee_bp), ("loan.late_interest_month_bp", r.late_interest_month_bp),
        ("loan.max_term_months", r.max_term_months), ("loan.max_amount_cents", r.max_amount_cents), ("sales.max_discount_pct", r.max_discount_pct),
    ] {
        settings_repo::set(&tx, k, &v.to_string())?;
    }
    audit_repo::log(&tx, user, "settings.financial_rules", "settings", 0, "")?;
    tx.commit()?;
    Ok(())
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NotificationConfig {
    pub whatsapp_3d_before: bool,
    pub email_on_due: bool,
    pub call_after_5d: bool,
    pub quiet_start_hour: i64,
    pub quiet_end_hour: i64,
    pub allow_sunday: bool,
    pub max_per_client_day: i64,
    pub max_per_client_week: i64,
    pub due_soon_days: i64,
    pub collateral_days: i64,
}

pub fn save_notification_config(conn: &mut Connection, user: &User, c: NotificationConfig) -> AppResult<()> {
    if !(0..=23).contains(&c.quiet_start_hour) || !(1..=24).contains(&c.quiet_end_hour) || c.quiet_start_hour >= c.quiet_end_hour {
        return Err(AppError::Validation("Janela de contato inválida.".into()));
    }
    if !(1..=10).contains(&c.max_per_client_day) || !(1..=30).contains(&c.max_per_client_week) || c.max_per_client_day > c.max_per_client_week {
        return Err(AppError::Validation("Limites de contato inválidos.".into()));
    }
    if !(1..=60).contains(&c.due_soon_days) || !(1..=90).contains(&c.collateral_days) {
        return Err(AppError::Validation("Antecedência de avisos inválida.".into()));
    }
    let tx = conn.transaction()?;
    let b = |v: bool| if v { "true" } else { "false" }.to_string();
    for (k, v) in [
        ("collections.whatsapp_3d_before", b(c.whatsapp_3d_before)), ("collections.email_on_due", b(c.email_on_due)),
        ("collections.call_after_5d", b(c.call_after_5d)), ("collections.quiet_start_hour", c.quiet_start_hour.to_string()),
        ("collections.quiet_end_hour", c.quiet_end_hour.to_string()), ("collections.allow_sunday", b(c.allow_sunday)),
        ("collections.max_per_client_day", c.max_per_client_day.to_string()), ("collections.max_per_client_week", c.max_per_client_week.to_string()),
        ("notifications.due_soon_days", c.due_soon_days.to_string()), ("notifications.collateral_days", c.collateral_days.to_string()),
    ] {
        settings_repo::set(&tx, k, &v)?;
    }
    audit_repo::log(&tx, user, "settings.notifications", "settings", 0, "")?;
    tx.commit()?;
    Ok(())
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct MessageTemplate {
    pub id: i64,
    pub code: String,
    pub channel: String,
    pub name: String,
    pub body: String,
    pub active: bool,
}

pub fn message_templates(conn: &Connection) -> AppResult<Vec<MessageTemplate>> {
    let mut stmt = conn.prepare("SELECT id, code, channel, name, body, active FROM notification_templates ORDER BY id")?;
    let rows = stmt
        .query_map([], |r| Ok(MessageTemplate { id: r.get(0)?, code: r.get(1)?, channel: r.get(2)?, name: r.get(3)?, body: r.get(4)?, active: r.get::<_, i64>(5)? == 1 }))?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

pub fn save_message_template(conn: &mut Connection, user: &User, id: i64, body: &str, active: bool) -> AppResult<()> {
    let body = require_text(body, "Mensagem", 1000)?;
    let allowed = ["nome", "parcela", "contrato", "valor", "vencimento"];
    let mut rest = body.as_str();
    while let Some(s) = rest.find('{') {
        let e = rest[s..].find('}').ok_or_else(|| AppError::Validation("Variável sem fechamento '}'.".into()))?;
        let var = &rest[s + 1..s + e];
        if !allowed.contains(&var) {
            return Err(AppError::Validation(format!("Variável desconhecida: {{{var}}}. Use: nome, parcela, contrato, valor, vencimento.")));
        }
        rest = &rest[s + e + 1..];
    }
    let tx = conn.transaction()?;
    let n = tx.execute("UPDATE notification_templates SET body=?2, active=?3, updated_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id=?1", rusqlite::params![id, body, active as i64])?;
    if n == 0 {
        return Err(AppError::Validation("Modelo não encontrado.".into()));
    }
    audit_repo::log(&tx, user, "settings.message_template", "notification_templates", id, "")?;
    tx.commit()?;
    Ok(())
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Regulatory {
    pub credit_enabled: bool,
    pub collateral_enabled: bool,
    pub credit_note: String,
    pub collateral_note: String,
    pub credit_by: String,
    pub credit_at: String,
    pub collateral_by: String,
    pub collateral_at: String,
}

pub fn regulatory(conn: &Connection) -> AppResult<Regulatory> {
    let g = |k: &str| settings_repo::get_or(conn, k, "");
    Ok(Regulatory {
        credit_enabled: settings_repo::get_bool(conn, "credit.enabled")?,
        collateral_enabled: settings_repo::get_bool(conn, "collateral.enabled")?,
        credit_note: g("regulatory.credit_note")?, collateral_note: g("regulatory.collateral_note")?,
        credit_by: g("regulatory.credit_by")?, credit_at: g("regulatory.credit_at")?,
        collateral_by: g("regulatory.collateral_by")?, collateral_at: g("regulatory.collateral_at")?,
    })
}

/// Habilita/desabilita crédito ou garantias. Habilitar exige a referência da validação jurídica/regulatória.
pub fn set_regulatory(conn: &mut Connection, user: &User, kind: &str, enabled: bool, note: &str) -> AppResult<()> {
    let key = match kind {
        "credit" => "credit",
        "collateral" => "collateral",
        _ => return Err(AppError::Validation("Operação inválida.".into())),
    };
    let note = note.trim();
    if enabled && note.chars().count() < 20 {
        return Err(AppError::Validation("Informe a referência da validação regulatória (parecer, enquadramento e autorização) com ao menos 20 caracteres.".into()));
    }
    if !enabled && note.chars().count() < 5 {
        return Err(AppError::Validation("Informe o motivo da desabilitação.".into()));
    }
    let tx = conn.transaction()?;
    settings_repo::set(&tx, &format!("{key}.enabled"), if enabled { "true" } else { "false" })?;
    settings_repo::set(&tx, &format!("regulatory.{key}_note"), note)?;
    settings_repo::set(&tx, &format!("regulatory.{key}_by"), &user.username)?;
    settings_repo::set(&tx, &format!("regulatory.{key}_at"), &settings_repo::now_local(&tx))?;
    audit_repo::log(&tx, user, if enabled { "regulatory.enable" } else { "regulatory.disable" }, "settings", 0, &format!("{key}: {note}"))?;
    tx.commit()?;
    Ok(())
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct IntegrationStatus {
    pub name: String,
    pub enabled: bool,
    pub secret_configured: bool,
    pub fields: BTreeMap<String, String>,
    /// Nenhum conector de envio/emissão está implementado nesta versão.
    pub connector_available: bool,
}

const INTEGRATIONS: [(&str, &[&str]); 3] = [
    ("whatsapp", &["phone_id"]),
    ("email", &["host", "port", "user"]),
    ("fiscal", &["regime", "provider"]),
];

pub fn integrations(conn: &Connection) -> AppResult<Vec<IntegrationStatus>> {
    let mut out = vec![];
    for (name, fields) in INTEGRATIONS {
        let mut f = BTreeMap::new();
        for field in fields {
            f.insert((*field).to_string(), settings_repo::get_or(conn, &format!("integrations.{name}.{field}"), "")?);
        }
        let secret: bool = conn.query_row("SELECT EXISTS(SELECT 1 FROM secrets WHERE key = ?1)", [format!("integrations.{name}")], |r| r.get(0))?;
        out.push(IntegrationStatus {
            name: name.into(), enabled: settings_repo::get_bool(conn, &format!("integrations.{name}.enabled"))?, secret_configured: secret,
            fields: f, connector_available: false,
        });
    }
    Ok(out)
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct IntegrationInput {
    pub name: String,
    pub enabled: bool,
    pub fields: BTreeMap<String, String>,
    /// Token/senha: gravado cifrado; nunca é devolvido ao frontend.
    pub secret: Option<String>,
}

pub fn save_integration(conn: &mut Connection, vault: &Vault, user: &User, i: IntegrationInput) -> AppResult<()> {
    let (name, allowed) = INTEGRATIONS.iter().find(|(n, _)| *n == i.name).ok_or_else(|| AppError::Validation("Integração inválida.".into()))?;
    let tx = conn.transaction()?;
    for (k, v) in &i.fields {
        if !allowed.contains(&k.as_str()) {
            return Err(AppError::Validation(format!("Campo desconhecido: {k}.")));
        }
        if *name == "email" && k == "port" && v.trim().parse::<u16>().is_err() {
            return Err(AppError::Validation("Porta inválida.".into()));
        }
        settings_repo::set(&tx, &format!("integrations.{name}.{k}"), v.trim())?;
    }
    if let Some(secret) = i.secret.as_deref().filter(|s| !s.is_empty()) {
        tx.execute(
            "INSERT INTO secrets (key, value_enc) VALUES (?1, ?2) ON CONFLICT(key) DO UPDATE SET value_enc = excluded.value_enc, updated_at = strftime('%Y-%m-%dT%H:%M:%SZ','now')",
            (format!("integrations.{name}"), vault.encrypt_text(secret)?),
        )?;
    }
    settings_repo::set(&tx, &format!("integrations.{name}.enabled"), if i.enabled { "true" } else { "false" })?;
    audit_repo::log(&tx, user, "settings.integration", "settings", 0, &format!("{name} enabled={}", i.enabled))?;
    tx.commit()?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::testutil::env;

    #[test]
    fn regulatory_enablement_requires_justification_and_is_audited() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let r = regulatory(&conn).unwrap();
        assert!(!r.credit_enabled && !r.collateral_enabled);
        assert!(set_regulatory(&mut conn, &e.admin, "credit", true, "ok").is_err());
        assert!(set_regulatory(&mut conn, &e.admin, "bitcoin", true, "x".repeat(30).as_str()).is_err());
        set_regulatory(&mut conn, &e.admin, "credit", true, "Parecer jurídico 2024/17 e autorização do órgão competente").unwrap();
        let r = regulatory(&conn).unwrap();
        assert!(r.credit_enabled && !r.collateral_enabled && r.credit_by == "admin");
        set_regulatory(&mut conn, &e.admin, "credit", false, "Revisão em curso").unwrap();
        assert!(!regulatory(&conn).unwrap().credit_enabled);
        let n: i64 = conn.query_row("SELECT COUNT(*) FROM audit_logs WHERE action LIKE 'regulatory.%'", [], |r| r.get(0)).unwrap();
        assert_eq!(n, 2);
    }

    #[test]
    fn company_validation_and_normalization() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let ok = CompanyInput { name: "Phantom Financeira Ltda.".into(), document: "11222333000181".into(), email: "contato@phantom.com.br".into(), phone: "(11) 4000-5000".into(), address: "Av. Faria Lima, 2000".into() };
        save_company(&mut conn, &e.admin, ok).unwrap();
        assert_eq!(settings_repo::get(&conn, "company.document").unwrap().unwrap(), "11.222.333/0001-81");
        let bad = CompanyInput { name: "X".into(), document: "11222333000182".into(), email: String::new(), phone: String::new(), address: String::new() };
        assert!(save_company(&mut conn, &e.admin, bad).is_err());
    }

    #[test]
    fn financial_rules_are_range_checked_and_drive_simulation() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let mut r = FinancialRules { default_rate_bp: 300, origination_fee_bp: 100, iof_bp: 0, late_fee_bp: 200, late_interest_month_bp: 100, max_term_months: 36, max_amount_cents: 1_000_000, max_discount_pct: 5 };
        save_financial_rules(&mut conn, &e.admin, FinancialRules { ..r }).unwrap();
        assert_eq!(settings_repo::get_i64(&conn, "loan.default_rate_bp", 0).unwrap(), 300);
        r.default_rate_bp = 5000;
        assert!(save_financial_rules(&mut conn, &e.admin, FinancialRules { ..r }).is_err());
    }

    #[test]
    fn notification_config_and_message_templates_validation() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let cfg = |start: i64, end: i64| NotificationConfig { whatsapp_3d_before: true, email_on_due: false, call_after_5d: true, quiet_start_hour: start, quiet_end_hour: end, allow_sunday: false, max_per_client_day: 2, max_per_client_week: 4, due_soon_days: 7, collateral_days: 7 };
        assert!(save_notification_config(&mut conn, &e.admin, cfg(20, 8)).is_err());
        save_notification_config(&mut conn, &e.admin, cfg(9, 18)).unwrap();
        assert!(settings_repo::get_bool(&conn, "collections.call_after_5d").unwrap());
        let t = message_templates(&conn).unwrap();
        assert!(save_message_template(&mut conn, &e.admin, t[0].id, "Olá {nome}, {segredo}", true).is_err());
        save_message_template(&mut conn, &e.admin, t[0].id, "Olá {nome}! Parcela {parcela} de {valor} vence em {vencimento}.", true).unwrap();
    }

    #[test]
    fn integration_secrets_are_encrypted_and_never_returned() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let mut f = BTreeMap::new();
        f.insert("phone_id".to_string(), "12345".to_string());
        save_integration(&mut conn, &e.vault, &e.admin, IntegrationInput { name: "whatsapp".into(), enabled: false, fields: f, secret: Some("EAAG-token-super-secreto".into()) }).unwrap();
        let stored: String = conn.query_row("SELECT value_enc FROM secrets", [], |r| r.get(0)).unwrap();
        assert!(!stored.contains("super-secreto"));
        assert_eq!(e.vault.decrypt_text(&stored).unwrap(), "EAAG-token-super-secreto");
        let st = integrations(&conn).unwrap();
        let wa = st.iter().find(|s| s.name == "whatsapp").unwrap();
        assert!(wa.secret_configured && !wa.connector_available && wa.fields["phone_id"] == "12345");
        assert!(!serde_json::to_string(&st).unwrap().contains("super-secreto"));
        let mut bad = BTreeMap::new();
        bad.insert("port".to_string(), "abc".to_string());
        assert!(save_integration(&mut conn, &e.vault, &e.admin, IntegrationInput { name: "email".into(), enabled: false, fields: bad, secret: None }).is_err());
    }
}
