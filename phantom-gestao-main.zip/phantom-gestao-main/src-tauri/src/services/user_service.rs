use rusqlite::Connection;
use serde::{Deserialize, Serialize};

use crate::domain::user::{normalize_username, validate_full_name, User};
use crate::error::{AppError, AppResult};
use crate::repositories::{audit_repo, user_repo};
use crate::security::password;

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UserRow {
    pub id: i64,
    pub username: String,
    pub full_name: String,
    pub role_code: String,
    pub role_name: String,
    pub active: bool,
    pub last_login_at: Option<String>,
    pub locked: bool,
}

pub fn list(conn: &Connection) -> AppResult<Vec<UserRow>> {
    let mut stmt = conn.prepare(
        "SELECT u.id, u.username, u.full_name, r.code, r.name, u.active, u.last_login_at,
                (u.locked_until IS NOT NULL AND u.locked_until > strftime('%Y-%m-%dT%H:%M:%SZ','now'))
         FROM users u JOIN roles r ON r.id = u.role_id ORDER BY u.full_name COLLATE NOCASE",
    )?;
    let rows = stmt
        .query_map([], |r| {
            Ok(UserRow {
                id: r.get(0)?, username: r.get(1)?, full_name: r.get(2)?, role_code: r.get(3)?, role_name: r.get(4)?,
                active: r.get::<_, i64>(5)? == 1, last_login_at: r.get(6)?, locked: r.get::<_, i64>(7)? == 1,
            })
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NewUser {
    pub username: String,
    pub full_name: String,
    pub role_code: String,
    pub password: String,
}

pub fn create(conn: &mut Connection, actor: &User, i: NewUser) -> AppResult<i64> {
    let username = normalize_username(&i.username)?;
    let name = validate_full_name(&i.full_name)?;
    password::validate_strength(&i.password)?;
    let phc = password::hash(&i.password)?;
    let tx = conn.transaction()?;
    if user_repo::find_by_username(&tx, &username)?.is_some() {
        return Err(AppError::Validation("Este nome de usuário já existe.".into()));
    }
    let role = user_repo::role_id_by_code(&tx, &i.role_code).map_err(|_| AppError::Validation("Perfil inválido.".into()))?;
    let id = user_repo::insert(&tx, &username, &name, &phc, role)?;
    audit_repo::log(&tx, actor, "user.create", "users", id, &format!("{username} ({})", i.role_code))?;
    tx.commit()?;
    Ok(id)
}

fn active_admins(conn: &Connection, except: Option<i64>) -> AppResult<i64> {
    Ok(conn.query_row(
        "SELECT COUNT(*) FROM users u JOIN roles r ON r.id = u.role_id WHERE r.code = 'admin' AND u.active = 1 AND (?1 IS NULL OR u.id <> ?1)",
        [except],
        |r| r.get(0),
    )?)
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UserUpdate {
    pub full_name: String,
    pub role_code: String,
    pub active: bool,
}

pub fn update(conn: &mut Connection, actor: &User, id: i64, i: UserUpdate) -> AppResult<()> {
    let name = validate_full_name(&i.full_name)?;
    let tx = conn.transaction()?;
    let role = user_repo::role_id_by_code(&tx, &i.role_code).map_err(|_| AppError::Validation("Perfil inválido.".into()))?;
    let (cur_role, cur_active): (String, i64) = tx
        .query_row("SELECT r.code, u.active FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ?1", [id], |r| Ok((r.get(0)?, r.get(1)?)))
        .map_err(|_| AppError::Validation("Usuário não encontrado.".into()))?;
    let loses_admin = cur_role == "admin" && cur_active == 1 && (i.role_code != "admin" || !i.active);
    if loses_admin && active_admins(&tx, Some(id))? == 0 {
        return Err(AppError::Validation("Deve existir ao menos um administrador ativo.".into()));
    }
    if id == actor.id && !i.active {
        return Err(AppError::Validation("Você não pode desativar o próprio usuário.".into()));
    }
    tx.execute(
        "UPDATE users SET full_name=?2, role_id=?3, active=?4, updated_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id=?1",
        rusqlite::params![id, name, role, i.active as i64],
    )?;
    audit_repo::log(&tx, actor, "user.update", "users", id, &format!("{} ativo={}", i.role_code, i.active))?;
    tx.commit()?;
    Ok(())
}

pub fn reset_password(conn: &mut Connection, actor: &User, id: i64, new_password: &str) -> AppResult<()> {
    password::validate_strength(new_password)?;
    let phc = password::hash(new_password)?;
    let tx = conn.transaction()?;
    let n = tx.execute(
        "UPDATE users SET password_hash=?2, failed_attempts=0, locked_until=NULL, updated_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id=?1",
        (id, phc),
    )?;
    if n == 0 {
        return Err(AppError::Validation("Usuário não encontrado.".into()));
    }
    audit_repo::log(&tx, actor, "user.password_reset", "users", id, "")?;
    tx.commit()?;
    Ok(())
}

pub fn change_own_password(conn: &mut Connection, user: &User, current: &str, new_password: &str) -> AppResult<()> {
    password::validate_strength(new_password)?;
    let tx = conn.transaction()?;
    let phc: String = tx.query_row("SELECT password_hash FROM users WHERE id = ?1", [user.id], |r| r.get(0))?;
    if !password::verify(current, &phc) {
        audit_repo::log(&tx, user, "user.password_change_failed", "users", user.id, "")?;
        tx.commit()?;
        return Err(AppError::Validation("Senha atual incorreta.".into()));
    }
    if current == new_password {
        return Err(AppError::Validation("A nova senha deve ser diferente da atual.".into()));
    }
    tx.execute("UPDATE users SET password_hash=?2, updated_at=strftime('%Y-%m-%dT%H:%M:%SZ','now') WHERE id=?1", (user.id, password::hash(new_password)?))?;
    audit_repo::log(&tx, user, "user.password_change", "users", user.id, "")?;
    tx.commit()?;
    Ok(())
}

pub fn unlock(conn: &mut Connection, actor: &User, id: i64) -> AppResult<()> {
    conn.execute("UPDATE users SET failed_attempts=0, locked_until=NULL WHERE id=?1", [id])?;
    audit_repo::log(conn, actor, "user.unlock", "users", id, "")?;
    Ok(())
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RoleMatrix {
    pub roles: Vec<RoleInfo>,
    pub permissions: Vec<PermissionInfo>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RoleInfo {
    pub code: String,
    pub name: String,
    pub description: String,
    pub granted: Vec<String>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PermissionInfo {
    pub code: String,
    pub description: String,
}

pub fn matrix(conn: &Connection) -> AppResult<RoleMatrix> {
    let mut roles = vec![];
    let mut stmt = conn.prepare("SELECT id, code, name, description FROM roles ORDER BY id")?;
    let base: Vec<(i64, String, String, String)> = stmt.query_map([], |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?)))?.collect::<Result<_, _>>()?;
    for (id, code, name, description) in base {
        let mut s = conn.prepare("SELECT p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = ?1 ORDER BY p.code")?;
        let granted = s.query_map([id], |r| r.get(0))?.collect::<Result<Vec<String>, _>>()?;
        roles.push(RoleInfo { code, name, description, granted });
    }
    let mut s = conn.prepare("SELECT code, description FROM permissions ORDER BY code")?;
    let permissions = s.query_map([], |r| Ok(PermissionInfo { code: r.get(0)?, description: r.get(1)? }))?.collect::<Result<_, _>>()?;
    Ok(RoleMatrix { roles, permissions })
}

/// Altera uma permissão de um perfil. O perfil de administrador é imutável.
pub fn set_permission(conn: &mut Connection, actor: &User, role_code: &str, permission: &str, granted: bool) -> AppResult<()> {
    if role_code == "admin" {
        return Err(AppError::Validation("O perfil Administrador não pode ser alterado.".into()));
    }
    let tx = conn.transaction()?;
    let role: i64 = tx.query_row("SELECT id FROM roles WHERE code = ?1", [role_code], |r| r.get(0)).map_err(|_| AppError::Validation("Perfil inválido.".into()))?;
    let perm: i64 = tx.query_row("SELECT id FROM permissions WHERE code = ?1", [permission], |r| r.get(0)).map_err(|_| AppError::Validation("Permissão inválida.".into()))?;
    if granted {
        tx.execute("INSERT OR IGNORE INTO role_permissions (role_id, permission_id) VALUES (?1, ?2)", (role, perm))?;
    } else {
        tx.execute("DELETE FROM role_permissions WHERE role_id = ?1 AND permission_id = ?2", (role, perm))?;
    }
    audit_repo::log(&tx, actor, "role.permission", "roles", role, &format!("{role_code}: {permission} = {granted}"))?;
    tx.commit()?;
    Ok(())
}

pub fn reload(conn: &Connection, id: i64) -> AppResult<User> {
    user_repo::load_user(conn, id)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::services::auth_service;
    use crate::testutil::env;

    fn nu(u: &str, role: &str) -> NewUser {
        NewUser { username: u.into(), full_name: "Pessoa Teste".into(), role_code: role.into(), password: "senhaforte123".into() }
    }

    #[test]
    fn create_validates_and_new_user_can_login_with_role_permissions() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        create(&mut conn, &e.admin, nu("op1", "operator")).unwrap();
        assert!(create(&mut conn, &e.admin, nu("OP1", "operator")).is_err());
        assert!(create(&mut conn, &e.admin, nu("x", "operator")).is_err());
        assert!(create(&mut conn, &e.admin, nu("op2", "inexistente")).is_err());
        let mut weak = nu("op3", "viewer");
        weak.password = "123".into();
        assert!(create(&mut conn, &e.admin, weak).is_err());
        drop(conn);
        let u = auth_service::login(&e.db, "op1", "senhaforte123").unwrap();
        assert!(u.permissions.contains(&"clients.manage".to_string()));
        assert!(!u.permissions.contains(&"users.manage".to_string()));
        assert!(!u.permissions.contains(&"loans.disburse".to_string()));
    }

    #[test]
    fn last_admin_and_self_protection() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let up = |role: &str, active: bool| UserUpdate { full_name: "Administrador Teste".into(), role_code: role.into(), active };
        assert!(update(&mut conn, &e.admin, e.admin.id, up("viewer", true)).is_err());
        assert!(update(&mut conn, &e.admin, e.admin.id, up("admin", false)).is_err());
        let other = create(&mut conn, &e.admin, nu("adm2", "admin")).unwrap();
        update(&mut conn, &e.admin, other, UserUpdate { full_name: "Segundo Admin".into(), role_code: "manager".into(), active: true }).unwrap();
        update(&mut conn, &e.admin, other, UserUpdate { full_name: "Segundo Admin".into(), role_code: "admin".into(), active: false }).unwrap();
    }

    #[test]
    fn password_reset_unlocks_and_change_requires_current() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        let id = create(&mut conn, &e.admin, nu("op1", "operator")).unwrap();
        drop(conn);
        for _ in 0..5 {
            let _ = auth_service::login(&e.db, "op1", "errada-12345");
        }
        assert!(matches!(auth_service::login(&e.db, "op1", "senhaforte123"), Err(AppError::Locked(_))));
        let mut conn = e.db.conn().unwrap();
        reset_password(&mut conn, &e.admin, id, "novasenha-456").unwrap();
        drop(conn);
        let u = auth_service::login(&e.db, "op1", "novasenha-456").unwrap();
        let mut conn = e.db.conn().unwrap();
        assert!(change_own_password(&mut conn, &u, "errada", "outrasenha-789").is_err());
        assert!(change_own_password(&mut conn, &u, "novasenha-456", "novasenha-456").is_err());
        change_own_password(&mut conn, &u, "novasenha-456", "outrasenha-789").unwrap();
        drop(conn);
        assert!(auth_service::login(&e.db, "op1", "outrasenha-789").is_ok());
    }

    #[test]
    fn permission_matrix_edit_applies_and_admin_is_locked() {
        let e = env();
        let mut conn = e.db.conn().unwrap();
        assert!(set_permission(&mut conn, &e.admin, "admin", "users.manage", false).is_err());
        set_permission(&mut conn, &e.admin, "viewer", "clients.view", true).unwrap();
        let m = matrix(&conn).unwrap();
        let viewer = m.roles.iter().find(|r| r.code == "viewer").unwrap();
        assert!(viewer.granted.contains(&"clients.view".to_string()));
        set_permission(&mut conn, &e.admin, "viewer", "clients.view", false).unwrap();
        assert!(set_permission(&mut conn, &e.admin, "viewer", "nao.existe", true).is_err());
        assert!(m.permissions.len() >= 30);
    }
}
