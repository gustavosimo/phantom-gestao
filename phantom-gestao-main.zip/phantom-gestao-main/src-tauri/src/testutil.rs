//! Utilitários compartilhados pelos testes de serviços.

use crate::database::Database;
use crate::domain::user::User;
use crate::security::vault::Vault;
use crate::services::auth_service;

pub struct Env {
    pub db: Database,
    pub vault: Vault,
    pub admin: User,
}

pub fn env() -> Env {
    let db = Database::open_in_memory().unwrap();
    let admin = auth_service::setup_admin(&db, "Administrador Teste", "admin", "senhaforte123").unwrap();
    let dir = std::env::temp_dir().join(format!(
        "phantom-test-{}-{}",
        std::process::id(),
        std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()
    ));
    Env { db, vault: Vault::with_key(&dir, [9u8; 32]), admin }
}

/// "Hoje" no fuso padrão do sistema (UTC-3), igual a `settings_repo::today`.
pub fn today() -> chrono::NaiveDate {
    chrono::Utc::now().with_timezone(&chrono::FixedOffset::east_opt(-3 * 3600).unwrap()).date_naive()
}
