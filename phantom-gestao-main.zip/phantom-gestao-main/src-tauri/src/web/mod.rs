//! Modo web (opcional): serve o frontend e uma API JSON sobre os mesmos comandos do desktop, para uso
//! remoto por navegador via túnel. Os dados continuam na máquina local (mesmo SQLite e mesmo cofre).
//!
//! Segurança:
//! - escuta apenas em 127.0.0.1; a exposição pública é feita pelo túnel (cloudflared);
//! - sessão por navegador (cookie HttpOnly + SameSite=Strict, expira por inatividade e por tempo total);
//! - exige o cabeçalho `X-Requested-With: phantom` e confere Origin/Host (defesa contra CSRF);
//! - limite de tentativas de login por IP, além do bloqueio por usuário já existente;
//! - comandos que acessam disco do servidor (caminhos), backup e demo são bloqueados (ver o gerador).
//!
//! Ativação: variável de ambiente `PHANTOM_WEB=1` (porta em `PHANTOM_WEB_PORT`, padrão 8787).
mod session;
mod uploads;

use std::net::SocketAddr;
use std::path::{Component, Path as FsPath, PathBuf};
use std::sync::{Arc, Mutex};
use std::time::Duration;

use axum::body::Bytes;
use axum::extract::{ConnectInfo, DefaultBodyLimit, Path, State};
use axum::http::{header, HeaderMap, HeaderValue, StatusCode, Uri};
use axum::response::{IntoResponse, Response};
use axum::routing::{get, post};
use axum::Router;
use tauri::{AppHandle, Manager, Runtime};

use crate::commands::ctx::Ctx;
use crate::commands::system::AppPaths;
use crate::database::Database;
use crate::error::{AppError, AppResult};
use crate::security::session::SessionState;
use crate::security::vault::Vault;
use session::{Limiter, Sessions};
use uploads::Uploads;

const COOKIE: &str = "phantom_sid";
const MAX_BODY: usize = 25 * 1024 * 1024;
const LOGIN_WINDOW: Duration = Duration::from_secs(15 * 60);
const LOGIN_MAX_ATTEMPTS: usize = 10;

/// O que o servidor precisa do app hospedeiro; permite testar sem janela/Tauri.
trait Backend: Send + Sync + 'static {
    fn with_ctx(&self, session: &SessionState, f: &mut dyn FnMut(&Ctx));
    fn asset(&self, path: &str) -> Option<(Vec<u8>, String)>;
    fn data_dir(&self) -> PathBuf;
}

impl<R: Runtime> Backend for AppHandle<R> {
    fn with_ctx(&self, session: &SessionState, f: &mut dyn FnMut(&Ctx)) {
        let db = self.state::<Database>();
        let vault = self.state::<Vault>();
        let paths = self.state::<AppPaths>();
        f(&Ctx { db: &db, vault: &vault, session, paths: &paths });
    }

    fn data_dir(&self) -> PathBuf {
        self.state::<AppPaths>().data_dir.clone()
    }

    fn asset(&self, path: &str) -> Option<(Vec<u8>, String)> {
        self.asset_resolver().get(path.to_string()).map(|a| (a.bytes, a.mime_type))
    }
}

struct WebApp {
    backend: Box<dyn Backend>,
    sessions: Sessions,
    login_limiter: Mutex<Limiter>,
    uploads: Uploads,
    dist_dir: Option<PathBuf>,
}

fn new_app(backend: impl Backend, dist_dir: Option<PathBuf>) -> Arc<WebApp> {
    let uploads = Uploads::new(backend.data_dir().join("web-uploads"));
    Arc::new(WebApp { backend: Box::new(backend), sessions: Sessions::default(), login_limiter: Mutex::new(Limiter::default()), uploads, dist_dir })
}

fn router(app: Arc<WebApp>) -> Router {
    Router::new()
        .route("/healthz", get(|| async { "ok" }))
        .route("/api/{cmd}", post(api))
        .route("/upload", post(upload))
        .fallback(get(static_file))
        .layer(DefaultBodyLimit::max(MAX_BODY))
        .layer(axum::middleware::map_response(security_headers))
        .with_state(app)
}

/// Inicia o servidor se `PHANTOM_WEB=1`. Não faz nada (e não abre porta) caso contrário.
pub fn start_if_enabled<R: Runtime>(handle: AppHandle<R>) {
    if std::env::var("PHANTOM_WEB").as_deref() != Ok("1") {
        return;
    }
    let port: u16 = std::env::var("PHANTOM_WEB_PORT").ok().and_then(|p| p.parse().ok()).unwrap_or(8787);
    let app = new_app(handle, std::env::var("PHANTOM_WEB_DIST").ok().map(PathBuf::from));
    tauri::async_runtime::spawn(async move {
        let addr = SocketAddr::from(([127, 0, 0, 1], port));
        match tokio::net::TcpListener::bind(addr).await {
            Ok(listener) => {
                eprintln!("[web] modo web ativo em http://{addr} (somente local; exponha via túnel)");
                if let Err(e) = axum::serve(listener, router(app).into_make_service_with_connect_info::<SocketAddr>()).await {
                    eprintln!("[web] servidor encerrado: {e}");
                }
            }
            Err(e) => eprintln!("[web] não foi possível abrir {addr}: {e}"),
        }
    });
}

async fn security_headers(mut res: Response) -> Response {
    let h = res.headers_mut();
    h.insert("x-content-type-options", HeaderValue::from_static("nosniff"));
    h.insert("x-frame-options", HeaderValue::from_static("DENY"));
    h.insert("referrer-policy", HeaderValue::from_static("no-referrer"));
    h.insert("cross-origin-opener-policy", HeaderValue::from_static("same-origin"));
    h.insert("strict-transport-security", HeaderValue::from_static("max-age=31536000"));
    res
}

fn json_response(status: StatusCode, body: &serde_json::Value, cookie: Option<String>) -> Response {
    let mut res = (status, [(header::CONTENT_TYPE, "application/json")], body.to_string()).into_response();
    res.headers_mut().insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    if let Some(c) = cookie.and_then(|c| HeaderValue::from_str(&c).ok()) {
        res.headers_mut().append(header::SET_COOKIE, c);
    }
    res
}

fn error_response(status: StatusCode, msg: &str) -> Response {
    json_response(status, &serde_json::Value::String(msg.into()), None)
}

fn status_for(e: &AppError) -> StatusCode {
    match e {
        AppError::Unauthenticated | AppError::InvalidCredentials => StatusCode::UNAUTHORIZED,
        AppError::Forbidden | AppError::Inactive => StatusCode::FORBIDDEN,
        AppError::Locked(_) => StatusCode::TOO_MANY_REQUESTS,
        AppError::Internal(_) => StatusCode::INTERNAL_SERVER_ERROR,
        AppError::Validation(_) | AppError::AlreadyConfigured => StatusCode::BAD_REQUEST,
    }
}

fn host_of(origin: &str) -> &str {
    origin.split("://").last().unwrap_or(origin).trim_end_matches('/')
}

/// IP real do cliente: o túnel roda localmente, então só ele pode preencher estes cabeçalhos.
fn client_ip(headers: &HeaderMap, peer: SocketAddr) -> String {
    let h = |n: &str| headers.get(n).and_then(|v| v.to_str().ok()).map(|v| v.split(',').next().unwrap_or("").trim().to_string());
    h("cf-connecting-ip").or_else(|| h("x-forwarded-for")).filter(|s| !s.is_empty()).unwrap_or_else(|| peer.ip().to_string())
}

/// Conexão segura: o túnel avisa por `X-Forwarded-Proto`; qualquer Host que não seja local também conta.
fn is_https(headers: &HeaderMap) -> bool {
    let forwarded = headers.get("x-forwarded-proto").and_then(|v| v.to_str().ok()).is_some_and(|v| v.eq_ignore_ascii_case("https"));
    let host = headers.get(header::HOST).and_then(|v| v.to_str().ok()).unwrap_or("");
    let local = host.starts_with("127.0.0.1") || host.starts_with("localhost") || host.starts_with("[::1]");
    forwarded || !local
}

fn cookie_token(headers: &HeaderMap) -> Option<String> {
    let raw = headers.get(header::COOKIE)?.to_str().ok()?;
    raw.split(';').filter_map(|kv| kv.trim().split_once('=')).find(|(k, _)| *k == COOKIE).map(|(_, v)| v.to_string())
}

enum CookieAction {
    None,
    Set(String),
    Clear,
}

/// Defesa contra CSRF: cabeçalho próprio (força preflight CORS) e Origin igual ao Host.
fn guard(headers: &HeaderMap) -> Option<Response> {
    if headers.get("x-requested-with").and_then(|v| v.to_str().ok()) != Some("phantom") {
        return Some(error_response(StatusCode::FORBIDDEN, "Requisição não permitida."));
    }
    if let Some(origin) = headers.get(header::ORIGIN).and_then(|v| v.to_str().ok()) {
        let host = headers.get(header::HOST).and_then(|v| v.to_str().ok()).unwrap_or("");
        if host_of(origin) != host {
            return Some(error_response(StatusCode::FORBIDDEN, "Origem não permitida."));
        }
    }
    None
}

/// Recebe um arquivo do navegador (corpo bruto; nome em `X-File-Name`, codificado em URL) e devolve a
/// referência `upload:...` que os comandos aceitam no lugar de um caminho. Exige sessão autenticada.
async fn upload(State(app): State<Arc<WebApp>>, headers: HeaderMap, body: Bytes) -> Response {
    if let Some(rejected) = guard(&headers) {
        return rejected;
    }
    let name = headers.get("x-file-name").and_then(|v| v.to_str().ok()).map(percent_decode).unwrap_or_default();
    let Some(token) = cookie_token(&headers) else {
        return error_response(StatusCode::UNAUTHORIZED, "Sessão não iniciada.");
    };
    let result = tokio::task::spawn_blocking(move || -> AppResult<String> {
        app.sessions.get(&token).ok_or(AppError::Unauthenticated)?.user()?;
        app.uploads.stage(&token, &name, &body)
    })
    .await;
    match result {
        Ok(Ok(reference)) => json_response(StatusCode::OK, &serde_json::json!({ "path": reference }), None),
        Ok(Err(e)) => json_response(status_for(&e), &serde_json::Value::String(e.to_string()), None),
        Err(_) => error_response(StatusCode::INTERNAL_SERVER_ERROR, "Erro interno. Consulte os registros do sistema."),
    }
}

fn percent_decode(s: &str) -> String {
    let b = s.as_bytes();
    let mut out = Vec::with_capacity(b.len());
    let mut i = 0;
    while i < b.len() {
        if b[i] == b'%' && i + 2 < b.len() {
            if let Ok(v) = u8::from_str_radix(&s[i + 1..i + 3], 16) {
                out.push(v);
                i += 3;
                continue;
            }
        }
        out.push(b[i]);
        i += 1;
    }
    String::from_utf8_lossy(&out).into_owned()
}

/// Troca referências `upload:...` (em qualquer ponto do JSON) pelo caminho real do arquivo enviado
/// por esta sessão. Referência desconhecida ou de outra sessão é erro.
fn resolve_uploads(v: &mut serde_json::Value, uploads: &Uploads, session: &str, used: &mut Vec<String>) -> AppResult<()> {
    match v {
        serde_json::Value::String(s) if s.starts_with(uploads::PREFIX) => {
            let real = uploads
                .resolve(session, s)
                .ok_or_else(|| AppError::Validation("Arquivo enviado não encontrado ou expirado. Envie novamente.".into()))?;
            used.push(std::mem::replace(s, real.to_string_lossy().into_owned()));
        }
        serde_json::Value::Array(a) => a.iter_mut().try_for_each(|x| resolve_uploads(x, uploads, session, used))?,
        serde_json::Value::Object(o) => o.values_mut().try_for_each(|x| resolve_uploads(x, uploads, session, used))?,
        _ => {}
    }
    Ok(())
}

async fn api(
    State(app): State<Arc<WebApp>>,
    ConnectInfo(peer): ConnectInfo<SocketAddr>,
    Path(cmd): Path<String>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    if let Some(rejected) = guard(&headers) {
        return rejected;
    }
    let args: serde_json::Value = if body.is_empty() {
        serde_json::Value::Null
    } else {
        match serde_json::from_slice(&body) {
            Ok(v) => v,
            Err(_) => return error_response(StatusCode::BAD_REQUEST, "Corpo da requisição inválido."),
        }
    };

    let ip = client_ip(&headers, peer);
    if cmd == "login" {
        let blocked = app.login_limiter.lock().map(|mut l| !l.allow(&ip, LOGIN_MAX_ATTEMPTS, LOGIN_WINDOW)).unwrap_or(true);
        if blocked {
            return error_response(StatusCode::TOO_MANY_REQUESTS, "Muitas tentativas de acesso. Aguarde alguns minutos.");
        }
    }

    let token = cookie_token(&headers);
    let secure = is_https(&headers);
    let a = app.clone();
    let (result, action) = match tokio::task::spawn_blocking(move || execute(&a, token.as_deref(), &cmd, args)).await {
        Ok(r) => r,
        Err(_) => return error_response(StatusCode::INTERNAL_SERVER_ERROR, "Erro interno. Consulte os registros do sistema."),
    };
    if matches!(action, CookieAction::Set(_)) {
        if let Ok(mut l) = app.login_limiter.lock() {
            l.reset(&ip);
        }
    }
    let secure_attr = if secure { "; Secure" } else { "" };
    let cookie = match action {
        CookieAction::None => None,
        CookieAction::Set(t) => Some(format!(
            "{COOKIE}={t}; HttpOnly; SameSite=Strict; Path=/; Max-Age={}{secure_attr}",
            session::ABSOLUTE_TTL.as_secs()
        )),
        CookieAction::Clear => Some(format!("{COOKIE}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0{secure_attr}")),
    };
    match result {
        Ok(v) => json_response(StatusCode::OK, &v, cookie),
        Err(e) => {
            if let AppError::Internal(d) = &e {
                eprintln!("[web] erro interno: {d}");
            }
            json_response(status_for(&e), &serde_json::Value::String(e.to_string()), cookie)
        }
    }
}

/// Executa um comando (bloqueante) no contexto da sessão do navegador.
fn execute(app: &WebApp, token: Option<&str>, cmd: &str, mut args: serde_json::Value) -> (AppResult<serde_json::Value>, CookieAction) {
    // Nesta thread, leituras de arquivo só enxergam a pasta de uploads e nenhuma escrita em disco é permitida.
    let _scope = crate::security::fs_scope::WebScope::enter(app.uploads.root());
    let mut used = Vec::new();
    if let Err(e) = resolve_uploads(&mut args, &app.uploads, token.unwrap_or(""), &mut used) {
        return (Err(e), CookieAction::None);
    }
    let run = |session: &SessionState| {
        let mut out = None;
        app.backend.with_ctx(session, &mut |ctx| out = Some(crate::commands::web::dispatch(cmd, ctx, args.clone())));
        out.flatten()
    };
    let unknown = || Err(AppError::Validation("Comando desconhecido.".into()));

    match cmd {
        // Cada login cria uma sessão nova (evita fixação de sessão); só vale se as credenciais conferirem.
        "login" => {
            let fresh = Arc::new(SessionState::default());
            match run(&fresh) {
                Some(Ok(v)) => {
                    if let Some(old) = token {
                        app.sessions.remove(old);
                    }
                    let t = app.sessions.insert(fresh);
                    (Ok(v), CookieAction::Set(t))
                }
                Some(Err(e)) => (Err(e), CookieAction::None),
                None => (unknown(), CookieAction::None),
            }
        }
        "logout" => {
            let r = match token.and_then(|t| app.sessions.get(t)) {
                Some(s) => run(&s).unwrap_or_else(unknown),
                None => Ok(serde_json::Value::Null),
            };
            if let Some(t) = token {
                app.sessions.remove(t);
                app.uploads.purge_session(t);
            }
            (r, CookieAction::Clear)
        }
        _ => {
            let session = token.and_then(|t| app.sessions.get(t)).unwrap_or_default();
            let r = run(&session).unwrap_or_else(unknown);
            // Arquivo anexado com sucesso é descartado; a pré-visualização o mantém até o cadastro terminar.
            if r.is_ok() && cmd != "local_image_preview" {
                used.iter().for_each(|u| app.uploads.consume(token.unwrap_or(""), u));
            }
            (r, CookieAction::None)
        }
    }
}

// ----------------------------------------------------------------------------------- arquivos estáticos

const CSP: &str = "default-src 'self'; img-src 'self' data: blob:; frame-src 'self' blob:; object-src 'none'; style-src 'self' 'unsafe-inline'; font-src 'self' data:; connect-src 'self' blob:; base-uri 'self'; form-action 'self'; frame-ancestors 'none'";

fn mime_for(path: &str) -> &'static str {
    match path.rsplit('.').next().unwrap_or("") {
        "html" => "text/html; charset=utf-8",
        "js" | "mjs" => "text/javascript",
        "css" => "text/css",
        "json" => "application/json",
        "svg" => "image/svg+xml",
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "webp" => "image/webp",
        "woff2" => "font/woff2",
        "woff" => "font/woff",
        "ico" => "image/x-icon",
        _ => "application/octet-stream",
    }
}

fn read_asset(app: &WebApp, path: &str) -> Option<(Vec<u8>, String)> {
    if let Some(found) = app.backend.asset(path) {
        return Some(found);
    }
    // Alternativa para desenvolvimento: pasta `dist` indicada em PHANTOM_WEB_DIST.
    let dir = app.dist_dir.as_deref()?;
    let rel = FsPath::new(path);
    if rel.components().any(|c| !matches!(c, Component::Normal(_))) {
        return None;
    }
    std::fs::read(dir.join(rel)).ok().map(|b| (b, mime_for(path).to_string()))
}

async fn static_file(State(app): State<Arc<WebApp>>, uri: Uri) -> Response {
    let path = uri.path().trim_start_matches('/');
    let path = if path.is_empty() { "index.html" } else { path };
    let found = read_asset(&app, path).or_else(|| {
        // Rotas do React Router (sem extensão) caem no index.html.
        if path.rsplit('/').next().is_some_and(|f| f.contains('.')) {
            None
        } else {
            read_asset(&app, "index.html")
        }
    });
    match found {
        Some((bytes, mime)) => {
            let mut res = (StatusCode::OK, [(header::CONTENT_TYPE, mime.clone())], bytes).into_response();
            let h = res.headers_mut();
            if mime.starts_with("text/html") {
                h.insert(header::CONTENT_SECURITY_POLICY, HeaderValue::from_static(CSP));
                h.insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
            }
            res
        }
        None => error_response(StatusCode::NOT_FOUND, "Não encontrado."),
    }
}

#[cfg(test)]
mod tests;
