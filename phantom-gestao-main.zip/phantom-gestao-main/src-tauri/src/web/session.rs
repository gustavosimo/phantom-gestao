//! Sessões web em memória (somem ao fechar o app) e limitador de tentativas.
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use aes_gcm::aead::rand_core::RngCore;
use aes_gcm::aead::OsRng;

use crate::security::session::SessionState;

/// Inatividade máxima e duração total de uma sessão web.
pub const IDLE_TTL: Duration = Duration::from_secs(30 * 60);
pub const ABSOLUTE_TTL: Duration = Duration::from_secs(12 * 60 * 60);

struct Entry {
    session: Arc<SessionState>,
    created: Instant,
    last: Instant,
}

#[derive(Default)]
pub struct Sessions {
    map: Mutex<HashMap<String, Entry>>,
}

fn new_token() -> String {
    let mut b = [0u8; 32];
    OsRng.fill_bytes(&mut b);
    b.iter().map(|x| format!("{x:02x}")).collect()
}

impl Sessions {
    pub fn insert(&self, session: Arc<SessionState>) -> String {
        let now = Instant::now();
        let token = new_token();
        if let Ok(mut m) = self.map.lock() {
            m.retain(|_, e| Self::alive(e, now));
            m.insert(token.clone(), Entry { session, created: now, last: now });
        }
        token
    }

    fn alive(e: &Entry, now: Instant) -> bool {
        now.duration_since(e.last) < IDLE_TTL && now.duration_since(e.created) < ABSOLUTE_TTL
    }

    /// Retorna a sessão se ainda válida, renovando o prazo de inatividade.
    pub fn get(&self, token: &str) -> Option<Arc<SessionState>> {
        let mut m = self.map.lock().ok()?;
        let now = Instant::now();
        match m.get_mut(token) {
            Some(e) if Self::alive(e, now) => {
                e.last = now;
                Some(e.session.clone())
            }
            Some(_) => {
                m.remove(token);
                None
            }
            None => None,
        }
    }

    pub fn remove(&self, token: &str) {
        if let Ok(mut m) = self.map.lock() {
            m.remove(token);
        }
    }
}

/// Janela deslizante de tentativas por chave (IP).
#[derive(Default)]
pub struct Limiter {
    hits: HashMap<String, Vec<Instant>>,
}

impl Limiter {
    /// Registra uma tentativa; retorna `false` quando o limite da janela já foi atingido.
    pub fn allow(&mut self, key: &str, max: usize, window: Duration) -> bool {
        let now = Instant::now();
        self.hits.retain(|_, v| v.last().is_some_and(|t| now.duration_since(*t) < window));
        let v = self.hits.entry(key.to_string()).or_default();
        v.retain(|t| now.duration_since(*t) < window);
        if v.len() >= max {
            return false;
        }
        v.push(now);
        true
    }

    pub fn reset(&mut self, key: &str) {
        self.hits.remove(key);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn limiter_blocks_after_max_and_resets() {
        let mut l = Limiter::default();
        let w = Duration::from_secs(60);
        for _ in 0..3 {
            assert!(l.allow("1.1.1.1", 3, w));
        }
        assert!(!l.allow("1.1.1.1", 3, w));
        assert!(l.allow("2.2.2.2", 3, w), "outro IP não é afetado");
        l.reset("1.1.1.1");
        assert!(l.allow("1.1.1.1", 3, w));
    }

    #[test]
    fn sessions_are_isolated_and_removable() {
        let s = Sessions::default();
        let a = s.insert(Arc::new(SessionState::default()));
        let b = s.insert(Arc::new(SessionState::default()));
        assert_ne!(a, b);
        assert_eq!(a.len(), 64);
        assert!(s.get(&a).is_some());
        s.remove(&a);
        assert!(s.get(&a).is_none());
        assert!(s.get(&b).is_some());
        assert!(s.get("inexistente").is_none());
    }
}
