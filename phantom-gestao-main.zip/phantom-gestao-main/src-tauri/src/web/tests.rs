//! Testes de ponta a ponta do servidor web: HTTP real contra o roteador, com app Tauri simulado e banco em memória.
use std::collections::HashMap;
use std::net::SocketAddr;

use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};

use super::*;
use crate::testutil::env;

struct Resp {
    status: u16,
    headers: HashMap<String, Vec<String>>,
    body: String,
}

impl Resp {
    fn header(&self, name: &str) -> Option<&str> {
        self.headers.get(name).and_then(|v| v.first()).map(String::as_str)
    }
}

struct TestBackend {
    db: Database,
    vault: Vault,
    paths: AppPaths,
}

impl Backend for TestBackend {
    fn with_ctx(&self, session: &SessionState, f: &mut dyn FnMut(&Ctx)) {
        f(&Ctx { db: &self.db, vault: &self.vault, session, paths: &self.paths });
    }

    fn asset(&self, _path: &str) -> Option<(Vec<u8>, String)> {
        None
    }

    fn data_dir(&self) -> PathBuf {
        self.paths.data_dir.clone()
    }
}

struct Server {
    addr: SocketAddr,
    data_dir: PathBuf,
}

async fn spawn_server(dist: Option<PathBuf>) -> Server {
    let e = env();
    static N: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
    let data_dir = std::env::temp_dir().join(format!("phantom-web-test-{}-{}", std::process::id(), N.fetch_add(1, std::sync::atomic::Ordering::SeqCst)));
    std::fs::create_dir_all(&data_dir).unwrap();
    let web = new_app(TestBackend { db: e.db, vault: e.vault, paths: AppPaths { data_dir: data_dir.clone() } }, dist);
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap();
    tokio::spawn(async move {
        axum::serve(listener, router(web).into_make_service_with_connect_info::<SocketAddr>()).await.unwrap();
    });
    Server { addr, data_dir }
}

async fn http(addr: SocketAddr, method: &str, path: &str, headers: &[(&str, &str)], body: &str) -> Resp {
    let host = if headers.iter().any(|(k, _)| k.eq_ignore_ascii_case("host")) { String::new() } else { format!("Host: {addr}\r\n") };
    let mut req = format!("{method} {path} HTTP/1.1\r\n{host}Connection: close\r\nContent-Length: {}\r\n", body.len());
    for (k, v) in headers {
        req.push_str(&format!("{k}: {v}\r\n"));
    }
    req.push_str("\r\n");
    req.push_str(body);
    let mut s = TcpStream::connect(addr).await.unwrap();
    s.write_all(req.as_bytes()).await.unwrap();
    let mut raw = Vec::new();
    s.read_to_end(&mut raw).await.unwrap();
    let text = String::from_utf8_lossy(&raw).to_string();
    let (head, body) = text.split_once("\r\n\r\n").unwrap_or((&text, ""));
    let mut lines = head.lines();
    let status: u16 = lines.next().unwrap().split_whitespace().nth(1).unwrap().parse().unwrap();
    let mut map: HashMap<String, Vec<String>> = HashMap::new();
    for l in lines {
        if let Some((k, v)) = l.split_once(':') {
            map.entry(k.trim().to_lowercase()).or_default().push(v.trim().to_string());
        }
    }
    Resp { status, headers: map, body: body.to_string() }
}

const API: &[(&str, &str)] = &[("X-Requested-With", "phantom"), ("Content-Type", "application/json")];

async fn call(addr: SocketAddr, cmd: &str, cookie: Option<&str>, body: &str) -> Resp {
    let mut h: Vec<(&str, &str)> = API.to_vec();
    let c;
    if let Some(ck) = cookie {
        c = format!("{COOKIE}={ck}");
        h.push(("Cookie", &c));
    }
    http(addr, "POST", &format!("/api/{cmd}"), &h, body).await
}

fn session_cookie(r: &Resp) -> String {
    let sc = r.headers.get("set-cookie").and_then(|v| v.first()).expect("Set-Cookie ausente");
    sc.split(';').next().unwrap().strip_prefix(&format!("{COOKIE}=")).unwrap().to_string()
}

const LOGIN_OK: &str = r#"{"username":"admin","password":"senhaforte123"}"#;

#[tokio::test]
async fn rejects_requests_without_csrf_header_or_with_foreign_origin() {
    let s = spawn_server(None).await;
    let r = http(s.addr, "POST", "/api/current_user", &[("Content-Type", "application/json")], "{}").await;
    assert_eq!(r.status, 403);
    let r = http(s.addr, "POST", "/api/current_user", &[("X-Requested-With", "phantom"), ("Origin", "https://evil.example")], "{}").await;
    assert_eq!(r.status, 403);
    let origin = format!("http://{}", s.addr);
    let r = http(s.addr, "POST", "/api/current_user", &[("X-Requested-With", "phantom"), ("Origin", &origin)], "{}").await;
    assert_eq!(r.status, 200);
}

#[tokio::test]
async fn login_session_cookie_and_logout_flow() {
    let s = spawn_server(None).await;

    // sem sessão: nada protegido passa, e o usuário atual é nulo
    assert_eq!(call(s.addr, "users_list", None, "{}").await.status, 401);
    assert_eq!(call(s.addr, "current_user", None, "{}").await.body, "null");

    // credenciais erradas: 401 e nenhum cookie
    let bad = call(s.addr, "login", None, r#"{"username":"admin","password":"errada"}"#).await;
    assert_eq!(bad.status, 401);
    assert!(bad.header("set-cookie").is_none());

    // login correto: cookie HttpOnly + SameSite=Strict, sem Secure em HTTP puro
    let ok = call(s.addr, "login", None, LOGIN_OK).await;
    assert_eq!(ok.status, 200, "{}", ok.body);
    let sc = ok.header("set-cookie").unwrap();
    assert!(sc.contains("HttpOnly") && sc.contains("SameSite=Strict") && sc.contains("Path=/"), "{sc}");
    assert!(!sc.contains("Secure"));
    let cookie = session_cookie(&ok);
    assert_eq!(cookie.len(), 64);

    // com o cookie: usuário reconhecido e comando protegido autorizado
    let me = call(s.addr, "current_user", Some(&cookie), "{}").await;
    assert!(me.body.contains("\"username\":\"admin\""), "{}", me.body);
    assert_eq!(call(s.addr, "users_list", Some(&cookie), "{}").await.status, 200);
    // cookie inventado não vale
    assert_eq!(call(s.addr, "users_list", Some(&"0".repeat(64)), "{}").await.status, 401);

    // atrás do túnel (HTTPS) o cookie ganha Secure
    let hs = http(s.addr, "POST", "/api/login", &[("X-Requested-With", "phantom"), ("X-Forwarded-Proto", "https")], LOGIN_OK).await;
    assert!(hs.header("set-cookie").unwrap().contains("Secure"));
    // Host público (sem o cabeçalho do túnel) também ganha Secure
    let hp = http(s.addr, "POST", "/api/login", &[("X-Requested-With", "phantom"), ("Host", "gestao.exemplo.com")], LOGIN_OK).await;
    assert!(hp.header("set-cookie").unwrap().contains("Secure"));

    // logout encerra a sessão no servidor e limpa o cookie
    let out = call(s.addr, "logout", Some(&cookie), "{}").await;
    assert_eq!(out.status, 200);
    assert!(out.header("set-cookie").unwrap().contains("Max-Age=0"));
    assert_eq!(call(s.addr, "users_list", Some(&cookie), "{}").await.status, 401);
}

#[tokio::test]
async fn blocked_and_unknown_commands() {
    let s = spawn_server(None).await;
    let ck = session_cookie(&call(s.addr, "login", None, LOGIN_OK).await);
    // gravar em caminho do servidor jamais é permitido pela web
    let r = call(s.addr, "attachment_save_to", Some(&ck), r#"{"id":1,"path":"C:/x.bin"}"#).await;
    assert_eq!(r.status, 400);
    assert!(r.body.contains("apenas no aplicativo desktop"), "{}", r.body);
    // configuração inicial só no desktop (evita que um visitante crie o administrador)
    let r = call(s.addr, "setup_admin", None, r#"{"fullName":"X","username":"x","password":"yyyyyyyyyy"}"#).await;
    assert_eq!(r.status, 400);
    let r = call(s.addr, "nao_existe", Some(&ck), "{}").await;
    assert_eq!(r.status, 400);
    // corpo que não é JSON
    assert_eq!(call(s.addr, "login", None, "{oops").await.status, 400);
}

#[tokio::test]
async fn login_is_rate_limited_per_ip() {
    let s = spawn_server(None).await;
    // usuários distintos para não acionar o bloqueio por usuário; só o limite por IP
    for i in 0..LOGIN_MAX_ATTEMPTS {
        let r = call(s.addr, "login", None, &format!(r#"{{"username":"u{i}","password":"x"}}"#)).await;
        assert_eq!(r.status, 401, "tentativa {i}");
    }
    let r = call(s.addr, "login", None, LOGIN_OK).await;
    assert_eq!(r.status, 429, "mesmo com a senha certa, o IP está bloqueado");
    // outro IP (cabeçalho do túnel) não é afetado
    let h = [("X-Requested-With", "phantom"), ("CF-Connecting-IP", "203.0.113.9")];
    assert_eq!(http(s.addr, "POST", "/api/login", &h, LOGIN_OK).await.status, 200);
}

#[tokio::test]
async fn serves_frontend_with_spa_fallback_and_blocks_traversal() {
    let dir = std::env::temp_dir().join(format!("phantom-web-dist-{}", std::process::id()));
    std::fs::create_dir_all(dir.join("assets")).unwrap();
    std::fs::write(dir.join("index.html"), "<html>phantom</html>").unwrap();
    std::fs::write(dir.join("assets/app.js"), "console.log(1)").unwrap();
    std::fs::write(dir.parent().unwrap().join("phantom-web-secret.txt"), "segredo").unwrap();
    let s = spawn_server(Some(dir)).await;

    let r = http(s.addr, "GET", "/", &[], "").await;
    assert_eq!(r.status, 200);
    assert!(r.body.contains("phantom"));
    assert!(r.header("content-security-policy").unwrap().contains("frame-ancestors 'none'"));
    assert_eq!(r.header("x-frame-options"), Some("DENY"));
    assert_eq!(r.header("x-content-type-options"), Some("nosniff"));
    // rota do React Router
    assert!(http(s.addr, "GET", "/clientes/12", &[], "").await.body.contains("phantom"));
    let js = http(s.addr, "GET", "/assets/app.js", &[], "").await;
    assert_eq!(js.header("content-type"), Some("text/javascript"));
    // arquivo com extensão inexistente não vira index.html
    assert_eq!(http(s.addr, "GET", "/assets/missing.js", &[], "").await.status, 404);
    // não sai da pasta do frontend
    for p in ["/../phantom-web-secret.txt", "/..%2fphantom-web-secret.txt", "/assets/../../phantom-web-secret.txt"] {
        let r = http(s.addr, "GET", p, &[], "").await;
        assert!(!r.body.contains("segredo"), "vazou por {p}");
    }
    assert_eq!(http(s.addr, "GET", "/healthz", &[], "").await.body, "ok");
}

async fn upload(addr: SocketAddr, cookie: Option<&str>, name: &str, body: &[u8]) -> Resp {
    // corpo binário: monta a requisição manualmente
    let mut head = format!("POST /upload HTTP/1.1\r\nHost: {addr}\r\nConnection: close\r\nX-Requested-With: phantom\r\nX-File-Name: {name}\r\nContent-Length: {}\r\n", body.len());
    if let Some(c) = cookie {
        head.push_str(&format!("Cookie: {COOKIE}={c}\r\n"));
    }
    head.push_str("\r\n");
    let mut s = TcpStream::connect(addr).await.unwrap();
    s.write_all(head.as_bytes()).await.unwrap();
    s.write_all(body).await.unwrap();
    let mut raw = Vec::new();
    s.read_to_end(&mut raw).await.unwrap();
    let text = String::from_utf8_lossy(&raw).to_string();
    let (head, body) = text.split_once("\r\n\r\n").unwrap_or((&text, ""));
    let status: u16 = head.lines().next().unwrap().split_whitespace().nth(1).unwrap().parse().unwrap();
    Resp { status, headers: HashMap::new(), body: body.to_string() }
}

fn upload_ref(r: &Resp) -> String {
    serde_json::from_str::<serde_json::Value>(&r.body).unwrap()["path"].as_str().unwrap().to_string()
}

#[tokio::test]
async fn upload_flow_is_authenticated_scoped_and_per_session() {
    let s = spawn_server(None).await;
    let png = b"\x89PNG\r\n\x1a\nconteudo";

    // sem login não envia nada
    assert_eq!(upload(s.addr, None, "a.png", png).await.status, 401);
    let a = session_cookie(&call(s.addr, "login", None, LOGIN_OK).await);
    let b = session_cookie(&call(s.addr, "login", None, LOGIN_OK).await);

    // tipos perigosos são recusados; nome com caminho é reduzido ao nome do arquivo
    assert_eq!(upload(s.addr, Some(&a), "virus.exe", b"MZ").await.status, 400);
    let r = upload(s.addr, Some(&a), "..%5C..%5CWindows%5Cfoto%20da%20loja.png", png).await;
    assert_eq!(r.status, 200, "{}", r.body);
    let reference = upload_ref(&r);
    assert!(reference.starts_with("upload:") && reference.ends_with("/foto da loja.png"), "{reference}");

    // a sessão dona usa a referência (a imagem volta como data URL); a outra sessão não enxerga
    let body = serde_json::json!({ "path": reference }).to_string();
    let ok = call(s.addr, "local_image_preview", Some(&a), &body).await;
    assert_eq!(ok.status, 200, "{}", ok.body);
    assert!(ok.body.contains("data:image/png;base64,"));
    assert_eq!(call(s.addr, "local_image_preview", Some(&b), &body).await.status, 400);

    // caminho cru do disco do servidor é recusado, mesmo existindo
    let outside = s.data_dir.join("segredo.png");
    std::fs::write(&outside, png).unwrap();
    let raw = serde_json::json!({ "path": outside.to_string_lossy() }).to_string();
    assert_eq!(call(s.addr, "local_image_preview", Some(&a), &raw).await.status, 403);
    // referência forjada apontando para fora
    let forged = serde_json::json!({ "path": "upload:../../segredo.png" }).to_string();
    assert_eq!(call(s.addr, "local_image_preview", Some(&a), &forged).await.status, 400);

    // logout apaga os envios da sessão
    call(s.addr, "logout", Some(&a), "{}").await;
    assert_eq!(std::fs::read_dir(s.data_dir.join("web-uploads")).unwrap().count(), 0);
}
