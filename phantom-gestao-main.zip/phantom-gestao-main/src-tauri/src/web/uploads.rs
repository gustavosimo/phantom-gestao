//! Área de upload do modo web. O navegador envia o arquivo para `/upload` e recebe uma referência
//! `upload:<token>/<nome>`; os comandos usam essa referência no lugar de um caminho do disco.
//! A referência só vale para a sessão que enviou, expira e é descartada ao ser usada.
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Mutex;
use std::time::{Duration, Instant};

use aes_gcm::aead::rand_core::RngCore;
use aes_gcm::aead::OsRng;

use crate::error::{AppError, AppResult};

pub const PREFIX: &str = "upload:";
const TTL: Duration = Duration::from_secs(2 * 60 * 60);
const MAX_PER_SESSION: usize = 30;
const ALLOWED_EXT: &[&str] = &["pdf", "png", "jpg", "jpeg", "webp", "gif", "bmp"];

struct Staged {
    session: String,
    dir: PathBuf,
    created: Instant,
}

pub struct Uploads {
    root: PathBuf,
    map: Mutex<HashMap<String, Staged>>,
}

/// Mantém só o nome do arquivo, sem separadores, caracteres de controle ou `:`.
fn sanitize(name: &str) -> String {
    let base = name.rsplit(['/', '\\']).next().unwrap_or("");
    let clean: String = base.chars().filter(|c| !c.is_control() && !matches!(c, ':' | '*' | '?' | '"' | '<' | '>' | '|')).collect();
    clean.trim().trim_start_matches('.').chars().take(120).collect()
}

impl Uploads {
    /// Cria a pasta de uploads, descartando sobras de execuções anteriores.
    pub fn new(root: PathBuf) -> Self {
        let _ = std::fs::remove_dir_all(&root);
        let _ = std::fs::create_dir_all(&root);
        Self { root, map: Mutex::new(HashMap::new()) }
    }

    pub fn root(&self) -> &Path {
        &self.root
    }

    pub fn stage(&self, session: &str, name: &str, bytes: &[u8]) -> AppResult<String> {
        let name = sanitize(name);
        let ext = name.rsplit('.').next().unwrap_or("").to_lowercase();
        if name.is_empty() || !name.contains('.') || !ALLOWED_EXT.contains(&ext.as_str()) {
            return Err(AppError::Validation("Tipo de arquivo não permitido. Envie PDF ou imagem (PNG, JPG, WEBP).".into()));
        }
        if bytes.is_empty() {
            return Err(AppError::Validation("Arquivo vazio.".into()));
        }
        let mut map = self.map.lock().map_err(|_| AppError::Internal("uploads indisponível".into()))?;
        let now = Instant::now();
        map.retain(|_, s| {
            let keep = now.duration_since(s.created) < TTL;
            if !keep {
                let _ = std::fs::remove_dir_all(&s.dir);
            }
            keep
        });
        if map.values().filter(|s| s.session == session).count() >= MAX_PER_SESSION {
            return Err(AppError::Validation("Muitos arquivos pendentes. Conclua o cadastro atual e tente de novo.".into()));
        }
        let mut raw = [0u8; 16];
        OsRng.fill_bytes(&mut raw);
        let token: String = raw.iter().map(|b| format!("{b:02x}")).collect();
        let dir = self.root.join(&token);
        std::fs::create_dir_all(&dir).map_err(|e| AppError::Internal(e.to_string()))?;
        std::fs::write(dir.join(&name), bytes).map_err(|e| AppError::Internal(e.to_string()))?;
        map.insert(token.clone(), Staged { session: session.to_string(), dir, created: now });
        Ok(format!("{PREFIX}{token}/{name}"))
    }

    /// Caminho real do arquivo enviado por esta sessão, se ainda existir.
    pub fn resolve(&self, session: &str, reference: &str) -> Option<PathBuf> {
        let rest = reference.strip_prefix(PREFIX)?;
        let (token, name) = rest.split_once('/')?;
        let map = self.map.lock().ok()?;
        let s = map.get(token).filter(|s| s.session == session)?;
        let p = s.dir.join(sanitize(name));
        p.is_file().then_some(p)
    }

    /// Descarta o arquivo (usado após anexar com sucesso).
    pub fn consume(&self, session: &str, reference: &str) {
        let Some(token) = reference.strip_prefix(PREFIX).and_then(|r| r.split('/').next()) else { return };
        if let Ok(mut map) = self.map.lock() {
            if map.get(token).is_some_and(|s| s.session == session) {
                if let Some(s) = map.remove(token) {
                    let _ = std::fs::remove_dir_all(&s.dir);
                }
            }
        }
    }

    pub fn purge_session(&self, session: &str) {
        if let Ok(mut map) = self.map.lock() {
            map.retain(|_, s| {
                let mine = s.session == session;
                if mine {
                    let _ = std::fs::remove_dir_all(&s.dir);
                }
                !mine
            });
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn up() -> Uploads {
        Uploads::new(std::env::temp_dir().join(format!("phantom-up-{}-{}", std::process::id(), line!())))
    }

    #[test]
    fn stages_resolves_per_session_and_consumes() {
        let u = Uploads::new(std::env::temp_dir().join(format!("phantom-up-a-{}", std::process::id())));
        let r = u.stage("sessA", "Comprovante 1.pdf", b"%PDF-1.4").unwrap();
        assert!(r.starts_with("upload:") && r.ends_with("/Comprovante 1.pdf"));
        let p = u.resolve("sessA", &r).unwrap();
        assert!(p.starts_with(u.root()) && p.file_name().unwrap() == "Comprovante 1.pdf");
        assert!(u.resolve("sessB", &r).is_none(), "outra sessão não enxerga o arquivo");
        assert!(u.resolve("sessA", "upload:../../x/a.pdf").is_none());
        u.consume("sessB", &r);
        assert!(u.resolve("sessA", &r).is_some(), "outra sessão não consegue consumir");
        u.consume("sessA", &r);
        assert!(u.resolve("sessA", &r).is_none() && !p.exists());
    }

    #[test]
    fn rejects_bad_names_types_and_traversal() {
        let u = up();
        for bad in ["virus.exe", "semextensao", ".pdf.", "", "x.html", "a.ps1"] {
            assert!(u.stage("s", bad, b"x").is_err(), "{bad}");
        }
        assert!(u.stage("s", "a.pdf", b"").is_err(), "vazio");
        let r = u.stage("s", "..\\..\\Windows\\sistema.pdf", b"x").unwrap();
        assert!(r.ends_with("/sistema.pdf"), "{r}");
        assert!(u.resolve("s", &r).unwrap().starts_with(u.root()));
        let r = u.stage("s", "C:/dir/foto.JPG", b"x").unwrap();
        assert!(r.ends_with("/foto.JPG"), "{r}");
    }

    #[test]
    fn purge_session_removes_only_that_session() {
        let u = Uploads::new(std::env::temp_dir().join(format!("phantom-up-b-{}", std::process::id())));
        let a = u.stage("a", "1.png", b"x").unwrap();
        let b = u.stage("b", "2.png", b"x").unwrap();
        u.purge_session("a");
        assert!(u.resolve("a", &a).is_none());
        assert!(u.resolve("b", &b).is_some());
    }

    #[test]
    fn per_session_quota() {
        let u = Uploads::new(std::env::temp_dir().join(format!("phantom-up-c-{}", std::process::id())));
        for i in 0..MAX_PER_SESSION {
            u.stage("s", &format!("{i}.png"), b"x").unwrap();
        }
        assert!(u.stage("s", "extra.png", b"x").is_err());
        assert!(u.stage("outra", "ok.png", b"x").is_ok());
    }
}
