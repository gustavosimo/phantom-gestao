import { useEffect, useState } from "react";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { LoaderCircle } from "lucide-react";
import { useAuth } from "@/app/auth-store";
import { ALL_MODULES } from "@/app/navigation";
import { AppLayout } from "@/layouts/AppLayout";
import { LoginPage } from "@/modules/auth/LoginPage";
import { Button } from "@/components/ui/button";
import { LogoMark } from "@/components/Logo";
import { Toaster } from "@/components/ui/toast";
import { api, errorMessage } from "@/services/api";
import { setDateFormat } from "@/lib/format";
import { DashboardPage } from "@/modules/dashboard/DashboardPage";
import { ClientsPage } from "@/modules/clients/ClientsPage";
import { ClientFormPage } from "@/modules/clients/ClientFormPage";
import { ClientDetailPage } from "@/modules/clients/ClientDetailPage";
import { LoansPage } from "@/modules/loans/LoansPage";
import { LoanWizardPage } from "@/modules/loans/LoanWizardPage";
import { LoanDetailPage } from "@/modules/loans/LoanDetailPage";
import { CollateralPage } from "@/modules/collateral/CollateralPage";
import { CollateralFormPage } from "@/modules/collateral/CollateralFormPage";
import { CollateralDetailPage } from "@/modules/collateral/CollateralDetailPage";
import { ProductsPage } from "@/modules/products/ProductsPage";
import { PurchasesPage } from "@/modules/purchases/PurchasesPage";
import { SalesPage } from "@/modules/sales/SalesPage";
import { PaymentsPage } from "@/modules/payments/PaymentsPage";
import { CollectionsPage } from "@/modules/collections/CollectionsPage";
import { ContractsPage } from "@/modules/contracts/ContractsPage";
import { NotificationsPage } from "@/modules/notifications/NotificationsPage";
import { ReportsPage } from "@/modules/reports/ReportsPage";
import { TemplatesPage } from "@/modules/templates/TemplatesPage";
import { SettingsPage } from "@/modules/settings/SettingsPage";

function Forbidden() {
  return (
    <div className="flex h-full items-center justify-center text-[13px] text-fg-muted">
      Você não tem permissão para acessar este módulo.
    </div>
  );
}

/** Rota protegida por permissão. */
function Guard({ permission, children }: { permission: string; children: React.ReactNode }) {
  const can = useAuth((s) => s.can);
  return can(permission) ? <>{children}</> : <Forbidden />;
}

const g = (permission: string, el: React.ReactNode) => <Guard permission={permission}>{el}</Guard>;

export function App() {
  const status = useAuth((s) => s.status);
  const init = useAuth((s) => s.init);
  const [bootError, setBootError] = useState<string | null>(null);

  useEffect(() => {
    init().catch((e) => setBootError(errorMessage(e)));
  }, [init]);

  useEffect(() => {
    if (status !== "authenticated") return;
    api.settings().then((s) => setDateFormat(s["regional.date_format"] ?? "DD/MM/AAAA")).catch(() => {});
  }, [status]);

  if (bootError) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-4 text-center">
        <p className="max-w-md text-sm text-error-fg">Não foi possível iniciar o sistema: {bootError}</p>
        <Button variant="outline" onClick={() => location.reload()}>Tentar novamente</Button>
      </div>
    );
  }

  if (status === "loading") {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-5 bg-app" role="status" aria-label="Carregando">
        <LogoMark size={120} className="animate-pulse" />
        <div className="flex flex-col items-center gap-1">
          <span className="font-heading text-lg font-extrabold tracking-[1px] text-fg">PHANTOM GESTÃO</span>
          <LoaderCircle size={16} className="animate-spin text-fg-subtle" />
        </div>
      </div>
    );
  }

  if (status === "anonymous" || status === "setup") {
    return (
      <>
        <LoginPage />
        <Toaster />
      </>
    );
  }

  const mod = (path: string) => ALL_MODULES.find((m) => m.path === path)!.permission;

  return (
    <BrowserRouter>
      <Routes>
        <Route element={<AppLayout />}>
          <Route index element={g(mod("/"), <DashboardPage />)} />
          <Route path="clientes" element={g(mod("/clientes"), <ClientsPage />)} />
          <Route path="clientes/novo" element={g("clients.manage", <ClientFormPage />)} />
          <Route path="clientes/:id" element={g(mod("/clientes"), <ClientDetailPage />)} />
          <Route path="clientes/:id/editar" element={g("clients.manage", <ClientFormPage />)} />
          <Route path="emprestimos" element={g(mod("/emprestimos"), <LoansPage />)} />
          <Route path="emprestimos/novo" element={g("loans.manage", <LoanWizardPage />)} />
          <Route path="emprestimos/:id" element={g(mod("/emprestimos"), <LoanDetailPage />)} />
          <Route path="garantias" element={g(mod("/garantias"), <CollateralPage />)} />
          <Route path="garantias/nova" element={g("collateral.manage", <CollateralFormPage />)} />
          <Route path="garantias/:id" element={g(mod("/garantias"), <CollateralDetailPage />)} />
          <Route path="produtos" element={g(mod("/produtos"), <ProductsPage />)} />
          <Route path="compras" element={g(mod("/compras"), <PurchasesPage />)} />
          <Route path="vendas" element={g(mod("/vendas"), <SalesPage />)} />
          <Route path="pagamentos" element={g(mod("/pagamentos"), <PaymentsPage />)} />
          <Route path="cobrancas" element={g(mod("/cobrancas"), <CollectionsPage />)} />
          <Route path="contratos" element={g(mod("/contratos"), <ContractsPage />)} />
          <Route path="modelos" element={g(mod("/modelos"), <TemplatesPage />)} />
          <Route path="notificacoes" element={g(mod("/notificacoes"), <NotificationsPage />)} />
          <Route path="relatorios" element={g(mod("/relatorios"), <ReportsPage />)} />
          <Route path="configuracoes" element={g(mod("/configuracoes"), <SettingsPage />)} />
          <Route path="configuracoes/:section" element={g(mod("/configuracoes"), <SettingsPage />)} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
      <Toaster />
    </BrowserRouter>
  );
}
