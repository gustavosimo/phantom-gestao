import { create } from "zustand";
import { authApi } from "@/services/api";
import type { User } from "@/types/auth";

type Status = "loading" | "setup" | "anonymous" | "authenticated";

interface AuthState {
  status: Status;
  user: User | null;
  init: () => Promise<void>;
  login: (username: string, password: string) => Promise<void>;
  setupAdmin: (fullName: string, username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  can: (permission: string) => boolean;
}

export const useAuth = create<AuthState>((set, get) => ({
  status: "loading",
  user: null,
  async init() {
    const user = await authApi.currentUser();
    if (user) return set({ user, status: "authenticated" });
    set({ status: (await authApi.setupRequired()) ? "setup" : "anonymous" });
  },
  async login(username, password) {
    const user = await authApi.login(username, password);
    set({ user, status: "authenticated" });
  },
  async setupAdmin(fullName, username, password) {
    const user = await authApi.setupAdmin(fullName, username, password);
    set({ user, status: "authenticated" });
  },
  async logout() {
    await authApi.logout();
    set({ user: null, status: "anonymous" });
  },
  can: (permission) => get().user?.permissions.includes(permission) ?? false,
}));

// Modo web: a sessão expira por inatividade no servidor; volta para a tela de login.
if (typeof window !== "undefined") {
  window.addEventListener("phantom:session-expired", () => {
    if (useAuth.getState().status === "authenticated") useAuth.setState({ user: null, status: "anonymous" });
  });
}
