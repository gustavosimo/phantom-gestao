import {
  BarChart3,
  Bell,
  BellRing,
  FileText,
  FilePenLine,
  HandCoins,
  LayoutDashboard,
  Package,
  Settings,
  ShieldCheck,
  ShoppingBag,
  ShoppingCart,
  Users,
  Wallet,
  type LucideIcon,
} from "lucide-react";

export interface ModuleDef {
  path: string;
  label: string;
  /** Título do cabeçalho quando difere do rótulo do menu. */
  title?: string;
  subtitle: string;
  icon: LucideIcon;
  permission: string;
  /** Fase do roadmap em que o módulo passa a ser funcional. */
  phase: number;
  /** Módulo bloqueado até a validação regulatória. */
  regulated?: boolean;
}

export interface NavSection {
  title: string;
  items: ModuleDef[];
}

export const NAV_SECTIONS: NavSection[] = [
  {
    title: "Principal",
    items: [
      { path: "/", label: "Dashboard", subtitle: "Visão geral das operações", icon: LayoutDashboard, permission: "dashboard.view", phase: 2 },
    ],
  },
  {
    title: "Operações",
    items: [
      { path: "/clientes", label: "Clientes", subtitle: "Gestão de clientes cadastrados", icon: Users, permission: "clients.view", phase: 2 },
      { path: "/emprestimos", label: "Empréstimos", subtitle: "Gestão de contratos de crédito", icon: HandCoins, permission: "loans.view", phase: 4, regulated: true },
      { path: "/garantias", label: "Garantias", subtitle: "Bens em custódia e avaliação", icon: ShieldCheck, permission: "collateral.view", phase: 4, regulated: true },
      { path: "/produtos", label: "Produtos", title: "Produtos e Estoque", subtitle: "Catálogo de itens disponíveis para venda", icon: Package, permission: "products.view", phase: 2 },
      { path: "/compras", label: "Compras", subtitle: "Registro de produtos adquiridos pela Phantom", icon: ShoppingBag, permission: "purchases.view", phase: 3 },
      { path: "/vendas", label: "Vendas", title: "Nova Venda", subtitle: "Ponto de venda", icon: ShoppingCart, permission: "sales.view", phase: 3 },
    ],
  },
  {
    title: "Financeiro",
    items: [
      { path: "/pagamentos", label: "Pagamentos", subtitle: "Todos os recebimentos e lançamentos", icon: Wallet, permission: "payments.view", phase: 5 },
      { path: "/cobrancas", label: "Cobranças", subtitle: "Parcelas a vencer e em atraso", icon: BellRing, permission: "collections.view", phase: 5 },
      { path: "/modelos", label: "Modelos", title: "Modelos de Contrato", subtitle: "Crie e edite os textos dos contratos", icon: FilePenLine, permission: "contracts.manage", phase: 4 },
      { path: "/contratos", label: "Contratos", subtitle: "Documentos e históricos de operações", icon: FileText, permission: "contracts.view", phase: 4 },
    ],
  },
  {
    title: "Sistema",
    items: [
      { path: "/notificacoes", label: "Notificações", title: "Central de Notificações", subtitle: "Central de avisos", icon: Bell, permission: "notifications.view", phase: 5 },
      { path: "/relatorios", label: "Relatórios", subtitle: "Indicadores financeiros e exportações", icon: BarChart3, permission: "reports.view", phase: 5 },
      { path: "/configuracoes", label: "Configurações", subtitle: "Preferências e administração do sistema", icon: Settings, permission: "settings.view", phase: 1 },
    ],
  },
];

export const ALL_MODULES: ModuleDef[] = NAV_SECTIONS.flatMap((s) => s.items);

export function findModule(pathname: string): ModuleDef | undefined {
  return ALL_MODULES.find((m) => (m.path === "/" ? pathname === "/" : pathname.startsWith(m.path)));
}
