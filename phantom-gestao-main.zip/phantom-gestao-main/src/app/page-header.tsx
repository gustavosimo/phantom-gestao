import { useEffect, type ReactNode } from "react";
import { Link } from "react-router-dom";
import { create } from "zustand";

interface HeaderState {
  title: string | null;
  subtitle: ReactNode;
  set: (title: string | null, subtitle: ReactNode) => void;
}

export const useHeader = create<HeaderState>((set) => ({
  title: null,
  subtitle: null,
  set: (title, subtitle) => set({ title, subtitle }),
}));

/** Define o título/subtítulo exibidos no cabeçalho da aplicação enquanto a página está montada. */
export function usePageHeader(title: string | null, subtitle: ReactNode = null, deps: unknown[] = []) {
  const set = useHeader((s) => s.set);
  useEffect(() => {
    set(title, subtitle);
    return () => set(null, null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [title, set, ...deps]);
}

/** Subtítulo em forma de breadcrumb: "Clientes / Novo cadastro". */
export function Breadcrumb({ items }: { items: { label: string; to?: string }[] }) {
  return (
    <span className="flex items-center gap-1.5">
      {items.map((it, i) => (
        <span key={i} className="flex items-center gap-1.5">
          {i > 0 && <span className="text-fg-subtle">/</span>}
          {it.to ? (
            <Link to={it.to} className="hover:text-fg hover:underline">
              {it.label}
            </Link>
          ) : (
            <span>{it.label}</span>
          )}
        </span>
      ))}
    </span>
  );
}
