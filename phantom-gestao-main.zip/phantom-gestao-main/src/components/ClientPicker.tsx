import { useEffect, useState } from "react";
import { Check, Search, X } from "lucide-react";
import { api } from "@/services/api";
import type { ClientOption } from "@/types/domain";
import { useDebounced } from "@/hooks/useApi";
import { Field } from "@/components/ui/form";
import { StatusBadge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

/** Seleção de cliente com busca por nome/documento. */
export function ClientPicker({ label = "Cliente", value, onChange, required, allowEmpty, emptyLabel = "Consumidor final", error }: { label?: string; value: ClientOption | null; onChange: (c: ClientOption | null) => void; required?: boolean; allowEmpty?: boolean; emptyLabel?: string; error?: string | null }) {
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<ClientOption[]>([]);
  const dq = useDebounced(q, 250);

  useEffect(() => {
    if (!open) return;
    let alive = true;
    api.clientOptions(dq || undefined).then((r) => alive && setItems(r)).catch(() => alive && setItems([]));
    return () => {
      alive = false;
    };
  }, [dq, open]);

  return (
    <Field label={label} required={required} error={error}>
      <div className="relative">
        {value ? (
          <div className="flex items-center justify-between gap-2 rounded-sm border border-line bg-input px-3.5 py-2.5">
            <span className="flex min-w-0 items-center gap-2 text-sm text-fg">
              <Check size={14} className="shrink-0 text-success-fg" />
              <span className="truncate">{value.name}</span>
              <span className="font-mono text-xs text-fg-subtle">{value.document}</span>
            </span>
            <button type="button" aria-label="Trocar cliente" onClick={() => onChange(null)} className="cursor-pointer text-fg-subtle hover:text-fg"><X size={14} /></button>
          </div>
        ) : (
          <>
            <div className={cn("flex items-center gap-2 rounded-sm border bg-input px-3.5 py-2.5 focus-within:border-silver-dim", error ? "border-error-line" : "border-line")}>
              <Search size={14} className="shrink-0 text-fg-subtle" />
              <input
                value={q}
                onChange={(e) => { setQ(e.target.value); setOpen(true); }}
                onFocus={() => setOpen(true)}
                onBlur={() => setTimeout(() => setOpen(false), 150)}
                placeholder={allowEmpty ? `${emptyLabel} — ou busque por nome/documento` : "Buscar por nome ou documento"}
                className="w-full bg-transparent text-sm text-fg outline-none placeholder:text-fg-subtle focus-visible:outline-none"
              />
            </div>
            {open && (
              <div className="absolute z-30 mt-1 max-h-60 w-full overflow-y-auto rounded-md border border-line bg-surface p-1.5">
                {items.length === 0 && <p className="px-3 py-2 text-[13px] text-fg-subtle">Nenhum cliente encontrado</p>}
                {items.map((c) => (
                  <button key={c.id} type="button" onMouseDown={(e) => e.preventDefault()} onClick={() => { onChange(c); setOpen(false); setQ(""); }} className="flex w-full cursor-pointer items-center justify-between gap-3 rounded-sm px-3 py-2 text-left text-[13px] hover:bg-surface-hover">
                    <span className="min-w-0 truncate text-fg">{c.name}<span className="ml-2 font-mono text-xs text-fg-subtle">{c.document}</span></span>
                    <StatusBadge status={c.status} />
                  </button>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </Field>
  );
}
