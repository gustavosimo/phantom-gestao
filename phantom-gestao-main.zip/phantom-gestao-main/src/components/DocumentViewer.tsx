import { useEffect, useRef, useState } from "react";
import { Download, FileText, LoaderCircle, Maximize2, Printer } from "lucide-react";
import { api, errorMessage } from "@/services/api";
import type { Attachment } from "@/types/domain";
import { blobUrl, dataUrl, downloadAttachment } from "@/lib/files";
import { FormModal } from "@/components/ui/dialog";
import { PdfView, needsPdfJs } from "@/components/PdfView";
import { cn } from "@/lib/utils";

/** Carrega e decifra um anexo sob demanda e devolve uma URL de exibição (imagem ou PDF). */
export function useAttachmentUrl(attachmentId: number | null | undefined) {
  const [state, setState] = useState<{ url: string | null; meta: Attachment | null; loading: boolean; error: string | null }>({ url: null, meta: null, loading: false, error: null });
  useEffect(() => {
    if (!attachmentId) {
      setState({ url: null, meta: null, loading: false, error: null });
      return;
    }
    let alive = true;
    let created: string | null = null;
    setState((s) => ({ ...s, loading: true, error: null }));
    api
      .attachmentRead(attachmentId)
      .then((d) => {
        if (!alive) return;
        const url = d.meta.mime === "application/pdf" ? (created = blobUrl(d.meta.mime, d.dataBase64)) : dataUrl(d.meta.mime, d.dataBase64);
        setState({ url, meta: d.meta, loading: false, error: null });
      })
      .catch((e) => alive && setState({ url: null, meta: null, loading: false, error: errorMessage(e) }));
    return () => {
      alive = false;
      if (created) URL.revokeObjectURL(created);
    };
  }, [attachmentId]);
  return state;
}

export function Thumb({ attachmentId, className, onClick, alt }: { attachmentId: number; className?: string; onClick?: () => void; alt: string }) {
  const { url, loading } = useAttachmentUrl(attachmentId);
  return (
    <button type="button" onClick={onClick} className={cn("flex cursor-pointer items-center justify-center overflow-hidden rounded-sm border border-line bg-app", className)} aria-label={alt}>
      {url ? <img src={url} alt={alt} className="size-full object-cover" /> : loading ? <LoaderCircle size={16} className="animate-spin text-fg-subtle" /> : <FileText size={18} className="text-fg-subtle" />}
    </button>
  );
}

/** Pré-visualização do documento com ações de baixar, imprimir e tela cheia. */
export function DocumentPreview({ attachmentId, title, subtitle, className }: { attachmentId: number | null; title?: string; subtitle?: string; className?: string }) {
  const { url, meta, loading, error } = useAttachmentUrl(attachmentId);
  const [full, setFull] = useState(false);
  const frame = useRef<HTMLIFrameElement>(null);
  const isPdf = meta?.mime === "application/pdf";

  function print() {
    if (isPdf && frame.current?.contentWindow) {
      frame.current.contentWindow.focus();
      frame.current.contentWindow.print();
    } else {
      window.print();
    }
  }

  return (
    <div className={cn("flex min-h-0 flex-col overflow-hidden rounded-md border border-line bg-surface", className)}>
      <div className="flex items-center justify-between gap-3 border-b border-line px-5 py-3.5">
        <div className="min-w-0">
          <p className="truncate text-[15px] font-medium text-fg">{title ?? meta?.originalName ?? "Documento"}</p>
          {subtitle && <p className="truncate text-xs text-fg-subtle">{subtitle}</p>}
        </div>
        <div className="flex gap-2">
          <IconBtn label="Baixar" disabled={!meta} onClick={() => meta && downloadAttachment(meta.id, meta.originalName)}><Download size={15} /></IconBtn>
          {!needsPdfJs() && <IconBtn label="Imprimir" disabled={!url} onClick={print}><Printer size={15} /></IconBtn>}
          <IconBtn label="Tela cheia" disabled={!url} onClick={() => setFull(true)}><Maximize2 size={15} /></IconBtn>
        </div>
      </div>
      <div className="relative flex min-h-[320px] flex-1 items-center justify-center bg-app p-4">
        {!attachmentId ? (
          <div className="flex flex-col items-center gap-2 text-fg-subtle"><FileText size={36} /><span className="text-[13px]">Selecione um documento para pré-visualizar</span></div>
        ) : loading ? (
          <LoaderCircle className="animate-spin text-fg-subtle" />
        ) : error ? (
          <p className="text-[13px] text-error-fg">{error}</p>
        ) : url ? (
          isPdf ? <PdfFrame url={url} title={meta?.originalName} frameRef={frame} /> : <img src={url} alt={meta?.originalName} className="max-h-full max-w-full rounded-sm object-contain" />
        ) : null}
      </div>
      <FormModal open={full} onOpenChange={setFull} title={meta?.originalName ?? "Documento"} width={900}>
        {url && (isPdf ? <PdfFrame url={url} title={meta?.originalName} className="h-[70vh] w-full" /> : <img src={url} alt={meta?.originalName} className="mx-auto max-h-[70vh] rounded-sm object-contain" />)}
      </FormModal>
    </div>
  );
}

function IconBtn({ children, label, onClick, disabled }: { children: React.ReactNode; label: string; onClick: () => void; disabled?: boolean }) {
  return (
    <button type="button" aria-label={label} title={label} disabled={disabled} onClick={onClick} className="flex size-8 cursor-pointer items-center justify-center rounded-sm bg-surface-hover text-fg-muted hover:text-fg disabled:cursor-default disabled:opacity-40">
      {children}
    </button>
  );
}

/** Visualizador de PDF: leitor do WebView/navegador no computador; páginas desenhadas pelo app no celular. */
function PdfFrame({ url, title, className, frameRef }: { url: string; title?: string; className?: string; frameRef?: React.RefObject<HTMLIFrameElement | null> }) {
  return <PdfView url={url} title={title} className={className} frameRef={frameRef} />;
}
