/**
 * Fundo da tela de login: brilhos suaves parados no fundo e feixes de luz diagonais que atravessam a tela de
 * tempos em tempos (CSS puro, sem JavaScript). É decorativo (aria-hidden) e fica estático quando o sistema
 * pede movimento reduzido.
 */
export function LoginBackdrop() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="phantom-glow-a absolute -top-[350px] -left-[250px] size-[900px] rounded-full" />
      <div className="phantom-glow-b absolute -right-[310px] -bottom-[300px] size-[760px] rounded-full" />
      <div className="phantom-beam phantom-beam-gold" />
      <div className="phantom-beam phantom-beam-silver" />
      {/* vinheta: escurece as bordas e mantém o foco no cartão */}
      <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at center, transparent 45%, rgba(8,9,11,0.55) 100%)" }} />
    </div>
  );
}
