import mark72 from "@/assets/brand/phantom-mark-72.png";
import mark144 from "@/assets/brand/phantom-mark-144.png";
import mark256 from "@/assets/brand/phantom-mark-256.png";
import { cn } from "@/lib/utils";

const SOURCES = { 72: mark72, 144: mark144, 256: mark256 } as const;

/**
 * Emblema oficial (recorte circular do arquivo original, sem redesenho), dentro de um anel fino dourado
 * nas cores do sistema. O tamanho informado é o do conjunto (anel incluído), então o layout não muda.
 */
export function LogoMark({ size, className, ring = true }: { size: number; className?: string; ring?: boolean }) {
  const inner = ring ? Math.round(size * 0.76) : size;
  const src = inner <= 36 ? SOURCES[72] : inner <= 72 ? SOURCES[144] : SOURCES[256];
  const img = (
    <img
      src={src}
      width={inner}
      height={inner}
      alt="Phantom Gestão"
      draggable={false}
      className={ring ? undefined : className}
      style={{ width: inner, height: inner }}
    />
  );
  if (!ring) return img;
  return (
    <span
      className={cn("inline-flex shrink-0 items-center justify-center rounded-full border border-gold-line", className)}
      style={{
        width: size,
        height: size,
        background: "radial-gradient(circle at 50% 30%, #1d1e23, #0d0e11 72%)",
        boxShadow: "0 0 0 1px rgba(217,164,65,0.06), 0 0 22px rgba(217,164,65,0.12), inset 0 0 14px rgba(217,164,65,0.07)",
      }}
    >
      {img}
    </span>
  );
}
