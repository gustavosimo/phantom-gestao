import { useEffect, useRef, useState } from "react";
import { LoaderCircle } from "lucide-react";
import { isDesktop } from "@/services/api";
import { cn } from "@/lib/utils";

/**
 * O WebView do desktop e os navegadores de computador exibem PDF em um <iframe>. Navegadores de celular
 * (Chrome/Android, iOS) não têm leitor embutido e mostram a página quebrada; nesses casos o PDF é desenhado
 * pelo próprio app (pdf.js), página por página, ajustado à largura da tela.
 */
export function needsPdfJs(): boolean {
  if (isDesktop || typeof navigator === "undefined") return false;
  try {
    if (localStorage.getItem("phantom.pdfjs") === "1") return true;
  } catch {
    /* ignorar */
  }
  const mobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
  const noViewer = (navigator as Navigator & { pdfViewerEnabled?: boolean }).pdfViewerEnabled === false;
  return mobile || noViewer;
}

interface PdfViewProps {
  url: string;
  title?: string;
  className?: string;
  /** chamado quando o documento terminou de carregar (usado para trocar a pré-visualização sem piscar) */
  onReady?: () => void;
  frameRef?: React.RefObject<HTMLIFrameElement | null>;
}

export function PdfView({ url, title, className, onReady, frameRef }: PdfViewProps) {
  if (!needsPdfJs()) {
    return (
      <iframe
        ref={frameRef}
        src={`${url}#toolbar=0&navpanes=0&view=FitH`}
        title={title}
        onLoad={onReady}
        className={cn("size-full min-h-[420px] rounded-sm bg-white", className)}
      />
    );
  }
  return <PdfPages url={url} className={className} onReady={onReady} />;
}

function PdfPages({ url, className, onReady }: { url: string; className?: string; onReady?: () => void }) {
  const host = useRef<HTMLDivElement>(null);
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");
  const ready = useRef(onReady);
  ready.current = onReady;

  useEffect(() => {
    let cancelled = false;
    let doc: { destroy: () => Promise<void> } | null = null;
    setState("loading");
    (async () => {
      try {
        const pdfjs = await import("pdfjs-dist");
        const worker = (await import("pdfjs-dist/build/pdf.worker.min.mjs?url")).default;
        pdfjs.GlobalWorkerOptions.workerSrc = worker;
        const data = await (await fetch(url)).arrayBuffer();
        const pdf = await pdfjs.getDocument({ data }).promise;
        doc = pdf;
        if (cancelled) return;
        const el = host.current;
        if (!el) return;
        el.replaceChildren();
        const width = el.clientWidth || 340;
        const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
        for (let n = 1; n <= pdf.numPages; n++) {
          const page = await pdf.getPage(n);
          if (cancelled) return;
          const scale = width / page.getViewport({ scale: 1 }).width;
          const vp = page.getViewport({ scale: scale * dpr });
          const canvas = document.createElement("canvas");
          canvas.width = Math.floor(vp.width);
          canvas.height = Math.floor(vp.height);
          canvas.style.width = "100%";
          canvas.style.height = "auto";
          canvas.className = "mb-3 rounded-sm bg-white shadow last:mb-0";
          el.appendChild(canvas);
          await page.render({ canvasContext: canvas.getContext("2d")!, viewport: vp }).promise;
          if (n === 1 && !cancelled) {
            setState("ready");
            ready.current?.();
          }
        }
      } catch {
        if (!cancelled) setState("error");
      }
    })();
    return () => {
      cancelled = true;
      void doc?.destroy();
    };
  }, [url]);

  return (
    <div className={cn("relative w-full", className)}>
      {state === "loading" && (
        <div className="flex items-center justify-center py-16 text-fg-subtle">
          <LoaderCircle className="animate-spin" />
        </div>
      )}
      {state === "error" && <p className="p-4 text-center text-[13px] text-error-fg">Não foi possível exibir o PDF. Use o botão Baixar.</p>}
      <div ref={host} className="w-full" />
    </div>
  );
}
