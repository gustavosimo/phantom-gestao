import { Link } from "react-router-dom";
import { Lock } from "lucide-react";
import { Notice } from "@/components/ui/layout";
import { useAuth } from "@/app/auth-store";

/** Aviso exibido enquanto crédito/garantias não foram habilitados após validação regulatória. */
export function RegulatoryBanner({ kind }: { kind: "credit" | "collateral" }) {
  const can = useAuth((s) => s.can);
  return (
    <Notice tone="warning" icon={Lock}>
      <strong>{kind === "credit" ? "Operações de crédito bloqueadas." : "Operações com garantias bloqueadas."}</strong>{" "}
      Simulações e cadastros estão liberados, mas {kind === "credit" ? "a contratação e o desembolso" : "o recebimento em custódia"} só serão habilitados após a validação do enquadramento jurídico, das autorizações e da modalidade operacional da empresa.{" "}
      {can("regulatory.manage") && (
        <Link to="/configuracoes/regras" className="font-semibold underline">
          Abrir Regras Financeiras
        </Link>
      )}
    </Notice>
  );
}
