import * as Dropdown from "@radix-ui/react-dropdown-menu";
import { EllipsisVertical, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export interface RowAction {
  label: string;
  icon?: LucideIcon;
  onSelect: () => void;
  destructive?: boolean;
  hidden?: boolean;
}

/** Menu de ações de uma linha de tabela (três pontos). */
export function RowMenu({ actions, label = "Ações" }: { actions: RowAction[]; label?: string }) {
  const visible = actions.filter((a) => !a.hidden);
  if (visible.length === 0) return null;
  return (
    <Dropdown.Root>
      <Dropdown.Trigger aria-label={label} onClick={(e) => e.stopPropagation()} className="flex size-10 cursor-pointer items-center justify-center rounded-sm text-fg-subtle hover:bg-surface-hover hover:text-fg sm:size-auto sm:p-1.5">
        <EllipsisVertical size={16} />
      </Dropdown.Trigger>
      <Dropdown.Portal>
        <Dropdown.Content align="end" sideOffset={4} onClick={(e) => e.stopPropagation()} className="z-50 min-w-[180px] rounded-md border border-line bg-surface p-1.5 text-sm">
          {visible.map((a) => (
            <Dropdown.Item
              key={a.label}
              onSelect={a.onSelect}
              className={cn("flex cursor-pointer items-center gap-2 rounded-sm px-3 py-2.5 text-[13px] outline-none data-[highlighted]:bg-surface-hover sm:py-2", a.destructive ? "text-error-fg" : "text-fg")}
            >
              {a.icon && <a.icon size={14} />}
              {a.label}
            </Dropdown.Item>
          ))}
        </Dropdown.Content>
      </Dropdown.Portal>
    </Dropdown.Root>
  );
}
