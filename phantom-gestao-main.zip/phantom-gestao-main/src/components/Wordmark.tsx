import { cn } from "@/lib/utils";

/** Assinatura institucional: PHANTOM / FINANCEIRA / ANÁLISE DE CRÉDITO. */
export function Wordmark({ className, align = "left" }: { className?: string; align?: "left" | "center" }) {
  return (
    <div className={cn("flex flex-col leading-none", align === "center" ? "items-center text-center" : "items-start", className)}>
      <span className="font-heading text-[22px] font-extrabold tracking-[1.5px] text-fg">PHANTOM</span>
      <span className="pt-1.5 font-heading text-[10px] font-semibold tracking-[5px] text-silver">FINANCEIRA</span>
      <span className="pt-1.5 font-heading text-[8.5px] font-bold tracking-[1.8px] text-silver-dim">ANÁLISE DE CRÉDITO</span>
    </div>
  );
}
