import { cn } from "@/lib/utils";

export type Tone = "success" | "warning" | "error" | "info" | "neutral";

const TONES: Record<Tone, string> = {
  success: "border-success-line bg-success-bg text-success-fg",
  warning: "border-warning-line bg-warning-bg text-warning-fg",
  error: "border-error-line bg-error-bg text-error-fg",
  info: "border-info-line bg-info-bg text-info-fg",
  neutral: "border-line bg-surface-hover text-fg-muted",
};

const DOTS: Record<Tone, string> = {
  success: "bg-success-fg",
  warning: "bg-warning-fg",
  error: "bg-error-fg",
  info: "bg-info-fg",
  neutral: "bg-fg-muted",
};

export function Badge({ tone = "neutral", children, className }: { tone?: Tone; children: React.ReactNode; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs leading-none font-semibold whitespace-nowrap", TONES[tone], className)}>
      <span className={cn("size-1.5 rounded-full", DOTS[tone])} />
      {children}
    </span>
  );
}

/** Mapa único de status → rótulo e tom, compartilhado por todos os módulos. */
const STATUS: Record<string, [string, Tone]> = {
  // clientes
  active: ["Ativo", "success"],
  pending: ["Pendente", "warning"],
  inactive: ["Inativo", "neutral"],
  late: ["Atrasado", "error"],
  // empréstimos
  pending_disbursement: ["Pendente", "warning"],
  paid_off: ["Quitado", "neutral"],
  renegotiated: ["Renegociado", "info"],
  cancelled: ["Cancelado", "neutral"],
  ontime: ["Em dia", "success"],
  // solicitações
  draft: ["Rascunho", "neutral"],
  analysis: ["Em análise", "warning"],
  approved: ["Aprovado", "success"],
  rejected: ["Recusado", "error"],
  contracted: ["Contratado", "info"],
  // parcelas
  paid: ["Pago", "success"],
  overdue: ["Atrasado", "error"],
  next: ["Próxima", "info"],
  partial: ["Parcial", "warning"],
  open: ["A vencer", "neutral"],
  // pagamentos / compras / vendas
  confirmed: ["Confirmado", "success"],
  reversed: ["Estornado", "neutral"],
  completed: ["Concluído", "success"],
  partially_returned: ["Devolução parcial", "warning"],
  // estoque
  available: ["Disponível", "success"],
  low: ["Baixo estoque", "warning"],
  out: ["Esgotado", "error"],
  // garantias
  evaluating: ["Em avaliação", "warning"],
  in_custody: ["Em custódia", "neutral"],
  near_deadline: ["Prazo próximo", "error"],
  redeemed: ["Resgatado", "success"],
  returned: ["Devolvido", "success"],
  legal_procedure: ["Procedimento legal", "error"],
  // contratos
  pending_signature: ["Aguardando assinatura", "warning"],
};

export function statusInfo(status: string): [string, Tone] {
  return STATUS[status] ?? [status, "neutral"];
}

export function StatusBadge({ status, label }: { status: string; label?: string }) {
  const [text, tone] = statusInfo(status);
  return <Badge tone={tone}>{label ?? text}</Badge>;
}

/** Status de empréstimo para exibição (ativo sem atraso = "Em dia"). */
export function LoanStatusBadge({ derived }: { derived: string }) {
  return <StatusBadge status={derived === "active" ? "ontime" : derived} />;
}
