import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-full text-sm font-semibold transition-colors disabled:pointer-events-none disabled:opacity-60 cursor-pointer",
  {
    variants: {
      variant: {
        primary: "bg-gradient-to-b from-gold-bright to-gold text-on-gold hover:brightness-110",
        gold: "border border-gold-line bg-gold-bg text-gold-bright hover:bg-[#35291a]",
        silver: "bg-silver text-on-silver hover:bg-silver-bright",
        secondary: "bg-surface-hover text-fg hover:bg-line",
        outline: "border border-line-strong text-fg hover:bg-surface-hover",
        ghost: "text-fg-muted hover:bg-surface-hover hover:text-fg",
        destructive: "bg-error-bg text-error-fg border border-error-line hover:bg-[#33201f]",
      },
      size: { default: "min-h-11 px-[18px] py-2.5 sm:min-h-0", sm: "min-h-10 px-3.5 py-1.5 text-[13px] sm:min-h-0", icon: "size-10 sm:size-9" },
    },
    defaultVariants: { variant: "primary", size: "default" },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return <Comp ref={ref} className={cn(buttonVariants({ variant, size }), className)} {...props} />;
  },
);
Button.displayName = "Button";
