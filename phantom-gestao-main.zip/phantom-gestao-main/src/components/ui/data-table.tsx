import * as React from "react";
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, LoaderCircle } from "lucide-react";
import { cn } from "@/lib/utils";

export interface Column<T> {
  key: string;
  header: string;
  /** largura relativa (fr) ou px */
  width?: string;
  align?: "left" | "right";
  /** chave enviada ao backend para ordenação; ausente = não ordenável */
  sort?: string;
  render: (row: T) => React.ReactNode;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  rows: T[] | undefined;
  rowKey: (row: T) => string | number;
  loading?: boolean;
  empty?: React.ReactNode;
  sort?: { key?: string; desc: boolean };
  onSort?: (key: string) => void;
  onRowClick?: (row: T) => void;
  /** classes extras por linha (ex.: destacar a selecionada) */
  rowClass?: (row: T) => string | false | undefined;
  footer?: React.ReactNode;
  className?: string;
  /** altura mínima do corpo, para manter a moldura do layout aprovado */
  minBodyHeight?: number;
}

export function DataTable<T>({ columns, rows, rowKey, loading, empty, sort, onSort, onRowClick, rowClass, footer, className, minBodyHeight }: DataTableProps<T>) {
  const grid = columns.map((c) => c.width ?? "1fr").join(" ");
  return (
    <div className={cn("flex min-h-0 flex-col overflow-hidden rounded-md border border-line bg-surface", className)}>
      <MobileCards columns={columns} rows={rows} rowKey={rowKey} loading={loading} empty={empty} onRowClick={onRowClick} rowClass={rowClass} />
      <div className="hidden overflow-x-auto md:block">
        <div style={{ minWidth: columns.length * 110 }}>
          <div role="row" className="grid gap-4 border-b border-line bg-app px-5 py-3.5 text-xs font-medium text-fg-muted" style={{ gridTemplateColumns: grid }}>
            {columns.map((c) => {
              const active = sort?.key === c.sort;
              return (
                <div key={c.key} role="columnheader" className={cn("flex items-center gap-1", c.align === "right" && "justify-end")}>
                  {c.sort && onSort ? (
                    <button onClick={() => onSort(c.sort!)} className="inline-flex cursor-pointer items-center gap-1 hover:text-fg">
                      {c.header}
                      {active && (sort?.desc ? <ArrowDown size={12} /> : <ArrowUp size={12} />)}
                    </button>
                  ) : (
                    c.header
                  )}
                </div>
              );
            })}
          </div>
          <div style={{ minHeight: minBodyHeight }} className="relative">
            {loading && (
              <div className="absolute inset-x-0 top-0 z-10 flex h-0.5 overflow-hidden bg-line">
                <div className="h-full w-1/3 animate-pulse bg-silver" />
              </div>
            )}
            {rows && rows.length > 0
              ? rows.map((r) => (
                  <div
                    key={rowKey(r)}
                    role="row"
                    onClick={onRowClick ? () => onRowClick(r) : undefined}
                    className={cn(
                      "grid items-center gap-4 border-b border-line px-5 py-3.5 text-sm text-fg last:border-b-0",
                      onRowClick && "cursor-pointer hover:bg-surface-hover/50",
                      loading && "opacity-60",
                      rowClass?.(r),
                    )}
                    style={{ gridTemplateColumns: grid }}
                  >
                    {columns.map((c) => (
                      <div key={c.key} role="cell" className={cn("min-w-0", c.align === "right" && "text-right")}>
                        {c.render(r)}
                      </div>
                    ))}
                  </div>
                ))
              : !loading && <div>{empty}</div>}
            {loading && !rows && (
              <div className="flex items-center justify-center py-16 text-fg-subtle">
                <LoaderCircle className="animate-spin" />
              </div>
            )}
          </div>
        </div>
      </div>
      {footer}
    </div>
  );
}

/**
 * Celular: cada linha vira um cartão. A primeira coluna é o título; colunas sem cabeçalho (ações) ficam ao lado
 * do título; as demais viram pares rótulo/valor.
 */
function MobileCards<T>({ columns, rows, rowKey, loading, empty, onRowClick, rowClass }: Pick<DataTableProps<T>, "columns" | "rows" | "rowKey" | "loading" | "empty" | "onRowClick" | "rowClass">) {
  const [first, ...rest] = columns;
  const isAction = (c: Column<T>) => /^(a[cç][õo]es?)?$/i.test(c.header.trim());
  const actions = rest.filter(isAction);
  const fields = rest.filter((c) => !isAction(c));
  return (
    <div className="relative md:hidden">
      {loading && (
        <div className="absolute inset-x-0 top-0 z-10 flex h-0.5 overflow-hidden bg-line">
          <div className="h-full w-1/3 animate-pulse bg-silver" />
        </div>
      )}
      {rows && rows.length > 0
        ? rows.map((r) => (
            <div
              key={rowKey(r)}
              role="row"
              onClick={onRowClick ? () => onRowClick(r) : undefined}
              className={cn("flex flex-col gap-3 border-b border-line px-4 py-3.5 text-sm text-fg last:border-b-0", onRowClick && "cursor-pointer active:bg-surface-hover/50", loading && "opacity-60", rowClass?.(r))}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">{first.render(r)}</div>
                {actions.length > 0 && <div className="flex shrink-0 items-center gap-1">{actions.map((c) => <div key={c.key}>{c.render(r)}</div>)}</div>}
              </div>
              {fields.length > 0 && (
                <dl className="grid grid-cols-2 gap-x-4 gap-y-2.5">
                  {fields.map((c) => (
                    <div key={c.key} className="min-w-0">
                      <dt className="text-[11px] text-fg-subtle">{c.header}</dt>
                      <dd className="min-w-0 text-[13px] break-words">{c.render(r)}</dd>
                    </div>
                  ))}
                </dl>
              )}
            </div>
          ))
        : !loading && <div>{empty}</div>}
      {loading && !rows && (
        <div className="flex items-center justify-center py-12 text-fg-subtle">
          <LoaderCircle className="animate-spin" />
        </div>
      )}
    </div>
  );
}

export function Pagination({ page, pageSize, total, onPage, noun }: { page: number; pageSize: number; total: number; onPage: (p: number) => void; noun: string }) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const from = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const to = Math.min(total, page * pageSize);
  const items: (number | "…")[] = [];
  for (let p = 1; p <= pages; p++) {
    if (p === 1 || p === pages || Math.abs(p - page) <= 1) items.push(p);
    else if (items[items.length - 1] !== "…") items.push("…");
  }
  return (
    <div className="mt-auto flex flex-col items-center gap-2.5 border-t border-line px-4 py-3.5 text-xs text-fg-muted sm:flex-row sm:justify-between sm:px-5">
      <span>
        Mostrando {from}–{to} de {total} {noun}
      </span>
      <nav aria-label="Paginação" className="flex items-center gap-1">
        <PageBtn disabled={page <= 1} onClick={() => onPage(page - 1)} label="Página anterior">
          <ChevronLeft size={14} />
        </PageBtn>
        {items.map((it, i) =>
          it === "…" ? (
            <span key={`e${i}`} className="px-1.5">…</span>
          ) : (
            <PageBtn key={it} active={it === page} onClick={() => onPage(it)} label={`Página ${it}`}>
              {it}
            </PageBtn>
          ),
        )}
        <PageBtn disabled={page >= pages} onClick={() => onPage(page + 1)} label="Próxima página">
          <ChevronRight size={14} />
        </PageBtn>
      </nav>
    </div>
  );
}

function PageBtn({ children, active, disabled, onClick, label }: { children: React.ReactNode; active?: boolean; disabled?: boolean; onClick: () => void; label: string }) {
  return (
    <button
      aria-label={label}
      aria-current={active ? "page" : undefined}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "flex size-9 cursor-pointer items-center justify-center rounded-sm text-[13px] disabled:cursor-default disabled:opacity-40 sm:size-7",
        active ? "bg-surface-hover font-semibold text-fg" : "hover:bg-surface-hover/60 hover:text-fg",
      )}
    >
      {children}
    </button>
  );
}

/** Estado e consulta de uma listagem paginada com filtros. */
export function useListQuery(initial: { pageSize?: number; status?: string; category?: string; extra?: string } = {}) {
  const [state, set] = React.useState({
    page: 1,
    pageSize: initial.pageSize ?? 8,
    search: "",
    status: initial.status ?? "",
    category: initial.category ?? "",
    extra: initial.extra ?? "",
    sort: undefined as string | undefined,
    desc: false,
  });
  const patch = (p: Partial<typeof state>) => set((s) => ({ ...s, page: 1, ...p }));
  return {
    state,
    setPage: (page: number) => set((s) => ({ ...s, page })),
    setSearch: (search: string) => patch({ search }),
    setStatus: (status: string) => patch({ status }),
    setCategory: (category: string) => patch({ category }),
    setExtra: (extra: string) => patch({ extra }),
    toggleSort: (key: string) => set((s) => ({ ...s, page: 1, sort: key, desc: s.sort === key ? !s.desc : false })),
    query: {
      page: state.page,
      pageSize: state.pageSize,
      search: state.search || undefined,
      status: state.status || undefined,
      category: state.category || undefined,
      extra: state.extra || undefined,
      sort: state.sort,
      desc: state.desc,
    },
  };
}
