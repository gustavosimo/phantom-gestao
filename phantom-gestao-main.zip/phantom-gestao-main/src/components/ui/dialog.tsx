import * as DialogPrimitive from "@radix-ui/react-dialog";
import { useState, type ReactNode } from "react";
import { LoaderCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { TextArea } from "@/components/ui/form";
import { toast } from "@/components/ui/toast";
import { cn } from "@/lib/utils";

interface ConfirmDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  actions: ReactNode;
}

/** Diálogo modal simples: título, descrição e ações (botões) fornecidas pelo chamador. */
export function Modal({ open, onOpenChange, title, description, actions }: ConfirmDialogProps) {
  return (
    <DialogPrimitive.Root open={open} onOpenChange={onOpenChange}>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay className="fixed inset-0 z-50 bg-black/60" />
        <DialogPrimitive.Content className="fixed top-1/2 left-1/2 z-50 w-[380px] max-w-[92vw] -translate-x-1/2 -translate-y-1/2 rounded-md border border-line bg-surface">
          <div className="flex flex-col gap-1 p-5">
            <DialogPrimitive.Title className="font-heading text-base font-semibold text-fg">{title}</DialogPrimitive.Title>
            <DialogPrimitive.Description className="text-[13px] text-fg-muted">{description}</DialogPrimitive.Description>
          </div>
          <div className="flex justify-end gap-3 p-5 pt-2">{actions}</div>
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}

export const ModalClose = DialogPrimitive.Close;

/** Modal com conteúdo livre (formulários). */
export function FormModal({
  open,
  onOpenChange,
  title,
  description,
  children,
  footer,
  width = 520,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
  children: ReactNode;
  footer?: ReactNode;
  width?: number;
}) {
  return (
    <DialogPrimitive.Root open={open} onOpenChange={onOpenChange}>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay className="fixed inset-0 z-50 bg-black/60" />
        <DialogPrimitive.Content
          style={{ width }}
          aria-describedby={undefined}
          className="fixed top-1/2 left-1/2 z-50 flex max-h-[92dvh] max-w-[96vw] -translate-x-1/2 -translate-y-1/2 flex-col rounded-md border border-line bg-surface"
        >
          <div className="flex flex-col gap-1 border-b border-line px-4 py-4 sm:px-6">
            <DialogPrimitive.Title className="font-heading text-base font-semibold text-fg">{title}</DialogPrimitive.Title>
            {description && <p className="text-[13px] text-fg-muted">{description}</p>}
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto px-4 py-4 sm:px-6 sm:py-5">{children}</div>
          {footer && <div className="flex flex-wrap justify-end gap-2 border-t border-line px-4 py-3 sm:gap-3 sm:px-6 sm:py-4 [&>button]:flex-1 sm:[&>button]:flex-none">{footer}</div>}
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}

/** Ação crítica: exige confirmação explícita e, opcionalmente, um motivo registrado na auditoria. */
export function ConfirmDialog({
  open,
  onOpenChange,
  title,
  description,
  confirmLabel,
  destructive,
  reasonLabel,
  minReason = 3,
  onConfirm,
  successMessage,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: ReactNode;
  confirmLabel: string;
  destructive?: boolean;
  reasonLabel?: string;
  minReason?: number;
  onConfirm: (reason: string) => Promise<unknown>;
  successMessage?: string;
}) {
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const needsReason = reasonLabel !== undefined;
  const valid = !needsReason || reason.trim().length >= minReason;

  async function go() {
    setBusy(true);
    try {
      await onConfirm(reason.trim());
      if (successMessage) toast.success(successMessage);
      setReason("");
      onOpenChange(false);
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
    }
  }

  return (
    <FormModal
      open={open}
      onOpenChange={(o) => {
        if (!busy) onOpenChange(o);
      }}
      title={title}
      width={440}
      footer={
        <>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={busy}>
            Cancelar
          </Button>
          <Button variant={destructive ? "destructive" : "primary"} onClick={go} disabled={busy || !valid}>
            {busy && <LoaderCircle size={14} className="animate-spin" />}
            {confirmLabel}
          </Button>
        </>
      }
    >
      <div className="flex flex-col gap-4">
        <div className={cn("text-[13px] text-fg-muted")}>{description}</div>
        {needsReason && <TextArea label={reasonLabel!} value={reason} onChange={setReason} rows={3} required />}
      </div>
    </FormModal>
  );
}
