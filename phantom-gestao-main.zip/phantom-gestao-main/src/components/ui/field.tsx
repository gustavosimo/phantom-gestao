import * as React from "react";
import { Eye, EyeOff } from "lucide-react";
import * as CheckboxPrimitive from "@radix-ui/react-checkbox";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface TextFieldProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "id"> {
  id: string;
  label: string;
  revealable?: boolean;
}

export const TextField = React.forwardRef<HTMLInputElement, TextFieldProps>(
  ({ id, label, type = "text", revealable, className, ...props }, ref) => {
    const [shown, setShown] = React.useState(false);
    const isPassword = type === "password";
    return (
      <div className="flex w-full flex-col gap-1.5">
        <label htmlFor={id} className="text-[13px] font-medium text-fg-muted">
          {label}
        </label>
        <div className="flex items-center gap-2 rounded-sm border border-line bg-input px-3.5 py-2.5 focus-within:border-silver-dim">
          <input
            ref={ref}
            id={id}
            type={isPassword && shown ? "text" : type}
            className={cn(
              "w-full min-w-0 bg-transparent text-sm text-fg outline-none focus-visible:outline-none placeholder:text-fg-subtle",
              className,
            )}
            {...props}
          />
          {isPassword && revealable && (
            <button
              type="button"
              onClick={() => setShown((s) => !s)}
              aria-label={shown ? "Ocultar senha" : "Mostrar senha"}
              className="cursor-pointer text-fg-subtle hover:text-fg"
            >
              {shown ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          )}
        </div>
      </div>
    );
  },
);
TextField.displayName = "TextField";

interface CheckboxFieldProps {
  id: string;
  label: string;
  checked: boolean;
  onCheckedChange: (v: boolean) => void;
}

export function CheckboxField({ id, label, checked, onCheckedChange }: CheckboxFieldProps) {
  return (
    <div className="flex items-center gap-2">
      <CheckboxPrimitive.Root
        id={id}
        checked={checked}
        onCheckedChange={(v) => onCheckedChange(v === true)}
        className="flex size-[18px] cursor-pointer items-center justify-center rounded-[4px] border-[1.5px] border-line-strong bg-input data-[state=checked]:border-silver data-[state=checked]:bg-silver"
      >
        <CheckboxPrimitive.Indicator>
          <Check size={14} className="text-on-silver" />
        </CheckboxPrimitive.Indicator>
      </CheckboxPrimitive.Root>
      <label htmlFor={id} className="cursor-pointer text-[13px] text-fg">
        {label}
      </label>
    </div>
  );
}
