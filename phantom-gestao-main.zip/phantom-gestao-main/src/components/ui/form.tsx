import * as React from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { maskMoney, inputToCents, centsToInput } from "@/lib/format";

const fieldBox = "flex items-center gap-2 rounded-sm border border-line bg-input px-3.5 py-2.5 focus-within:border-silver-dim";
const inputCls = "w-full min-w-0 bg-transparent text-sm text-fg outline-none placeholder:text-fg-subtle focus-visible:outline-none disabled:opacity-60";

export function Field({ label, htmlFor, hint, error, required, className, children }: { label: string; htmlFor?: string; hint?: string; error?: string | null; required?: boolean; className?: string; children: React.ReactNode }) {
  return (
    <div className={cn("flex min-w-0 flex-col gap-1.5", className)}>
      <label htmlFor={htmlFor} className="text-[13px] font-medium text-fg-muted">
        {label}
        {required && <span className="text-error-fg"> *</span>}
      </label>
      {children}
      {error ? <p className="text-xs text-error-fg">{error}</p> : hint ? <p className="text-xs text-fg-subtle">{hint}</p> : null}
    </div>
  );
}

type InputProps = Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange" | "value"> & {
  label: string;
  value: string;
  onChange: (v: string) => void;
  hint?: string;
  error?: string | null;
  mask?: (v: string) => string;
  mono?: boolean;
};

export function TextInput({ label, value, onChange, hint, error, mask, mono, className, required, id, ...rest }: InputProps) {
  const uid = React.useId();
  const fid = id ?? uid;
  return (
    <Field label={label} htmlFor={fid} hint={hint} error={error} required={required} className={className}>
      <div className={cn(fieldBox, error && "border-error-line")}>
        <input id={fid} value={value} onChange={(e) => onChange(mask ? mask(e.target.value) : e.target.value)} aria-invalid={!!error} className={cn(inputCls, mono && "font-mono")} {...rest} />
      </div>
    </Field>
  );
}

/** Campo monetário: digita-se somente números; o valor externo é sempre em centavos. */
export function MoneyInput({ label, cents, onChange, hint, error, required, className, disabled, placeholder = "0,00" }: { label: string; cents: number | null; onChange: (c: number | null) => void; hint?: string; error?: string | null; required?: boolean; className?: string; disabled?: boolean; placeholder?: string }) {
  const uid = React.useId();
  return (
    <Field label={label} htmlFor={uid} hint={hint} error={error} required={required} className={className}>
      <div className={cn(fieldBox, error && "border-error-line")}>
        <span className="text-sm text-fg-subtle">R$</span>
        <input
          id={uid}
          inputMode="numeric"
          disabled={disabled}
          placeholder={placeholder}
          value={centsToInput(cents)}
          onChange={(e) => onChange(inputToCents(maskMoney(e.target.value)))}
          aria-invalid={!!error}
          className={cn(inputCls, "font-mono")}
        />
      </div>
    </Field>
  );
}

export function SelectInput({ label, value, onChange, options, hint, error, required, className, disabled, placeholder }: { label: string; value: string; onChange: (v: string) => void; options: { value: string; label: string }[]; hint?: string; error?: string | null; required?: boolean; className?: string; disabled?: boolean; placeholder?: string }) {
  const uid = React.useId();
  return (
    <Field label={label} htmlFor={uid} hint={hint} error={error} required={required} className={className}>
      <div className={cn(fieldBox, "relative", error && "border-error-line")}>
        <select id={uid} value={value} disabled={disabled} onChange={(e) => onChange(e.target.value)} className={cn(inputCls, "cursor-pointer appearance-none pr-6")}>
          {placeholder !== undefined && <option value="" className="bg-surface">{placeholder}</option>}
          {options.map((o) => (
            <option key={o.value} value={o.value} className="bg-surface">
              {o.label}
            </option>
          ))}
        </select>
        <ChevronDown size={16} className="pointer-events-none absolute right-3.5 text-fg-subtle" />
      </div>
    </Field>
  );
}

export function TextArea({ label, value, onChange, rows = 3, hint, error, required, className, placeholder, maxLength }: { label: string; value: string; onChange: (v: string) => void; rows?: number; hint?: string; error?: string | null; required?: boolean; className?: string; placeholder?: string; maxLength?: number }) {
  const uid = React.useId();
  return (
    <Field label={label} htmlFor={uid} hint={hint} error={error} required={required} className={className}>
      <div className={cn(fieldBox, "items-start", error && "border-error-line")}>
        <textarea id={uid} rows={rows} value={value} maxLength={maxLength} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} className={cn(inputCls, "resize-y")} />
      </div>
    </Field>
  );
}

export function Toggle({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={cn("relative h-6 w-10 shrink-0 cursor-pointer rounded-full transition-colors disabled:cursor-not-allowed disabled:opacity-50", checked ? "bg-silver" : "bg-line")}
    >
      <span className={cn("absolute top-0.5 size-5 rounded-full bg-on-silver transition-all", checked ? "left-[18px]" : "left-0.5 bg-fg-muted")} />
    </button>
  );
}

export function ChipGroup<T extends string>({ label, value, onChange, items }: { label: string; value: T; onChange: (v: T) => void; items: { value: T; label: string }[] }) {
  return (
    <div className="flex flex-col gap-2.5">
      <span className="text-[13px] font-medium text-fg-muted">{label}</span>
      <div role="radiogroup" aria-label={label} className="flex flex-wrap gap-2">
        {items.map((i) => (
          <button
            key={i.value}
            type="button"
            role="radio"
            aria-checked={value === i.value}
            onClick={() => onChange(i.value)}
            className={cn(
              "cursor-pointer rounded-full border px-4 py-2 text-[13px] font-semibold transition-colors",
              value === i.value ? "border-silver bg-silver text-on-silver" : "border-line-strong text-fg hover:bg-surface-hover",
            )}
          >
            {i.label}
          </button>
        ))}
      </div>
    </div>
  );
}
