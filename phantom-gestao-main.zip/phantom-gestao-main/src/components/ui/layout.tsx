import type { LucideIcon } from "lucide-react";
import { ChevronDown, Search, TrendingDown, TrendingUp } from "lucide-react";
import * as React from "react";
import { cn } from "@/lib/utils";

export function Card({ className, children, id }: { className?: string; children: React.ReactNode; id?: string }) {
  return <section id={id} className={cn("rounded-md border border-line bg-surface", className)}>{children}</section>;
}

export function CardHeader({ title, subtitle, right, className }: { title: React.ReactNode; subtitle?: React.ReactNode; right?: React.ReactNode; className?: string }) {
  return (
    <div className={cn("sticky left-0 flex flex-wrap items-start justify-between gap-x-4 gap-y-3 px-4 pt-4 pb-3 sm:px-6 sm:pt-5 sm:pb-4", className)}>
      <div className="min-w-0">
        <h3 className="font-heading text-base font-semibold text-fg">{title}</h3>
        {subtitle && <p className="pt-0.5 text-xs text-fg-muted">{subtitle}</p>}
      </div>
      {right}
    </div>
  );
}

export function StatCard({
  label,
  value,
  icon: Icon,
  tone = "neutral",
  delta,
  hint,
  small,
}: {
  label: string;
  value: React.ReactNode;
  icon?: LucideIcon;
  tone?: "neutral" | "success" | "warning" | "error" | "info";
  delta?: { text: string; positive: boolean | null };
  hint?: React.ReactNode;
  small?: boolean;
}) {
  const iconTone = {
    neutral: "text-gold",
    success: "text-success-fg",
    warning: "text-warning-fg",
    error: "text-error-fg",
    info: "text-info-fg",
  }[tone];
  return (
    <div className={cn("flex min-w-0 flex-col gap-2 rounded-md border border-line bg-surface sm:gap-3", small ? "px-3 py-3 sm:px-4 sm:py-3.5" : "p-3.5 sm:p-5")}>
      <div className="flex items-center justify-between gap-2">
        <span className="text-[13px] text-fg-muted">{label}</span>
        {Icon && (
          <span className={cn("flex size-7 shrink-0 items-center justify-center rounded-sm", iconTone)}>
            <Icon size={14} />
          </span>
        )}
      </div>
      <div className={cn("font-heading font-bold text-fg [&_.font-mono]:font-heading", small ? "text-base sm:text-lg" : "text-xl sm:text-2xl")}>{value}</div>
      {delta && (
        <div
          className={cn(
            "flex items-center gap-1.5 text-xs",
            delta.positive === null ? "text-fg-subtle" : delta.positive ? "text-success-fg" : "text-error-fg",
          )}
        >
          {delta.positive === null ? null : delta.positive ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
          {delta.text}
        </div>
      )}
      {hint && <div className="text-xs text-fg-subtle">{hint}</div>}
    </div>
  );
}

export function SearchInput({ value, onChange, placeholder, className }: { value: string; onChange: (v: string) => void; placeholder: string; className?: string }) {
  return (
    <div className={cn("flex items-center gap-2 rounded-sm border border-line bg-surface px-3.5 py-2.5", className)}>
      <Search size={15} className="shrink-0 text-fg-subtle" />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        aria-label={placeholder}
        className="w-full bg-transparent text-[13px] text-fg outline-none placeholder:text-fg-subtle focus-visible:outline-none"
      />
    </div>
  );
}

export function FilterSelect({
  value,
  onChange,
  label,
  options,
  className,
}: {
  value: string;
  onChange: (v: string) => void;
  label: string;
  options: { value: string; label: string }[];
  className?: string;
}) {
  return (
    <label className={cn("relative inline-flex items-center rounded-sm border border-line bg-surface", className)}>
      <span className="sr-only">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="cursor-pointer appearance-none bg-transparent py-2.5 pr-9 pl-3.5 text-[13px] text-fg-muted outline-none"
      >
        <option value="" className="bg-surface">{label}</option>
        {options.map((o) => (
          <option key={o.value} value={o.value} className="bg-surface">
            {o.label}
          </option>
        ))}
      </select>
      <ChevronDown size={14} className="pointer-events-none absolute right-3 text-fg-subtle" />
    </label>
  );
}

export function Segmented<T extends string>({
  value,
  onChange,
  items,
  className,
}: {
  value: T;
  onChange: (v: T) => void;
  items: { value: T; label: string; badge?: number }[];
  className?: string;
}) {
  return (
    <div role="tablist" className={cn("inline-flex max-w-full gap-1 overflow-x-auto rounded-sm border border-line bg-surface p-1", className)}>
      {items.map((i) => (
        <button
          key={i.value}
          role="tab"
          aria-selected={value === i.value}
          onClick={() => onChange(i.value)}
          className={cn(
            "shrink-0 cursor-pointer rounded-[5px] px-3 py-2 text-[13px] font-medium whitespace-nowrap transition-colors sm:px-4",
            value === i.value ? "border border-gold-line bg-gold-bg text-gold-bright" : "border border-transparent text-fg-muted hover:text-fg",
          )}
        >
          {i.label}
          {i.badge ? <span className="ml-2 rounded-full bg-error-bg px-1.5 py-0.5 text-[11px] text-error-fg">{i.badge}</span> : null}
        </button>
      ))}
    </div>
  );
}

export function EmptyState({ icon: Icon, title, text, action }: { icon?: LucideIcon; title: string; text?: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-2 px-4 py-10 text-center sm:px-6 sm:py-14">
      {Icon && (
        <span className="flex size-11 items-center justify-center rounded-full bg-surface-hover text-fg-subtle">
          <Icon size={20} />
        </span>
      )}
      <p className="text-sm font-medium text-fg">{title}</p>
      {text && <p className="max-w-sm text-[13px] text-fg-muted">{text}</p>}
      {action}
    </div>
  );
}

export function ErrorNotice({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="flex items-center justify-between gap-3 rounded-sm border border-error-line bg-error-bg px-4 py-3 text-[13px] text-error-fg">
      <span>{message}</span>
      {onRetry && (
        <button onClick={onRetry} className="cursor-pointer font-semibold underline">
          Tentar novamente
        </button>
      )}
    </div>
  );
}

export function Notice({ tone = "warning", icon: Icon, children, className }: { tone?: "warning" | "info" | "error" | "success"; icon?: LucideIcon; children: React.ReactNode; className?: string }) {
  const cls = {
    warning: "border-warning-line bg-warning-bg text-warning-fg",
    info: "border-info-line bg-info-bg text-info-fg",
    error: "border-error-line bg-error-bg text-error-fg",
    success: "border-success-line bg-success-bg text-success-fg",
  }[tone];
  return (
    <div className={cn("flex items-start gap-2.5 rounded-sm border px-4 py-3 text-xs leading-relaxed", cls, className)}>
      {Icon && <Icon size={14} className="mt-0.5 shrink-0" />}
      <div>{children}</div>
    </div>
  );
}

export function Mono({ children, className }: { children: React.ReactNode; className?: string }) {
  return <span className={cn("font-mono text-[13px] whitespace-nowrap", className)}>{children}</span>;
}
