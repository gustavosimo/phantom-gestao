import { create } from "zustand";
import { CircleAlert, CircleCheck, X } from "lucide-react";
import { errorMessage } from "@/services/api";

interface Toast {
  id: number;
  tone: "success" | "error";
  text: string;
}

interface ToastState {
  toasts: Toast[];
  push: (tone: Toast["tone"], text: string) => void;
  dismiss: (id: number) => void;
}

let seq = 0;

export const useToasts = create<ToastState>((set) => ({
  toasts: [],
  push(tone, text) {
    const id = ++seq;
    set((s) => ({ toasts: [...s.toasts.slice(-3), { id, tone, text }] }));
    setTimeout(() => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })), tone === "error" ? 8000 : 4000);
  },
  dismiss: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
}));

export const toast = {
  success: (text: string) => useToasts.getState().push("success", text),
  error: (e: unknown) => useToasts.getState().push("error", errorMessage(e)),
};

export function Toaster() {
  const toasts = useToasts((s) => s.toasts);
  const dismiss = useToasts((s) => s.dismiss);
  return (
    <div className="pointer-events-none fixed right-3 bottom-3 left-3 z-[60] flex flex-col gap-2 sm:right-6 sm:bottom-6 sm:left-auto sm:w-[360px]" aria-live="polite">
      {toasts.map((t) => (
        <div
          key={t.id}
          role={t.tone === "error" ? "alert" : "status"}
          className={`pointer-events-auto flex items-start gap-2.5 rounded-md border px-4 py-3 text-[13px] ${
            t.tone === "error"
              ? "border-error-line bg-error-bg text-error-fg"
              : "border-success-line bg-success-bg text-success-fg"
          }`}
        >
          {t.tone === "error" ? <CircleAlert size={16} className="mt-0.5 shrink-0" /> : <CircleCheck size={16} className="mt-0.5 shrink-0" />}
          <span className="flex-1">{t.text}</span>
          <button onClick={() => dismiss(t.id)} aria-label="Fechar" className="cursor-pointer opacity-70 hover:opacity-100">
            <X size={14} />
          </button>
        </div>
      ))}
    </div>
  );
}
