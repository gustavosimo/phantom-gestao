import { useApi } from "@/hooks/useApi";
import { api } from "@/services/api";

/** Estado regulatório das operações de crédito e garantias. */
export function useRegulatory() {
  const { data, reload } = useApi(() => api.regulatory(), []);
  return {
    loaded: !!data,
    creditEnabled: data?.creditEnabled ?? false,
    collateralEnabled: data?.collateralEnabled ?? false,
    data,
    reload,
  };
}
