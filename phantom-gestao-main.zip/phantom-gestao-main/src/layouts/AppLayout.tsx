import { useEffect, useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { Outlet, useLocation } from "react-router-dom";
import { Header } from "@/layouts/Header";
import { Sidebar } from "@/layouts/Sidebar";
import { useAuth } from "@/app/auth-store";
import { toast } from "@/components/ui/toast";

/** Encerra a sessão após inatividade (proteção de dados pessoais em estações compartilhadas). */
const IDLE_MINUTES = 30;

function useIdleLogout() {
  const logout = useAuth((s) => s.logout);
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    const arm = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        logout().then(() => toast.success("Sessão encerrada por inatividade.")).catch(() => {});
      }, IDLE_MINUTES * 60_000);
    };
    const events = ["mousemove", "mousedown", "keydown", "wheel", "touchstart"] as const;
    events.forEach((e) => window.addEventListener(e, arm, { passive: true }));
    arm();
    return () => {
      clearTimeout(timer);
      events.forEach((e) => window.removeEventListener(e, arm));
    };
  }, [logout]);
}

const COLLAPSE_KEY = "phantom.sidebar-collapsed";

function readCollapsed(): boolean {
  try {
    return localStorage.getItem(COLLAPSE_KEY) === "1";
  } catch {
    return false;
  }
}

export function AppLayout() {
  useIdleLogout();
  const [collapsed, setCollapsed] = useState(readCollapsed);
  const [navOpen, setNavOpen] = useState(false);
  const { pathname } = useLocation();
  useEffect(() => setNavOpen(false), [pathname]);

  function toggle() {
    setCollapsed((c) => {
      try {
        localStorage.setItem(COLLAPSE_KEY, c ? "0" : "1");
      } catch {
        /* ignorar */
      }
      return !c;
    });
  }

  return (
    <div className="flex h-full gap-2 bg-app p-1.5 lg:p-2">
      <Sidebar collapsed={collapsed} onToggle={toggle} />
      {/* celular/tablet: o menu vira uma gaveta que abre pelo botão do cabeçalho */}
      <Dialog.Root open={navOpen} onOpenChange={setNavOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 z-50 bg-black/60 lg:hidden" />
          <Dialog.Content aria-describedby={undefined} className="fixed inset-y-0 left-0 z-50 w-[min(300px,86vw)] p-1.5 outline-none lg:hidden">
            <Dialog.Title className="sr-only">Menu de navegação</Dialog.Title>
            <Sidebar mobile collapsed={false} onToggle={() => {}} onNavigate={() => setNavOpen(false)} />
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
      <div className="flex min-w-0 flex-1 flex-col gap-1.5 lg:gap-2">
        <Header onMenu={() => setNavOpen(true)} />
        <main className="min-h-0 flex-1 overflow-y-auto rounded-lg border border-line bg-app p-3 sm:p-5 lg:p-7">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
