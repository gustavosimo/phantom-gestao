import { useEffect, useMemo, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import * as Dropdown from "@radix-ui/react-dropdown-menu";
import { Bell, Menu, Search, X } from "lucide-react";
import { ALL_MODULES, findModule } from "@/app/navigation";
import { useAuth } from "@/app/auth-store";
import { useHeader } from "@/app/page-header";
import { Avatar } from "@/layouts/Sidebar";
import { UserMenu } from "@/layouts/UserMenu";
import { api } from "@/services/api";
import type { NotificationRow } from "@/types/domain";
import { relativeTime } from "@/lib/format";
import { cn } from "@/lib/utils";

function normalize(s: string) {
  return s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
}

/** Busca global: módulos acessíveis ao usuário e, com 3+ caracteres, clientes cadastrados. */
function GlobalSearch() {
  const navigate = useNavigate();
  const can = useAuth((s) => s.can);
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [clients, setClients] = useState<{ id: number; name: string }[]>([]);
  // celular: a busca é um ícone que abre uma barra sobre o cabeçalho
  const [expanded, setExpanded] = useState(false);

  const results = useMemo(() => {
    const q = normalize(query.trim());
    if (!q) return [];
    return ALL_MODULES.filter((m) => can(m.permission) && normalize(m.label).includes(q));
  }, [query, can]);

  useEffect(() => {
    const q = query.trim();
    if (q.length < 3 || !can("clients.view")) {
      setClients([]);
      return;
    }
    const t = setTimeout(() => {
      api.clientOptions(q).then((r) => setClients(r.slice(0, 5))).catch(() => setClients([]));
    }, 250);
    return () => clearTimeout(t);
  }, [query, can]);

  function go(path: string) {
    navigate(path);
    setQuery("");
    setOpen(false);
    setExpanded(false);
  }

  const empty = results.length === 0 && clients.length === 0;

  return (
    <>
    {!expanded && (
      <button type="button" aria-label="Abrir busca" onClick={() => setExpanded(true)} className="flex size-[38px] cursor-pointer items-center justify-center rounded-full bg-surface text-fg-muted hover:text-fg md:hidden">
        <Search size={17} />
      </button>
    )}
    <div className={cn(expanded ? "fixed inset-x-1.5 top-1.5 z-50 flex h-14 items-center gap-2 rounded-lg border border-line bg-app px-3" : "relative hidden md:block")}>
      <div className={cn("flex items-center gap-2 rounded-full border border-line bg-surface px-3.5 py-2", expanded ? "min-w-0 flex-1" : "w-[220px]")}>
        <Search size={14} className="shrink-0 text-fg-subtle" />
        <input
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              if (results[0]) go(results[0].path);
              else if (clients[0]) go(`/clientes/${clients[0].id}`);
            }
            if (e.key === "Escape") setOpen(false);
          }}
          placeholder="Buscar..."
          aria-label="Busca global"
          autoFocus={expanded}
          className="w-full bg-transparent text-[13px] text-fg outline-none placeholder:text-fg-subtle focus-visible:outline-none"
        />
      </div>
      {expanded && (
        <button type="button" aria-label="Fechar busca" onClick={() => { setExpanded(false); setQuery(""); setOpen(false); }} className="flex size-9 shrink-0 cursor-pointer items-center justify-center rounded-full text-fg-muted hover:text-fg">
          <X size={18} />
        </button>
      )}
      {open && query.trim() && (
        <div className={cn("absolute top-full z-40 mt-2 rounded-md border border-line bg-surface p-1.5", expanded ? "inset-x-0" : "right-0 w-[260px]")}>
          {empty ? (
            <div className="px-3 py-2 text-[13px] text-fg-subtle">Nada encontrado</div>
          ) : (
            <>
              {results.map(({ path, label, icon: Icon }) => (
                <button key={path} onMouseDown={(e) => e.preventDefault()} onClick={() => go(path)} className="flex w-full cursor-pointer items-center gap-2 rounded-sm px-3 py-2 text-left text-[13px] text-fg-muted hover:bg-surface-hover hover:text-fg">
                  <Icon size={14} /> {label}
                </button>
              ))}
              {clients.length > 0 && <div className="px-3 pt-2 pb-1 text-[11px] font-bold tracking-wider text-fg-subtle uppercase">Clientes</div>}
              {clients.map((c) => (
                <button key={c.id} onMouseDown={(e) => e.preventDefault()} onClick={() => go(`/clientes/${c.id}`)} className="flex w-full cursor-pointer items-center gap-2 rounded-sm px-3 py-2 text-left text-[13px] text-fg-muted hover:bg-surface-hover hover:text-fg">
                  {c.name}
                </button>
              ))}
            </>
          )}
        </div>
      )}
    </div>
    </>
  );
}

function NotificationsButton() {
  const can = useAuth((s) => s.can);
  const [unread, setUnread] = useState(0);
  const [items, setItems] = useState<NotificationRow[]>([]);
  const allowed = can("notifications.view");
  const { pathname } = useLocation();

  useEffect(() => {
    if (!allowed) return;
    let alive = true;
    const load = () => {
      api.unreadCount().then((n) => alive && setUnread(n)).catch(() => {});
    };
    api.runRules().catch(() => {}).finally(load);
    const t = setInterval(load, 60_000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [allowed, pathname]);

  async function loadItems(open: boolean) {
    if (!open) return;
    try {
      const page = await api.notifications({ page: 1, pageSize: 5, status: "unread" });
      setItems(page.items);
    } catch {
      setItems([]);
    }
  }

  if (!allowed) return null;
  return (
    <Dropdown.Root onOpenChange={loadItems}>
      <Dropdown.Trigger aria-label={`Notificações${unread ? ` (${unread} não lidas)` : ""}`} className="relative flex size-[38px] cursor-pointer items-center justify-center rounded-full bg-surface text-fg-muted hover:text-fg">
        <Bell size={17} />
        {unread > 0 && <span className="absolute top-1 right-1 size-2 rounded-full border-2 border-app bg-error-fg" />}
      </Dropdown.Trigger>
      <Dropdown.Portal>
        <Dropdown.Content align="end" sideOffset={8} className="z-50 w-[min(340px,calc(100vw-1rem))] rounded-md border border-line bg-surface">
          <div className="border-b border-line px-4 py-3 text-[13px] font-semibold text-fg">Avisos e Notificações</div>
          <div className="max-h-[320px] overflow-y-auto">
            {items.length === 0 ? (
              <p className="px-4 py-4 text-[13px] text-fg-muted">Nenhuma notificação não lida.</p>
            ) : (
              items.map((n) => (
                <div key={n.id} className="flex flex-col gap-0.5 border-b border-line px-4 py-3 last:border-b-0">
                  <span className="text-[13px] font-medium text-fg">{n.title}</span>
                  {n.body && <span className="text-xs text-fg-muted">{n.body}</span>}
                  <span className="text-[11px] text-fg-subtle">{relativeTime(n.createdAt)}</span>
                </div>
              ))
            )}
          </div>
          <Dropdown.Item asChild>
            <Link to="/notificacoes" className={cn("block cursor-pointer border-t border-line px-4 py-3 text-center text-[13px] font-medium text-fg outline-none data-[highlighted]:bg-surface-hover")}>
              Ver central de notificações
            </Link>
          </Dropdown.Item>
        </Dropdown.Content>
      </Dropdown.Portal>
    </Dropdown.Root>
  );
}

export function Header({ onMenu }: { onMenu?: () => void }) {
  const { pathname } = useLocation();
  const mod = findModule(pathname);
  const user = useAuth((s) => s.user);
  const title = useHeader((s) => s.title);
  const subtitle = useHeader((s) => s.subtitle);

  return (
    <header className="flex h-14 shrink-0 items-center justify-between gap-2 rounded-lg border border-line bg-app px-3 sm:px-5 lg:h-[72px] lg:px-7">
      <div className="flex min-w-0 items-center gap-2">
        {onMenu && (
          <button type="button" aria-label="Abrir menu" onClick={onMenu} className="flex size-9 shrink-0 cursor-pointer items-center justify-center rounded-md text-fg-muted hover:bg-surface-hover hover:text-fg lg:hidden">
            <Menu size={20} />
          </button>
        )}
        <div className="flex min-w-0 flex-col gap-0.5">
          <h2 className="truncate font-heading text-base font-bold text-fg sm:text-lg lg:text-xl">{title ?? mod?.title ?? mod?.label ?? "Phantom Gestão"}</h2>
          <div className="hidden truncate text-xs text-fg-muted sm:block">{subtitle ?? mod?.subtitle ?? ""}</div>
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-2 lg:gap-4">
        <GlobalSearch />
        <NotificationsButton />
        <div className="hidden h-7 w-px bg-line lg:block" />
        {user && (
          <div className="flex items-center gap-2.5">
            <Avatar name={user.fullName} />
            <div className="hidden flex-col leading-tight lg:flex">
              <span className="text-[13px] font-semibold text-fg">{user.fullName}</span>
              <span className="text-[11px] text-fg-subtle">{user.roleName}</span>
            </div>
            <UserMenu variant="chevron" />
          </div>
        )}
      </div>
    </header>
  );
}
