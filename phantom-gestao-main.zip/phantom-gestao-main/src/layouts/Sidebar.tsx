import { NavLink } from "react-router-dom";
import { PanelLeftClose, PanelLeftOpen, X } from "lucide-react";
import { LogoMark } from "@/components/Logo";
import { NAV_SECTIONS } from "@/app/navigation";
import { useAuth } from "@/app/auth-store";
import { UserMenu } from "@/layouts/UserMenu";
import { cn } from "@/lib/utils";

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
  /** Gaveta do celular: sempre expandida, ocupa a largura do painel e fecha ao navegar. */
  mobile?: boolean;
  onNavigate?: () => void;
}

function initials(name: string) {
  const parts = name.trim().split(/\s+/);
  return ((parts[0]?.[0] ?? "") + (parts.length > 1 ? parts[parts.length - 1][0] : "")).toUpperCase();
}

export function Avatar({ name, size = 34 }: { name: string; size?: number }) {
  return (
    <div
      className="flex shrink-0 items-center justify-center rounded-full bg-surface-hover text-xs font-semibold text-silver"
      style={{ width: size, height: size }}
    >
      {initials(name)}
    </div>
  );
}

export function Sidebar({ collapsed: collapsedProp, onToggle, mobile, onNavigate }: SidebarProps) {
  const user = useAuth((s) => s.user);
  const can = useAuth((s) => s.can);
  const collapsed = mobile ? false : collapsedProp;

  return (
    <aside
      className={cn(
        "h-full shrink-0 flex-col overflow-hidden rounded-lg border border-line bg-sidebar transition-[width] duration-150",
        mobile ? "flex w-full" : cn("hidden lg:flex", collapsed ? "w-[72px]" : "w-[260px]"),
      )}
    >
      <div className={cn("flex items-center gap-2.5 p-5", collapsed && "flex-col px-0")}>
        <LogoMark size={36} />
        {!collapsed && (
          <div className="flex min-w-0 flex-1 flex-col leading-tight">
            <span className="font-heading text-sm font-extrabold tracking-[0.5px] text-fg">PHANTOM</span>
            <span className="font-heading text-[10px] font-semibold tracking-[1.5px] text-silver-dim">GESTÃO</span>
          </div>
        )}
        <button
          type="button"
          onClick={mobile ? onNavigate : onToggle}
          aria-label={mobile ? "Fechar menu" : collapsed ? "Expandir menu lateral" : "Recolher menu lateral"}
          className="cursor-pointer rounded-sm p-1 text-fg-subtle hover:bg-surface-hover hover:text-fg"
        >
          {mobile ? <X size={18} /> : collapsed ? <PanelLeftOpen size={16} /> : <PanelLeftClose size={16} />}
        </button>
      </div>

      <nav className="flex min-h-0 flex-1 flex-col gap-0.5 overflow-y-auto px-3 py-2">
        {NAV_SECTIONS.map((section) => {
          const items = section.items.filter((i) => can(i.permission));
          if (items.length === 0) return null;
          return (
            <div key={section.title} className="flex flex-col gap-0.5">
              {collapsed ? (
                <div className="mx-3 my-2 h-px bg-line" />
              ) : (
                <div className="px-4 py-2 text-[11px] font-bold tracking-[1px] text-fg-subtle uppercase">
                  {section.title}
                </div>
              )}
              {items.map(({ path, label, icon: Icon }) => (
                <NavLink
                  key={path}
                  to={path}
                  end={path === "/"}
                  title={collapsed ? label : undefined}
                  onClick={onNavigate}
                  className={({ isActive }) =>
                    cn(
                      "flex items-center gap-3 rounded-sm border border-transparent px-4 py-2.5 text-sm font-medium transition-colors",
                      mobile && "py-3",
                      collapsed && "justify-center px-0",
                      isActive
                        ? "border-gold-line bg-gold-bg text-gold-bright [&>svg]:text-gold"
                        : "text-fg-muted hover:bg-surface-hover/60 hover:text-fg",
                    )
                  }
                >
                  <Icon size={18} className="shrink-0" />
                  {!collapsed && label}
                </NavLink>
              ))}
            </div>
          );
        })}
      </nav>

      {user && (
        <div className={cn("m-3 flex items-center gap-2.5 rounded-lg border border-line bg-surface p-3", collapsed && "justify-center px-0")}>
          <Avatar name={user.fullName} />
          {!collapsed && (
            <>
              <div className="flex min-w-0 flex-1 flex-col leading-tight">
                <span className="truncate text-[13px] font-semibold text-fg">{user.fullName}</span>
                <span className="text-[11px] text-fg-subtle">{user.roleName}</span>
              </div>
              <UserMenu variant="dots" />
            </>
          )}
        </div>
      )}
    </aside>
  );
}
