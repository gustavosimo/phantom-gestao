import { useEffect, useState } from "react";
import { Minus, Square, Copy, X } from "lucide-react";
import { getCurrentWindow } from "@tauri-apps/api/window";
import { cn } from "@/lib/utils";

function inTauri() {
  return typeof window !== "undefined" && "__TAURI_INTERNALS__" in window;
}

/** Barra de título própria (janela sem moldura), no mesmo estilo dos painéis do sistema. */
export function TitleBar() {
  const [maximized, setMaximized] = useState(false);

  useEffect(() => {
    if (!inTauri()) return;
    const win = getCurrentWindow();
    let off: (() => void) | undefined;
    const sync = () => win.isMaximized().then(setMaximized).catch(() => {});
    sync();
    win.onResized(sync).then((u) => (off = u)).catch(() => {});
    return () => off?.();
  }, []);

  const act = (f: (w: ReturnType<typeof getCurrentWindow>) => Promise<void>) => () => {
    if (inTauri()) f(getCurrentWindow()).catch(() => {});
  };

  // No navegador (modo web) não há janela própria: o próprio navegador fornece a moldura.
  if (!inTauri()) return null;

  return (
    <div data-tauri-drag-region className="flex h-9 shrink-0 items-center justify-between bg-app pr-1 pl-3 select-none">
      <div data-tauri-drag-region className="flex-1 self-stretch" />
      <div className="flex items-center gap-0.5">
        <CtrlBtn label="Minimizar" onClick={act((w) => w.minimize())}><Minus size={14} /></CtrlBtn>
        <CtrlBtn label={maximized ? "Restaurar" : "Maximizar"} onClick={act((w) => w.toggleMaximize())}>{maximized ? <Copy size={12} /> : <Square size={12} />}</CtrlBtn>
        <CtrlBtn label="Fechar" danger onClick={act((w) => w.close())}><X size={15} /></CtrlBtn>
      </div>
    </div>
  );
}

function CtrlBtn({ label, onClick, danger, children }: { label: string; onClick: () => void; danger?: boolean; children: React.ReactNode }) {
  return (
    <button type="button" aria-label={label} title={label} onClick={onClick} className={cn("flex h-7 w-11 cursor-pointer items-center justify-center rounded-md text-fg-muted transition-colors", danger ? "hover:bg-[#c42b1c] hover:text-white" : "hover:bg-surface-hover hover:text-fg")}>
      {children}
    </button>
  );
}
