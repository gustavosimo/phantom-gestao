import { useState } from "react";
import * as Dropdown from "@radix-ui/react-dropdown-menu";
import { ChevronDown, EllipsisVertical, KeyRound, LogOut } from "lucide-react";
import { useAuth } from "@/app/auth-store";
import { Button } from "@/components/ui/button";
import { FormModal, Modal, ModalClose } from "@/components/ui/dialog";
import { TextInput } from "@/components/ui/form";
import { toast } from "@/components/ui/toast";
import { authApi, errorMessage } from "@/services/api";

/** Menu do usuário: alterar senha e sair (com confirmação). */
export function UserMenu({ variant }: { variant: "chevron" | "dots" }) {
  const user = useAuth((s) => s.user);
  const logout = useAuth((s) => s.logout);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pwdOpen, setPwdOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!user) return null;

  async function doLogout() {
    try {
      await logout();
    } catch (e) {
      setError(errorMessage(e));
    }
  }

  return (
    <>
      <Dropdown.Root>
        <Dropdown.Trigger aria-label="Menu do usuário" className="cursor-pointer rounded-sm p-1 text-fg-subtle hover:text-fg">
          {variant === "chevron" ? <ChevronDown size={14} /> : <EllipsisVertical size={16} />}
        </Dropdown.Trigger>
        <Dropdown.Portal>
          <Dropdown.Content align="end" sideOffset={8} className="z-50 min-w-[210px] rounded-md border border-line bg-surface p-1.5 text-sm">
            <div className="px-3 py-2">
              <div className="text-[13px] font-semibold text-fg">{user.fullName}</div>
              <div className="text-[11px] text-fg-subtle">
                {user.roleName} · @{user.username}
              </div>
            </div>
            <Dropdown.Separator className="my-1 h-px bg-line" />
            <Dropdown.Item onSelect={() => setPwdOpen(true)} className="flex cursor-pointer items-center gap-2 rounded-sm px-3 py-2 text-fg outline-none data-[highlighted]:bg-surface-hover">
              <KeyRound size={14} /> Alterar senha
            </Dropdown.Item>
            <Dropdown.Item onSelect={() => setConfirmOpen(true)} className="flex cursor-pointer items-center gap-2 rounded-sm px-3 py-2 text-error-fg outline-none data-[highlighted]:bg-surface-hover">
              <LogOut size={14} /> Sair
            </Dropdown.Item>
          </Dropdown.Content>
        </Dropdown.Portal>
      </Dropdown.Root>

      <Modal
        open={confirmOpen}
        onOpenChange={setConfirmOpen}
        title="Encerrar sessão?"
        description={error ?? "Você precisará entrar novamente para continuar usando o Phantom Gestão."}
        actions={
          <>
            <ModalClose asChild>
              <Button variant="outline">Cancelar</Button>
            </ModalClose>
            <Button onClick={doLogout}>Sair</Button>
          </>
        }
      />
      {pwdOpen && <ChangePassword onClose={() => setPwdOpen(false)} />}
    </>
  );
}

function ChangePassword({ onClose }: { onClose: () => void }) {
  const [cur, setCur] = useState("");
  const [next, setNext] = useState("");
  const [again, setAgain] = useState("");
  const [busy, setBusy] = useState(false);
  async function go() {
    setBusy(true);
    try {
      await authApi.changePassword(cur, next);
      toast.success("Senha alterada.");
      onClose();
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
    }
  }
  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title="Alterar senha" width={420}
      footer={<><Button variant="outline" onClick={onClose} disabled={busy}>Cancelar</Button><Button onClick={go} disabled={busy || !cur || next.length < 10 || next !== again}>Alterar senha</Button></>}>
      <div className="flex flex-col gap-4">
        <TextInput label="Senha atual" type="password" value={cur} onChange={setCur} autoFocus />
        <TextInput label="Nova senha" type="password" value={next} onChange={setNext} hint="Mínimo de 10 caracteres, com letras e números." />
        <TextInput label="Confirmar nova senha" type="password" value={again} onChange={setAgain} error={again && next !== again ? "As senhas não coincidem." : null} />
      </div>
    </FormModal>
  );
}
