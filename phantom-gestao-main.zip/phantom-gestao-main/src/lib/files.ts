import { open, save } from "@tauri-apps/plugin-dialog";
import { api, isDesktop } from "@/services/api";
import { toast } from "@/components/ui/toast";

export const DOC_FILTERS = [{ name: "Documentos e imagens", extensions: ["pdf", "png", "jpg", "jpeg", "webp"] }];
export const IMAGE_FILTERS = [{ name: "Imagens", extensions: ["png", "jpg", "jpeg", "webp"] }];

/**
 * Modo web: abre o seletor do navegador e envia cada arquivo ao servidor, que devolve uma referência
 * `upload:<token>/<nome>`. Ela é usada no lugar do caminho do disco (que no navegador não existe) e
 * funciona com `fileName()` e com os mesmos comandos do desktop.
 */
const MAX_UPLOAD_BYTES = 15 * 1024 * 1024;

function browserPick(filters: { extensions: string[] }[], multiple: boolean): Promise<File[]> {
  return new Promise((resolve) => {
    const input = document.createElement("input");
    input.type = "file";
    input.multiple = multiple;
    input.accept = filters.flatMap((f) => f.extensions).map((e) => `.${e}`).join(",");
    input.onchange = () => resolve(Array.from(input.files ?? []));
    input.oncancel = () => resolve([]);
    input.click();
  });
}

async function uploadFile(file: File): Promise<string> {
  if (file.size > MAX_UPLOAD_BYTES) throw "Arquivo maior que 15 MB.";
  let res: Response;
  try {
    res = await fetch("/upload", {
      method: "POST",
      credentials: "same-origin",
      headers: { "X-Requested-With": "phantom", "X-File-Name": encodeURIComponent(file.name) },
      body: file,
    });
  } catch {
    throw "Sem conexão com o servidor. Verifique a internet e tente novamente.";
  }
  const body = await res.json().catch(() => null);
  if (!res.ok) throw typeof body === "string" ? body : "Não foi possível enviar o arquivo.";
  return (body as { path: string }).path;
}

async function pickAndUpload(filters: { extensions: string[] }[], multiple: boolean): Promise<string[]> {
  const files = await browserPick(filters, multiple);
  const refs: string[] = [];
  for (const f of files) {
    try {
      refs.push(await uploadFile(f));
    } catch (e) {
      toast.error(e);
    }
  }
  return refs;
}

export async function pickFile(filters = DOC_FILTERS): Promise<string | null> {
  if (!isDesktop) return (await pickAndUpload(filters, false))[0] ?? null;
  const r = await open({ multiple: false, directory: false, filters });
  return typeof r === "string" ? r : null;
}

export async function pickFiles(filters = IMAGE_FILTERS): Promise<string[]> {
  if (!isDesktop) return pickAndUpload(filters, true);
  const r = await open({ multiple: true, directory: false, filters });
  return Array.isArray(r) ? r : typeof r === "string" ? [r] : [];
}

export async function pickDirectory(): Promise<string | null> {
  const r = await open({ multiple: false, directory: true });
  return typeof r === "string" ? r : null;
}

export function fileName(path: string): string {
  return path.split(/[\\/]/).pop() ?? path;
}

/** Modo web: o arquivo decifrado vem do servidor e o navegador o baixa. */
async function browserDownload(id: number, suggestedName: string): Promise<void> {
  try {
    const { meta, dataBase64 } = await api.attachmentRead(id);
    const url = blobUrl(meta.mime, dataBase64);
    const a = document.createElement("a");
    a.href = url;
    a.download = suggestedName || meta.originalName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10_000);
  } catch (e) {
    toast.error(e);
  }
}

/** "Salvar como…": o arquivo cifrado é decifrado pelo backend e gravado no destino escolhido. */
export async function downloadAttachment(id: number, suggestedName: string): Promise<void> {
  if (!isDesktop) return browserDownload(id, suggestedName);
  const ext = suggestedName.split(".").pop() ?? "";
  const path = await save({ defaultPath: suggestedName, filters: ext ? [{ name: ext.toUpperCase(), extensions: [ext] }] : undefined });
  if (!path) return;
  try {
    await api.attachmentSaveTo(id, path);
    toast.success(`Arquivo salvo em ${path}`);
  } catch (e) {
    toast.error(e);
  }
}

export function dataUrl(mime: string, b64: string): string {
  return `data:${mime};base64,${b64}`;
}

export function blobUrl(mime: string, b64: string): string {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return URL.createObjectURL(new Blob([bytes], { type: mime }));
}

export function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${Math.round(n / 1024)} KB`;
  return `${(n / 1024 / 1024).toFixed(1).replace(".", ",")} MB`;
}
