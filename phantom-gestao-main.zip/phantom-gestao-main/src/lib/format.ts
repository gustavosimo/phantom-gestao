/** Formatação e máscaras. Valores monetários são sempre inteiros em centavos (sem ponto flutuante). */

export function formatBRL(cents: number | null | undefined): string {
  if (cents === null || cents === undefined) return "—";
  const neg = cents < 0;
  const abs = Math.abs(cents);
  const reais = Math.floor(abs / 100);
  const c = String(abs % 100).padStart(2, "0");
  const grouped = String(reais).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  return `${neg ? "-" : ""}R$ ${grouped},${c}`;
}

/** Converte "R$ 1.234,56", "1234,5" ou "1234" em centavos. Retorna null se inválido. */
export function parseBRL(input: string): number | null {
  const s = input.replace(/[R$\s]/g, "");
  if (!s) return null;
  if (!/^\d{1,3}(\.\d{3})*(,\d{0,2})?$|^\d+(,\d{0,2})?$/.test(s)) return null;
  const [reais, dec = ""] = s.replace(/\./g, "").split(",");
  return Number(reais) * 100 + Number(dec.padEnd(2, "0"));
}

/** Máscara progressiva de moeda: só dígitos → "1.234,56" (a cada tecla). */
export function maskMoney(raw: string): string {
  const digits = raw.replace(/\D/g, "").replace(/^0+(?=\d)/, "");
  if (!digits) return "";
  const padded = digits.padStart(3, "0");
  const reais = padded.slice(0, -2).replace(/^0+(?=\d)/, "");
  const grouped = reais.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  return `${grouped},${padded.slice(-2)}`;
}

export function centsToInput(cents: number | null | undefined): string {
  return cents === null || cents === undefined ? "" : maskMoney(String(cents));
}

export function inputToCents(v: string): number | null {
  const d = v.replace(/\D/g, "");
  return d ? Number(d) : null;
}

export function formatBp(bp: number): string {
  return `${Math.trunc(bp / 100)},${String(Math.abs(bp) % 100).padStart(2, "0")}`;
}

export function parsePercentToBp(v: string): number | null {
  const s = v.replace("%", "").trim().replace(",", ".");
  if (!/^\d+(\.\d{0,2})?$/.test(s)) return null;
  const [i, d = ""] = s.split(".");
  return Number(i) * 100 + Number(d.padEnd(2, "0"));
}

let dateFormat: "DD/MM/AAAA" | "AAAA-MM-DD" = "DD/MM/AAAA";
export function setDateFormat(f: string) {
  dateFormat = f === "AAAA-MM-DD" ? "AAAA-MM-DD" : "DD/MM/AAAA";
}

export function formatDate(iso: string | null | undefined): string {
  if (!iso) return "—";
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  if (!m) return iso;
  return dateFormat === "AAAA-MM-DD" ? `${m[1]}-${m[2]}-${m[3]}` : `${m[3]}/${m[2]}/${m[1]}`;
}

export function formatDateShort(iso: string | null | undefined): string {
  if (!iso) return "—";
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  return m ? `${m[3]}/${m[2]}` : iso;
}

/** Datas "...Z" vindas do banco são UTC; converte para hora local de exibição. */
export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso.endsWith("Z") || iso.length <= 10 ? iso : iso + "Z");
  if (isNaN(d.getTime())) return iso;
  const date = formatDate(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`);
  return `${date} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

/** Datas/horas locais sem fuso (AAAA-MM-DDTHH:MM:SS), como gravadas no caixa. */
export function formatLocalDateTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  const m = /^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})/.exec(iso);
  return m ? `${formatDate(m[1])} ${m[2]}` : formatDate(iso);
}

export function relativeTime(iso: string): string {
  const d = new Date(iso.endsWith("Z") || iso.length <= 10 ? iso : iso + "Z").getTime();
  if (isNaN(d)) return "";
  const min = Math.round((Date.now() - d) / 60000);
  if (min < 1) return "agora";
  if (min < 60) return `há ${min} min`;
  const h = Math.round(min / 60);
  if (h < 24) return `há ${h}h`;
  const days = Math.round(h / 24);
  return days === 1 ? "ontem" : `há ${days} dias`;
}

export function todayISO(offsetDays = 0): string {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export const digitsOnly = (s: string) => s.replace(/\D/g, "");

export function maskCpfCnpj(v: string, kind: "PF" | "PJ"): string {
  const d = digitsOnly(v).slice(0, kind === "PF" ? 11 : 14);
  if (kind === "PF") {
    return d.replace(/^(\d{3})(\d)/, "$1.$2").replace(/^(\d{3})\.(\d{3})(\d)/, "$1.$2.$3").replace(/\.(\d{3})(\d)/, ".$1-$2");
  }
  return d
    .replace(/^(\d{2})(\d)/, "$1.$2")
    .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
    .replace(/\.(\d{3})(\d)/, ".$1/$2")
    .replace(/(\d{4})(\d)/, "$1-$2");
}

export function formatDocument(d: string): string {
  if (/\*/.test(d)) return d;
  return maskCpfCnpj(d, d.length > 11 ? "PJ" : "PF");
}

export function maskDocumentDisplay(d: string): string {
  if (d.length === 11) return `${d.slice(0, 3)}.***.***-${d.slice(9)}`;
  if (d.length === 14) return `${d.slice(0, 2)}.***.***/${d.slice(8, 12)}-${d.slice(12)}`;
  return d;
}

export function maskPhone(v: string): string {
  const d = digitsOnly(v).slice(0, 11);
  if (d.length <= 2) return d ? `(${d}` : "";
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
}

export function formatPhone(v: string | null | undefined): string {
  return v ? maskPhone(v) : "—";
}

export function maskCep(v: string): string {
  const d = digitsOnly(v).slice(0, 8);
  return d.length > 5 ? `${d.slice(0, 5)}-${d.slice(5)}` : d;
}

export function initials(name: string): string {
  const p = name.trim().split(/\s+/);
  return ((p[0]?.[0] ?? "") + (p.length > 1 ? p[p.length - 1][0] : "")).toUpperCase();
}

export const METHOD_LABELS: Record<string, string> = {
  cash: "Dinheiro",
  pix: "Pix",
  card: "Cartão",
  transfer: "Transferência",
  boleto: "Boleto",
};

export function plural(n: number, one: string, many: string): string {
  return `${n} ${n === 1 ? one : many}`;
}
