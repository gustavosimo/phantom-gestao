import React from "react";
import ReactDOM from "react-dom/client";
import "@/styles/index.css";
import { App } from "@/app/App";
import { TitleBar } from "@/layouts/TitleBar";

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
  <React.StrictMode>
    <div className="flex h-full flex-col bg-app">
      <TitleBar />
      <div className="relative min-h-0 flex-1">
        <div className="absolute inset-0">
          <App />
        </div>
      </div>
    </div>
  </React.StrictMode>,
);
