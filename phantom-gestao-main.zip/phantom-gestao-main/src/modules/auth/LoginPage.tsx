import { useState, type FormEvent } from "react";
import { CircleAlert, LoaderCircle } from "lucide-react";
import { LogoMark } from "@/components/Logo";
import { Wordmark } from "@/components/Wordmark";
import { LoginBackdrop } from "@/components/LoginBackdrop";
import { Button, } from "@/components/ui/button";
import { CheckboxField, TextField } from "@/components/ui/field";
import { Modal, ModalClose } from "@/components/ui/dialog";
import { useAuth } from "@/app/auth-store";
import { errorMessage } from "@/services/api";

const REMEMBER_KEY = "phantom.remembered-user";

function readRemembered(): string {
  try {
    return localStorage.getItem(REMEMBER_KEY) ?? "";
  } catch {
    return "";
  }
}

export function LoginPage() {
  const setupMode = useAuth((s) => s.status === "setup");
  const login = useAuth((s) => s.login);
  const setupAdmin = useAuth((s) => s.setupAdmin);

  const remembered = readRemembered();
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState(remembered);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [remember, setRemember] = useState(remembered !== "");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [forgotOpen, setForgotOpen] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (!username.trim() || !password) {
      setError("Informe usuário e senha.");
      return;
    }
    if (setupMode && password !== confirm) {
      setError("As senhas não coincidem.");
      return;
    }
    setLoading(true);
    try {
      if (setupMode) {
        await setupAdmin(fullName, username, password);
      } else {
        await login(username, password);
        try {
          if (remember) localStorage.setItem(REMEMBER_KEY, username.trim().toLowerCase());
          else localStorage.removeItem(REMEMBER_KEY);
        } catch {
          /* armazenamento indisponível: ignorar */
        }
      }
    } catch (err) {
      setError(errorMessage(err));
      setPassword("");
      setConfirm("");
      setLoading(false);
    }
  }

  return (
    <div className="relative flex h-full items-center justify-center overflow-hidden bg-app">
      <LoginBackdrop />

      <form
        onSubmit={onSubmit}
        noValidate
        className="relative flex w-[420px] max-w-[92vw] flex-col items-center rounded-lg border border-line bg-surface px-6 py-10 sm:px-10 sm:py-12"
      >
        <LogoMark size={72} />
        <Wordmark align="center" className="pt-4" />
        <div className="flex w-full flex-col items-center gap-1 pt-5 pb-1">
          <h1 className="font-heading text-xl font-extrabold tracking-[1px] text-fg">GESTÃO</h1>
          <p className="text-xs text-fg-muted">
            {setupMode ? "Configuração inicial — crie o administrador" : "Vendas • Crédito • Garantias"}
          </p>
        </div>

        <div className="flex w-full flex-col gap-4 pt-8">
          {error && (
            <div
              role="alert"
              className="flex items-center gap-2 rounded-sm border border-error-line bg-error-bg px-3.5 py-2.5 text-[13px] text-error-fg"
            >
              <CircleAlert size={16} className="shrink-0" />
              {error}
            </div>
          )}

          {setupMode && (
            <TextField
              id="full-name"
              label="Nome completo"
              placeholder="Seu nome"
              autoComplete="name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              disabled={loading}
            />
          )}
          <TextField
            id="username"
            label="Usuário"
            placeholder="seu.usuario"
            autoComplete="username"
            autoFocus
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            disabled={loading}
          />
          <TextField
            id="password"
            label="Senha"
            type="password"
            revealable
            placeholder="••••••••••"
            autoComplete={setupMode ? "new-password" : "current-password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            disabled={loading}
          />
          {setupMode && (
            <TextField
              id="confirm"
              label="Confirmar senha"
              type="password"
              revealable
              placeholder="••••••••••"
              autoComplete="new-password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              disabled={loading}
            />
          )}

          {!setupMode && (
            <div className="flex items-center justify-between py-0.5">
              <CheckboxField id="remember" label="Lembrar de mim" checked={remember} onCheckedChange={setRemember} />
              <button
                type="button"
                onClick={() => setForgotOpen(true)}
                className="cursor-pointer text-[13px] font-medium text-silver hover:text-silver-bright"
              >
                Esqueci minha senha
              </button>
            </div>
          )}

          <Button
            type="submit"
            disabled={loading}
            className={loading ? "w-full opacity-75 disabled:opacity-75" : "w-full"}
          >
            {loading ? (
              <>
                <LoaderCircle size={16} className="animate-spin" />
                {setupMode ? "Criando..." : "Entrando..."}
              </>
            ) : setupMode ? (
              "Criar administrador"
            ) : (
              "Entrar"
            )}
          </Button>
        </div>
      </form>

      <p className="absolute bottom-[31px] w-full text-center text-[11px] text-fg-subtle">
        Phantom Gestão · v{__APP_VERSION__}
      </p>

      <Modal
        open={forgotOpen}
        onOpenChange={setForgotOpen}
        title="Recuperação de acesso"
        description="Por segurança, senhas não são enviadas nem exibidas. Peça a um administrador do sistema para redefinir o seu acesso."
        actions={
          <ModalClose asChild>
            <Button variant="outline">Entendi</Button>
          </ModalClose>
        }
      />
    </div>
  );
}
