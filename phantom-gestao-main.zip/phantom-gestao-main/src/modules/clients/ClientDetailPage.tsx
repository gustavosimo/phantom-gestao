import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Briefcase, Eye, EyeOff, FileText, HandCoins, IdCard, Mail, MapPin, Phone, ShieldCheck, ShoppingCart, Wallet, FilePlus2, Download } from "lucide-react";
import { Breadcrumb, usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi } from "@/hooks/useApi";
import { api } from "@/services/api";
import type { HistoryRow } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, EmptyState, ErrorNotice, Mono, Notice, Segmented, StatCard } from "@/components/ui/layout";
import { DataTable } from "@/components/ui/data-table";
import { StatusBadge } from "@/components/ui/badge";
import { FormModal } from "@/components/ui/dialog";
import { SelectInput, TextInput } from "@/components/ui/form";
import { toast } from "@/components/ui/toast";
import { downloadAttachment, fileName, pickFile } from "@/lib/files";
import { formatBRL, formatDate, formatDocument, formatPhone, initials, maskDocumentDisplay, relativeTime } from "@/lib/format";
import { cn } from "@/lib/utils";

type Tab = "general" | "loan" | "collateral" | "purchase" | "sale" | "payment" | "contracts" | "all";

const KIND_LABEL: Record<string, string> = { loan: "Empréstimo", collateral: "Garantia", payment: "Pagamento", sale: "Venda", purchase: "Compra" };

function historyStatus(r: HistoryRow): string {
  if (r.kind === "loan") return r.status === "active" ? "ontime" : r.status;
  if (r.kind === "collateral") return r.status === "registered" || r.status === "appraising" ? "evaluating" : r.status;
  if (r.kind === "payment") return r.status === "confirmed" ? "paid" : r.status;
  return r.status;
}

const DOC_TYPES = ["RG", "CNH", "Comprovante de residência", "Comprovante de renda", "Contrato social", "Cartão CNPJ", "Outro"];

export function ClientDetailPage() {
  const { id } = useParams();
  const cid = Number(id);
  const navigate = useNavigate();
  const can = useAuth((s) => s.can);
  const [tab, setTab] = useState<Tab>("general");
  const [reveal, setReveal] = useState(false);
  const [docModal, setDocModal] = useState(false);
  const [draft, setDraft] = useState({ docType: "RG", number: "", path: "" });

  const client = useApi(() => api.client(cid), [cid]);
  const summary = useApi(() => api.clientSummary(cid), [cid]);
  const kind = tab === "general" || tab === "all" || tab === "contracts" ? undefined : tab;
  const history = useApi(() => api.clientHistory(cid, kind), [cid, kind]);
  const docs = useApi(() => (can("clients.sensitive") ? api.clientDocuments(cid) : Promise.resolve([])), [cid]);
  const contracts = useApi(() => (tab === "contracts" && client.data ? api.contracts({ pageSize: 50, search: client.data.name }) : Promise.resolve(null)), [tab, client.data?.name]);

  const c = client.data;
  usePageHeader(c?.name ?? "Cliente", <Breadcrumb items={[{ label: "Clientes", to: "/clientes" }, { label: c ? `Cliente desde ${formatDate(c.createdAt)} · ID #CLI-${String(cid).padStart(5, "0")}` : "…" }]} />, [c?.name]);

  async function attach() {
    try {
      await api.clientAddDocument(cid, draft.docType, draft.number || undefined, draft.path || undefined);
      toast.success("Documento anexado.");
      setDocModal(false);
      setDraft({ docType: "RG", number: "", path: "" });
      docs.reload();
    } catch (e) {
      toast.error(e);
    }
  }

  if (client.error) return <ErrorNotice message={client.error} onRetry={client.reload} />;
  if (!c) return null;

  const doc = c.documentMasked ? c.document : reveal ? formatDocument(c.document) : maskDocumentDisplay(c.document);
  const address = [c.street && `${c.street}${c.number ? `, ${c.number}` : ""}`, c.city && `${c.city}${c.state ? `/${c.state}` : ""}`].filter(Boolean).join(" — ");
  const lastPurchase = summary.data?.lastPurchaseAt ? relativeTime(summary.data.lastPurchaseAt).replace("há ", "há ") : "—";

  const rows = history.data ?? [];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] items-start gap-5">
      <Card className="p-4 sm:p-5">
        <div className="flex flex-col items-center gap-3 pb-4 text-center">
          <span className="flex size-[72px] items-center justify-center rounded-full bg-surface-hover font-heading text-2xl font-semibold text-fg-muted">{initials(c.name)}</span>
          <h2 className="font-heading text-lg font-semibold text-fg">{c.name}</h2>
          <StatusBadge status={c.derivedStatus} />
        </div>
        <div className="flex flex-col gap-3.5 border-t border-line py-4">
          <InfoRow icon={IdCard} label={c.kind === "PF" ? "CPF" : "CNPJ"}>
            <span className="flex items-center gap-2">
              <Mono className="text-sm text-fg">{doc}</Mono>
              {!c.documentMasked && (
                <button onClick={() => setReveal((r) => !r)} aria-label={reveal ? "Ocultar documento" : "Revelar documento"} className="cursor-pointer text-fg-subtle hover:text-fg">
                  {reveal ? <EyeOff size={13} /> : <Eye size={13} />}
                </button>
              )}
            </span>
          </InfoRow>
          <InfoRow icon={Phone} label="Telefone">{formatPhone(c.phone)}</InfoRow>
          <InfoRow icon={Mail} label="E-mail">{c.email ?? "—"}</InfoRow>
          <InfoRow icon={MapPin} label="Endereço">{address || "—"}</InfoRow>
          <InfoRow icon={Briefcase} label="Profissão">{c.profession ?? "—"}</InfoRow>
        </div>
        {c.contactOptOut && <Notice tone="warning" className="mb-3">Cliente optou por não receber contatos de cobrança.</Notice>}
        {can("clients.manage") && <Button variant="outline" className="w-full" onClick={() => navigate(`/clientes/${cid}/editar`)}>Editar Cadastro</Button>}
      </Card>

      <div className="flex min-w-0 flex-col gap-5">
        <div className="overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          <Segmented<Tab>
            value={tab}
            onChange={setTab}
            items={[
              { value: "general", label: "Dados Gerais" },
              { value: "loan", label: "Empréstimos" },
              { value: "collateral", label: "Garantias" },
              { value: "purchase", label: "Compras" },
              { value: "sale", label: "Vendas" },
              { value: "payment", label: "Pagamentos" },
              { value: "contracts", label: "Contratos" },
              { value: "all", label: "Histórico" },
            ]}
          />
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard small label="Total Emprestado" icon={HandCoins} value={<Mono className="text-lg">{formatBRL(summary.data?.totalLentCents ?? 0)}</Mono>} />
          <StatCard small label="Em Aberto" icon={Wallet} value={<Mono className="text-lg">{formatBRL(summary.data?.openBalanceCents ?? 0)}</Mono>} />
          <StatCard small label="Garantias Ativas" icon={ShieldCheck} value={summary.data?.activeCollaterals ?? 0} />
          <StatCard small label="Última Compra" icon={ShoppingCart} value={lastPurchase} />
        </div>

        {tab === "contracts" ? (
          <Card className="overflow-x-auto">
            <CardHeader title="Contratos do cliente" className="!pb-3" />
            <DataTable
              className="rounded-none border-x-0 border-b-0"
              rows={contracts.data?.items.filter((k) => k.clientId === cid)}
              rowKey={(k) => k.id}
              onRowClick={() => navigate("/contratos")}
              empty={<EmptyState icon={FileText} title="Nenhum contrato" />}
              columns={[
                { key: "ref", header: "Contrato", width: "1.2fr", render: (k) => <Mono className="font-semibold">{k.refCode}</Mono> },
                { key: "kind", header: "Operação", width: "1fr", render: (k) => <span className="text-fg-muted">{{ loan: "Empréstimo", collateral: "Garantia", sale: "Venda", purchase: "Compra" }[k.kind]}</span> },
                { key: "date", header: "Data", width: "1fr", render: (k) => <span className="text-fg-muted">{formatDate(k.createdAt)}</span> },
                { key: "status", header: "Status", width: "1fr", render: (k) => <StatusBadge status={k.displayStatus} /> },
              ]}
            />
          </Card>
        ) : (
          <Card className="overflow-x-auto">
            <CardHeader title={tab === "general" ? "Histórico Recente" : tab === "all" ? "Histórico completo" : `${KIND_LABEL[tab]}s`} className="!pb-3" />
            <DataTable
              className="rounded-none border-x-0 border-b-0"
              rows={history.loading && rows.length === 0 ? undefined : tab === "general" ? rows.slice(0, 6) : rows}
              loading={history.loading}
              rowKey={(r) => `${r.kind}-${r.occurredAt}-${r.description}-${r.amountCents}`}
              empty={<EmptyState icon={FileText} title="Nenhuma movimentação" text="O histórico do cliente aparece aqui conforme as operações são registradas." />}
              columns={[
                { key: "kind", header: "Tipo", width: "1fr", render: (r) => <span className="font-semibold text-fg">{KIND_LABEL[r.kind]}</span> },
                { key: "desc", header: "Descrição", width: "1.8fr", render: (r) => <span className="text-fg-muted">{r.description}</span> },
                { key: "amount", header: "Valor", width: "1fr", render: (r) => <Mono>{formatBRL(r.amountCents)}</Mono> },
                { key: "date", header: "Data", width: ".9fr", render: (r) => <span className="text-fg-muted">{formatDate(r.occurredAt)}</span> },
                { key: "status", header: "Status", width: "1fr", render: (r) => <StatusBadge status={historyStatus(r)} /> },
              ]}
            />
          </Card>
        )}

        {tab === "general" && can("clients.sensitive") && (
          <Card className="overflow-x-auto">
            <CardHeader title="Documentos" subtitle="Armazenados cifrados; cada visualização é auditada." right={can("clients.manage") && <Button variant="outline" size="sm" onClick={() => setDocModal(true)}><FilePlus2 size={14} /> Adicionar</Button>} className="!pb-3" />
            {(docs.data ?? []).map((d) => (
              <div key={d.id} className="flex items-center gap-3 border-t border-line px-6 py-3">
                <FileText size={16} className="text-fg-subtle" />
                <div className="min-w-0 flex-1">
                  <p className="text-[13px] font-medium text-fg">{d.docType}{d.number ? ` · ${d.number}` : ""}</p>
                  <p className="truncate text-xs text-fg-subtle">{d.fileName ?? "Sem arquivo"} · {formatDate(d.createdAt)}</p>
                </div>
                {d.attachmentId && <button aria-label="Baixar" onClick={() => downloadAttachment(d.attachmentId!, d.fileName ?? "documento")} className="cursor-pointer text-fg-subtle hover:text-fg"><Download size={15} /></button>}
              </div>
            ))}
            {(docs.data?.length ?? 0) === 0 && <p className="border-t border-line px-6 py-5 text-[13px] text-fg-muted">Nenhum documento anexado.</p>}
          </Card>
        )}
      </div>

      <FormModal open={docModal} onOpenChange={setDocModal} title="Adicionar documento" width={460} footer={<><Button variant="outline" onClick={() => setDocModal(false)}>Cancelar</Button><Button onClick={attach} disabled={!draft.path && !draft.number}>Anexar</Button></>}>
        <div className="flex flex-col gap-4">
          <SelectInput label="Tipo de documento" value={draft.docType} onChange={(v) => setDraft((d) => ({ ...d, docType: v }))} options={DOC_TYPES.map((t) => ({ value: t, label: t }))} />
          <TextInput label="Número (opcional)" value={draft.number} onChange={(v) => setDraft((d) => ({ ...d, number: v }))} />
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" onClick={async () => { const p = await pickFile(); if (p) setDraft((d) => ({ ...d, path: p })); }}>Escolher arquivo</Button>
            <span className="truncate text-xs text-fg-muted">{draft.path ? fileName(draft.path) : "Nenhum arquivo selecionado"}</span>
          </div>
        </div>
      </FormModal>
    </div>
  );
}

function InfoRow({ icon: Icon, label, children }: { icon: typeof Phone; label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-3">
      <Icon size={15} className="mt-0.5 shrink-0 text-fg-subtle" />
      <div className="min-w-0">
        <p className="text-[11px] text-fg-subtle">{label}</p>
        <div className={cn("text-sm text-fg")}>{children}</div>
      </div>
    </div>
  );
}

export function TableHead({ cols, grid = "min-w-[640px] grid-cols-[1.2fr_1fr_1fr_1fr]" }: { cols: string[]; grid?: string }) {
  return (
    <div className={cn("grid gap-4 border-y border-line bg-app px-6 py-3 text-xs font-medium text-fg-muted", grid)}>
      {cols.map((c) => <span key={c}>{c}</span>)}
    </div>
  );
}
