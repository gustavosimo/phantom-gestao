import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { FilePlus2, FileText, LoaderCircle, Trash2 } from "lucide-react";
import { Breadcrumb, usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { api, errorMessage } from "@/services/api";
import type { ClientInput } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Segmented } from "@/components/ui/layout";
import { Notice } from "@/components/ui/layout";
import { SelectInput, TextArea, TextInput, Toggle } from "@/components/ui/form";
import { FormModal } from "@/components/ui/dialog";
import { toast } from "@/components/ui/toast";
import { fileName, pickFile } from "@/lib/files";
import { maskCep, maskCpfCnpj, maskPhone, formatDocument } from "@/lib/format";
import { useApi } from "@/hooks/useApi";

type Tab = "personal" | "documents" | "contacts" | "address" | "notes";

const EMPTY: ClientInput = {
  kind: "PF", name: "", document: "", rg: "", birthDate: "", profession: "", maritalStatus: "", email: "", phone: "", phone2: "",
  zip: "", street: "", number: "", complement: "", district: "", city: "", state: "", notes: "", status: "pending", contactOptOut: false,
};

const UFS = ["AC","AL","AP","AM","BA","CE","DF","ES","GO","MA","MT","MS","MG","PA","PB","PR","PE","PI","RJ","RN","RS","RO","RR","SC","SP","SE","TO"];
const DOC_TYPES = ["RG", "CNH", "Comprovante de residência", "Comprovante de renda", "Contrato social", "Cartão CNPJ", "Outro"];

interface PendingDoc {
  docType: string;
  number: string;
  path: string;
}

export function ClientFormPage() {
  const { id } = useParams();
  const editId = id ? Number(id) : null;
  const navigate = useNavigate();
  const can = useAuth((s) => s.can);
  const [tab, setTab] = useState<Tab>("personal");
  const [form, setForm] = useState<ClientInput>(EMPTY);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState<PendingDoc[]>([]);
  const [docModal, setDocModal] = useState(false);
  const [docDraft, setDocDraft] = useState<PendingDoc>({ docType: "RG", number: "", path: "" });
  const docs = useApi(() => (editId && can("clients.sensitive") ? api.clientDocuments(editId) : Promise.resolve([])), [editId]);

  usePageHeader(editId ? "Editar Cliente" : "Novo Cliente", <Breadcrumb items={[{ label: "Clientes", to: "/clientes" }, { label: editId ? "Editar cadastro" : "Novo cadastro" }]} />, [editId]);

  const loaded = useApi(() => (editId ? api.client(editId) : Promise.resolve(null)), [editId]);
  useEffect(() => {
    const c = loaded.data;
    if (!c) return;
    setForm({
      kind: c.kind, name: c.name, document: c.documentMasked ? c.document : formatDocument(c.document), rg: c.rg ?? "", birthDate: c.birthDate ?? "",
      profession: c.profession ?? "", maritalStatus: c.maritalStatus ?? "", email: c.email ?? "", phone: c.phone ? maskPhone(c.phone) : "",
      phone2: c.phone2 ? maskPhone(c.phone2) : "", zip: c.zip ? maskCep(c.zip) : "", street: c.street ?? "", number: c.number ?? "",
      complement: c.complement ?? "", district: c.district ?? "", city: c.city ?? "", state: c.state ?? "", notes: c.notes ?? "", status: c.status,
      contactOptOut: c.contactOptOut,
    });
  }, [loaded.data]);

  const set = <K extends keyof ClientInput>(k: K, v: ClientInput[K]) => {
    setForm((f) => ({ ...f, [k]: v }));
    setErrors((e) => ({ ...e, [k]: "" }));
  };
  const isPF = form.kind === "PF";

  function validate(): boolean {
    const e: Record<string, string> = {};
    if (form.name.trim().length < 3) e.name = "Informe o nome completo.";
    if (!form.document.trim()) e.document = isPF ? "Informe o CPF." : "Informe o CNPJ.";
    setErrors(e);
    if (e.name || e.document) setTab("personal");
    return Object.keys(e).length === 0;
  }

  async function save() {
    if (!validate()) return;
    setSaving(true);
    const clean = (v?: string | null) => (v && v.trim() ? v.trim() : null);
    const payload: ClientInput = {
      ...form,
      name: form.name.trim(),
      rg: clean(form.rg), birthDate: isPF ? clean(form.birthDate) : null, profession: clean(form.profession),
      maritalStatus: isPF ? clean(form.maritalStatus) : null, email: clean(form.email), phone: clean(form.phone), phone2: clean(form.phone2),
      zip: clean(form.zip), street: clean(form.street), number: clean(form.number), complement: clean(form.complement),
      district: clean(form.district), city: clean(form.city), state: clean(form.state), notes: clean(form.notes),
    };
    try {
      let cid = editId;
      if (editId) {
        await api.clientUpdate(editId, payload);
      } else {
        cid = await api.clientCreate(payload);
        for (const d of pending) {
          try {
            await api.clientAddDocument(cid, d.docType, d.number || undefined, d.path);
          } catch (e) {
            toast.error(`Cliente salvo, mas o documento "${fileName(d.path)}" falhou: ${errorMessage(e)}`);
          }
        }
      }
      toast.success(editId ? "Cadastro atualizado." : "Cliente cadastrado.");
      navigate(`/clientes/${cid}`);
    } catch (e) {
      const msg = errorMessage(e);
      if (/CPF|CNPJ|documento/i.test(msg)) setErrors((x) => ({ ...x, document: msg }));
      else if (/e-mail/i.test(msg)) { setErrors((x) => ({ ...x, email: msg })); setTab("contacts"); }
      else if (/telefone/i.test(msg)) { setErrors((x) => ({ ...x, phone: msg })); setTab("contacts"); }
      else if (/CEP|UF/i.test(msg)) setTab("address");
      toast.error(e);
    } finally {
      setSaving(false);
    }
  }

  async function addDocNow() {
    if (!docDraft.path) return;
    if (editId) {
      try {
        await api.clientAddDocument(editId, docDraft.docType, docDraft.number || undefined, docDraft.path);
        toast.success("Documento anexado.");
        docs.reload();
      } catch (e) {
        toast.error(e);
        return;
      }
    } else {
      setPending((p) => [...p, docDraft]);
    }
    setDocModal(false);
    setDocDraft({ docType: "RG", number: "", path: "" });
  }

  return (
    <div className="mx-auto flex max-w-[920px] flex-col rounded-md border border-line bg-surface">
      <div className="p-4 pb-0">
        <Segmented<Tab>
          value={tab}
          onChange={setTab}
          items={[
            { value: "personal", label: "Dados Pessoais" },
            { value: "documents", label: "Documentos" },
            { value: "contacts", label: "Contatos" },
            { value: "address", label: "Endereço" },
            { value: "notes", label: "Observações" },
          ]}
        />
      </div>

      <div className="flex flex-col gap-5 px-5 py-6">
        {tab === "personal" && (
          <>
            <h3 className="font-heading text-[15px] font-semibold text-fg">Informações {isPF ? "pessoais" : "da empresa"}</h3>
            <TextInput label={isPF ? "Nome completo" : "Razão social"} required value={form.name} onChange={(v) => set("name", v)} error={errors.name} placeholder={isPF ? "Ex: Mariana Alves Souza" : "Ex: Carla Nogueira Ltda"} />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <SelectInput label="Tipo de pessoa" value={form.kind} disabled={!!editId} onChange={(v) => { setForm((f) => ({ ...f, kind: v as "PF" | "PJ", document: "" })); }} options={[{ value: "PF", label: "Pessoa Física (PF)" }, { value: "PJ", label: "Pessoa Jurídica (PJ)" }]} />
              {isPF ? <TextInput label="Data de nascimento" type="date" value={form.birthDate ?? ""} onChange={(v) => set("birthDate", v)} /> : <TextInput label="Atividade principal" value={form.profession ?? ""} onChange={(v) => set("profession", v)} placeholder="Ex: Comércio varejista" />}
              {isPF && (
                <>
                  <TextInput label="Profissão" value={form.profession ?? ""} onChange={(v) => set("profession", v)} placeholder="Ex: Comerciante" />
                  <SelectInput label="Estado civil" value={form.maritalStatus ?? ""} onChange={(v) => set("maritalStatus", v)} placeholder="Selecione" options={["Solteiro(a)", "Casado(a)", "Divorciado(a)", "Viúvo(a)", "União estável"].map((x) => ({ value: x, label: x }))} />
                </>
              )}
            </div>
            <div className="border-t border-line pt-5">
              <h3 className="pb-4 font-heading text-[15px] font-semibold text-fg">Documento principal</h3>
              {form.document.includes("*") && <Notice tone="info" className="mb-4">O documento está protegido. Sem a permissão de dados sensíveis ele não pode ser alterado.</Notice>}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <TextInput
                  label={isPF ? "CPF" : "CNPJ"} required mono value={form.document} error={errors.document}
                  disabled={form.document.includes("*")}
                  mask={(v) => maskCpfCnpj(v, form.kind)} onChange={(v) => set("document", v)}
                  placeholder={isPF ? "000.000.000-00" : "00.000.000/0000-00"}
                />
                {isPF && <TextInput label="RG" mono value={form.rg ?? ""} onChange={(v) => set("rg", v)} placeholder="00.000.000-0" />}
              </div>
            </div>
          </>
        )}

        {tab === "documents" && (
          <>
            <div className="flex items-center justify-between">
              <h3 className="font-heading text-[15px] font-semibold text-fg">Documentos anexados</h3>
              <Button variant="outline" size="sm" onClick={() => setDocModal(true)}><FilePlus2 size={14} /> Adicionar documento</Button>
            </div>
            <Notice tone="info">Documentos pessoais são armazenados cifrados e acessados somente por usuários autorizados (LGPD). Formatos: PDF, PNG, JPG ou WEBP, até 15 MB.</Notice>
            <div className="flex flex-col rounded-sm border border-line">
              {[...(docs.data ?? []).map((d) => ({ key: `d${d.id}`, title: d.docType, sub: d.fileName ?? d.number ?? "Sem arquivo", removable: false })), ...pending.map((p, i) => ({ key: `p${i}`, title: p.docType, sub: `${fileName(p.path)} — será anexado ao salvar`, removable: true, idx: i }))].map((d) => (
                <div key={d.key} className="flex items-center gap-3 border-b border-line px-4 py-3 last:border-b-0">
                  <FileText size={16} className="text-fg-subtle" />
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-medium text-fg">{d.title}</p>
                    <p className="truncate text-xs text-fg-subtle">{d.sub}</p>
                  </div>
                  {d.removable && "idx" in d && (
                    <button aria-label="Remover" onClick={() => setPending((p) => p.filter((_, i) => i !== d.idx))} className="cursor-pointer text-fg-subtle hover:text-error-fg"><Trash2 size={15} /></button>
                  )}
                </div>
              ))}
              {(docs.data?.length ?? 0) + pending.length === 0 && <p className="px-4 py-6 text-center text-[13px] text-fg-muted">Nenhum documento anexado.</p>}
            </div>
          </>
        )}

        {tab === "contacts" && (
          <>
            <h3 className="font-heading text-[15px] font-semibold text-fg">Contatos</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <TextInput label="E-mail" type="email" value={form.email ?? ""} onChange={(v) => set("email", v)} error={errors.email} placeholder="nome@email.com" />
              <TextInput label="Telefone / WhatsApp" value={form.phone ?? ""} mask={maskPhone} onChange={(v) => set("phone", v)} error={errors.phone} placeholder="(11) 98765-4321" />
              <TextInput label="Telefone secundário" value={form.phone2 ?? ""} mask={maskPhone} onChange={(v) => set("phone2", v)} placeholder="(11) 4000-0000" />
            </div>
            <div className="flex items-start justify-between gap-6 rounded-sm border border-line px-4 py-3.5">
              <div>
                <p className="text-[13px] font-medium text-fg">Não receber contatos de cobrança</p>
                <p className="text-xs text-fg-muted">Quando ativo, o sistema bloqueia WhatsApp, e-mail e ligações de cobrança para este cliente (LGPD).</p>
              </div>
              <Toggle label="Não receber contatos de cobrança" checked={!!form.contactOptOut} onChange={(v) => set("contactOptOut", v)} />
            </div>
          </>
        )}

        {tab === "address" && (
          <>
            <h3 className="font-heading text-[15px] font-semibold text-fg">Endereço</h3>
            <div className="grid grid-cols-1 sm:grid-cols-6 gap-5">
              <TextInput className="sm:col-span-2" label="CEP" mono value={form.zip ?? ""} mask={maskCep} onChange={(v) => set("zip", v)} placeholder="00000-000" />
              <TextInput className="sm:col-span-4" label="Logradouro" value={form.street ?? ""} onChange={(v) => set("street", v)} />
              <TextInput className="sm:col-span-2" label="Número" value={form.number ?? ""} onChange={(v) => set("number", v)} />
              <TextInput className="sm:col-span-4" label="Complemento" value={form.complement ?? ""} onChange={(v) => set("complement", v)} />
              <TextInput className="sm:col-span-2" label="Bairro" value={form.district ?? ""} onChange={(v) => set("district", v)} />
              <TextInput className="sm:col-span-3" label="Cidade" value={form.city ?? ""} onChange={(v) => set("city", v)} />
              <SelectInput className="sm:col-span-1" label="UF" value={form.state ?? ""} onChange={(v) => set("state", v)} placeholder="—" options={UFS.map((u) => ({ value: u, label: u }))} />
            </div>
          </>
        )}

        {tab === "notes" && (
          <>
            <h3 className="font-heading text-[15px] font-semibold text-fg">Observações e situação</h3>
            <SelectInput label="Situação do cadastro" value={form.status ?? "pending"} onChange={(v) => set("status", v)} options={[{ value: "pending", label: "Pendente" }, { value: "active", label: "Ativo" }, { value: "inactive", label: "Inativo" }]} hint="Somente clientes ativos podem solicitar empréstimos." />
            <TextArea label="Observações" rows={5} value={form.notes ?? ""} onChange={(v) => set("notes", v)} placeholder="Informações internas sobre o cliente" />
          </>
        )}
      </div>

      <div className="flex items-center justify-between border-t border-line px-5 py-4">
        <span className="text-xs text-fg-subtle">* Campos obrigatórios para prosseguir</span>
        <div className="flex gap-3">
          <Button variant="outline" onClick={() => navigate(editId ? `/clientes/${editId}` : "/clientes")} disabled={saving}>Cancelar</Button>
          <Button onClick={save} disabled={saving || (!!editId && loaded.loading)}>
            {saving && <LoaderCircle size={14} className="animate-spin" />}
            Salvar Cliente
          </Button>
        </div>
      </div>

      <FormModal
        open={docModal}
        onOpenChange={setDocModal}
        title="Adicionar documento"
        width={460}
        footer={<><Button variant="outline" onClick={() => setDocModal(false)}>Cancelar</Button><Button onClick={addDocNow} disabled={!docDraft.path}>Anexar</Button></>}
      >
        <div className="flex flex-col gap-4">
          <SelectInput label="Tipo de documento" value={docDraft.docType} onChange={(v) => setDocDraft((d) => ({ ...d, docType: v }))} options={DOC_TYPES.map((t) => ({ value: t, label: t }))} />
          <TextInput label="Número (opcional)" value={docDraft.number} onChange={(v) => setDocDraft((d) => ({ ...d, number: v }))} />
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" onClick={async () => { const p = await pickFile(); if (p) setDocDraft((d) => ({ ...d, path: p })); }}>Escolher arquivo</Button>
            <span className="truncate text-xs text-fg-muted">{docDraft.path ? fileName(docDraft.path) : "Nenhum arquivo selecionado"}</span>
          </div>
        </div>
      </FormModal>
    </div>
  );
}
