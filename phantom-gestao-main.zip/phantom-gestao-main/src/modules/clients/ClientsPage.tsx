import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Pencil, Plus, SlidersHorizontal, UserCheck, UserX, Eye, Users } from "lucide-react";
import { usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi, useDebounced } from "@/hooks/useApi";
import { api } from "@/services/api";
import type { ClientRow } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { DataTable, Pagination, useListQuery, type Column } from "@/components/ui/data-table";
import { EmptyState, ErrorNotice, FilterSelect, Mono, SearchInput } from "@/components/ui/layout";
import { StatusBadge } from "@/components/ui/badge";
import { RowMenu } from "@/components/RowMenu";
import { toast } from "@/components/ui/toast";
import { formatDate, formatPhone, initials } from "@/lib/format";
import { cn } from "@/lib/utils";

export function Avatar2({ name, size = 28 }: { name: string; size?: number }) {
  return (
    <span className="flex shrink-0 items-center justify-center rounded-full bg-surface-hover text-[11px] font-semibold text-fg-muted" style={{ width: size, height: size }}>
      {initials(name)}
    </span>
  );
}

export function ClientsPage() {
  usePageHeader(null);
  const navigate = useNavigate();
  const can = useAuth((s) => s.can);
  const list = useListQuery({ pageSize: 8 });
  const [search, setSearch] = useState("");
  const debounced = useDebounced(search);
  const [more, setMore] = useState(false);
  const query = { ...list.query, search: debounced || undefined };
  const { data, loading, error, reload } = useApi(() => api.clients(query), [JSON.stringify(query)]);

  async function toggleStatus(c: ClientRow) {
    try {
      await api.clientSetStatus(c.id, c.status === "inactive" ? "active" : "inactive");
      toast.success(c.status === "inactive" ? "Cliente reativado." : "Cliente inativado.");
      reload();
    } catch (e) {
      toast.error(e);
    }
  }

  const columns: Column<ClientRow>[] = [
    {
      key: "name", header: "Nome", width: "2.2fr", sort: "name",
      render: (c) => (
        <span className="flex items-center gap-3">
          <Avatar2 name={c.name} />
          <span className="truncate font-medium">{c.name}</span>
        </span>
      ),
    },
    { key: "doc", header: "CPF/CNPJ", width: "1.2fr", render: (c) => <Mono className="text-fg-muted">{c.document}</Mono> },
    { key: "phone", header: "Telefone", width: "1fr", render: (c) => <span className="text-fg-muted">{formatPhone(c.phone)}</span> },
    { key: "status", header: "Status", width: ".8fr", sort: "status", render: (c) => <StatusBadge status={c.status} /> },
    { key: "date", header: "Cadastro", width: ".9fr", sort: "createdAt", render: (c) => <span className="text-fg-muted">{formatDate(c.createdAt)}</span> },
    {
      key: "actions", header: "Ações", width: "60px",
      render: (c) => (
        <RowMenu
          actions={[
            { label: "Ver detalhes", icon: Eye, onSelect: () => navigate(`/clientes/${c.id}`) },
            { label: "Editar cadastro", icon: Pencil, hidden: !can("clients.manage"), onSelect: () => navigate(`/clientes/${c.id}/editar`) },
            { label: c.status === "inactive" ? "Reativar cliente" : "Inativar cliente", icon: c.status === "inactive" ? UserCheck : UserX, hidden: !can("clients.manage"), destructive: c.status !== "inactive", onSelect: () => toggleStatus(c) },
          ]}
        />
      ),
    },
  ];

  return (
    <div className="flex min-h-full flex-col gap-5">
      <div className="flex flex-wrap items-center gap-3">
        <SearchInput value={search} onChange={(v) => { setSearch(v); list.setPage(1); }} placeholder="Buscar por nome, CPF/CNPJ..." className="w-full sm:w-[280px]" />
        <FilterSelect label="Status" value={list.state.status} onChange={list.setStatus} options={[{ value: "active", label: "Ativo" }, { value: "pending", label: "Pendente" }, { value: "late", label: "Atrasado" }, { value: "inactive", label: "Inativo" }]} />
        <FilterSelect label="Data de cadastro" value={list.state.extra} onChange={list.setExtra} options={[{ value: "7d", label: "Últimos 7 dias" }, { value: "30d", label: "Últimos 30 dias" }, { value: "90d", label: "Últimos 90 dias" }, { value: "year", label: "Último ano" }]} />
        <button onClick={() => setMore((m) => !m)} aria-expanded={more} className={cn("flex cursor-pointer items-center gap-2 rounded-sm px-3 py-2.5 text-[13px] hover:text-fg", more ? "text-fg" : "text-fg-muted")}>
          <SlidersHorizontal size={15} /> Mais filtros
        </button>
        {more && <FilterSelect label="Tipo de pessoa" value={list.state.category} onChange={list.setCategory} options={[{ value: "PF", label: "Pessoa Física" }, { value: "PJ", label: "Pessoa Jurídica" }]} />}
        {can("clients.manage") && (
          <Button className="ml-auto" onClick={() => navigate("/clientes/novo")}>
            <Plus size={14} /> Novo Cliente
          </Button>
        )}
      </div>

      {error && <ErrorNotice message={error} onRetry={reload} />}

      <DataTable
        className="flex-1"
        columns={columns}
        rows={data?.items}
        rowKey={(c) => c.id}
        loading={loading}
        sort={{ key: list.state.sort, desc: list.state.desc }}
        onSort={list.toggleSort}
        onRowClick={(c) => navigate(`/clientes/${c.id}`)}
        minBodyHeight={420}
        empty={
          <EmptyState
            icon={Users}
            title={list.state.search || search || list.state.status || list.state.extra || list.state.category ? "Nenhum cliente encontrado" : "Nenhum cliente cadastrado"}
            text="Cadastre clientes para iniciar empréstimos, vendas e garantias."
            action={can("clients.manage") ? <Button size="sm" onClick={() => navigate("/clientes/novo")}>Novo Cliente</Button> : undefined}
          />
        }
        footer={data && <Pagination page={data.page} pageSize={data.pageSize} total={data.total} onPage={list.setPage} noun="clientes" />}
      />
    </div>
  );
}
