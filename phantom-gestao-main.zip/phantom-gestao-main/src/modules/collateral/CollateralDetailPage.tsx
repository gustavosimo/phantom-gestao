import { useState } from "react";
import { useParams } from "react-router-dom";
import { Box, CalendarPlus, CheckCircle2, ClipboardCheck, FileSignature, FileText, Gavel, Link2, Laptop, PackageOpen, ShieldCheck, Download, ImageIcon } from "lucide-react";
import { Breadcrumb, usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi } from "@/hooks/useApi";
import { useRegulatory } from "@/hooks/useRegulatory";
import { api } from "@/services/api";
import type { CollateralEvent } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card, ErrorNotice, Notice } from "@/components/ui/layout";
import { StatusBadge } from "@/components/ui/badge";
import { ConfirmDialog, FormModal } from "@/components/ui/dialog";
import { MoneyInput, TextInput } from "@/components/ui/form";
import { RegulatoryBanner } from "@/components/RegulatoryBanner";
import { Thumb, useAttachmentUrl } from "@/components/DocumentViewer";
import { toast } from "@/components/ui/toast";
import { downloadAttachment } from "@/lib/files";
import { formatBRL, formatDate, formatDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

const COND: Record<string, string> = { new: "Novo", refurbished: "Seminovo", used: "Usado", damaged: "Danificado" };
const EVENT_ICON: Record<string, typeof Box> = { registered: Box, valuation: ClipboardCheck, approved: CheckCircle2, received: PackageOpen, extended: CalendarPlus, redeemed: ShieldCheck, returned: ShieldCheck, legal_procedure: Gavel, rejected: Box };

export function CollateralDetailPage() {
  const { id } = useParams();
  const gid = Number(id);
  const can = useAuth((s) => s.can);
  const reg = useRegulatory();
  const q = useApi(() => api.collateral(gid), [gid]);
  const contract = useApi(() => (can("contracts.view") ? api.contractForRef("collateral", gid) : Promise.resolve(null)), [gid]);
  const [photo, setPhoto] = useState(0);
  const [modal, setModal] = useState<null | "valuate" | "reject" | "receive" | "extend" | "redeem" | "return" | "legal" | "sign">(null);
  const a = q.data?.asset;
  usePageHeader(a?.name ?? "Garantia", a ? <Breadcrumb items={[{ label: "Garantias", to: "/garantias" }, { label: `Garantia #${a.code} · ${a.clientName}` }]} /> : null, [a?.name]);

  const photos = q.data?.photos ?? [];
  const main = useAttachmentUrl(photos[photo]?.id);

  function refresh() { q.reload(); contract.reload(); }
  async function run(fn: () => Promise<unknown>, ok: string) {
    try { await fn(); toast.success(ok); refresh(); } catch (e) { toast.error(e); }
  }

  if (q.error) return <ErrorNotice message={q.error} onRetry={q.reload} />;
  if (!a || !q.data) return null;

  const evaluating = a.status === "registered" || a.status === "appraising";
  const inCustody = a.status === "in_custody";
  const signed = contract.data?.signedAt != null;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[380px_1fr] items-start gap-5">
      <div className="flex flex-col gap-4">
        <div className="flex h-[260px] items-center justify-center overflow-hidden rounded-md border border-line bg-surface">
          {main.url ? <img src={main.url} alt={a.name} className="size-full object-cover" /> : <Laptop size={56} className="text-fg-subtle" strokeWidth={1.2} />}
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[0, 1, 2, 3].map((i) => photos[i] ? (
            <Thumb key={i} attachmentId={photos[i].id} alt={`Foto ${i + 1}`} onClick={() => setPhoto(i)} className={cn("h-16", photo === i && "border-fg")} />
          ) : (
            <div key={i} className="flex h-16 items-center justify-center rounded-sm border border-line bg-app text-fg-subtle"><ImageIcon size={16} /></div>
          ))}
        </div>
        <Card className="p-4 sm:p-5">
          <h3 className="pb-4 font-heading text-[15px] font-semibold text-fg">Histórico de Custódia</h3>
          <ol className="flex flex-col gap-4">
            {q.data.events.map((e: CollateralEvent) => {
              const Icon = EVENT_ICON[e.kind] ?? Link2;
              return (
                <li key={e.id} className="flex gap-3">
                  <Icon size={15} className="mt-0.5 shrink-0 text-fg-muted" />
                  <div>
                    <p className="text-[13px] font-medium text-fg">{e.description}</p>
                    <p className="text-[11px] text-fg-subtle">{formatDateTime(e.createdAt)}{e.username ? ` · ${e.username}` : ""}</p>
                  </div>
                </li>
              );
            })}
          </ol>
        </Card>
        {q.data.terms.length > 0 && (
          <Card className="p-4 sm:p-5">
            <h3 className="pb-3 font-heading text-[15px] font-semibold text-fg">Termos</h3>
            {q.data.terms.map((t) => (
              <button key={t.id} onClick={() => downloadAttachment(t.id, t.originalName)} className="flex w-full cursor-pointer items-center gap-2 py-1.5 text-left text-[13px] text-fg-muted hover:text-fg"><Download size={14} /> {t.originalName}</button>
            ))}
          </Card>
        )}
      </div>

      <div className="flex min-w-0 flex-col gap-5">
        {reg.loaded && !reg.collateralEnabled && <RegulatoryBanner kind="collateral" />}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <StatusBadge status={a.displayStatus} />
          <div className="flex flex-wrap gap-3">
            {can("collateral.manage") && evaluating && <Button variant="outline" onClick={() => setModal("valuate")}><ClipboardCheck size={14} /> {a.appraisedCents === null ? "Registrar avaliação" : "Reavaliar"}</Button>}
            {can("loans.approve") && a.status === "appraising" && <><Button onClick={() => run(() => api.collateralApprove(gid, true), "Garantia aprovada.")}><CheckCircle2 size={14} /> Aprovar</Button><Button variant="destructive" onClick={() => setModal("reject")}>Recusar</Button></>}
            {can("contracts.manage") && a.status === "approved" && !signed && <Button variant="outline" onClick={() => run(() => api.contractGenerate("collateral", gid), "Termo de garantia gerado.")}><FileText size={14} /> {contract.data ? "Gerar nova versão do termo" : "Gerar termo de garantia"}</Button>}
            {can("contracts.manage") && contract.data && !signed && a.status === "approved" && <Button variant="outline" onClick={() => setModal("sign")}><FileSignature size={14} /> Registrar assinatura</Button>}
            {can("collateral.manage") && a.status === "approved" && <Button onClick={() => setModal("receive")} disabled={!reg.collateralEnabled || !signed} title={!reg.collateralEnabled ? "Bloqueado até a habilitação regulatória" : !signed ? "Gere e assine o termo de garantia" : undefined}><PackageOpen size={14} /> Receber em custódia</Button>}
            {can("collateral.manage") && inCustody && <Button variant="outline" onClick={() => setModal("extend")}><CalendarPlus size={14} /> Prorrogar prazo</Button>}
            {can("collateral.manage") && (inCustody || a.status === "legal_procedure") && <><Button variant="outline" onClick={() => setModal("redeem")}>Registrar Resgate</Button><Button variant="outline" onClick={() => setModal("return")}>Registrar Devolução</Button></>}
            {can("loans.approve") && inCustody && a.daysLeft !== null && a.daysLeft < 0 && <Button variant="destructive" onClick={() => setModal("legal")}><Gavel size={14} /> Registrar procedimento legal</Button>}
          </div>
        </div>

        <Card className="p-4 sm:p-6">
          <h3 className="pb-4 font-heading text-base font-semibold text-fg">Dados da Garantia</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-10 gap-y-4">
            <Field label="Proprietário">{a.clientName}</Field>
            <Field label="Contrato vinculado">{a.loanId ? `#${a.loanId}` : "—"}</Field>
            <Field label="Categoria">{a.category}</Field>
            <Field label="Avaliação">{a.appraisedCents === null ? "Aguardando avaliação" : formatBRL(a.appraisedCents)}</Field>
            <Field label="Marca / Modelo">{[a.brand, a.model].filter(Boolean).join(" · ") || "—"}</Field>
            <Field label="Local de armazenamento">{a.storageLocation ?? "—"}</Field>
            <Field label="Número de série">{a.serialNumber ?? "—"}</Field>
            <Field label="Vencimento da custódia">{a.custodyDue ? `${formatDate(a.custodyDue)}${a.daysLeft !== null ? ` (${a.daysLeft >= 0 ? `${a.daysLeft} dias` : `${-a.daysLeft} dias vencido`})` : ""}` : "—"}</Field>
            {a.linkedValueCents !== null && <Field label="Valor da operação vinculada">{formatBRL(a.linkedValueCents)}</Field>}
          </div>
        </Card>

        <Card className="p-4 sm:p-6">
          <h3 className="pb-2 font-heading text-base font-semibold text-fg">Condição Atual</h3>
          <p className="text-sm text-fg-muted">{COND[a.condition]}{a.notes ? ` — ${a.notes}` : ""}</p>
        </Card>

        {inCustody && a.loanId && (
          <Notice tone="info" icon={ShieldCheck} className="!text-[13px]">Este bem está em custódia como garantia do contrato #{a.loanId} e não está disponível para venda.</Notice>
        )}
        {a.status === "legal_procedure" && <Notice tone="error" icon={Gavel}>Procedimento legal registrado. O sistema não realiza apropriação nem comercialização automática do bem.</Notice>}
      </div>

      <ValuateModal open={modal === "valuate"} onClose={() => setModal(null)} current={a.appraisedCents} onSave={(v, n) => run(() => api.collateralValuate(gid, v, n), "Avaliação registrada.")} />
      <ConfirmDialog open={modal === "reject"} onOpenChange={(o) => !o && setModal(null)} title="Recusar garantia" confirmLabel="Recusar" destructive reasonLabel="Motivo da recusa" description="A garantia será marcada como recusada." onConfirm={async (r) => { await api.collateralApprove(gid, false, r); refresh(); }} successMessage="Garantia recusada." />
      <ReceiveModal open={modal === "receive"} onClose={() => setModal(null)} defaultLoc={a.storageLocation ?? "Cofre — Matriz"} defaultDays={a.custodyDays ?? 30} onSave={(l, d) => run(() => api.collateralReceive(gid, l, d), "Bem recebido em custódia. Termo de recebimento gerado.")} />
      <ConfirmDialog open={modal === "extend"} onOpenChange={(o) => !o && setModal(null)} title="Prorrogar prazo de custódia" confirmLabel="Prorrogar 30 dias" reasonLabel="Motivo" description="O prazo será estendido em 30 dias." onConfirm={async (r) => { await api.collateralExtend(gid, 30, r); refresh(); }} successMessage="Prazo prorrogado." />
      <ConfirmDialog open={modal === "redeem"} onOpenChange={(o) => !o && setModal(null)} title="Registrar resgate" confirmLabel="Registrar resgate" reasonLabel="Observação" description="O resgate exige a quitação do empréstimo vinculado. Será gerado o termo de resgate." onConfirm={async (r) => { await api.collateralRelease(gid, "redeemed", r); refresh(); }} successMessage="Resgate registrado." />
      <ConfirmDialog open={modal === "return"} onOpenChange={(o) => !o && setModal(null)} title="Registrar devolução" confirmLabel="Registrar devolução" reasonLabel="Observação" description="Devolução ao cliente sem resgate (ex.: contrato cancelado). Será gerado o termo de devolução." onConfirm={async (r) => { await api.collateralRelease(gid, "returned", r); refresh(); }} successMessage="Devolução registrada." />
      <ConfirmDialog open={modal === "legal"} onOpenChange={(o) => !o && setModal(null)} title="Registrar procedimento legal" confirmLabel="Registrar" destructive reasonLabel="Referência do procedimento (nº, data, responsável)" minReason={10} description="Apenas documenta que o procedimento legal cabível foi iniciado. O sistema não se apropria nem vende o bem." onConfirm={async (r) => { await api.collateralLegal(gid, r); refresh(); }} successMessage="Procedimento registrado." />
      <SignCollateral open={modal === "sign"} onClose={() => setModal(null)} contractId={contract.data?.id ?? 0} owner={a.clientName} onDone={refresh} />
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="text-[11px] text-fg-subtle">{label}</p>
      <p className="pt-0.5 text-sm text-fg">{children}</p>
    </div>
  );
}

function ValuateModal({ open, onClose, current, onSave }: { open: boolean; onClose: () => void; current: number | null; onSave: (v: number, notes?: string) => void }) {
  const [v, setV] = useState<number | null>(current);
  const [n, setN] = useState("");
  return (
    <FormModal open={open} onOpenChange={(o) => !o && onClose()} title="Avaliação do bem" width={440}
      footer={<><Button variant="outline" onClick={onClose}>Cancelar</Button><Button disabled={!v || v <= 0} onClick={() => { onSave(v!, n || undefined); onClose(); }}>Salvar avaliação</Button></>}>
      <div className="flex flex-col gap-4">
        <MoneyInput label="Valor de avaliação (R$)" cents={v} onChange={setV} required />
        <TextInput label="Observação" value={n} onChange={setN} />
      </div>
    </FormModal>
  );
}

function ReceiveModal({ open, onClose, defaultLoc, defaultDays, onSave }: { open: boolean; onClose: () => void; defaultLoc: string; defaultDays: number; onSave: (loc: string, days: number) => void }) {
  const [loc, setLoc] = useState(defaultLoc);
  const [days, setDays] = useState(String(defaultDays));
  return (
    <FormModal open={open} onOpenChange={(o) => !o && onClose()} title="Receber em custódia" description="Será gerado o termo de recebimento." width={440}
      footer={<><Button variant="outline" onClick={onClose}>Cancelar</Button><Button disabled={!loc.trim() || !Number(days)} onClick={() => { onSave(loc, Number(days)); onClose(); }}>Confirmar recebimento</Button></>}>
      <div className="flex flex-col gap-4">
        <TextInput label="Local de custódia" value={loc} onChange={setLoc} required />
        <TextInput label="Prazo (dias)" type="number" min={1} value={days} onChange={setDays} />
      </div>
    </FormModal>
  );
}

function SignCollateral({ open, onClose, contractId, owner, onDone }: { open: boolean; onClose: () => void; contractId: number; owner: string; onDone: () => void }) {
  const [name, setName] = useState(owner);
  return (
    <FormModal open={open} onOpenChange={(o) => !o && onClose()} title="Registrar assinatura do termo" width={440}
      footer={<><Button variant="outline" onClick={onClose}>Cancelar</Button><Button disabled={!name.trim()} onClick={async () => { try { await api.contractSign(contractId, name); toast.success("Assinatura registrada."); onClose(); onDone(); } catch (e) { toast.error(e); } }}>Registrar</Button></>}>
      <TextInput label="Nome de quem assinou" value={name} onChange={setName} required />
    </FormModal>
  );
}
