import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { ImageIcon, LoaderCircle, Upload, X } from "lucide-react";
import { Breadcrumb, usePageHeader } from "@/app/page-header";
import { api } from "@/services/api";
import type { ClientOption } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card, Notice } from "@/components/ui/layout";
import { ChipGroup, MoneyInput, SelectInput, TextArea, TextInput } from "@/components/ui/form";
import { ClientPicker } from "@/components/ClientPicker";
import { toast } from "@/components/ui/toast";
import { fileName, pickFiles } from "@/lib/files";
import { CATEGORIES } from "@/modules/collateral/CollateralPage";
import { useRegulatory } from "@/hooks/useRegulatory";
import { RegulatoryBanner } from "@/components/RegulatoryBanner";

type Condition = "new" | "refurbished" | "used" | "damaged";

export function CollateralFormPage() {
  usePageHeader("Nova Garantia", <Breadcrumb items={[{ label: "Garantias", to: "/garantias" }, { label: "Cadastro de bem em custódia" }]} />);
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const reg = useRegulatory();
  const [client, setClient] = useState<ClientOption | null>(null);
  const [category, setCategory] = useState("Eletrônicos");
  const [name, setName] = useState("");
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [serial, setSerial] = useState("");
  const [condition, setCondition] = useState<Condition>("refurbished");
  const [value, setValue] = useState<number | null>(null);
  const [location, setLocation] = useState("Cofre — Matriz");
  const [days, setDays] = useState("30");
  const [notes, setNotes] = useState("");
  const [photos, setPhotos] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  void params;

  async function addPhotos() {
    const picked = await pickFiles();
    setPhotos((p) => [...p, ...picked].slice(0, 8));
  }

  async function save() {
    const e: Record<string, string> = {};
    if (!client) e.client = "Selecione o cliente proprietário.";
    if (name.trim().length < 2) e.name = "Informe o produto.";
    setErrors(e);
    if (Object.keys(e).length) return;
    setSaving(true);
    try {
      const id = await api.collateralCreate({
        clientId: client!.id, category, name: name.trim(), brand: brand || null, model: model || null, serialNumber: serial || null, condition,
        appraisedCents: value, storageLocation: location || null, custodyDays: Number(days) || null, notes: notes || null, photoPaths: photos,
      });
      toast.success("Garantia cadastrada. Siga para avaliação, aprovação e contrato.");
      navigate(`/garantias/${id}`);
    } catch (err) {
      toast.error(err);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="mx-auto flex max-w-[920px] flex-col gap-4">
      {reg.loaded && !reg.collateralEnabled && <RegulatoryBanner kind="collateral" />}
      <Card>
        <div className="flex flex-col gap-5 px-5 py-6">
          <h3 className="font-heading text-[15px] font-semibold text-fg">Cliente e Produto</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <ClientPicker value={client} onChange={setClient} required error={errors.client} />
            <SelectInput label="Categoria" value={category} onChange={setCategory} options={CATEGORIES.map((c) => ({ value: c, label: c }))} />
          </div>
          <TextInput label="Produto" required value={name} onChange={setName} error={errors.name} placeholder="Ex: Notebook Dell Inspiron 15" />
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
            <TextInput label="Marca" value={brand} onChange={setBrand} />
            <TextInput label="Modelo" value={model} onChange={setModel} />
            <TextInput label="Número de série / IMEI" value={serial} onChange={setSerial} mono />
          </div>

          <div className="border-t border-line pt-5">
            <h3 className="pb-4 font-heading text-[15px] font-semibold text-fg">Fotos do produto</h3>
            <div className="flex flex-wrap gap-4">
              {photos.map((p, i) => (
                <div key={p} className="relative flex size-[90px] flex-col items-center justify-center gap-1 overflow-hidden rounded-sm border border-line bg-app px-1.5">
                  <ImageIcon size={18} className="text-fg-subtle" />
                  <span className="w-full truncate text-center text-[10px] text-fg-subtle" title={p}>{fileName(p)}</span>
                  <button aria-label="Remover foto" onClick={() => setPhotos((x) => x.filter((_, j) => j !== i))} className="absolute top-1 right-1 flex size-5 cursor-pointer items-center justify-center rounded-full bg-black/70 text-fg"><X size={11} /></button>
                </div>
              ))}
              {Array.from({ length: Math.max(0, 3 - photos.length) }).map((_, i) => (
                <div key={`ph${i}`} className="flex size-[90px] items-center justify-center rounded-sm border border-line bg-app text-fg-subtle"><ImageIcon size={18} /></div>
              ))}
              {photos.length < 8 && (
                <button type="button" onClick={addPhotos} className="flex size-[90px] cursor-pointer flex-col items-center justify-center gap-1.5 rounded-sm border border-line-strong text-xs text-fg-muted hover:bg-surface-hover">
                  <Upload size={16} /> Adicionar
                </button>
              )}
            </div>
            <p className="pt-2 text-xs text-fg-subtle">Até 8 fotos (PNG, JPG ou WEBP). Armazenadas cifradas.</p>
          </div>

          <div className="flex flex-col gap-5 border-t border-line pt-5">
            <h3 className="font-heading text-[15px] font-semibold text-fg">Avaliação e Condição</h3>
            <ChipGroup<Condition> label="Condição do item" value={condition} onChange={setCondition} items={[{ value: "new", label: "Novo" }, { value: "refurbished", label: "Seminovo" }, { value: "used", label: "Usado" }, { value: "damaged", label: "Danificado" }]} />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <MoneyInput label="Avaliação manual (R$)" cents={value} onChange={setValue} hint="Opcional agora; pode ser informada na etapa de avaliação." />
              <TextInput label="Local de armazenamento" value={location} onChange={setLocation} />
              <TextInput label="Prazo de custódia (dias)" type="number" min={1} value={days} onChange={setDays} />
            </div>
            <TextArea label="Observações" value={notes} onChange={setNotes} rows={2} />
            <Notice tone="info">O vínculo com o contrato de empréstimo é feito na solicitação de crédito (etapa “Simulação › Garantia vinculada”). Bens em garantia nunca entram no estoque comercial.</Notice>
          </div>
        </div>
        <div className="flex items-center justify-end gap-3 border-t border-line px-5 py-4">
          <Button variant="outline" onClick={() => navigate("/garantias")} disabled={saving}>Cancelar</Button>
          <Button onClick={save} disabled={saving}>{saving && <LoaderCircle size={14} className="animate-spin" />}Cadastrar garantia</Button>
        </div>
      </Card>
    </div>
  );
}
