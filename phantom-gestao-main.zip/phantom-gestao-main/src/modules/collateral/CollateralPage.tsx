import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Box, CalendarClock, ClipboardCheck, Eye, Plus, Undo2, ShieldCheck, type LucideIcon } from "lucide-react";
import { usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi, useDebounced } from "@/hooks/useApi";
import { useRegulatory } from "@/hooks/useRegulatory";
import { api } from "@/services/api";
import type { CollateralRow } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { DataTable, Pagination, useListQuery, type Column } from "@/components/ui/data-table";
import { EmptyState, ErrorNotice, FilterSelect, Mono, SearchInput, StatCard } from "@/components/ui/layout";
import { StatusBadge } from "@/components/ui/badge";
import { RegulatoryBanner } from "@/components/RegulatoryBanner";
import { RowMenu } from "@/components/RowMenu";
import { formatBRL } from "@/lib/format";

export const CATEGORIES = ["Eletrônicos", "Joias", "Instrumentos", "Esportes", "Veículos", "Ferramentas", "Outros"];

export function iconFor(c: CollateralRow["displayStatus"]): LucideIcon {
  return c === "evaluating" ? ClipboardCheck : c === "redeemed" || c === "returned" ? Undo2 : Box;
}

export function deadlineLabel(c: CollateralRow): string {
  if (c.displayStatus === "redeemed" || c.displayStatus === "returned") return c.displayStatus === "redeemed" ? "Resgatado" : "Devolvido";
  if (c.daysLeft === null) return "—";
  if (c.daysLeft < 0) return `${Math.abs(c.daysLeft)} dias vencido`;
  return `${c.daysLeft} dias`;
}

export function CollateralPage() {
  usePageHeader(null);
  const navigate = useNavigate();
  const can = useAuth((s) => s.can);
  const reg = useRegulatory();
  const list = useListQuery({ pageSize: 8 });
  const [search, setSearch] = useState("");
  const debounced = useDebounced(search);
  const query = { ...list.query, search: debounced || undefined };
  const stats = useApi(() => api.collateralStats(), []);
  const { data, loading, error, reload } = useApi(() => api.collaterals(query), [JSON.stringify(query)]);

  const columns: Column<CollateralRow>[] = [
    {
      key: "name", header: "Produto", width: "2.4fr", sort: "name",
      render: (c) => {
        const Icon = iconFor(c.displayStatus);
        return (
          <span className="flex items-center gap-3">
            <span className="flex size-9 shrink-0 items-center justify-center text-fg-muted"><Icon size={16} /></span>
            <span className="min-w-0"><span className="block truncate font-medium">{c.name}</span><span className="text-[11px] text-fg-subtle">{c.code}</span></span>
          </span>
        );
      },
    },
    { key: "client", header: "Cliente", width: "1.3fr", render: (c) => <span className="text-fg-muted">{c.clientName}</span> },
    { key: "cat", header: "Categoria", width: "1fr", render: (c) => <span className="text-fg-muted">{c.category}</span> },
    { key: "value", header: "Avaliação", width: "1fr", sort: "value", render: (c) => (c.appraisedCents === null ? <Mono className="text-fg-muted">Aguardando</Mono> : <Mono>{formatBRL(c.appraisedCents)}</Mono>) },
    { key: "due", header: "Prazo", width: ".9fr", sort: "due", render: (c) => <span className="text-fg-muted">{deadlineLabel(c)}</span> },
    { key: "status", header: "Status", width: "1fr", render: (c) => <StatusBadge status={c.displayStatus} /> },
    { key: "act", header: "", width: "50px", render: (c) => <RowMenu actions={[{ label: "Ver detalhes", icon: Eye, onSelect: () => navigate(`/garantias/${c.id}`) }]} /> },
  ];

  return (
    <div className="flex min-h-full flex-col gap-5">
      {reg.loaded && !reg.collateralEnabled && <RegulatoryBanner kind="collateral" />}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard label="Em Custódia" icon={Box} value={`${stats.data?.inCustody ?? 0} itens`} />
        <StatCard label="Aguardando Avaliação" icon={ClipboardCheck} tone="warning" value={`${stats.data?.awaitingAppraisal ?? 0} itens`} />
        <StatCard label="Prazos Próximos (7 dias)" icon={CalendarClock} tone="error" value={`${stats.data?.nearDeadline ?? 0} itens`} />
        <StatCard label="Resgatados (mês)" icon={Undo2} tone="success" value={`${stats.data?.redeemedMonth ?? 0} itens`} />
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <SearchInput value={search} onChange={(v) => { setSearch(v); list.setPage(1); }} placeholder="Buscar por produto, cliente..." className="w-full sm:w-[260px]" />
        <FilterSelect label="Categoria" value={list.state.category} onChange={list.setCategory} options={CATEGORIES.map((c) => ({ value: c, label: c }))} />
        <FilterSelect label="Status" value={list.state.status} onChange={list.setStatus} options={[{ value: "evaluating", label: "Em avaliação" }, { value: "approved", label: "Aprovada" }, { value: "in_custody", label: "Em custódia" }, { value: "near_deadline", label: "Prazo próximo" }, { value: "redeemed", label: "Resgatado" }, { value: "returned", label: "Devolvido" }, { value: "legal_procedure", label: "Procedimento legal" }, { value: "rejected", label: "Recusada" }]} />
        {can("collateral.manage") && <Button className="ml-auto" onClick={() => navigate("/garantias/nova")}><Plus size={14} /> Nova Garantia</Button>}
      </div>
      {error && <ErrorNotice message={error} onRetry={reload} />}
      <DataTable
        className="flex-1" columns={columns} rows={data?.items} rowKey={(c) => c.id} loading={loading}
        sort={{ key: list.state.sort, desc: list.state.desc }} onSort={list.toggleSort} onRowClick={(c) => navigate(`/garantias/${c.id}`)} minBodyHeight={360}
        empty={<EmptyState icon={ShieldCheck} title="Nenhuma garantia cadastrada" text="Bens recebidos em garantia ficam separados do estoque comercial." />}
        footer={data && <Pagination page={data.page} pageSize={data.pageSize} total={data.total} onPage={list.setPage} noun="garantias" />}
      />
    </div>
  );
}
