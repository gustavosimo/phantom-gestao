import { useState } from "react";
import { BellRing, CalendarClock, CalendarDays, Mail, MessageCircle, Phone, TriangleAlert, Wallet } from "lucide-react";
import { usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi } from "@/hooks/useApi";
import { api } from "@/services/api";
import type { CollectionRow, NotificationConfig } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card, EmptyState, ErrorNotice, Mono, Notice, Segmented, StatCard } from "@/components/ui/layout";
import { DataTable } from "@/components/ui/data-table";
import { Badge } from "@/components/ui/badge";
import { FormModal } from "@/components/ui/dialog";
import { SelectInput, TextArea, Toggle } from "@/components/ui/form";
import { toast } from "@/components/ui/toast";
import { formatBRL, formatDate, formatDateTime, plural } from "@/lib/format";
import { cn } from "@/lib/utils";

type Scope = "upcoming" | "overdue" | "all";
const CHANNEL_ICON = { whatsapp: MessageCircle, call: Phone, email: Mail } as const;
const CHANNEL_LABEL = { whatsapp: "WhatsApp", call: "Ligação", email: "E-mail" } as const;
const STATUS_LABEL: Record<string, string> = { sent: "enviado", attempted: "tentativa", failed: "falha", answered: "atendeu", no_answer: "sem resposta", blocked: "bloqueado" };

export function CollectionsPage() {
  usePageHeader(null);
  const can = useAuth((s) => s.can);
  const [scope, setScope] = useState<Scope>("overdue");
  const summary = useApi(() => api.collectionsSummary(), []);
  const rows = useApi(() => api.collections(scope), [scope]);
  const history = useApi(() => api.collectionHistory(), []);
  const settings = useApi(() => api.settings(), []);
  const [contact, setContact] = useState<{ row: CollectionRow; channel: "whatsapp" | "email" | "call" } | null>(null);
  const s = summary.data;

  async function toggleRule(key: "whatsapp3dBefore" | "emailOnDue" | "callAfter5d", value: boolean) {
    const st = settings.data;
    if (!st) return;
    const cfg: NotificationConfig = {
      whatsapp3dBefore: st["collections.whatsapp_3d_before"] === "true", emailOnDue: st["collections.email_on_due"] === "true", callAfter5d: st["collections.call_after_5d"] === "true",
      quietStartHour: Number(st["collections.quiet_start_hour"]), quietEndHour: Number(st["collections.quiet_end_hour"]), allowSunday: st["collections.allow_sunday"] === "true",
      maxPerClientDay: Number(st["collections.max_per_client_day"]), maxPerClientWeek: Number(st["collections.max_per_client_week"]),
      dueSoonDays: Number(st["notifications.due_soon_days"]), collateralDays: Number(st["notifications.collateral_days"]), [key]: value,
    };
    try { await api.saveNotificationConfig(cfg); settings.reload(); toast.success("Lembrete atualizado."); } catch (e) { toast.error(e); }
  }

  const on = (k: string) => settings.data?.[k] === "true";

  return (
    <div className="flex flex-col gap-5">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard label="Vencendo Hoje" icon={CalendarClock} tone="warning" value={plural(s?.dueTodayCount ?? 0, "parcela", "parcelas")} />
        <StatCard label="Vencendo em 7 dias" icon={CalendarDays} tone="info" value={plural(s?.dueWeekCount ?? 0, "parcela", "parcelas")} />
        <StatCard label="Em Atraso" icon={TriangleAlert} tone="error" value={plural(s?.overdueCount ?? 0, "parcela", "parcelas")} />
        <StatCard label="Valor Total em Atraso" icon={Wallet} tone="error" value={<Mono className="text-lg sm:text-2xl">{formatBRL(s?.overdueCents ?? 0)}</Mono>} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] items-start gap-5">
        <div className="flex min-w-0 flex-col gap-4">
          <Segmented value={scope} onChange={setScope} items={[{ value: "upcoming", label: "Vencendo" }, { value: "overdue", label: "Em Atraso" }, { value: "all", label: "Todas" }]} className="self-start" />
          {rows.error && <ErrorNotice message={rows.error} onRetry={rows.reload} />}
          <DataTable
            rows={rows.data}
            loading={rows.loading}
            rowKey={(r) => r.installmentId}
            empty={<EmptyState icon={BellRing} title="Nenhuma parcela neste filtro" text="Parcelas de empréstimos ativos a vencer ou em atraso aparecem aqui." />}
            columns={[
              { key: "client", header: "Cliente", width: "1.8fr", render: (r) => <span className="truncate font-medium">{r.clientName}{r.contactOptOut && <span className="ml-2 text-[11px] text-warning-fg">sem contato</span>}</span> },
              { key: "inst", header: "Parcela", width: ".7fr", render: (r) => <Mono className="text-fg-muted">{r.number}/{r.totalInstallments}</Mono> },
              { key: "value", header: "Valor", width: "1.1fr", render: (r) => <Mono>{formatBRL(r.remainingCents)}</Mono> },
              { key: "due", header: "Vencimento", width: "1.1fr", render: (r) => <Mono className="text-fg-muted">{formatDate(r.dueDate)}</Mono> },
              { key: "late", header: scope === "upcoming" ? "Prazo" : "Atraso", width: "1fr", render: (r) => (r.daysLate > 0 ? <Badge tone="error">{r.daysLate} dias</Badge> : <Badge tone="info">{r.daysToDue === 0 ? "hoje" : `em ${r.daysToDue}d`}</Badge>) },
              {
                key: "act", header: "Ações", width: "130px",
                render: (r) => (
                  <span className="flex gap-1.5">
                    {(["whatsapp", "call", "email"] as const).map((ch) => {
                      const Icon = CHANNEL_ICON[ch];
                      return (
                        <button key={ch} aria-label={`${CHANNEL_LABEL[ch]} para ${r.clientName}`} title={CHANNEL_LABEL[ch]} disabled={!can("collections.manage") || r.contactOptOut} onClick={(e) => { e.stopPropagation(); setContact({ row: r, channel: ch }); }}
                          className={cn("flex size-9 cursor-pointer items-center justify-center rounded-sm disabled:cursor-not-allowed disabled:opacity-40 sm:size-8", ch === "whatsapp" ? "bg-success-bg text-success-fg" : "bg-surface-hover text-fg-muted hover:text-fg")}>
                          <Icon size={15} />
                        </button>
                      );
                    })}
                  </span>
                ),
              },
            ]}
          />
        </div>

        <div className="flex flex-col gap-5">
          <Card className="p-4 sm:p-5">
            <h3 className="pb-3 font-heading text-[15px] font-semibold text-fg">Histórico de Contatos</h3>
            <div className="flex flex-col gap-3.5">
              {(history.data ?? []).slice(0, 6).map((h) => {
                const Icon = CHANNEL_ICON[h.channel];
                return (
                  <div key={h.id} className="flex gap-3">
                    <Icon size={15} className={cn("mt-0.5 shrink-0", h.status === "blocked" || h.status === "failed" ? "text-error-fg" : "text-fg-muted")} />
                    <div className="min-w-0">
                      <p className="truncate text-[13px] font-medium text-fg">{CHANNEL_LABEL[h.channel]} · {h.clientName}</p>
                      <p className="text-[11px] text-fg-subtle">{STATUS_LABEL[h.status] ?? h.status} · {formatDateTime(h.createdAt)}</p>
                      {h.error && <p className="text-[11px] text-error-fg">{h.error}</p>}
                    </div>
                  </div>
                );
              })}
              {history.data?.length === 0 && <p className="text-[13px] text-fg-muted">Nenhum contato registrado.</p>}
            </div>
          </Card>

          <Card className="p-4 sm:p-5">
            <h3 className="pb-3 font-heading text-[15px] font-semibold text-fg">Lembretes Automáticos</h3>
            <div className="flex flex-col gap-3.5">
              {([
                ["whatsapp3dBefore", "WhatsApp 3 dias antes", "collections.whatsapp_3d_before"],
                ["emailOnDue", "E-mail no vencimento", "collections.email_on_due"],
                ["callAfter5d", "Ligação após 5 dias de atraso", "collections.call_after_5d"],
              ] as const).map(([k, label, setting]) => (
                <div key={k} className="flex items-center justify-between gap-3">
                  <span className="text-[13px] text-fg-muted">{label}</span>
                  <Toggle label={label} checked={on(setting)} disabled={!can("settings.manage")} onChange={(v) => toggleRule(k, v)} />
                </div>
              ))}
            </div>
            <p className="pt-3 text-[11px] leading-relaxed text-fg-subtle">Os lembretes geram tarefas na Central de Notificações para a equipe executar. O envio automático depende das integrações (Configurações › Integrações).</p>
          </Card>
        </div>
      </div>

      {contact && <ContactModal row={contact.row} channel={contact.channel} onClose={() => setContact(null)} onDone={() => { setContact(null); history.reload(); }} />}
    </div>
  );
}

function ContactModal({ row, channel, onClose, onDone }: { row: CollectionRow; channel: "whatsapp" | "email" | "call"; onClose: () => void; onDone: () => void }) {
  const initial = useApi(() => (channel === "call" ? Promise.resolve("") : api.collectionMessage(channel, row.installmentId)), [channel, row.installmentId]);
  const [message, setMessage] = useState<string | null>(null);
  const [status, setStatus] = useState(channel === "call" ? "answered" : "sent");
  const [busy, setBusy] = useState(false);
  const text = message ?? initial.data ?? "";

  async function go() {
    setBusy(true);
    try {
      const r = await api.collectionContact({ installmentId: row.installmentId, channel, status, message: text || undefined });
      if (r.url) {
        try { await api.openExternal(r.url); } catch (e) { toast.error(e); }
      }
      toast.success("Contato registrado no histórico.");
      onDone();
    } catch (e) { toast.error(e); onDone(); } finally { setBusy(false); }
  }

  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title={`${CHANNEL_LABEL[channel]} — ${row.clientName}`} description={`Parcela ${row.number}/${row.totalInstallments} · ${formatBRL(row.remainingCents)} · venc. ${formatDate(row.dueDate)}`} width={520}
      footer={<><Button variant="outline" onClick={onClose} disabled={busy}>Cancelar</Button><Button onClick={go} disabled={busy}>{channel === "call" ? "Registrar ligação" : channel === "whatsapp" ? "Abrir WhatsApp e registrar" : "Abrir e-mail e registrar"}</Button></>}>
      <div className="flex flex-col gap-4">
        {channel !== "call" && <TextArea label="Mensagem" value={text} onChange={setMessage} rows={5} />}
        <SelectInput label="Resultado" value={status} onChange={setStatus} options={channel === "call" ? [{ value: "answered", label: "Atendeu" }, { value: "no_answer", label: "Não atendeu" }, { value: "attempted", label: "Tentativa" }] : [{ value: "sent", label: "Enviado" }, { value: "attempted", label: "Tentativa (não confirmado)" }, { value: "failed", label: "Falha" }]} />
        <Notice tone="info">Política de cobrança não abusiva: o sistema respeita a janela de horário, domingos, o limite diário/semanal de contatos e o opt-out do cliente. Bloqueios ficam registrados no histórico.</Notice>
      </div>
    </FormModal>
  );
}
