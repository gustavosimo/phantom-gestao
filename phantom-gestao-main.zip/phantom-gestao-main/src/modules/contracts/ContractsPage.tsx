import { useEffect, useState } from "react";
import { FileSignature, FileText } from "lucide-react";
import { usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi, useDebounced } from "@/hooks/useApi";
import { api } from "@/services/api";
import type { ContractRow } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card, EmptyState, ErrorNotice, Mono, SearchInput } from "@/components/ui/layout";
import { StatusBadge } from "@/components/ui/badge";
import { ConfirmDialog, FormModal } from "@/components/ui/dialog";
import { TextArea, TextInput } from "@/components/ui/form";
import { DocumentPreview } from "@/components/DocumentViewer";
import { DataTable, Pagination } from "@/components/ui/data-table";
import { toast } from "@/components/ui/toast";
import { formatDate } from "@/lib/format";
import { cn } from "@/lib/utils";

const KIND_LABEL = { loan: "Empréstimo", collateral: "Garantia", sale: "Venda", purchase: "Compra" } as const;

export function ContractsPage() {
  usePageHeader(null);
  const can = useAuth((s) => s.can);
  const [search, setSearch] = useState("");
  const dq = useDebounced(search);
  const [page, setPage] = useState(1);
  const list = useApi(() => api.contracts({ page, pageSize: 8, search: dq || undefined }), [page, dq]);
  const [selected, setSelected] = useState<number | null>(null);
  const [doc, setDoc] = useState<number | null>(null);
  const [sign, setSign] = useState(false);
  const [cancel, setCancel] = useState(false);

  useEffect(() => {
    if (list.data && list.data.items.length > 0 && !list.data.items.some((c) => c.id === selected)) setSelected(list.data.items[0].id);
    if (list.data && list.data.items.length === 0) setSelected(null);
  }, [list.data, selected]);

  const detail = useApi(() => (selected ? api.contract(selected) : Promise.resolve(null)), [selected]);
  const c = detail.data?.contract;
  useEffect(() => setDoc(c?.attachmentId ?? null), [c?.id, c?.attachmentId]);

  function refresh() { list.reload(); detail.reload(); }

  // por padrão só a versão mais recente de cada documento; as anteriores ficam em "Ver versões anteriores"
  const [oldDocs, setOldDocs] = useState(false);
  const allDocs = detail.data?.documents ?? [];
  const newest = new Map<string, number>();
  for (const x of allDocs) {
    const m = /^(.*)_v(\d+)\.pdf$/.exec(x.originalName);
    if (m) newest.set(m[1], Math.max(newest.get(m[1]) ?? 0, Number(m[2])));
  }
  const isOld = (x: { originalName: string }) => {
    const m = /^(.*)_v(\d+)\.pdf$/.exec(x.originalName);
    return !!m && newest.get(m[1]) !== Number(m[2]);
  };
  const visibleDocs = oldDocs ? allDocs : allDocs.filter((x) => !isOld(x));
  const hiddenCount = allDocs.filter(isOld).length;

  return (
    <div className="flex min-h-full flex-col gap-5">
      <SearchInput value={search} onChange={(v) => { setSearch(v); setPage(1); }} placeholder="Buscar por contrato, cliente..." className="w-full sm:w-[320px]" />
      {list.error && <ErrorNotice message={list.error} onRetry={list.reload} />}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_520px] items-start gap-5">
        <DataTable
          rows={list.data?.items}
          loading={list.loading}
          rowKey={(k: ContractRow) => k.id}
          onRowClick={(k: ContractRow) => setSelected(k.id)}
          rowClass={(k: ContractRow) => selected === k.id && "bg-surface-hover/60"}
          empty={<EmptyState icon={FileText} title="Nenhum contrato" text="Contratos são gerados a partir de empréstimos e garantias, usando modelos aprovados pelo responsável jurídico." />}
          columns={[
            { key: "ref", header: "Contrato", width: "1.1fr", render: (k: ContractRow) => <Mono className="font-semibold">{k.refCode}</Mono> },
            { key: "client", header: "Cliente", width: "1.6fr", render: (k: ContractRow) => <span className="truncate font-medium">{k.clientName ?? "—"}</span> },
            { key: "kind", header: "Operação", width: "1fr", render: (k: ContractRow) => <span className="text-fg-muted">{KIND_LABEL[k.kind]}</span> },
            { key: "date", header: "Data", width: "1fr", render: (k: ContractRow) => <span className="text-fg-muted">{formatDate(k.createdAt)}</span> },
            { key: "status", header: "Status", width: "1.2fr", render: (k: ContractRow) => <StatusBadge status={k.displayStatus === "paid_off" ? "paid_off" : k.displayStatus} /> },
          ]}
          footer={list.data && list.data.total > 0 ? <Pagination page={list.data.page} pageSize={list.data.pageSize} total={list.data.total} onPage={setPage} noun="contratos" /> : undefined}
        />

        <div className="flex flex-col gap-5">
          <DocumentPreview attachmentId={doc} title={c ? detail.data?.documents.find((d) => d.id === doc)?.originalName ?? `${c.number}.pdf` : "Selecione um contrato"} subtitle={c ? `${KIND_LABEL[c.kind]} · ${c.clientName ?? "—"} · ${formatDate(c.createdAt)}` : undefined} className="min-h-[420px]" />
          {c && (
            <Card className="p-4 sm:p-5">
              <div className="flex items-start justify-between gap-3 pb-3">
                <div>
                  <h3 className="font-heading text-[15px] font-semibold text-fg">{c.number}</h3>
                  <p className="text-xs text-fg-subtle">Versão {c.version} · {c.signedAt ? `assinado em ${formatDate(c.signedAt)} por ${c.signedByName}` : "aguardando assinatura"}</p>
                </div>
                <div className="flex gap-2">
                  {can("contracts.manage") && !c.signedAt && c.status !== "cancelled" && <Button size="sm" variant="outline" onClick={() => setSign(true)}><FileSignature size={13} /> Registrar assinatura</Button>}
                  {can("contracts.manage") && !c.signedAt && c.status !== "cancelled" && <Button size="sm" variant="ghost" onClick={() => setCancel(true)}>Cancelar</Button>}
                </div>
              </div>
              <h4 className="pb-2.5 text-[13px] font-medium text-fg-muted">Histórico de Documentos</h4>
              <div className="flex flex-wrap items-center gap-3">
                {visibleDocs.map((d) => (
                  <button key={d.id} onClick={() => setDoc(d.id)} className={cn("flex cursor-pointer items-center gap-2 rounded-sm border bg-app px-3 py-2 text-left", doc === d.id ? "border-silver" : "border-line hover:border-line-strong")}>
                    <FileText size={14} className="text-fg-muted" />
                    <span><span className="block text-xs font-medium text-fg">{d.originalName}</span><span className="text-[10px] text-fg-subtle">{formatDate(d.createdAt)}</span></span>
                  </button>
                ))}
                {hiddenCount > 0 && (
                  <button type="button" onClick={() => setOldDocs((v) => !v)} className="cursor-pointer text-xs text-fg-muted underline underline-offset-2 hover:text-fg">
                    {oldDocs ? "Ocultar versões anteriores" : `Ver versões anteriores (${hiddenCount})`}
                  </button>
                )}
              </div>
            </Card>
          )}
        </div>
      </div>

      {c && <SignModal open={sign} onOpenChange={setSign} id={c.id} defaultName={c.clientName ?? ""} onDone={refresh} />}
      {c && <ConfirmDialog open={cancel} onOpenChange={setCancel} title={`Cancelar ${c.number}`} destructive confirmLabel="Cancelar contrato" reasonLabel="Motivo" description="Contratos ainda não assinados podem ser cancelados. O histórico de versões é preservado." onConfirm={async (r) => { await api.contractCancel(c.id, r); refresh(); }} successMessage="Contrato cancelado." />}
    </div>
  );
}

function SignModal({ open, onOpenChange, id, defaultName, onDone }: { open: boolean; onOpenChange: (o: boolean) => void; id: number; defaultName: string; onDone: () => void }) {
  const [name, setName] = useState(defaultName);
  const [note, setNote] = useState("");
  useEffect(() => setName(defaultName), [defaultName, id]);
  return (
    <FormModal open={open} onOpenChange={onOpenChange} title="Registrar assinatura" description="Registre a assinatura realizada fora do sistema (manuscrita ou eletrônica)." width={460}
      footer={<><Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button><Button disabled={!name.trim()} onClick={async () => { try { await api.contractSign(id, name, note || undefined); toast.success("Assinatura registrada."); onOpenChange(false); onDone(); } catch (e) { toast.error(e); } }}>Registrar</Button></>}>
      <div className="flex flex-col gap-4">
        <TextInput label="Nome de quem assinou" required value={name} onChange={setName} />
        <TextArea label="Observação" rows={2} value={note} onChange={setNote} />
      </div>
    </FormModal>
  );
}
