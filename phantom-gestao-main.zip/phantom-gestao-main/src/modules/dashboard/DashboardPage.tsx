import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import {
  Banknote, CalendarClock, CircleCheck, ClipboardList, Clock, HandCoins, Landmark, ShieldCheck, ShoppingCart,
  TriangleAlert, UserPlus, Wallet, Bell, ChevronRight,
} from "lucide-react";
import { useAuth } from "@/app/auth-store";
import { usePageHeader } from "@/app/page-header";
import { useApi } from "@/hooks/useApi";
import { api } from "@/services/api";
import type { Period } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, EmptyState, ErrorNotice, Mono, Segmented, StatCard } from "@/components/ui/layout";
import { DataTable } from "@/components/ui/data-table";
import { StatusBadge } from "@/components/ui/badge";
import { TextInput } from "@/components/ui/form";
import { formatBRL, formatDate, relativeTime, todayISO } from "@/lib/format";
import { cn } from "@/lib/utils";

const KIND_LABEL: Record<string, string> = { loan: "Empréstimo", sale: "Venda", collateral: "Garantia", payment: "Pagamento" };

function deltaText(value: number, previous: number): { text: string; positive: boolean | null } {
  if (previous === 0) return value === 0 ? { text: "sem variação vs. período anterior", positive: null } : { text: "novo no período", positive: true };
  const pct = Math.round(((value - previous) * 1000) / previous) / 10;
  return { text: `${pct > 0 ? "+" : ""}${String(pct).replace(".", ",")}% vs. período anterior`, positive: pct >= 0 };
}

const NOTICE_ICON: Record<string, { icon: typeof Clock; cls: string }> = {
  warning: { icon: Clock, cls: "text-warning-fg" },
  error: { icon: TriangleAlert, cls: "text-error-fg" },
  success: { icon: CircleCheck, cls: "text-success-fg" },
  info: { icon: Bell, cls: "text-info-fg" },
};

function ChartTooltip({ active, payload, label }: { active?: boolean; payload?: { name: string; value: number; color: string }[]; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-sm border border-line bg-surface px-3 py-2 text-xs">
      <div className="pb-1 font-medium text-fg">{label}</div>
      {payload.map((p) => (
        <div key={p.name} className="flex items-center gap-2 text-fg-muted">
          <span className="size-2 rounded-full" style={{ background: p.color }} />
          {p.name}: <Mono className="text-xs text-fg">{formatBRL(p.value)}</Mono>
        </div>
      ))}
    </div>
  );
}

export function DashboardPage() {
  usePageHeader(null);
  const navigate = useNavigate();
  const can = useAuth((s) => s.can);
  const [kind, setKind] = useState<Period["kind"]>("30d");
  const [from, setFrom] = useState(todayISO(-29));
  const [to, setTo] = useState(todayISO());
  const period: Period = kind === "custom" ? { kind, from, to } : { kind };
  const { data: d, loading, error, reload } = useApi(() => api.dashboard(period), [kind, from, to]);

  const chartData = (d?.series ?? []).map((s) => ({ label: s.label, Recebido: s.receivedCents, Previsto: s.forecastCents }));
  const hasChart = chartData.some((s) => s.Recebido > 0 || s.Previsto > 0);
  const periodLabel = { today: "hoje", "7d": "nos últimos 7 dias", "30d": "nos últimos 30 dias", quarter: "no trimestre", year: "no ano", custom: "no período" }[kind];

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3">
          <Segmented
            value={kind}
            onChange={setKind}
            items={[
              { value: "today", label: "Hoje" },
              { value: "7d", label: "7 dias" },
              { value: "30d", label: "30 dias" },
              { value: "custom", label: "Personalizado" },
            ]}
          />
          {kind === "custom" && (
            <div className="flex items-end gap-2">
              <TextInput label="De" type="date" value={from} onChange={setFrom} />
              <TextInput label="Até" type="date" value={to} onChange={setTo} />
            </div>
          )}
        </div>
        <div className="flex gap-3">
          {can("clients.manage") && <Button onClick={() => navigate("/clientes/novo")}>Novo Cliente</Button>}
          {can("loans.manage") && <Button variant="gold" onClick={() => navigate("/emprestimos/novo")}>Novo Empréstimo</Button>}
          {can("sales.manage") && <Button variant="gold" onClick={() => navigate("/vendas")}>Nova Venda</Button>}
        </div>
      </div>

      {error && <ErrorNotice message={error} onRetry={reload} />}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard label="Carteira Ativa" icon={Wallet} value={<Mono className="text-lg sm:text-2xl">{loading && !d ? "—" : formatBRL(d?.portfolioCents ?? 0)}</Mono>} hint={`${d?.activeLoans ?? 0} empréstimo(s) ativo(s)`} />
        <StatCard
          label="Recebido no Período"
          icon={Landmark}
          value={<Mono className="text-lg sm:text-2xl">{formatBRL(d?.received.value ?? 0)}</Mono>}
          delta={d ? deltaText(d.received.value, d.received.previous) : undefined}
        />
        <StatCard
          label="Parcelas em Atraso"
          icon={Clock}
          tone="error"
          value={<Mono className="text-lg sm:text-2xl">{formatBRL(d?.overdueCents ?? 0)}</Mono>}
          delta={d ? { text: `${d.overdueCount} parcela(s) em atraso`, positive: d.overdueCount === 0 ? null : false } : undefined}
        />
        <StatCard
          label="Novos Clientes"
          icon={UserPlus}
          value={<span className="text-xl sm:text-2xl">{d?.newClients.value ?? 0}</span>}
          delta={d ? deltaText(d.newClients.value, d.newClients.previous) : undefined}
        />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard small label="Empréstimos ativos" icon={HandCoins} value={d?.activeLoans ?? 0} />
        <StatCard small label="Saldo devedor total" icon={Banknote} value={<Mono className="text-base">{formatBRL(d?.outstandingCents ?? 0)}</Mono>} />
        <StatCard small label="Saldo a receber" icon={Landmark} value={<Mono className="text-base">{formatBRL(d?.receivableCents ?? 0)}</Mono>} />
        <StatCard small label="Garantias em custódia" icon={ShieldCheck} value={d?.collateralInCustody ?? 0} />
        <StatCard small label="Vendas no mês" icon={ShoppingCart} value={<Mono className="text-base">{formatBRL(d?.salesMonthCents ?? 0)}</Mono>} />
        <StatCard small label="Recebimentos do dia" icon={CircleCheck} tone="success" value={<Mono className="text-base">{formatBRL(d?.receivedTodayCents ?? 0)}</Mono>} />
        <StatCard small label="Parcelas a vencer (7 dias)" icon={CalendarClock} tone="warning" value={d?.dueSoonCount ?? 0} hint={d ? formatBRL(d.dueSoonCents) : undefined} />
        <StatCard
          small
          label="Pendências operacionais"
          icon={ClipboardList}
          tone={d && sumPending(d) > 0 ? "warning" : "neutral"}
          value={d ? sumPending(d) : 0}
          hint={d ? pendingHint(d) : undefined}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] items-start gap-5">
        <div className="flex min-w-0 flex-col gap-5">
          <Card>
            <CardHeader
              title="Financeiro Mensal"
              subtitle={d?.seriesGranularity === "day" ? `Recebimentos e previsão — ${periodLabel}` : "Recebimentos nos últimos 6 meses"}
              right={
                <div className="flex items-center gap-4 text-xs text-fg-muted">
                  <span className="flex items-center gap-1.5"><span className="size-2 rounded-full bg-silver" />Recebido</span>
                  <span className="flex items-center gap-1.5"><span className="size-2 rounded-full bg-line-strong" />Previsto</span>
                </div>
              }
            />
            <div className="h-[180px] px-4 pb-4">
              {hasChart ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} barGap={3} margin={{ top: 4, right: 8, left: 8, bottom: 0 }}>
                    <CartesianGrid vertical={false} stroke="#34373e" strokeOpacity={0.4} />
                    <XAxis dataKey="label" tickLine={false} axisLine={false} tick={{ fill: "#6b6f78", fontSize: 11 }} interval="preserveStartEnd" />
                    <YAxis hide />
                    <Tooltip content={<ChartTooltip />} cursor={{ fill: "#ffffff08" }} />
                    <Bar dataKey="Recebido" fill="#c0c0c0" radius={[3, 3, 0, 0]} maxBarSize={22} />
                    <Bar dataKey="Previsto" fill="#43464e" radius={[3, 3, 0, 0]} maxBarSize={22} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <EmptyState title="Sem movimentação no período" text="Os gráficos refletem recebimentos e parcelas previstas registrados no sistema." />
              )}
            </div>
          </Card>

          <Card className="overflow-x-auto">
            <CardHeader title="Últimas Operações" right={<button className="cursor-pointer text-[13px] font-medium text-fg-muted hover:text-fg" onClick={() => navigate("/pagamentos")}>Ver todas</button>} className="!pb-3" />
            <DataTable
              className="rounded-none border-x-0 border-b-0"
              rows={d?.recent}
              rowKey={(r) => `${r.kind}-${r.occurredAt}-${r.clientName}-${r.amountCents}`}
              empty={<EmptyState title="Nenhuma operação registrada" text="As operações recentes aparecerão aqui." />}
              columns={[
                { key: "client", header: "Cliente", width: "1.4fr", render: (r) => <span className="truncate font-medium text-fg">{r.clientName}</span> },
                { key: "kind", header: "Tipo", width: "1fr", render: (r) => <span className="text-fg-muted">{KIND_LABEL[r.kind] ?? r.kind}</span> },
                { key: "amount", header: "Valor", width: "1fr", render: (r) => <Mono>{formatBRL(r.amountCents)}</Mono> },
                { key: "date", header: "Data", width: ".7fr", render: (r) => <span className="text-fg-muted">{formatDate(r.occurredAt).slice(0, 5)}</span> },
                { key: "status", header: "Status", width: "1fr", render: (r) => <StatusBadge status={opStatus(r.kind, r.status)} /> },
              ]}
            />
          </Card>
        </div>

        <Card className="overflow-x-auto">
          <div className="flex items-center justify-between px-5 pt-5 pb-3">
            <h3 className="font-heading text-base font-semibold text-fg">Avisos e Notificações</h3>
            {d && d.unreadNotifications > 0 && <span className="flex size-6 items-center justify-center rounded-full border border-error-line bg-error-bg text-xs font-semibold text-error-fg">{d.unreadNotifications}</span>}
          </div>
          {d && d.notifications.length > 0 ? (
            d.notifications.map((n) => {
              const { icon: Icon, cls } = NOTICE_ICON[n.severity] ?? NOTICE_ICON.info;
              return (
                <div key={n.id} className="flex items-center gap-3 border-t border-line px-5 py-3.5">
                  <span className={cn("flex size-9 shrink-0 items-center justify-center rounded-sm", cls)}><Icon size={16} /></span>
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-medium text-fg">{n.title}</p>
                    <p className="truncate text-xs text-fg-subtle">{n.body ?? relativeTime(n.createdAt)}</p>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="border-t border-line"><EmptyState title="Sem avisos" text="Nenhuma notificação gerada até o momento." /></div>
          )}
          <button onClick={() => navigate("/notificacoes")} className="flex w-full cursor-pointer items-center justify-center gap-1 border-t border-line px-5 py-3.5 text-[13px] font-medium text-fg hover:bg-surface-hover/50">
            Ver central de notificações <ChevronRight size={14} />
          </button>
        </Card>
      </div>
    </div>
  );
}

function sumPending(d: NonNullable<ReturnType<typeof useApi<import("@/types/domain").Dashboard>>["data"]>): number {
  const p = d.pending;
  return p.applicationsInAnalysis + p.contractsPendingSignature + p.collateralAwaitingAppraisal + p.purchasesPending + p.paymentsPending + p.clientsWithoutDocuments;
}

function pendingHint(d: import("@/types/domain").Dashboard): string {
  const p = d.pending;
  const parts = [
    p.applicationsInAnalysis && `${p.applicationsInAnalysis} solicitação(ões)`,
    p.contractsPendingSignature && `${p.contractsPendingSignature} contrato(s)`,
    p.collateralAwaitingAppraisal && `${p.collateralAwaitingAppraisal} avaliação(ões)`,
    p.purchasesPending && `${p.purchasesPending} compra(s)`,
    p.paymentsPending && `${p.paymentsPending} pagamento(s)`,
    p.clientsWithoutDocuments && `${p.clientsWithoutDocuments} cadastro(s)`,
  ].filter(Boolean);
  return parts.slice(0, 2).join(" · ") || "Nenhuma pendência";
}

function opStatus(kind: string, s: string): string {
  if (kind === "loan") return s === "active" ? "ontime" : s;
  if (kind === "collateral") return s === "registered" || s === "appraising" ? "evaluating" : s;
  return s;
}
