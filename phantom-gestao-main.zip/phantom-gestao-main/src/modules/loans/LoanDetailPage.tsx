import { useState } from "react";
import { useParams } from "react-router-dom";
import { Download, FileText, FileSignature, Handshake, Landmark, Receipt, Undo2 } from "lucide-react";
import { Breadcrumb, usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi } from "@/hooks/useApi";
import { useRegulatory } from "@/hooks/useRegulatory";
import { api } from "@/services/api";
import type { InstallmentView, PaymentMethod } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card, ErrorNotice, Mono, Notice } from "@/components/ui/layout";
import { DataTable } from "@/components/ui/data-table";
import { LoanStatusBadge, StatusBadge } from "@/components/ui/badge";
import { ConfirmDialog, FormModal } from "@/components/ui/dialog";
import { MoneyInput, SelectInput, TextArea, TextInput } from "@/components/ui/form";
import { DocumentPreview } from "@/components/DocumentViewer";
import { RegulatoryBanner } from "@/components/RegulatoryBanner";
import { toast } from "@/components/ui/toast";
import { downloadAttachment, formatBytes } from "@/lib/files";
import { METHOD_LABELS, formatBRL, formatBp, formatDate, parsePercentToBp, todayISO } from "@/lib/format";

const METHODS = Object.entries(METHOD_LABELS).map(([value, label]) => ({ value, label }));
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random()));

export function LoanDetailPage() {
  const { id } = useParams();
  const loanId = Number(id);
  const can = useAuth((s) => s.can);
  const reg = useRegulatory();
  const loan = useApi(() => api.loan(loanId), [loanId]);
  const contract = useApi(() => (can("contracts.view") ? api.contractForRef("loan", loanId) : Promise.resolve(null)), [loanId, loan.data?.contractId]);
  const contractDetail = useApi(() => (contract.data ? api.contract(contract.data.id) : Promise.resolve(null)), [contract.data?.id]);
  const d = loan.data;

  usePageHeader(`Contrato #${loanId}`, d ? <Breadcrumb items={[{ label: "Empréstimos", to: "/emprestimos" }, { label: `${d.loan.clientName}${d.purpose ? ` · ${d.purpose}` : ""}`, to: `/clientes/${d.loan.clientId}` }]} /> : null, [loanId, d?.loan.clientName]);

  const [pay, setPay] = useState<InstallmentView | null>(null);
  const [settle, setSettle] = useState(false);
  const [reneg, setReneg] = useState(false);
  const [disburse, setDisburse] = useState(false);
  const [sign, setSign] = useState(false);
  const [preview, setPreview] = useState<number | null>(null);
  const [genBusy, setGenBusy] = useState(false);

  function refresh() {
    loan.reload();
    contract.reload();
    contractDetail.reload();
  }

  async function generate() {
    setGenBusy(true);
    try {
      await api.contractGenerate("loan", loanId, contract.data ? "Nova versão" : undefined);
      toast.success("Contrato gerado.");
      refresh();
    } catch (e) { toast.error(e); } finally { setGenBusy(false); }
  }

  if (loan.error) return <ErrorNotice message={loan.error} onRetry={loan.reload} />;
  if (!d) return null;

  const l = d.loan;
  const pct = d.scheduledCents > 0 ? Math.floor((d.paidCents * 100) / d.scheduledCents) : 0;
  const isActive = l.status === "active";
  const pending = l.status === "pending_disbursement";
  // versões antigas do contrato ficam só no histórico (Contratos); aqui aparece a mais recente
  const allDocs = contractDetail.data?.documents ?? [];
  const latest = new Map<string, number>();
  for (const a of allDocs) {
    const m = /^(.*)_v(\d+)\.pdf$/.exec(a.originalName);
    if (m) latest.set(m[1], Math.max(latest.get(m[1]) ?? 0, Number(m[2])));
  }
  const docs = allDocs.filter((a) => {
    const m = /^(.*)_v(\d+)\.pdf$/.exec(a.originalName);
    return !m || latest.get(m[1]) === Number(m[2]);
  });
  const signed = contract.data?.signedAt != null;

  return (
    <div className="flex flex-col gap-5">
      {reg.loaded && !reg.creditEnabled && (pending || isActive) && <RegulatoryBanner kind="credit" />}
      <div className="flex flex-wrap items-center justify-end gap-3">
        {can("contracts.manage") && !signed && (pending || isActive) && (
          <Button variant="outline" onClick={generate} disabled={genBusy}><FileText size={14} /> {contract.data ? "Gerar nova versão do contrato" : "Gerar contrato"}</Button>
        )}
        {can("contracts.manage") && contract.data && !signed && <Button variant="outline" onClick={() => setSign(true)}><FileSignature size={14} /> Registrar assinatura</Button>}
        {can("loans.disburse") && pending && <Button onClick={() => setDisburse(true)} disabled={!reg.creditEnabled} title={!reg.creditEnabled ? "Bloqueado até a habilitação regulatória" : undefined}><Landmark size={14} /> Registrar desembolso</Button>}
        {can("payments.manage") && isActive && <Button variant="outline" onClick={() => setSettle(true)}><Receipt size={14} /> Quitar</Button>}
        {can("loans.manage") && isActive && <Button variant="outline" onClick={() => setReneg(true)}><Handshake size={14} /> Renegociar</Button>}
      </div>

      {pending && <Notice tone="info">Empréstimo contratado, aguardando desembolso. É necessário gerar o contrato, registrar a assinatura e então registrar o desembolso.</Notice>}

      <div className="grid grid-cols-1 lg:grid-cols-[340px_1fr] items-start gap-5">
        <div className="flex flex-col gap-5">
          <Card className="p-4 sm:p-5">
            <div className="flex items-center justify-between pb-3">
              <h3 className="font-heading text-[15px] font-semibold text-fg">Situação da Operação</h3>
              <LoanStatusBadge derived={l.derivedStatus} />
            </div>
            <dl className="flex flex-col gap-3 text-[13px]">
              <Line k="Valor original" v={formatBRL(l.principalCents)} />
              <Line k="Saldo devedor" v={formatBRL(l.balanceCents)} />
              <Line k="Taxa de juros" v={`${formatBp(d.rateBp)}% a.m.`} />
              {d.cetAnnualBp !== null && <Line k="CET" v={`${formatBp(d.cetAnnualBp)}% a.a.`} />}
              <Line k="Parcelas pagas" v={`${l.paidInstallments} de ${l.totalInstallments}`} />
              <Line k="Data de contratação" v={formatDate(l.contractedAt)} />
              {d.disbursedAt && <Line k="Desembolso" v={formatDate(d.disbursedAt)} />}
              <Line k="Vencimento final" v={formatDate(d.finalDueDate)} />
              {d.renegotiations > 0 && <Line k="Renegociações" v={String(d.renegotiations)} />}
            </dl>
          </Card>

          <Card className="p-4 sm:p-5">
            <h3 className="pb-3 font-heading text-[15px] font-semibold text-fg">Progresso de Pagamento</h3>
            <div className="h-2 overflow-hidden rounded-full bg-app" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
              <div className="h-full rounded-full bg-silver" style={{ width: `${pct}%` }} />
            </div>
            <p className="pt-2.5 text-xs text-fg-muted">{pct}% quitado — {formatBRL(d.paidCents)} pagos</p>
          </Card>

          <Card className="p-4 sm:p-5">
            <h3 className="pb-3 font-heading text-[15px] font-semibold text-fg">Comprovantes</h3>
            <div className="flex flex-col gap-2">
              {docs.length === 0 && <p className="text-[13px] text-fg-muted">Nenhum documento gerado ainda.</p>}
              {docs.map((a) => (
                <div key={a.id} className="flex items-center gap-3 rounded-sm border border-line px-3 py-2.5">
                  <button onClick={() => setPreview(a.id)} className="flex min-w-0 flex-1 cursor-pointer items-center gap-3 text-left">
                    <span className="flex size-8 items-center justify-center text-fg-muted"><FileText size={15} /></span>
                    <span className="min-w-0">
                      <span className="block truncate text-[13px] text-fg">{a.originalName}</span>
                      <span className="text-[11px] text-fg-subtle">{formatBytes(a.sizeBytes)}</span>
                    </span>
                  </button>
                  <button aria-label="Baixar" onClick={() => downloadAttachment(a.id, a.originalName)} className="cursor-pointer text-fg-subtle hover:text-fg"><Download size={15} /></button>
                </div>
              ))}
              {contract.data && <p className="pt-1 text-[11px] text-fg-subtle">{contract.data.number} · {signed ? `assinado em ${formatDate(contract.data.signedAt)} por ${contract.data.signedByName}` : "aguardando assinatura"}</p>}
            </div>
          </Card>
        </div>

        <Card className="overflow-x-auto">
          <div className="px-6 py-4"><h3 className="font-heading text-[15px] font-semibold text-fg">Cronograma de Parcelas</h3></div>
          <DataTable
            className="rounded-none border-0 border-t border-line"
            rows={d.installments}
            rowKey={(i) => i.id}
            columns={[
              { key: "n", header: "Parcela", width: ".8fr", render: (i) => <Mono className="text-fg-muted">{i.number}/{l.totalInstallments}</Mono> },
              { key: "due", header: "Vencimento", width: "1fr", render: (i) => <span className="text-fg-muted">{formatDate(i.dueDate)}</span> },
              {
                key: "amount", header: "Valor", width: "1.1fr",
                render: (i) => (
                  <span>
                    <Mono>{formatBRL(i.amountCents)}</Mono>
                    {i.status === "partial" && <span className="block text-[11px] text-fg-subtle">pago {formatBRL(i.paidCents)}</span>}
                  </span>
                ),
              },
              { key: "status", header: "Status", width: "1fr", render: (i) => (<span><StatusBadge status={i.displayStatus} />{i.due && i.due.charges.daysLate > 0 && <span className="block pt-1 text-[11px] text-error-fg">{i.due.charges.daysLate} dias · + {formatBRL(i.due.charges.feeCents + i.due.charges.interestCents)}</span>}</span>) },
              {
                key: "act", header: "", width: "120px", align: "right",
                render: (i) => (isActive && can("payments.manage") && (i.status === "open" || i.status === "partial") ? <Button size="sm" variant="outline" onClick={() => setPay(i)}>Receber</Button> : null),
              },
            ]}
          />
        </Card>
      </div>

      {pay && <PayModal inst={pay} onClose={() => setPay(null)} onDone={() => { setPay(null); refresh(); }} />}
      <SettleModal open={settle} onOpenChange={setSettle} loanId={loanId} total={d.installments.reduce((s, i) => s + (i.due?.totalDueCents ?? 0), 0)} onDone={refresh} />
      <RenegotiateModal open={reneg} onOpenChange={setReneg} loanId={loanId} balance={d.installments.reduce((s, i) => s + (i.due?.totalDueCents ?? 0), 0)} onDone={refresh} />
      <DisburseModal open={disburse} onOpenChange={setDisburse} loanId={loanId} net={l.principalCents - d.feeCents} onDone={refresh} />
      <SignModal open={sign} onOpenChange={setSign} contractId={contract.data?.id ?? 0} defaultName={l.clientName} onDone={refresh} />
      <FormModal open={preview !== null} onOpenChange={(o) => !o && setPreview(null)} title="Documento" width={860}>
        <DocumentPreview attachmentId={preview} className="h-[68vh]" />
      </FormModal>
    </div>
  );
}

function Line({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between">
      <dt className="text-fg-muted">{k}</dt>
      <dd><Mono className="font-semibold text-fg">{v}</Mono></dd>
    </div>
  );
}

function PayModal({ inst, onClose, onDone }: { inst: InstallmentView; onClose: () => void; onDone: () => void }) {
  const due = inst.due!;
  const [amount, setAmount] = useState<number | null>(due.totalDueCents);
  const [method, setMethod] = useState<PaymentMethod>("pix");
  const [key] = useState(uid);
  const [busy, setBusy] = useState(false);
  const charges = due.charges.feeCents + due.charges.interestCents;
  const err = amount === null || amount <= 0 ? "Informe o valor." : amount > due.totalDueCents ? `Máximo: ${formatBRL(due.totalDueCents)}.` : amount < charges ? `Cubra ao menos os encargos (${formatBRL(charges)}).` : null;

  async function go() {
    setBusy(true);
    try {
      const pid = await api.installmentPay(inst.id, amount!, method, key);
      toast.success(amount === due.totalDueCents ? "Parcela quitada." : "Pagamento parcial registrado.");
      try { await api.paymentReceipt(pid); } catch { /* recibo é opcional */ }
      onDone();
    } catch (e) { toast.error(e); } finally { setBusy(false); }
  }

  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title={`Receber parcela ${inst.number}`} description={`Vencimento ${formatDate(inst.dueDate)}`} width={460}
      footer={<><Button variant="outline" onClick={onClose} disabled={busy}>Cancelar</Button><Button onClick={go} disabled={busy || !!err}>Confirmar recebimento</Button></>}>
      <div className="flex flex-col gap-4">
        <div className="flex flex-col gap-2 rounded-sm border border-line bg-app p-4 text-[13px]">
          <div className="flex justify-between"><span className="text-fg-muted">Saldo da parcela</span><Mono>{formatBRL(due.remainingCents)}</Mono></div>
          {due.charges.daysLate > 0 && (
            <>
              <div className="flex justify-between"><span className="text-fg-muted">Multa por atraso</span><Mono>{formatBRL(due.charges.feeCents)}</Mono></div>
              <div className="flex justify-between"><span className="text-fg-muted">Juros de mora ({due.charges.daysLate} dias)</span><Mono>{formatBRL(due.charges.interestCents)}</Mono></div>
            </>
          )}
          <div className="flex justify-between border-t border-line pt-2 font-semibold"><span>Total devido hoje</span><Mono>{formatBRL(due.totalDueCents)}</Mono></div>
        </div>
        <MoneyInput label="Valor recebido" cents={amount} onChange={setAmount} error={err} hint="Pagamentos parciais são permitidos; encargos de atraso são quitados primeiro." />
        <SelectInput label="Forma de pagamento" value={method} onChange={(v) => setMethod(v as PaymentMethod)} options={METHODS} />
      </div>
    </FormModal>
  );
}

function SettleModal({ open, onOpenChange, loanId, total, onDone }: { open: boolean; onOpenChange: (o: boolean) => void; loanId: number; total: number; onDone: () => void }) {
  const [method, setMethod] = useState<PaymentMethod>("pix");
  const [key] = useState(uid);
  return (
    <ConfirmDialog open={open} onOpenChange={onOpenChange} title="Quitar empréstimo" confirmLabel="Confirmar quitação" successMessage="Empréstimo quitado."
      description={<div className="flex flex-col gap-4"><p>Será registrado um único recebimento de <strong className="text-fg">{formatBRL(total)}</strong> (parcelas em aberto + encargos de atraso). Esta ação gera lançamento no caixa.</p><SelectInput label="Forma de pagamento" value={method} onChange={(v) => setMethod(v as PaymentMethod)} options={METHODS} /></div>}
      onConfirm={async () => { await api.loanSettle(loanId, method, key); onDone(); }} />
  );
}

function DisburseModal({ open, onOpenChange, loanId, net, onDone }: { open: boolean; onOpenChange: (o: boolean) => void; loanId: number; net: number; onDone: () => void }) {
  const [method, setMethod] = useState<PaymentMethod>("pix");
  return (
    <ConfirmDialog open={open} onOpenChange={onOpenChange} title="Registrar desembolso" confirmLabel="Registrar desembolso" successMessage="Desembolso registrado."
      description={<div className="flex flex-col gap-4"><p>Saída de caixa de <strong className="text-fg">{formatBRL(net)}</strong> (valor líquido, já descontadas tarifas). O empréstimo passa a ser <strong className="text-fg">ativo</strong> e o cronograma entra em cobrança. Ação irreversível.</p><SelectInput label="Forma de pagamento" value={method} onChange={(v) => setMethod(v as PaymentMethod)} options={METHODS} /></div>}
      onConfirm={async () => { await api.loanDisburse(loanId, method); onDone(); }} />
  );
}

function SignModal({ open, onOpenChange, contractId, defaultName, onDone }: { open: boolean; onOpenChange: (o: boolean) => void; contractId: number; defaultName: string; onDone: () => void }) {
  const [name, setName] = useState(defaultName);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  async function go() {
    setBusy(true);
    try { await api.contractSign(contractId, name, note || undefined); toast.success("Assinatura registrada."); onOpenChange(false); onDone(); } catch (e) { toast.error(e); } finally { setBusy(false); }
  }
  return (
    <FormModal open={open} onOpenChange={onOpenChange} title="Registrar assinatura" description="Registre a assinatura realizada fora do sistema (manuscrita ou eletrônica)." width={460}
      footer={<><Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button><Button onClick={go} disabled={busy || !name.trim()}>Registrar</Button></>}>
      <div className="flex flex-col gap-4">
        <TextInput label="Nome de quem assinou" value={name} onChange={setName} required />
        <TextArea label="Observação (opcional)" value={note} onChange={setNote} rows={2} placeholder="Ex.: assinatura física, via presencial" />
      </div>
    </FormModal>
  );
}

function RenegotiateModal({ open, onOpenChange, loanId, balance, onDone }: { open: boolean; onOpenChange: (o: boolean) => void; loanId: number; balance: number; onDone: () => void }) {
  const [term, setTerm] = useState("12");
  const [rate, setRate] = useState("");
  const [first, setFirst] = useState(() => todayISO(30));
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  async function go() {
    setBusy(true);
    try {
      await api.loanRenegotiate({ loanId, newTermMonths: Number(term), newRateBp: rate ? parsePercentToBp(rate) : null, firstDueDate: first, reason });
      toast.success("Empréstimo renegociado. As parcelas anteriores foram preservadas no histórico.");
      onOpenChange(false);
      onDone();
    } catch (e) { toast.error(e); } finally { setBusy(false); }
  }
  return (
    <FormModal open={open} onOpenChange={onOpenChange} title="Renegociar empréstimo" width={480}
      description={`O saldo atual (${formatBRL(balance)}, incluindo encargos de atraso) será parcelado em novo cronograma. As parcelas anteriores ficam registradas como renegociadas.`}
      footer={<><Button variant="outline" onClick={() => onOpenChange(false)} disabled={busy}>Cancelar</Button><Button onClick={go} disabled={busy || reason.trim().length < 3}>Renegociar</Button></>}>
      <div className="flex flex-col gap-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <TextInput label="Novo prazo (parcelas)" type="number" min={1} max={120} value={term} onChange={setTerm} />
          <TextInput label="Nova taxa (% a.m.)" value={rate} onChange={setRate} mono placeholder="padrão" />
        </div>
        <TextInput label="Primeiro vencimento" type="date" value={first} onChange={setFirst} />
        <TextArea label="Motivo da renegociação" required value={reason} onChange={setReason} rows={3} />
        <p className="flex items-center gap-1.5 text-xs text-fg-subtle"><Undo2 size={12} /> A renegociação é registrada na auditoria.</p>
      </div>
    </FormModal>
  );
}
