import { useEffect, useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Check, CircleAlert, CircleCheck, LoaderCircle, Info as InfoIcon } from "lucide-react";
import { usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi, useDebounced } from "@/hooks/useApi";
import { useRegulatory } from "@/hooks/useRegulatory";
import { api, errorMessage } from "@/services/api";
import type { Analysis, ApplicationRow, ClientOption, Simulation } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card, Mono, Notice } from "@/components/ui/layout";
import { MoneyInput, SelectInput, TextArea, TextInput } from "@/components/ui/form";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { ClientPicker } from "@/components/ClientPicker";
import { RegulatoryBanner } from "@/components/RegulatoryBanner";
import { toast } from "@/components/ui/toast";
import { formatBRL, formatBp, formatDate, formatPhone, parsePercentToBp, todayISO } from "@/lib/format";
import { cn } from "@/lib/utils";

const STEPS = ["Cliente", "Solicitação", "Simulação", "Análise", "Aprovação", "Resumo"];
const PURPOSES = ["Capital de giro", "Reforma", "Pessoal", "Veículo", "Equipamentos", "Outros"];
const TERMS = [3, 6, 10, 12, 18, 24, 36, 48, 60];

function Stepper({ current }: { current: number }) {
  return (
    <ol className="mx-auto flex w-full max-w-[1040px] items-start justify-between pb-6" aria-label="Etapas do empréstimo">
      {STEPS.map((label, i) => {
        const n = i + 1;
        const done = n < current;
        const active = n === current;
        return (
          <li key={label} className="flex flex-1 flex-col items-center gap-2" aria-current={active ? "step" : undefined}>
            <div className="flex w-full items-center">
              <span className={cn("h-px flex-1", i === 0 ? "bg-transparent" : done || active ? "bg-line-strong" : "bg-line")} />
              <span className={cn("flex size-8 shrink-0 items-center justify-center rounded-full border text-[13px] font-semibold", done ? "border-line-strong bg-surface-hover text-fg-muted" : active ? "border-fg bg-app text-fg" : "border-line bg-surface text-fg-subtle")}>
                {done ? <Check size={14} /> : n}
              </span>
              <span className={cn("h-px flex-1", i === STEPS.length - 1 ? "bg-transparent" : done ? "bg-line-strong" : "bg-line")} />
            </div>
            <span className={cn("text-xs", active ? "font-semibold text-fg" : "hidden text-fg-subtle sm:inline")}>{label}</span>
          </li>
        );
      })}
    </ol>
  );
}

export function LoanWizardPage() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const can = useAuth((s) => s.can);
  const reg = useRegulatory();

  const [step, setStep] = useState(1);
  const [client, setClient] = useState<ClientOption | null>(null);
  const [appId, setAppId] = useState<number | null>(null);
  const [amount, setAmount] = useState<number | null>(null);
  const [term, setTerm] = useState("12");
  const [purpose, setPurpose] = useState("Capital de giro");
  const [collateralId, setCollateralId] = useState("");
  const [firstDue, setFirstDue] = useState(() => todayISO(30));
  const [rate, setRate] = useState("");
  const [sim, setSim] = useState<Simulation | null>(null);
  const [simError, setSimError] = useState<string | null>(null);
  const [simLoading, setSimLoading] = useState(false);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [analysisNotes, setAnalysisNotes] = useState("");
  const [decisionNotes, setDecisionNotes] = useState("");
  const [app, setApp] = useState<ApplicationRow | null>(null);
  const [busy, setBusy] = useState(false);

  usePageHeader("Novo Empréstimo", client ? `${client.name} · ${client.status === "active" ? "Cliente verificado" : "Cadastro não verificado"}` : "Selecione o cliente", [client?.id]);

  // retomar solicitação / pré-selecionar cliente
  useEffect(() => {
    const sid = params.get("solicitacao");
    const cid = params.get("cliente");
    if (sid) {
      api.application(Number(sid)).then(async (a) => {
        setApp(a);
        setAppId(a.id);
        setClient({ id: a.clientId, name: a.clientName, document: "", status: "active" });
        setAmount(a.amountCents);
        setTerm(String(a.termMonths));
        setPurpose(a.purpose ?? "Capital de giro");
        setFirstDue(a.firstDueDate);
        setRate(formatBp(a.rateBp));
        setCollateralId(a.collateralId ? String(a.collateralId) : "");
        setAnalysis(a.analysis);
        setAnalysisNotes(a.analysisNotes ?? "");
        setStep(a.status === "draft" ? 3 : a.status === "analysis" ? 5 : a.status === "approved" ? 6 : 6);
      }).catch((e) => toast.error(e));
    } else if (cid) {
      api.clientOptions().then((all) => {
        const found = all.find((c) => c.id === Number(cid));
        if (found) { setClient(found); setStep(2); }
      }).catch(() => {});
    }
  }, [params]);

  const settings = useApi(() => api.settings(), []);
  useEffect(() => {
    if (!rate && settings.data?.["loan.default_rate_bp"]) setRate(formatBp(Number(settings.data["loan.default_rate_bp"])));
  }, [settings.data, rate]);
  const maxTerm = Number(settings.data?.["loan.max_term_months"] ?? 60);

  const collaterals = useApi(() => (client ? api.collaterals({ pageSize: 100, search: client.name }) : Promise.resolve(null)), [client?.id]);
  const availableCollateral = (collaterals.data?.items ?? []).filter((c) => c.clientId === client?.id && !c.loanId && ["registered", "appraising", "approved"].includes(c.status));
  const summary = useApi(() => (client ? api.clientSummary(client.id) : Promise.resolve(null)), [client?.id]);
  const clientDetail = useApi(() => (client ? api.client(client.id) : Promise.resolve(null)), [client?.id]);

  const rateBp = useMemo(() => (rate ? parsePercentToBp(rate) : null), [rate]);
  const simKey = useDebounced(JSON.stringify([amount, term, firstDue, rateBp]), 350);
  useEffect(() => {
    if (step < 3 || !amount || rateBp === null) { setSim(null); return; }
    let alive = true;
    setSimLoading(true);
    api.simulate({ amountCents: amount, termMonths: Number(term), rateBp, firstDueDate: firstDue })
      .then((s) => { if (alive) { setSim(s); setSimError(null); } })
      .catch((e) => { if (alive) { setSim(null); setSimError(errorMessage(e)); } })
      .finally(() => alive && setSimLoading(false));
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [simKey, step]);

  async function saveApplication(): Promise<number | null> {
    if (!client || !amount) return null;
    const input = { clientId: client.id, amountCents: amount, termMonths: Number(term), rateBp, purpose, firstDueDate: firstDue, collateralId: collateralId ? Number(collateralId) : null };
    try {
      if (appId) { await api.applicationUpdate(appId, input); return appId; }
      const id = await api.applicationCreate(input);
      setAppId(id);
      return id;
    } catch (e) {
      toast.error(e);
      return null;
    }
  }

  async function next() {
    setBusy(true);
    try {
      if (step === 3) {
        if (!sim) { toast.error(simError ?? "Corrija a simulação para continuar."); return; }
        const id = await saveApplication();
        if (!id) return;
        setAnalysis(null);
      }
      setStep((s) => Math.min(6, s + 1));
    } finally { setBusy(false); }
  }

  async function runAnalysis() {
    if (!appId) return;
    setBusy(true);
    try {
      const a = await api.applicationAnalyze(appId, analysisNotes || undefined);
      setAnalysis(a);
      setApp(await api.application(appId));
    } catch (e) { toast.error(e); } finally { setBusy(false); }
  }

  async function decide(approve: boolean) {
    if (!appId) return;
    setBusy(true);
    try {
      await api.applicationDecide(appId, approve, decisionNotes);
      setApp(await api.application(appId));
      toast.success(approve ? "Solicitação aprovada." : "Solicitação recusada.");
      if (approve) setStep(6);
    } catch (e) { toast.error(e); } finally { setBusy(false); }
  }

  async function contract() {
    if (!appId) return;
    setBusy(true);
    try {
      const loanId = await api.loanContract(appId);
      toast.success(`Empréstimo #${loanId} contratado. Gere o contrato e registre a assinatura.`);
      navigate(`/emprestimos/${loanId}`);
    } catch (e) { toast.error(e); } finally { setBusy(false); }
  }

  const canNext = step === 1 ? !!client : step === 2 ? true : step === 3 ? !!sim : step === 4 ? !!analysis : step === 5 ? app?.status === "approved" : false;
  const nextLabel = ["Avançar para Solicitação", "Avançar para Simulação", "Avançar para Análise", "Avançar para Aprovação", "Avançar para Resumo"][step - 1];

  return (
    <div className="mx-auto flex max-w-[1060px] flex-col gap-5">
      {reg.loaded && !reg.creditEnabled && <RegulatoryBanner kind="credit" />}
      <Stepper current={step} />

      {step === 1 && (
        <Card className="p-4 sm:p-6">
          <h3 className="pb-4 font-heading text-base font-semibold text-fg">Selecione o cliente</h3>
          <ClientPicker value={client} onChange={setClient} required />
          {client && client.status !== "active" && <Notice tone="warning" className="mt-4">Este cadastro está <strong>{client.status === "pending" ? "pendente" : client.status}</strong>. A análise cadastral exige cliente ativo.</Notice>}
        </Card>
      )}

      {step === 2 && client && (
        <Card className="p-4 sm:p-6">
          <h3 className="pb-4 font-heading text-base font-semibold text-fg">Dados do solicitante</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 text-sm">
            <Info label="Cliente">{client.name}</Info>
            <Info label="Situação"><StatusBadge status={clientDetail.data?.derivedStatus ?? client.status} /></Info>
            <Info label="Telefone">{formatPhone(clientDetail.data?.phone)}</Info>
            <Info label="Total emprestado"><Mono>{formatBRL(summary.data?.totalLentCents ?? 0)}</Mono></Info>
            <Info label="Saldo em aberto"><Mono>{formatBRL(summary.data?.openBalanceCents ?? 0)}</Mono></Info>
            <Info label="Garantias ativas">{summary.data?.activeCollaterals ?? 0}</Info>
          </div>
          <Notice tone="info" icon={InfoIcon} className="mt-5">Confira os dados do solicitante. A análise cadastral (etapa 4) verifica ativação do cadastro, contatos, atrasos e exposição.</Notice>
        </Card>
      )}

      {step === 3 && (
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] items-start gap-5">
          <Card className="p-4 sm:p-6">
            <h3 className="pb-4 font-heading text-base font-semibold text-fg">Dados da Simulação</h3>
            <div className="flex flex-col gap-5">
              <MoneyInput label="Valor solicitado" cents={amount} onChange={setAmount} required />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <SelectInput label="Prazo" value={term} onChange={setTerm} options={TERMS.filter((t) => t <= maxTerm).map((t) => ({ value: String(t), label: `${t} parcelas` }))} />
                <SelectInput label="Finalidade" value={purpose} onChange={setPurpose} options={PURPOSES.map((p) => ({ value: p, label: p }))} />
                <SelectInput label="Garantia vinculada" value={collateralId} onChange={setCollateralId} placeholder="Nenhuma" options={availableCollateral.map((c) => ({ value: String(c.id), label: `${c.code} — ${c.name}` }))} />
                <TextInput label="Primeiro vencimento" type="date" value={firstDue} onChange={setFirstDue} />
                <TextInput label="Taxa de juros (% a.m.)" value={rate} onChange={setRate} mono hint="Padrão definido em Regras Financeiras." error={rate && rateBp === null ? "Taxa inválida." : null} />
              </div>
              {simError && <Notice tone="error" icon={CircleAlert}>{simError}</Notice>}
            </div>
          </Card>
          <SimulationCard sim={sim} loading={simLoading} />
        </div>
      )}

      {step === 4 && (
        <Card className="p-4 sm:p-6">
          <div className="flex items-start justify-between pb-4">
            <div>
              <h3 className="font-heading text-base font-semibold text-fg">Análise cadastral</h3>
              <p className="text-xs text-fg-muted">Verificações objetivas e determinísticas sobre o cadastro e a exposição do cliente.</p>
            </div>
            {can("loans.manage") && <Button variant="outline" onClick={runAnalysis} disabled={busy}>{busy && <LoaderCircle size={14} className="animate-spin" />}{analysis ? "Analisar novamente" : "Executar análise"}</Button>}
          </div>
          {analysis ? (
            <div className="flex flex-col gap-2">
              {analysis.checks.map((c) => (
                <div key={c.key} className="flex items-center gap-3 rounded-sm border border-line px-4 py-3">
                  {c.ok ? <CircleCheck size={16} className="text-success-fg" /> : <CircleAlert size={16} className={c.required ? "text-error-fg" : "text-warning-fg"} />}
                  <div className="flex-1">
                    <p className="text-[13px] font-medium text-fg">{c.label}{c.required && <span className="ml-2 text-[11px] text-fg-subtle">obrigatório</span>}</p>
                    <p className="text-xs text-fg-muted">{c.detail}</p>
                  </div>
                  <Badge tone={c.ok ? "success" : c.required ? "error" : "warning"}>{c.ok ? "OK" : c.required ? "Pendência" : "Atenção"}</Badge>
                </div>
              ))}
              {analysis.blocking && <Notice tone="error" className="mt-2">Há pendências obrigatórias. Regularize o cadastro e execute a análise novamente.</Notice>}
            </div>
          ) : (
            <p className="rounded-sm border border-dashed border-line px-4 py-8 text-center text-[13px] text-fg-muted">Execute a análise para continuar.</p>
          )}
          <div className="pt-5"><TextArea label="Observações do analista" value={analysisNotes} onChange={setAnalysisNotes} rows={3} /></div>
        </Card>
      )}

      {step === 5 && (
        <Card className="p-4 sm:p-6">
          <h3 className="pb-1 font-heading text-base font-semibold text-fg">Aprovação</h3>
          <p className="pb-4 text-xs text-fg-muted">A decisão é registrada com usuário, data e parecer na trilha de auditoria.</p>
          {app?.status === "approved" || app?.status === "rejected" ? (
            <Notice tone={app.status === "approved" ? "success" : "error"}>
              <strong>{app.status === "approved" ? "Aprovada" : "Recusada"}</strong> em {formatDate(app.decidedAt)} — {app.decisionNotes}
            </Notice>
          ) : can("loans.approve") ? (
            <div className="flex flex-col gap-4">
              {analysis?.blocking && <Notice tone="error">A análise possui pendências obrigatórias; só é possível recusar.</Notice>}
              <TextArea label="Parecer" required value={decisionNotes} onChange={setDecisionNotes} rows={3} />
              <div className="flex gap-3">
                <Button onClick={() => decide(true)} disabled={busy || !decisionNotes.trim() || !!analysis?.blocking}>Aprovar solicitação</Button>
                <Button variant="destructive" onClick={() => decide(false)} disabled={busy || !decisionNotes.trim()}>Recusar</Button>
              </div>
            </div>
          ) : (
            <Notice tone="info">Aguardando aprovação por um usuário com a permissão “Aprovar ou recusar empréstimos”.</Notice>
          )}
        </Card>
      )}

      {step === 6 && client && (
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] items-start gap-5">
          <Card className="p-4 sm:p-6">
            <h3 className="pb-4 font-heading text-base font-semibold text-fg">Resumo da operação</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4 text-sm">
              <Info label="Cliente">{client.name}</Info>
              <Info label="Situação da solicitação">{app && <StatusBadge status={app.status} />}</Info>
              <Info label="Valor"><Mono>{formatBRL(amount)}</Mono></Info>
              <Info label="Prazo">{term} parcelas</Info>
              <Info label="Finalidade">{purpose}</Info>
              <Info label="Primeiro vencimento">{formatDate(firstDue)}</Info>
              <Info label="Garantia vinculada">{collateralId ? availableCollateral.find((c) => String(c.id) === collateralId)?.name ?? `#${collateralId}` : "Nenhuma"}</Info>
              <Info label="Parecer">{app?.decisionNotes ?? "—"}</Info>
            </div>
            {app?.status === "rejected" && <Notice tone="error" className="mt-5">Solicitação recusada. Crie uma nova para tentar novamente.</Notice>}
            {app?.status === "approved" && !reg.creditEnabled && <div className="mt-5"><RegulatoryBanner kind="credit" /></div>}
            {app?.status === "contracted" && <Notice tone="success" className="mt-5">Esta solicitação já foi contratada.</Notice>}
          </Card>
          <SimulationCard sim={sim} loading={simLoading} />
        </div>
      )}

      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={() => (step === 1 ? navigate("/emprestimos") : setStep(step - 1))} disabled={busy}>{step === 1 ? "Cancelar" : "Voltar"}</Button>
        {step < 6 ? (
          <Button onClick={next} disabled={!canNext || busy}>{busy && <LoaderCircle size={14} className="animate-spin" />}{nextLabel}</Button>
        ) : (
          <Button onClick={contract} disabled={busy || app?.status !== "approved" || !can("loans.disburse") || !reg.creditEnabled} title={!reg.creditEnabled ? "Bloqueado até a habilitação regulatória" : undefined}>
            {busy && <LoaderCircle size={14} className="animate-spin" />}Contratar empréstimo
          </Button>
        )}
      </div>
    </div>
  );
}

function Info({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="pb-1 text-xs text-fg-subtle">{label}</p>
      <div className="text-sm text-fg">{children}</div>
    </div>
  );
}

function SimulationCard({ sim, loading }: { sim: Simulation | null; loading: boolean }) {
  return (
    <Card className="overflow-x-auto">
      <div className="flex items-center justify-between px-5 py-4">
        <h3 className="font-heading text-[15px] font-semibold text-fg">Resultado da Simulação</h3>
        <span className="rounded-[4px] border border-info-line bg-info-bg px-2 py-1 text-[10px] font-bold tracking-wider text-info-fg">SIMULAÇÃO</span>
      </div>
      <div className="flex flex-col gap-4 border-t border-line bg-app px-5 py-5">
        {sim ? (
          <>
            <div className={cn("transition-opacity", loading && "opacity-50")}>
              <p className="text-xs text-fg-subtle">Valor da parcela</p>
              <p className="pt-1 font-heading text-[26px] font-bold text-fg">{formatBRL(sim.installmentCents)} <span className="text-base font-semibold text-fg-muted">/ mês</span></p>
            </div>
            <div className="flex flex-col gap-2.5 border-t border-line pt-4 text-[13px]">
              <Row k="Taxa de juros" v={`${formatBp(sim.rateBp)}% a.m.`} />
              <Row k="CET (Custo Efetivo Total)" v={`${formatBp(sim.cetAnnualBp)}% a.a.`} />
              <Row k="Total a pagar" v={formatBRL(sim.totalCents)} />
              <Row k="Total de juros" v={formatBRL(sim.totalInterestCents)} />
              {sim.feesCents > 0 && <Row k="Encargos (tarifa/IOF)" v={formatBRL(sim.feesCents)} />}
              {sim.feesCents > 0 && <Row k="Valor líquido liberado" v={formatBRL(sim.netCents)} />}
            </div>
            <Notice tone="warning" icon={InfoIcon}>Valores de simulação. A contratação final depende da análise de crédito.</Notice>
          </>
        ) : (
          <p className="py-6 text-center text-[13px] text-fg-muted">{loading ? "Calculando…" : "Informe valor, prazo e vencimento para simular."}</p>
        )}
      </div>
    </Card>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-fg-muted">{k}</span>
      <Mono className="font-medium text-fg">{v}</Mono>
    </div>
  );
}
