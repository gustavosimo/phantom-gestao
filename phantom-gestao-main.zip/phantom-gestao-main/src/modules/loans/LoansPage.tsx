import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Eye, HandCoins, Plus, Play } from "lucide-react";
import { usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi, useDebounced } from "@/hooks/useApi";
import { useRegulatory } from "@/hooks/useRegulatory";
import { api } from "@/services/api";
import type { ApplicationRow, LoanRow } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { DataTable, Pagination, useListQuery, type Column } from "@/components/ui/data-table";
import { EmptyState, ErrorNotice, FilterSelect, Mono, Segmented, SearchInput } from "@/components/ui/layout";
import { LoanStatusBadge, StatusBadge } from "@/components/ui/badge";
import { RegulatoryBanner } from "@/components/RegulatoryBanner";
import { RowMenu } from "@/components/RowMenu";
import { formatBRL, formatDate } from "@/lib/format";

export function LoansPage() {
  usePageHeader(null);
  const navigate = useNavigate();
  const can = useAuth((s) => s.can);
  const reg = useRegulatory();
  const [view, setView] = useState<"loans" | "apps">("loans");
  const list = useListQuery({ pageSize: 8 });
  const [search, setSearch] = useState("");
  const debounced = useDebounced(search);
  const query = { ...list.query, search: debounced || undefined };
  const loans = useApi(() => (view === "loans" ? api.loans(query) : Promise.resolve(null)), [JSON.stringify(query), view]);
  const apps = useApi(() => (view === "apps" ? api.applications() : Promise.resolve(null)), [view]);

  const columns: Column<LoanRow>[] = [
    { key: "id", header: "Nº Contrato", width: ".8fr", sort: "id", render: (l) => <Mono className="font-semibold">#{l.id}</Mono> },
    { key: "client", header: "Cliente", width: "2fr", sort: "client", render: (l) => <span className="font-medium">{l.clientName}</span> },
    { key: "value", header: "Valor", width: "1.1fr", sort: "value", render: (l) => <Mono>{formatBRL(l.principalCents)}</Mono> },
    { key: "bal", header: "Saldo Devedor", width: "1.1fr", render: (l) => <Mono className="text-fg-muted">{formatBRL(l.balanceCents)}</Mono> },
    { key: "inst", header: "Parcelas", width: ".7fr", render: (l) => <Mono className="text-fg-muted">{l.paidInstallments}/{l.totalInstallments}</Mono> },
    { key: "due", header: "Vencimento", width: "1fr", sort: "due", render: (l) => <span className="text-fg-muted">{l.nextDue ? formatDate(l.nextDue) : "—"}</span> },
    { key: "status", header: "Status", width: ".9fr", render: (l) => <LoanStatusBadge derived={l.derivedStatus} /> },
    { key: "act", header: "", width: "50px", render: (l) => <RowMenu actions={[{ label: "Ver contrato", icon: Eye, onSelect: () => navigate(`/emprestimos/${l.id}`) }]} /> },
  ];

  return (
    <div className="flex min-h-full flex-col gap-5">
      {reg.loaded && !reg.creditEnabled && <RegulatoryBanner kind="credit" />}
      <div className="flex flex-wrap items-center gap-3">
        <Segmented value={view} onChange={setView} items={[{ value: "loans", label: "Contratos" }, { value: "apps", label: "Solicitações" }]} />
        {view === "loans" && (
          <>
            <SearchInput value={search} onChange={(v) => { setSearch(v); list.setPage(1); }} placeholder="Buscar por nº, cliente..." className="w-full sm:w-[260px]" />
            <FilterSelect label="Status" value={list.state.status} onChange={list.setStatus} options={[{ value: "active", label: "Em dia" }, { value: "pending_disbursement", label: "Pendente" }, { value: "late", label: "Atrasado" }, { value: "paid_off", label: "Quitado" }]} />
            <FilterSelect label="Vencimento" value={list.state.extra} onChange={list.setExtra} options={[{ value: "7d", label: "Próximos 7 dias" }, { value: "30d", label: "Próximos 30 dias" }, { value: "overdue", label: "Em atraso" }]} />
          </>
        )}
        {can("loans.manage") && <Button className="ml-auto" onClick={() => navigate("/emprestimos/novo")}><Plus size={14} /> Novo Empréstimo</Button>}
      </div>

      {(loans.error || apps.error) && <ErrorNotice message={(loans.error || apps.error)!} onRetry={view === "loans" ? loans.reload : apps.reload} />}

      {view === "loans" ? (
        <DataTable
          className="flex-1"
          columns={columns}
          rows={loans.data?.items}
          rowKey={(l) => l.id}
          loading={loans.loading}
          sort={{ key: list.state.sort, desc: list.state.desc }}
          onSort={list.toggleSort}
          onRowClick={(l) => navigate(`/emprestimos/${l.id}`)}
          minBodyHeight={420}
          empty={<EmptyState icon={HandCoins} title="Nenhum contrato de crédito" text="Contratos aparecem aqui após a aprovação e contratação de uma solicitação." />}
          footer={loans.data && <Pagination page={loans.data.page} pageSize={loans.data.pageSize} total={loans.data.total} onPage={list.setPage} noun="contratos" />}
        />
      ) : (
        <ApplicationsTable rows={apps.data ?? undefined} loading={apps.loading} onOpen={(a) => navigate(a.loanId ? `/emprestimos/${a.loanId}` : `/emprestimos/novo?solicitacao=${a.id}`)} />
      )}
    </div>
  );
}

function ApplicationsTable({ rows, loading, onOpen }: { rows: ApplicationRow[] | undefined; loading: boolean; onOpen: (a: ApplicationRow) => void }) {
  const columns: Column<ApplicationRow>[] = [
    { key: "id", header: "Nº", width: ".6fr", render: (a) => <Mono className="font-semibold">S-{a.id}</Mono> },
    { key: "client", header: "Cliente", width: "2fr", render: (a) => <span className="font-medium">{a.clientName}</span> },
    { key: "amount", header: "Valor solicitado", width: "1.2fr", render: (a) => <Mono>{formatBRL(a.amountCents)}</Mono> },
    { key: "term", header: "Prazo", width: ".8fr", render: (a) => <span className="text-fg-muted">{a.termMonths}x</span> },
    { key: "date", header: "Criada em", width: "1fr", render: (a) => <span className="text-fg-muted">{formatDate(a.createdAt)}</span> },
    { key: "status", header: "Situação", width: "1fr", render: (a) => <StatusBadge status={a.status} /> },
    { key: "act", header: "", width: "50px", render: (a) => <RowMenu actions={[{ label: a.loanId ? "Ver contrato" : "Continuar", icon: a.loanId ? Eye : Play, onSelect: () => onOpen(a) }]} /> },
  ];
  return <DataTable className="flex-1" columns={columns} rows={rows} rowKey={(a) => a.id} loading={loading} onRowClick={onOpen} minBodyHeight={420} empty={<EmptyState icon={HandCoins} title="Nenhuma solicitação em andamento" />} />;
}
