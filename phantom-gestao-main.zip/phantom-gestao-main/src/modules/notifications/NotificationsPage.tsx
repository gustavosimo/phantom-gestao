import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Bell, Clock, Mail, MessageCircle, ShieldCheck, TriangleAlert, CircleCheck, UserPlus, Package, FileText, ClipboardList, RefreshCw } from "lucide-react";
import { usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi } from "@/hooks/useApi";
import { api } from "@/services/api";
import type { NotificationRow } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card, EmptyState, ErrorNotice, Notice, Segmented } from "@/components/ui/layout";
import { Pagination } from "@/components/ui/data-table";
import { toast } from "@/components/ui/toast";
import { relativeTime } from "@/lib/format";
import { cn } from "@/lib/utils";

type Tab = "unread" | "alert" | "due" | "payment" | "pending" | "all";

const KIND_ICON: Record<string, { icon: typeof Bell; cls: string }> = {
  due_today: { icon: Clock, cls: "text-warning-fg" },
  due_soon: { icon: Clock, cls: "text-info-fg" },
  overdue: { icon: TriangleAlert, cls: "text-error-fg" },
  collateral_deadline: { icon: TriangleAlert, cls: "text-error-fg" },
  collateral_appraisal: { icon: ShieldCheck, cls: "text-info-fg" },
  contract_pending: { icon: FileText, cls: "text-warning-fg" },
  document_pending: { icon: ClipboardList, cls: "text-warning-fg" },
  payment_confirmed: { icon: CircleCheck, cls: "text-success-fg" },
  loan_paid_off: { icon: CircleCheck, cls: "text-success-fg" },
  new_clients: { icon: UserPlus, cls: "text-info-fg" },
  collateral_redeemed: { icon: Package, cls: "text-success-fg" },
  task: { icon: ClipboardList, cls: "text-fg-muted" },
};

const ENTITY_ROUTE: Record<string, (id: number) => string> = {
  collateral: (id) => `/garantias/${id}`, client: (id) => `/clientes/${id}`, loan: (id) => `/emprestimos/${id}`, contract: () => "/contratos", payment: () => "/pagamentos", installment: () => "/cobrancas",
};

export function NotificationsPage() {
  const navigate = useNavigate();
  const can = useAuth((s) => s.can);
  const [tab, setTab] = useState<Tab>("unread");
  const [page, setPage] = useState(1);
  const unread = useApi(() => api.unreadCount(), []);
  const list = useApi(() => api.notifications({ page, pageSize: 8, status: tab }), [tab, page]);
  const stats = useApi(() => api.deliveryStats(), []);
  const [busy, setBusy] = useState(false);

  usePageHeader("Central de Notificações", `${unread.data ?? 0} não lida${unread.data === 1 ? "" : "s"}`, [unread.data]);

  function reloadAll() { list.reload(); unread.reload(); }
  async function open(n: NotificationRow) {
    if (!n.read) { try { await api.markRead(n.id); reloadAll(); } catch { /* segue */ } }
    const route = n.entityType && n.entityId !== null ? ENTITY_ROUTE[n.entityType]?.(n.entityId) : null;
    if (route) navigate(route);
  }
  async function markAll() {
    try { await api.markAllRead(); toast.success("Todas as notificações foram marcadas como lidas."); reloadAll(); } catch (e) { toast.error(e); }
  }
  async function refresh() {
    setBusy(true);
    try { const n = await api.runRules(); toast.success(n > 0 ? `${n} novo(s) aviso(s) gerado(s).` : "Nenhum aviso novo."); reloadAll(); } catch (e) { toast.error(e); } finally { setBusy(false); }
  }

  const chan = (c: string) => stats.data?.find((s) => s.channel === c);
  const sendLine = (c: string) => { const s = chan(c); return s ? `${s.total} registro(s) · ${s.ok} ok · ${s.failed} falha(s)${s.blocked ? ` · ${s.blocked} bloqueado(s)` : ""}` : "Nenhum registro"; };

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <Segmented<Tab> value={tab} onChange={(t) => { setTab(t); setPage(1); }} items={[{ value: "unread", label: "Não lidas" }, { value: "alert", label: "Alertas" }, { value: "due", label: "Vencimentos" }, { value: "payment", label: "Pagamentos" }, { value: "pending", label: "Pendências" }, { value: "all", label: "Todas" }]} />
        <Button variant="ghost" size="sm" onClick={refresh} disabled={busy}><RefreshCw size={14} className={busy ? "animate-spin" : ""} /> Verificar agora</Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] items-start gap-5">
        <div className="overflow-x-auto rounded-md border border-line bg-surface">
          {list.error && <div className="p-4"><ErrorNotice message={list.error} onRetry={list.reload} /></div>}
          {(list.data?.items ?? []).map((n) => {
            const { icon: Icon, cls } = KIND_ICON[n.kind] ?? { icon: Bell, cls: "text-fg-muted" };
            return (
              <button key={n.id} onClick={() => open(n)} className="flex w-full cursor-pointer items-center gap-4 border-b border-line px-5 py-4 text-left last:border-b-0 hover:bg-surface-hover/40">
                <span className={cn("flex size-10 shrink-0 items-center justify-center rounded-sm", cls)}><Icon size={17} /></span>
                <div className="min-w-0 flex-1">
                  <p className="flex items-center gap-2 text-sm font-medium text-fg">{n.title}{!n.read && <span className="size-1.5 rounded-full bg-fg-muted" aria-label="não lida" />}</p>
                  {n.body && <p className="truncate pt-0.5 text-[13px] text-fg-muted">{n.body}</p>}
                </div>
                <span className="shrink-0 text-xs text-fg-subtle">{relativeTime(n.createdAt)}</span>
              </button>
            );
          })}
          {list.data && list.data.items.length === 0 && <EmptyState icon={Bell} title={tab === "unread" ? "Nenhuma notificação não lida" : "Nenhuma notificação"} text="Avisos de vencimento, atraso, garantias, contratos e pagamentos aparecem aqui, gerados por regras do sistema." />}
          {list.data && list.data.total > 0 && <Pagination page={list.data.page} pageSize={list.data.pageSize} total={list.data.total} onPage={setPage} noun="avisos" />}
        </div>

        <div className="flex flex-col gap-5">
          <Card className="p-4 sm:p-5">
            <h3 className="pb-3 font-heading text-[15px] font-semibold text-fg">Histórico de Envio</h3>
            <div className="flex flex-col gap-3.5">
              <div className="flex gap-3"><Mail size={15} className="mt-0.5 text-fg-muted" /><div><p className="text-[13px] font-medium text-fg">E-mail de cobrança</p><p className="text-[11px] text-fg-subtle">{sendLine("email")}</p></div></div>
              <div className="flex gap-3"><MessageCircle size={15} className="mt-0.5 text-fg-muted" /><div><p className="text-[13px] font-medium text-fg">WhatsApp</p><p className="text-[11px] text-fg-subtle">{sendLine("whatsapp")}</p></div></div>
              <div className="flex gap-3"><Clock size={15} className="mt-0.5 text-fg-muted" /><div><p className="text-[13px] font-medium text-fg">Ligações</p><p className="text-[11px] text-fg-subtle">{sendLine("call")}</p></div></div>
            </div>
            <Notice tone="info" className="mt-4">Envios são registrados manualmente a partir de Cobranças. A integração automática com WhatsApp Business API e e-mail ainda não está conectada.</Notice>
          </Card>
          <Card className="p-4 sm:p-5">
            <Button variant="outline" className="w-full" onClick={markAll} disabled={!can("notifications.view") || (unread.data ?? 0) === 0}>Marcar todas como lidas</Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
