import { useState } from "react";
import { Ban, CheckCircle2, LoaderCircle, Plus, ReceiptText, Wallet } from "lucide-react";
import { usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi, useDebounced } from "@/hooks/useApi";
import { api } from "@/services/api";
import type { CashRow, ClientOption, InstallmentView, PaymentMethod, PaymentRow } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { DataTable, Pagination, useListQuery, type Column } from "@/components/ui/data-table";
import { EmptyState, ErrorNotice, FilterSelect, Mono, Notice, SearchInput, Segmented, StatCard } from "@/components/ui/layout";
import { Badge, StatusBadge } from "@/components/ui/badge";
import { ConfirmDialog, FormModal } from "@/components/ui/dialog";
import { MoneyInput, SelectInput, TextInput } from "@/components/ui/form";
import { ClientPicker } from "@/components/ClientPicker";
import { DocumentPreview } from "@/components/DocumentViewer";
import { RowMenu } from "@/components/RowMenu";
import { toast } from "@/components/ui/toast";
import { METHOD_LABELS, formatBRL, formatDate, formatLocalDateTime, todayISO } from "@/lib/format";
import { cn } from "@/lib/utils";

const METHODS = Object.entries(METHOD_LABELS).map(([value, label]) => ({ value, label }));
const ORIGIN: Record<string, string> = { loan: "Empréstimo", sale: "Venda", purchase: "Compra", payable: "Conta a pagar", receivable: "Conta a receber", collateral: "Garantia", other: "Outros" };
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random()));

export function PaymentsPage() {
  usePageHeader(null);
  const [view, setView] = useState<"payments" | "cash">("payments");
  return (
    <div className="flex min-h-full flex-col gap-5">
      <Segmented value={view} onChange={setView} items={[{ value: "payments", label: "Lançamentos" }, { value: "cash", label: "Caixa e conciliação" }]} className="self-start" />
      {view === "payments" ? <Payments /> : <Cash />}
    </div>
  );
}

function Payments() {
  const can = useAuth((s) => s.can);
  const list = useListQuery({ pageSize: 8 });
  const [search, setSearch] = useState("");
  const dq = useDebounced(search);
  const [origin, setOrigin] = useState("");
  const query = { ...list.query, search: dq || undefined };
  const { data, loading, error, reload } = useApi(() => api.payments(query, { origin: origin || undefined }), [JSON.stringify(query), origin]);
  const [register, setRegister] = useState(false);
  const [reverse, setReverse] = useState<PaymentRow | null>(null);
  const [receipt, setReceipt] = useState<number | null>(null);

  async function confirm(p: PaymentRow) {
    try { await api.paymentConfirm(p.id); toast.success("Lançamento confirmado e registrado no caixa."); reload(); } catch (e) { toast.error(e); }
  }
  async function showReceipt(p: PaymentRow) {
    try { setReceipt((await api.paymentReceipt(p.id)).id); } catch (e) { toast.error(e); }
  }

  const columns: Column<PaymentRow>[] = [
    { key: "id", header: "ID", width: ".9fr", render: (p) => <Mono className="text-fg-muted">#{p.code}</Mono> },
    { key: "client", header: "Cliente", width: "2fr", sort: "client", render: (p) => <span><span className="font-medium">{p.clientName ?? (p.originType === "sale" ? "Consumidor final" : "—")}</span>{p.description && <span className="block truncate text-[11px] text-fg-subtle">{p.description}</span>}</span> },
    { key: "origin", header: "Origem", width: "1.1fr", render: (p) => <span className="text-fg-muted">{ORIGIN[p.originType] ?? p.originType}{p.direction === "out" && !["payable", "receivable"].includes(p.originType) ? " (saída)" : ""}</span> },
    { key: "value", header: "Valor", width: "1fr", sort: "amount", render: (p) => <Mono className={cn("font-semibold", p.direction === "out" && "text-fg-muted")}>{p.direction === "out" ? "- " : ""}{formatBRL(p.amountCents)}</Mono> },
    { key: "method", header: "Forma", width: "1fr", render: (p) => <span className="text-fg-muted">{METHOD_LABELS[p.method]}</span> },
    { key: "date", header: "Data", width: ".9fr", sort: "date", render: (p) => <span className="text-fg-muted">{formatDate(p.paidAt ?? p.dueDate ?? p.createdAt)}</span> },
    { key: "status", header: "Situação", width: "1.1fr", render: (p) => <StatusBadge status={p.status} /> },
    {
      key: "act", header: "", width: "50px",
      render: (p) => (
        <RowMenu actions={[
          { label: "Confirmar lançamento", icon: CheckCircle2, hidden: !can("payments.manage") || !["pending", "overdue"].includes(p.status), onSelect: () => confirm(p) },
          { label: "Recibo (PDF)", icon: ReceiptText, hidden: !["confirmed", "reversed"].includes(p.status), onSelect: () => showReceipt(p) },
          { label: "Estornar", icon: Ban, destructive: true, hidden: !can("payments.reverse") || p.status !== "confirmed" || p.reversalOfId !== null || ["sale", "purchase"].includes(p.originType) || (p.originType === "loan" && p.direction === "out"), onSelect: () => setReverse(p) },
        ]} />
      ),
    },
  ];

  return (
    <>
      <div className="flex flex-wrap items-center gap-3">
        <SearchInput value={search} onChange={(v) => { setSearch(v); list.setPage(1); }} placeholder="Buscar por cliente, ID..." className="w-full sm:w-[260px]" />
        <FilterSelect label="Origem" value={origin} onChange={(v) => { setOrigin(v); list.setPage(1); }} options={Object.entries(ORIGIN).map(([value, label]) => ({ value, label }))} />
        <FilterSelect label="Situação" value={list.state.status} onChange={list.setStatus} options={[{ value: "confirmed", label: "Confirmado" }, { value: "pending", label: "Pendente" }, { value: "overdue", label: "Atrasado" }, { value: "reversed", label: "Estornado" }]} />
        {can("payments.manage") && <Button className="ml-auto" onClick={() => setRegister(true)}><Plus size={14} /> Registrar Pagamento</Button>}
      </div>
      {error && <ErrorNotice message={error} onRetry={reload} />}
      <DataTable className="flex-1" columns={columns} rows={data?.items} rowKey={(p) => p.id} loading={loading} sort={{ key: list.state.sort, desc: list.state.desc }} onSort={list.toggleSort} minBodyHeight={400}
        empty={<EmptyState icon={Wallet} title="Nenhum lançamento" text="Recebimentos de parcelas, vendas, compras e contas aparecem aqui. Lançamentos confirmados nunca são excluídos." />}
        footer={data && <Pagination page={data.page} pageSize={data.pageSize} total={data.total} onPage={list.setPage} noun="lançamentos" />} />
      {register && <RegisterModal onClose={() => setRegister(false)} onDone={() => { setRegister(false); reload(); }} />}
      {reverse && <ConfirmDialog open onOpenChange={(o) => !o && setReverse(null)} title={`Estornar ${reverse.code}`} destructive confirmLabel="Estornar" reasonLabel="Motivo do estorno" description={<>O lançamento original é preservado e um lançamento inverso de <strong className="text-fg">{formatBRL(reverse.amountCents)}</strong> é criado no caixa. Parcelas pagas por ele voltam a ficar em aberto.</>} onConfirm={async (r) => { await api.paymentReverse(reverse.id, r); reload(); }} successMessage="Pagamento estornado." />}
      <FormModal open={receipt !== null} onOpenChange={(o) => !o && setReceipt(null)} title="Recibo" width={820}>
        <DocumentPreview attachmentId={receipt} className="h-[66vh]" />
      </FormModal>
    </>
  );
}

function RegisterModal({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const [mode, setMode] = useState<"manual" | "installment">("manual");
  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title="Registrar pagamento" width={540}>
      <div className="flex flex-col gap-5">
        <Segmented value={mode} onChange={setMode} items={[{ value: "manual", label: "Conta a pagar / receber" }, { value: "installment", label: "Parcela de empréstimo" }]} />
        {mode === "manual" ? <ManualForm onClose={onClose} onDone={onDone} /> : <InstallmentForm onClose={onClose} onDone={onDone} />}
      </div>
    </FormModal>
  );
}

function ManualForm({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const [direction, setDirection] = useState<"in" | "out">("in");
  const [client, setClient] = useState<ClientOption | null>(null);
  const [party, setParty] = useState("");
  const [desc, setDesc] = useState("");
  const [amount, setAmount] = useState<number | null>(null);
  const [method, setMethod] = useState<PaymentMethod>("pix");
  const [paid, setPaid] = useState<"now" | "later">("now");
  const [due, setDue] = useState(() => todayISO(7));
  const [key] = useState(uid);
  const [busy, setBusy] = useState(false);
  const valid = !!amount && desc.trim().length >= 3 && (!!client || party.trim().length >= 2);
  async function go() {
    setBusy(true);
    try {
      await api.paymentRegister({ clientId: client?.id ?? null, partyName: client ? null : party, direction, description: desc, amountCents: amount!, method, dueDate: paid === "later" ? due : null, confirm: paid === "now", idempotencyKey: key });
      toast.success(paid === "now" ? "Lançamento confirmado." : "Lançamento agendado.");
      onDone();
    } catch (e) { toast.error(e); } finally { setBusy(false); }
  }
  return (
    <div className="flex flex-col gap-4">
      <Segmented value={direction} onChange={setDirection} items={[{ value: "in", label: "A receber" }, { value: "out", label: "A pagar" }]} />
      <ClientPicker label="Cliente (opcional)" value={client} onChange={setClient} allowEmpty emptyLabel="Sem cliente" />
      {!client && <TextInput label="Favorecido / pagador" required value={party} onChange={setParty} />}
      <TextInput label="Descrição" required value={desc} onChange={setDesc} />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <MoneyInput label="Valor" required cents={amount} onChange={setAmount} />
        <SelectInput label="Forma de pagamento" value={method} onChange={(v) => setMethod(v as PaymentMethod)} options={METHODS} />
        <SelectInput label="Situação" value={paid} onChange={(v) => setPaid(v as "now" | "later")} options={[{ value: "now", label: direction === "in" ? "Já recebido" : "Já pago" }, { value: "later", label: "Pendente (agendar)" }]} />
        {paid === "later" && <TextInput label="Vencimento" type="date" value={due} onChange={setDue} />}
      </div>
      <div className="flex justify-end gap-3 pt-2">
        <Button variant="outline" onClick={onClose} disabled={busy}>Cancelar</Button>
        <Button onClick={go} disabled={!valid || busy}>{busy && <LoaderCircle size={14} className="animate-spin" />}Registrar</Button>
      </div>
    </div>
  );
}

function InstallmentForm({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const [client, setClient] = useState<ClientOption | null>(null);
  const loans = useApi(() => (client ? api.loans({ pageSize: 50, search: client.name, status: undefined }) : Promise.resolve(null)), [client?.id]);
  const active = (loans.data?.items ?? []).filter((l) => l.clientId === client?.id && l.status === "active");
  const [loanId, setLoanId] = useState("");
  const detail = useApi(() => (loanId ? api.loan(Number(loanId)) : Promise.resolve(null)), [loanId]);
  const open = (detail.data?.installments ?? []).filter((i) => i.status === "open" || i.status === "partial");
  const [instId, setInstId] = useState("");
  const inst: InstallmentView | undefined = open.find((i) => String(i.id) === instId);
  const [amount, setAmount] = useState<number | null>(null);
  const [method, setMethod] = useState<PaymentMethod>("pix");
  const [key] = useState(uid);
  const [busy, setBusy] = useState(false);

  async function go() {
    setBusy(true);
    try {
      const pid = await api.installmentPay(inst!.id, amount!, method, key);
      toast.success("Recebimento registrado.");
      try { await api.paymentReceipt(pid); } catch { /* opcional */ }
      onDone();
    } catch (e) { toast.error(e); } finally { setBusy(false); }
  }

  return (
    <div className="flex flex-col gap-4">
      <ClientPicker value={client} onChange={(c) => { setClient(c); setLoanId(""); setInstId(""); }} required />
      {client && (active.length === 0 && loans.data ? <Notice tone="info">Este cliente não possui empréstimos ativos.</Notice> : (
        <SelectInput label="Empréstimo" value={loanId} onChange={(v) => { setLoanId(v); setInstId(""); }} placeholder="Selecione" options={active.map((l) => ({ value: String(l.id), label: `#${l.id} — saldo ${formatBRL(l.balanceCents)}` }))} />
      ))}
      {loanId && <SelectInput label="Parcela" value={instId} onChange={(v) => { setInstId(v); const i = open.find((x) => String(x.id) === v); setAmount(i?.due?.totalDueCents ?? null); }} placeholder="Selecione" options={open.map((i) => ({ value: String(i.id), label: `${i.number} — vence ${formatDate(i.dueDate)} — ${formatBRL(i.due?.totalDueCents ?? i.amountCents)}${i.displayStatus === "overdue" ? " (atrasada)" : ""}` }))} />}
      {inst?.due && (
        <>
          {inst.due.charges.daysLate > 0 && <Notice tone="warning">Parcela com {inst.due.charges.daysLate} dias de atraso: multa {formatBRL(inst.due.charges.feeCents)} + juros {formatBRL(inst.due.charges.interestCents)} incluídos no total.</Notice>}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <MoneyInput label="Valor recebido" cents={amount} onChange={setAmount} hint={`Total devido: ${formatBRL(inst.due.totalDueCents)}`} />
            <SelectInput label="Forma de pagamento" value={method} onChange={(v) => setMethod(v as PaymentMethod)} options={METHODS} />
          </div>
        </>
      )}
      <div className="flex justify-end gap-3 pt-2">
        <Button variant="outline" onClick={onClose} disabled={busy}>Cancelar</Button>
        <Button onClick={go} disabled={!inst || !amount || busy}>{busy && <LoaderCircle size={14} className="animate-spin" />}Confirmar recebimento</Button>
      </div>
    </div>
  );
}

function Cash() {
  const can = useAuth((s) => s.can);
  const [filter, setFilter] = useState("");
  const [page, setPage] = useState(1);
  const summary = useApi(() => api.cashSummary(), []);
  const list = useApi(() => api.cash({ page, pageSize: 10, status: filter || undefined }), [page, filter]);
  const [sel, setSel] = useState<number[]>([]);
  const [manual, setManual] = useState(false);

  function refresh() { summary.reload(); list.reload(); setSel([]); }
  async function reconcile(value: boolean) {
    try { await api.cashReconcile(sel, value); toast.success(value ? "Lançamentos conciliados." : "Conciliação desfeita."); refresh(); } catch (e) { toast.error(e); }
  }
  const toggle = (id: number) => setSel((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  const s = summary.data;
  const columns: Column<CashRow>[] = [
    ...(can("payments.manage") ? [{ key: "sel", header: "", width: "36px", render: (r: CashRow) => <input type="checkbox" aria-label="Selecionar lançamento" checked={sel.includes(r.id)} onChange={() => toggle(r.id)} className="size-4 cursor-pointer accent-[#c0c0c0]" /> }] : []),
    { key: "date", header: "Data", width: "1.2fr", render: (r) => <span className="text-fg-muted">{formatLocalDateTime(r.occurredAt)}</span> },
    { key: "cat", header: "Categoria", width: "1.1fr", render: (r) => <span>{r.category}</span> },
    { key: "desc", header: "Descrição", width: "2.2fr", render: (r) => <span className="truncate text-fg-muted">{r.description ?? "—"}</span> },
    { key: "method", header: "Forma", width: ".9fr", render: (r) => <span className="text-fg-muted">{METHOD_LABELS[r.method] ?? r.method}</span> },
    { key: "val", header: "Valor", width: "1.1fr", render: (r) => <Mono className={cn("font-semibold", r.kind === "in" ? "text-success-fg" : "text-error-fg")}>{r.kind === "in" ? "+" : "-"} {formatBRL(r.amountCents)}</Mono> },
    { key: "rec", header: "Conciliação", width: "1fr", render: (r) => (r.reconciled ? <Badge tone="success">Conciliado</Badge> : <Badge tone="warning">Pendente</Badge>) },
  ];

  return (
    <>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard label="Saldo em caixa" value={<Mono className="text-base sm:text-xl">{formatBRL(s?.balanceCents ?? 0)}</Mono>} />
        <StatCard label="Entradas" tone="success" value={<Mono className="text-base sm:text-xl">{formatBRL(s?.inflowCents ?? 0)}</Mono>} />
        <StatCard label="Saídas" tone="error" value={<Mono className="text-base sm:text-xl">{formatBRL(s?.outflowCents ?? 0)}</Mono>} />
        <StatCard label="Não conciliados" value={s?.unreconciledCount ?? 0} hint={`A receber ${formatBRL(s?.receivablePendingCents ?? 0)} · A pagar ${formatBRL(s?.payablePendingCents ?? 0)}`} />
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <FilterSelect label="Conciliação" value={filter} onChange={(v) => { setFilter(v); setPage(1); }} options={[{ value: "unreconciled", label: "Não conciliados" }, { value: "reconciled", label: "Conciliados" }]} />
        {can("payments.manage") && (
          <>
            <Button variant="outline" size="sm" disabled={sel.length === 0} onClick={() => reconcile(true)}>Conciliar selecionados ({sel.length})</Button>
            <Button variant="ghost" size="sm" disabled={sel.length === 0} onClick={() => reconcile(false)}>Desfazer conciliação</Button>
            <Button className="ml-auto" variant="outline" onClick={() => setManual(true)}><Plus size={14} /> Suprimento / Sangria</Button>
          </>
        )}
      </div>
      <DataTable columns={columns} rows={list.data?.items} rowKey={(r) => r.id} loading={list.loading} minBodyHeight={340}
        empty={<EmptyState icon={Wallet} title="Sem movimentações de caixa" text="Os lançamentos de caixa são gerados por recebimentos, vendas, compras e desembolsos. São imutáveis." />}
        footer={list.data && <Pagination page={list.data.page} pageSize={list.data.pageSize} total={list.data.total} onPage={setPage} noun="movimentos" />} />
      {manual && <ManualCash onClose={() => setManual(false)} onDone={() => { setManual(false); refresh(); }} />}
    </>
  );
}

function ManualCash({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const [kind, setKind] = useState<"in" | "out">("in");
  const [amount, setAmount] = useState<number | null>(null);
  const [method, setMethod] = useState<PaymentMethod>("cash");
  const [desc, setDesc] = useState("");
  const [busy, setBusy] = useState(false);
  async function go() {
    setBusy(true);
    try { await api.cashManual(kind, amount!, method, desc); toast.success("Lançamento de caixa registrado."); onDone(); } catch (e) { toast.error(e); } finally { setBusy(false); }
  }
  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title="Suprimento / Sangria" width={440}
      footer={<><Button variant="outline" onClick={onClose} disabled={busy}>Cancelar</Button><Button onClick={go} disabled={busy || !amount || desc.trim().length < 3}>Registrar</Button></>}>
      <div className="flex flex-col gap-4">
        <Segmented value={kind} onChange={setKind} items={[{ value: "in", label: "Suprimento (entrada)" }, { value: "out", label: "Sangria (saída)" }]} />
        <MoneyInput label="Valor" cents={amount} onChange={setAmount} required />
        <SelectInput label="Forma" value={method} onChange={(v) => setMethod(v as PaymentMethod)} options={METHODS} />
        <TextInput label="Descrição" required value={desc} onChange={setDesc} />
      </div>
    </FormModal>
  );
}
