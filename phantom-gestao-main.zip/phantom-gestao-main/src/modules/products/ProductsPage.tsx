import { useEffect, useState } from "react";
import { Bike, Boxes, ClipboardList, Guitar, History, X, Package, Pencil, Plus, Smartphone, Tv, Watch, Laptop, type LucideIcon } from "lucide-react";
import { usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi, useDebounced } from "@/hooks/useApi";
import { api } from "@/services/api";
import type { ProductRow } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { DataTable, Pagination, useListQuery, type Column } from "@/components/ui/data-table";
import { EmptyState, ErrorNotice, FilterSelect, Mono, SearchInput } from "@/components/ui/layout";
import { StatusBadge } from "@/components/ui/badge";
import { FormModal } from "@/components/ui/dialog";
import { MoneyInput, SelectInput, TextArea, TextInput } from "@/components/ui/form";
import { RowMenu } from "@/components/RowMenu";
import { toast } from "@/components/ui/toast";
import { formatBRL, formatDateTime } from "@/lib/format";
import { Segmented } from "@/components/ui/layout";
import { Thumb } from "@/components/DocumentViewer";
import { IMAGE_FILTERS, pickFile } from "@/lib/files";

export function productIcon(p: { category: string; name: string }): LucideIcon {
  const t = `${p.category} ${p.name}`.toLowerCase();
  if (/tv|televis/.test(t)) return Tv;
  if (/notebook|laptop|computador/.test(t)) return Laptop;
  if (/relógio|relogio|acess/.test(t)) return Watch;
  if (/violão|violao|guitarra|instrument/.test(t)) return Guitar;
  if (/bicicleta|esporte/.test(t)) return Bike;
  if (/smartphone|celular|eletr/.test(t)) return Smartphone;
  return Package;
}

export function ProductsPage() {
  usePageHeader(null);
  const can = useAuth((s) => s.can);
  const list = useListQuery({ pageSize: 8 });
  const [search, setSearch] = useState("");
  const debounced = useDebounced(search);
  const query = { ...list.query, search: debounced || undefined };
  const cats = useApi(() => api.productCategories(), []);
  const { data, loading, error, reload } = useApi(() => api.products(query), [JSON.stringify(query)]);
  const [edit, setEdit] = useState<ProductRow | "new" | null>(null);
  const [stock, setStock] = useState<ProductRow | null>(null);
  const [count, setCount] = useState<ProductRow | null>(null);
  const [hist, setHist] = useState<ProductRow | null>(null);

  const columns: Column<ProductRow>[] = [
    {
      key: "name", header: "Produto", width: "2.4fr", sort: "name",
      render: (p) => {
        const Icon = productIcon(p);
        return (
          <span className="flex items-center gap-3">
            <span className="flex size-9 shrink-0 items-center justify-center text-fg-muted"><Icon size={16} /></span>
            <span className="min-w-0"><span className="block truncate font-medium">{p.name}</span>{p.reservedQty > 0 && <span className="text-[11px] text-fg-subtle">{p.reservedQty} reservado(s)</span>}</span>
          </span>
        );
      },
    },
    { key: "sku", header: "Código", width: "1fr", sort: "sku", render: (p) => <Mono className="text-fg-muted">{p.sku}</Mono> },
    { key: "cat", header: "Categoria", width: "1fr", render: (p) => <span className="text-fg-muted">{p.category}</span> },
    { key: "cost", header: "Custo", width: "1fr", sort: "cost", render: (p) => <Mono className="text-fg-muted">{formatBRL(p.costCents)}</Mono> },
    { key: "price", header: "Preço", width: "1fr", sort: "price", render: (p) => <Mono className="font-semibold">{formatBRL(p.priceCents)}</Mono> },
    { key: "qty", header: "Qtd.", width: ".5fr", sort: "qty", render: (p) => <span className="text-fg-muted">{p.stockQty}</span> },
    { key: "status", header: "Status", width: "1.1fr", render: (p) => <StatusBadge status={p.status} /> },
    {
      key: "act", header: "", width: "50px",
      render: (p) => (
        <RowMenu actions={[
          { label: "Editar produto", icon: Pencil, hidden: !can("products.manage"), onSelect: () => setEdit(p) },
          { label: "Ajustar estoque", icon: Boxes, hidden: !can("products.manage"), onSelect: () => setStock(p) },
          { label: "Contagem de inventário", icon: ClipboardList, hidden: !can("products.manage"), onSelect: () => setCount(p) },
          { label: "Movimentações e custos", icon: History, onSelect: () => setHist(p) },
        ]} />
      ),
    },
  ];

  return (
    <div className="flex min-h-full flex-col gap-5">
      <div className="flex flex-wrap items-center gap-3">
        <SearchInput value={search} onChange={(v) => { setSearch(v); list.setPage(1); }} placeholder="Buscar por nome, código..." className="w-full sm:w-[260px]" />
        <FilterSelect label="Categoria" value={list.state.category} onChange={list.setCategory} options={(cats.data ?? []).map((c) => ({ value: c, label: c }))} />
        <FilterSelect label="Status" value={list.state.status} onChange={list.setStatus} options={[{ value: "available", label: "Disponível" }, { value: "low", label: "Baixo estoque" }, { value: "out", label: "Esgotado" }, { value: "inactive", label: "Inativo" }]} />
        {can("products.manage") && <Button className="ml-auto" onClick={() => setEdit("new")}><Plus size={14} /> Novo Produto</Button>}
      </div>
      {error && <ErrorNotice message={error} onRetry={reload} />}
      <DataTable
        className="flex-1" columns={columns} rows={data?.items} rowKey={(p) => p.id} loading={loading}
        sort={{ key: list.state.sort, desc: list.state.desc }} onSort={list.toggleSort} minBodyHeight={420}
        empty={<EmptyState icon={Package} title="Nenhum produto cadastrado" text="Produtos entram no estoque por cadastro ou por compras." />}
        footer={data && <Pagination page={data.page} pageSize={data.pageSize} total={data.total} onPage={list.setPage} noun="produtos" />}
      />
      {edit && <ProductForm product={edit === "new" ? null : edit} categories={cats.data ?? []} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); reload(); cats.reload(); }} />}
      {stock && <StockModal product={stock} onClose={() => setStock(null)} onSaved={() => { setStock(null); reload(); }} />}
      {count && <CountModal product={count} onClose={() => setCount(null)} onSaved={() => { setCount(null); reload(); }} />}
      {hist && <HistoryModal product={hist} onClose={() => setHist(null)} />}
    </div>
  );
}

function ProductForm({ product, categories, onClose, onSaved }: { product: ProductRow | null; categories: string[]; onClose: () => void; onSaved: () => void }) {
  const [f, setF] = useState({
    sku: product?.sku ?? "", name: product?.name ?? "", category: product?.category ?? categories[0] ?? "Eletrônicos", brand: product?.brand ?? "", model: product?.model ?? "",
    serial: product?.serialNumber ?? "", min: String(product?.minStock ?? 1), active: product ? (product.active ? "1" : "0") : "1", notes: product?.notes ?? "",
  });
  const [cost, setCost] = useState<number | null>(product?.costCents ?? null);
  const [price, setPrice] = useState<number | null>(product?.priceCents ?? null);
  const [busy, setBusy] = useState(false);
  const [newCat, setNewCat] = useState(false);
  const set = (k: keyof typeof f) => (v: string) => setF((x) => ({ ...x, [k]: v }));
  const photos = useApi(() => (product ? api.attachments("product", product.id, "photo") : Promise.resolve([])), [product?.id]);

  const [queued, setQueued] = useState<string[]>([]);

  async function addPhoto() {
    const path = await pickFile(IMAGE_FILTERS);
    if (!path) return;
    if (!product) { setQueued((q) => [...q, path]); return; }
    try { await api.attachmentAdd("product", product.id, "photo", path); toast.success("Foto anexada."); photos.reload(); } catch (e) { toast.error(e); }
  }

  async function save() {
    setBusy(true);
    const input = { sku: f.sku || null, name: f.name, category: f.category, brand: f.brand || null, model: f.model || null, serialNumber: f.serial || null, costCents: cost ?? 0, priceCents: price ?? 0, minStock: Number(f.min) || 0, active: f.active === "1", notes: f.notes || null };
    try {
      let failed = 0;
      if (product) await api.productUpdate(product.id, input);
      else {
        const id = await api.productCreate(input);
        for (const path of queued) { try { await api.attachmentAdd("product", id, "photo", path); } catch { failed++; } }
      }
      toast.success(product ? "Produto atualizado." : "Produto cadastrado.");
      if (failed) toast.error(`${failed} foto(s) não puderam ser anexadas; adicione-as editando o produto.`);
      onSaved();
    } catch (e) { toast.error(e); } finally { setBusy(false); }
  }

  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title={product ? "Editar produto" : "Novo produto"} width={600}
      description={product ? undefined : "O estoque inicial é lançado depois, por compra ou ajuste com justificativa."}
      footer={<><Button variant="outline" onClick={onClose} disabled={busy}>Cancelar</Button><Button onClick={save} disabled={busy || f.name.trim().length < 2}>Salvar produto</Button></>}>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <TextInput className="sm:col-span-2" label="Nome do produto" required value={f.name} onChange={set("name")} />
        <TextInput label="Código interno" mono value={f.sku} onChange={set("sku")} placeholder="Gerado automaticamente" />
        {newCat || categories.length === 0 ? <TextInput label="Categoria" required value={f.category} onChange={set("category")} /> : (
          <div className="flex flex-col gap-1.5">
            <SelectInput label="Categoria" value={f.category} onChange={set("category")} options={categories.map((c) => ({ value: c, label: c }))} />
            <button type="button" className="cursor-pointer self-start text-xs text-fg-muted underline" onClick={() => { setNewCat(true); set("category")(""); }}>Nova categoria</button>
          </div>
        )}
        <TextInput label="Marca" value={f.brand} onChange={set("brand")} />
        <TextInput label="Modelo" value={f.model} onChange={set("model")} />
        <TextInput label="Número de série" mono value={f.serial} onChange={set("serial")} />
        <TextInput label="Estoque mínimo" type="number" min={0} value={f.min} onChange={set("min")} />
        <MoneyInput label="Valor de aquisição (custo)" cents={cost} onChange={setCost} />
        <MoneyInput label="Preço de venda" cents={price} onChange={setPrice} />
        {product && <SelectInput label="Situação" value={f.active} onChange={set("active")} options={[{ value: "1", label: "Ativo" }, { value: "0", label: "Inativo" }]} />}
        <TextArea className="sm:col-span-2" label="Observações" value={f.notes} onChange={set("notes")} rows={2} />
        <div className="sm:col-span-2">
          <p className="pb-2 text-[13px] font-medium text-fg-muted">Fotos</p>
          <div className="flex flex-wrap gap-3">
            {(photos.data ?? []).map((a) => <Thumb key={a.id} attachmentId={a.id} alt={a.originalName} className="size-16" />)}
            {queued.map((q, i) => <QueuedPhoto key={q} path={q} onRemove={() => setQueued((l) => l.filter((_, j) => j !== i))} />)}
            <button type="button" onClick={addPhoto} className="flex size-16 cursor-pointer items-center justify-center rounded-sm border border-line-strong text-[11px] text-fg-muted hover:bg-surface-hover">+ Foto</button>
          </div>
          {!product && queued.length > 0 && <p className="pt-2 text-xs text-fg-subtle">As fotos serão anexadas ao salvar. Use o X para remover uma foto da lista.</p>}
        </div>
      </div>
    </FormModal>
  );
}

function StockModal({ product, onClose, onSaved }: { product: ProductRow; onClose: () => void; onSaved: () => void }) {
  const [kind, setKind] = useState<"in" | "out">("in");
  const [qty, setQty] = useState("1");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try { await api.productAdjustStock(product.id, (kind === "in" ? 1 : -1) * Number(qty), reason); toast.success("Estoque ajustado."); onSaved(); } catch (e) { toast.error(e); } finally { setBusy(false); }
  }
  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title={`Ajustar estoque — ${product.name}`} description={`Saldo atual: ${product.stockQty} (${product.reservedQty} reservado)`} width={440}
      footer={<><Button variant="outline" onClick={onClose} disabled={busy}>Cancelar</Button><Button onClick={save} disabled={busy || !Number(qty) || Number(qty) < 1 || reason.trim().length < 3}>Registrar ajuste</Button></>}>
      <div className="flex flex-col gap-4">
        <Segmented value={kind} onChange={setKind} items={[{ value: "in", label: "Entrada" }, { value: "out", label: "Saída" }]} />
        <TextInput label="Quantidade" type="number" min={1} value={qty} onChange={setQty} />
        <TextInput label="Justificativa" required value={reason} onChange={setReason} />
      </div>
    </FormModal>
  );
}

function CountModal({ product, onClose, onSaved }: { product: ProductRow; onClose: () => void; onSaved: () => void }) {
  const [counted, setCounted] = useState(String(product.stockQty));
  const [note, setNote] = useState("Contagem de inventário");
  const [busy, setBusy] = useState(false);
  const diff = Number(counted) - product.stockQty;
  async function save() {
    setBusy(true);
    try { const d = await api.productInventoryCount(product.id, Number(counted), note); toast.success(d === 0 ? "Contagem confere com o sistema." : `Diferença de ${d > 0 ? "+" : ""}${d} registrada.`); onSaved(); } catch (e) { toast.error(e); } finally { setBusy(false); }
  }
  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title={`Inventário — ${product.name}`} description={`Saldo no sistema: ${product.stockQty}`} width={440}
      footer={<><Button variant="outline" onClick={onClose} disabled={busy}>Cancelar</Button><Button onClick={save} disabled={busy || counted === "" || Number(counted) < 0}>Registrar contagem</Button></>}>
      <div className="flex flex-col gap-4">
        <TextInput label="Quantidade contada" type="number" min={0} value={counted} onChange={setCounted} hint={Number.isFinite(diff) ? `Diferença: ${diff > 0 ? "+" : ""}${diff}` : undefined} />
        <TextInput label="Observação" value={note} onChange={setNote} />
      </div>
    </FormModal>
  );
}

function HistoryModal({ product, onClose }: { product: ProductRow; onClose: () => void }) {
  const [tab, setTab] = useState<"mov" | "cost">("mov");
  const mov = useApi(() => api.productMovements(product.id), [product.id]);
  const costs = useApi(() => api.productCosts(product.id), [product.id]);
  const KIND: Record<string, string> = { purchase: "Compra", sale: "Venda", return: "Devolução", adjustment: "Ajuste", inventory: "Inventário", reserve: "Reserva", release: "Liberação" };
  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title={product.name} description={product.sku} width={620}>
      <div className="flex flex-col gap-4">
        <Segmented value={tab} onChange={setTab} items={[{ value: "mov", label: "Movimentações" }, { value: "cost", label: "Histórico de custos" }]} />
        <div className="max-h-[320px] overflow-y-auto rounded-sm border border-line">
          {tab === "mov" ? (mov.data ?? []).map((m) => (
            <div key={m.id} className="grid min-w-[640px] grid-cols-[1fr_.6fr_1.4fr_1fr] items-center gap-3 border-b border-line px-4 py-2.5 text-[13px] last:border-b-0">
              <span>{KIND[m.kind] ?? m.kind}</span><Mono className={m.qty < 0 ? "text-error-fg" : "text-success-fg"}>{m.qty > 0 ? "+" : ""}{m.qty}</Mono><span className="truncate text-fg-muted">{m.reason ?? "—"}</span><span className="text-xs text-fg-subtle">{formatDateTime(m.createdAt)}</span>
            </div>
          )) : (costs.data ?? []).map((c, i) => (
            <div key={i} className="grid grid-cols-[1fr_1.6fr_1fr] items-center gap-3 border-b border-line px-4 py-2.5 text-[13px] last:border-b-0">
              <Mono>{formatBRL(c.costCents)}</Mono><span className="text-fg-muted">{c.reason}</span><span className="text-xs text-fg-subtle">{formatDateTime(c.createdAt)}</span>
            </div>
          ))}
          {(tab === "mov" ? mov.data : costs.data)?.length === 0 && <p className="px-4 py-6 text-center text-[13px] text-fg-muted">Sem registros.</p>}
        </div>
      </div>
    </FormModal>
  );
}

function QueuedPhoto({ path, onRemove }: { path: string; onRemove: () => void }) {
  const [src, setSrc] = useState<string | null>(null);
  useEffect(() => { let alive = true; api.localImagePreview(path).then((d) => alive && setSrc(d)).catch(() => {}); return () => { alive = false; }; }, [path]);
  const name = path.split(/[\/]/).pop() ?? path;
  return (
    <div className="flex w-24 flex-col gap-1">
      <div className="group relative size-24 overflow-hidden rounded-sm border border-line bg-app">
        {src ? <img src={src} alt={name} className="size-full object-cover" /> : <span className="flex size-full items-center justify-center text-[11px] text-fg-subtle">…</span>}
        <button type="button" aria-label="Remover foto" title="Remover da lista" onClick={onRemove} className="absolute top-1 right-1 flex size-5 cursor-pointer items-center justify-center rounded-full bg-black/70 text-fg hover:bg-black"><X size={12} /></button>
      </div>
      <span className="truncate text-[10px] text-fg-subtle" title={name}>{name}</span>
    </div>
  );
}
