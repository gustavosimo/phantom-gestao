import { useState } from "react";
import { Ban, CheckCircle2, FileText, LoaderCircle, ShoppingBag, Upload } from "lucide-react";
import { usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi } from "@/hooks/useApi";
import { api } from "@/services/api";
import type { ClientOption, PaymentMethod, PurchaseRow } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, EmptyState, ErrorNotice, Mono, Segmented } from "@/components/ui/layout";
import { StatusBadge } from "@/components/ui/badge";
import { ConfirmDialog, FormModal } from "@/components/ui/dialog";
import { MoneyInput, SelectInput, TextInput } from "@/components/ui/form";
import { ClientPicker } from "@/components/ClientPicker";
import { DocumentPreview } from "@/components/DocumentViewer";
import { RowMenu } from "@/components/RowMenu";
import { toast } from "@/components/ui/toast";
import { fileName, pickFile } from "@/lib/files";
import { METHOD_LABELS, formatBRL, maskCpfCnpj, todayISO } from "@/lib/format";
import { CATEGORIES } from "@/modules/collateral/CollateralPage";
import { DataTable, Pagination } from "@/components/ui/data-table";

const METHODS = Object.entries(METHOD_LABELS).map(([value, label]) => ({ value, label }));

export function PurchasesPage() {
  usePageHeader(null);
  const can = useAuth((s) => s.can);
  const [page, setPage] = useState(1);
  const list = useApi(() => api.purchases({ page, pageSize: 8 }), [page]);
  const [cancel, setCancel] = useState<PurchaseRow | null>(null);
  const [receipt, setReceipt] = useState<number | null>(null);

  async function confirm(p: PurchaseRow) {
    try { await api.purchaseConfirm(p.id); toast.success("Compra confirmada: estoque e caixa atualizados."); list.reload(); } catch (e) { toast.error(e); }
  }
  async function showReceipt(p: PurchaseRow) {
    try { const a = await api.purchaseReceipt(p.id); setReceipt(a.id); } catch (e) { toast.error(e); }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[460px_1fr] items-start gap-5">
      {can("purchases.manage") ? <NewPurchaseForm onSaved={() => { setPage(1); list.reload(); }} /> : <Card className="p-4 sm:p-6"><EmptyState title="Somente consulta" text="Seu perfil não permite registrar compras." /></Card>}

      <Card className="overflow-x-auto">
        <CardHeader title="Compras Recentes" className="!pb-4" />
        {list.error && <div className="p-4"><ErrorNotice message={list.error} onRetry={list.reload} /></div>}
        <DataTable
          className="rounded-none border-x-0 border-b-0"
          rows={list.data?.items}
          loading={list.loading}
          rowKey={(p) => p.id}
          empty={<EmptyState icon={ShoppingBag} title="Nenhuma compra registrada" text="Compras confirmadas dão entrada no estoque e saída no caixa." />}
          columns={[
            { key: "product", header: "Produto", width: "1.7fr", render: (p) => <span className="truncate font-medium">{p.productName}</span> },
            { key: "seller", header: "Vendedor", width: "1.3fr", render: (p) => <span className="truncate text-fg-muted">{p.sellerName}</span> },
            { key: "amount", header: "Valor", width: "1.1fr", render: (p) => <Mono>{formatBRL(p.amountCents)}</Mono> },
            { key: "method", header: "Pagamento", width: "1fr", render: (p) => <span className="text-fg-muted">{METHOD_LABELS[p.paymentMethod]}</span> },
            { key: "status", header: "Status", width: "1.1fr", render: (p) => <StatusBadge status={p.status} /> },
            {
              key: "menu", header: "", width: "40px",
              render: (p) => (
                <RowMenu actions={[
                  { label: "Confirmar compra", icon: CheckCircle2, hidden: !can("purchases.manage") || p.status !== "pending", onSelect: () => confirm(p) },
                  { label: "Comprovante (PDF)", icon: FileText, hidden: p.status !== "confirmed", onSelect: () => showReceipt(p) },
                  { label: "Cancelar compra", icon: Ban, destructive: true, hidden: !can("purchases.manage") || p.status === "cancelled", onSelect: () => setCancel(p) },
                ]} />
              ),
            },
          ]}
          footer={list.data && list.data.total > 0 ? <Pagination page={list.data.page} pageSize={list.data.pageSize} total={list.data.total} onPage={setPage} noun="compras" /> : undefined}
        />
      </Card>

      {cancel && (
        <ConfirmDialog open onOpenChange={(o) => !o && setCancel(null)} title="Cancelar compra" destructive confirmLabel="Cancelar compra" reasonLabel="Motivo do cancelamento"
          description={cancel.status === "confirmed" ? "O estoque será baixado e o pagamento estornado (histórico preservado). Só é possível se os itens ainda estiverem disponíveis." : "A compra pendente e o pagamento agendado serão cancelados."}
          onConfirm={async (r) => { await api.purchaseCancel(cancel.id, r); list.reload(); }} successMessage="Compra cancelada." />
      )}
      <FormModal open={receipt !== null} onOpenChange={(o) => !o && setReceipt(null)} title="Comprovante de compra" width={820}>
        <DocumentPreview attachmentId={receipt} className="h-[66vh]" />
      </FormModal>
    </div>
  );
}

function NewPurchaseForm({ onSaved }: { onSaved: () => void }) {
  const [sellerMode, setSellerMode] = useState<"name" | "client">("name");
  const [seller, setSeller] = useState<ClientOption | null>(null);
  const [sellerName, setSellerName] = useState("");
  const [sellerDoc, setSellerDoc] = useState("");
  const [productMode, setProductMode] = useState<"new" | "existing">("new");
  const [productName, setProductName] = useState("");
  const [existingId, setExistingId] = useState("");
  const [category, setCategory] = useState("Eletrônicos");
  const [qty, setQty] = useState("1");
  const [amount, setAmount] = useState<number | null>(null);
  const [salePrice, setSalePrice] = useState<number | null>(null);
  const [method, setMethod] = useState<PaymentMethod>("pix");
  const [paid, setPaid] = useState<"now" | "later">("now");
  const [due, setDue] = useState(() => todayISO(15));
  const [proof, setProof] = useState("");
  const [file, setFile] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const products = useApi(() => (productMode === "existing" ? api.products({ pageSize: 200 }) : Promise.resolve(null)), [productMode]);

  const valid = amount && amount > 0 && proof.trim().length >= 3 && (sellerMode === "client" ? !!seller : sellerName.trim().length >= 2) && (productMode === "existing" ? !!existingId : productName.trim().length >= 2);

  function reset() {
    setSeller(null); setSellerName(""); setSellerDoc(""); setProductName(""); setExistingId(""); setQty("1"); setAmount(null); setSalePrice(null); setProof(""); setFile(null); setPaid("now");
  }

  async function save() {
    setBusy(true);
    try {
      await api.purchaseRegister({
        sellerClientId: sellerMode === "client" ? seller!.id : null, sellerName: sellerMode === "name" ? sellerName : null, sellerDocument: sellerMode === "name" && sellerDoc ? sellerDoc : null,
        productId: productMode === "existing" ? Number(existingId) : null, productName: productMode === "new" ? productName : null, category: productMode === "new" ? category : null,
        salePriceCents: salePrice, qty: Number(qty) || 1, amountCents: amount!, paymentMethod: method, confirm: paid === "now", dueDate: paid === "later" ? due : null,
        originProof: proof, receiptPath: file,
      });
      toast.success(paid === "now" ? "Compra registrada: entrada no estoque e saída no caixa." : "Compra registrada como pendente.");
      reset();
      onSaved();
    } catch (e) { toast.error(e); } finally { setBusy(false); }
  }

  return (
    <Card className="p-4 sm:p-6">
      <h3 className="pb-4 font-heading text-base font-semibold text-fg">Nova Compra</h3>
      <div className="flex flex-col gap-4">
        <Segmented value={sellerMode} onChange={setSellerMode} items={[{ value: "name", label: "Vendedor avulso" }, { value: "client", label: "Cliente cadastrado" }]} />
        {sellerMode === "client" ? <ClientPicker label="Vendedor" value={seller} onChange={setSeller} required /> : (
          <>
            <TextInput label="Vendedor" required value={sellerName} onChange={setSellerName} placeholder="Nome do vendedor ou fornecedor" />
            <TextInput label="CPF/CNPJ do vendedor (opcional)" mono value={sellerDoc} mask={(v) => maskCpfCnpj(v, v.replace(/\D/g, "").length > 11 ? "PJ" : "PF")} onChange={setSellerDoc} />
          </>
        )}
        <Segmented value={productMode} onChange={setProductMode} items={[{ value: "new", label: "Produto novo" }, { value: "existing", label: "Produto existente" }]} />
        {productMode === "new" ? (
          <>
            <TextInput label="Produto" required value={productName} onChange={setProductName} placeholder="Ex: Notebook Dell Inspiron 15" />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <SelectInput label="Categoria" value={category} onChange={setCategory} options={CATEGORIES.map((c) => ({ value: c, label: c }))} />
              <MoneyInput label="Preço de venda" cents={salePrice} onChange={setSalePrice} />
            </div>
          </>
        ) : (
          <SelectInput label="Produto" required value={existingId} onChange={setExistingId} placeholder="Selecione" options={(products.data?.items ?? []).map((p) => ({ value: String(p.id), label: `${p.sku} — ${p.name}` }))} />
        )}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <MoneyInput label="Valor pago (total)" required cents={amount} onChange={setAmount} />
          <TextInput label="Quantidade" type="number" min={1} value={qty} onChange={setQty} />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <SelectInput label="Forma de pagamento" value={method} onChange={(v) => setMethod(v as PaymentMethod)} options={METHODS} />
          <SelectInput label="Pagamento" value={paid} onChange={(v) => setPaid(v as "now" | "later")} options={[{ value: "now", label: "Efetuado agora" }, { value: "later", label: "Agendar (pendente)" }]} />
        </div>
        {paid === "later" && <TextInput label="Vencimento" type="date" value={due} onChange={setDue} />}
        <TextInput label="Comprovante de procedência" required value={proof} onChange={setProof} placeholder="Ex: Nota fiscal nº 123 / declaração do vendedor" hint="Obrigatório para registrar a origem do bem adquirido." />
        <div>
          <p className="pb-1.5 text-[13px] font-medium text-fg-muted">Comprovante (arquivo)</p>
          <button type="button" onClick={async () => { const p = await pickFile(); if (p) setFile(p); }} className="flex w-full cursor-pointer flex-col items-center gap-2 rounded-sm border border-line-strong px-4 py-6 text-xs text-fg-muted hover:bg-surface-hover">
            <Upload size={18} />
            {file ? fileName(file) : "Clique para anexar comprovante"}
          </button>
        </div>
        <div className="flex justify-end gap-3 pt-1">
          <Button variant="outline" onClick={reset} disabled={busy}>Cancelar</Button>
          <Button onClick={save} disabled={!valid || busy}>{busy && <LoaderCircle size={14} className="animate-spin" />}Registrar Compra</Button>
        </div>
      </div>
    </Card>
  );
}
