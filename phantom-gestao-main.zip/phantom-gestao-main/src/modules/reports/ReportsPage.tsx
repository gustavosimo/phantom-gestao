import { useState } from "react";
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Download, FileSpreadsheet, FileText, LoaderCircle, Printer, TrendingDown, TrendingUp } from "lucide-react";
import { save } from "@tauri-apps/plugin-dialog";
import { usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi } from "@/hooks/useApi";
import { api, isDesktop } from "@/services/api";
import type { Period } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, EmptyState, ErrorNotice, Mono, Segmented } from "@/components/ui/layout";
import { DataTable } from "@/components/ui/data-table";
import { FormModal } from "@/components/ui/dialog";
import { SelectInput, TextInput } from "@/components/ui/form";
import { toast } from "@/components/ui/toast";
import { downloadAttachment } from "@/lib/files";
import { formatBRL, formatBp, formatDate, todayISO } from "@/lib/format";
import { cn } from "@/lib/utils";

type K = "7d" | "30d" | "quarter" | "year" | "custom";
const PIE_COLORS = ["#c0c0c0", "#6fcf97", "#6fa8dc", "#e0b35c"];

function Kpi({ label, value, delta, invertGood }: { label: string; value: React.ReactNode; delta?: { v: number; p: number; unit?: "pct" | "pp" }; invertGood?: boolean }) {
  let text = "";
  let good: boolean | null = null;
  if (delta) {
    if (delta.unit === "pp") {
      const d = delta.v - delta.p;
      text = `${d >= 0 ? "+" : ""}${formatBp(d)} p.p.`;
      good = invertGood ? d <= 0 : d >= 0;
    } else if (delta.p > 0) {
      const pct = Math.round(((delta.v - delta.p) * 1000) / delta.p) / 10;
      text = `${pct >= 0 ? "+" : ""}${String(pct).replace(".", ",")}%`;
      good = invertGood ? pct <= 0 : pct >= 0;
    } else text = delta.v > 0 ? "novo" : "—";
  }
  return (
    <div className="flex flex-col gap-3 rounded-md border border-line bg-surface p-5">
      <span className="text-[13px] text-fg-muted">{label}</span>
      <div className="font-heading text-xl font-bold text-fg sm:text-2xl">{value}</div>
      {delta && <div className={cn("flex items-center gap-1.5 text-xs", good === null ? "text-fg-subtle" : good ? "text-success-fg" : "text-error-fg")}>{good === null ? null : good ? <TrendingUp size={12} /> : <TrendingDown size={12} />}{text} vs. período anterior</div>}
    </div>
  );
}

export function ReportsPage() {
  usePageHeader(null);
  const can = useAuth((s) => s.can);
  const [kind, setKind] = useState<K>("30d");
  const [from, setFrom] = useState(todayISO(-29));
  const [to, setTo] = useState(todayISO());
  const period: Period = kind === "custom" ? { kind, from, to } : { kind };
  const o = useApi(() => api.reportOverview(period), [kind, from, to]);
  const gen = useApi(() => api.reportsGenerated(), []);
  const [exportOpen, setExportOpen] = useState(false);
  const d = o.data;
  const total = d?.operations.reduce((s, x) => s + x.count, 0) ?? 0;
  const bars = (d?.revenueSeries ?? []).map((s) => ({ label: s.label, Receita: s.receivedCents }));
  const hasBars = bars.some((b) => b.Receita > 0);

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex min-w-0 max-w-full flex-wrap items-center gap-3">
          <Segmented<K> value={kind} onChange={setKind} items={[{ value: "7d", label: "7 dias" }, { value: "30d", label: "30 dias" }, { value: "quarter", label: "Trimestre" }, { value: "year", label: "Ano" }, { value: "custom", label: "Personalizado" }]} />
          {kind === "custom" && <div className="flex items-end gap-2"><TextInput label="De" type="date" value={from} onChange={setFrom} /><TextInput label="Até" type="date" value={to} onChange={setTo} /></div>}
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={() => window.print()}><Printer size={14} /> Imprimir</Button>
          {can("reports.export") && <Button onClick={() => setExportOpen(true)}>Exportar Relatório</Button>}
        </div>
      </div>
      {o.error && <ErrorNotice message={o.error} onRetry={o.reload} />}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
        <Kpi label="Receita Total" value={<Mono className="text-lg sm:text-2xl">{formatBRL(d?.revenue.value ?? 0)}</Mono>} delta={d && { v: d.revenue.value, p: d.revenue.previous }} />
        <Kpi label="Novos Contratos" value={d?.newContracts.value ?? 0} delta={d && { v: d.newContracts.value, p: d.newContracts.previous }} />
        <Kpi label="Ticket Médio" value={<Mono className="text-lg sm:text-2xl">{formatBRL(d?.avgTicketCents.value ?? 0)}</Mono>} delta={d && { v: d.avgTicketCents.value, p: d.avgTicketCents.previous }} />
        <Kpi label="Taxa de Inadimplência" value={<span>{formatBp(d?.delinquencyBp.value ?? 0)}%</span>} invertGood />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-5">
        <Card>
          <CardHeader title="Receita por Mês" subtitle="Juros e encargos recebidos + margem bruta de vendas" />
          <div className="h-[190px] px-4 pb-4">
            {hasBars ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={bars} margin={{ top: 4, right: 8, left: 8, bottom: 0 }}>
                  <CartesianGrid vertical={false} stroke="#34373e" strokeOpacity={0.4} />
                  <XAxis dataKey="label" tickLine={false} axisLine={false} tick={{ fill: "#6b6f78", fontSize: 11 }} interval="preserveStartEnd" />
                  <YAxis hide />
                  <Tooltip formatter={(v) => formatBRL(Number(v))} contentStyle={{ background: "#1e2025", border: "1px solid #34373e", borderRadius: 6, fontSize: 12 }} cursor={{ fill: "#ffffff08" }} />
                  <Bar dataKey="Receita" fill="#c0c0c0" radius={[3, 3, 0, 0]} maxBarSize={28} />
                </BarChart>
              </ResponsiveContainer>
            ) : <EmptyState title="Sem receita no período" />}
          </div>
        </Card>
        <Card>
          <CardHeader title="Operações por Tipo" />
          <div className="flex items-center gap-4 px-5 pb-5">
            <div className="size-[140px] shrink-0">
              {total > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={d!.operations} dataKey="count" nameKey="label" innerRadius={42} outerRadius={66} stroke="#1e2025" strokeWidth={2}>
                      {d!.operations.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                    </Pie>
                    <Tooltip contentStyle={{ background: "#1e2025", border: "1px solid #34373e", borderRadius: 6, fontSize: 12 }} />
                  </PieChart>
                </ResponsiveContainer>
              ) : <div className="flex size-full items-center justify-center rounded-full border border-dashed border-line text-[11px] text-fg-subtle">sem dados</div>}
            </div>
            <ul className="flex flex-1 flex-col gap-2.5 text-[13px]">
              {(d?.operations ?? []).map((x, i) => (
                <li key={x.label} className="flex items-center justify-between gap-2 text-fg-muted">
                  <span className="flex items-center gap-2"><span className="size-2 rounded-full" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />{x.label}</span>
                  <span className="font-semibold text-fg">{total ? Math.round((x.count * 100) / total) : 0}%</span>
                </li>
              ))}
            </ul>
          </div>
        </Card>
      </div>

      <Card className="overflow-x-auto">
        <CardHeader title="Relatórios Gerados" className="!pb-3" />
        <DataTable
          className="rounded-none border-x-0 border-b-0"
          rows={gen.data}
          rowKey={(g) => g.id}
          empty={<EmptyState icon={FileText} title="Nenhum relatório gerado" text="Use “Exportar Relatório” para gerar PDF ou CSV; os arquivos ficam guardados aqui." />}
          columns={[
            { key: "title", header: "Relatório", width: "2fr", render: (g) => <span className="font-medium">{g.title}</span> },
            { key: "period", header: "Período", width: "1.4fr", render: (g) => <span className="text-fg-muted">{g.periodLabel.replace(/(\d{4})-(\d{2})-(\d{2})/g, "$3/$2/$1")}</span> },
            { key: "at", header: "Gerado em", width: "1fr", render: (g) => <span className="text-fg-muted">{formatDate(g.createdAt)}</span> },
            { key: "fmt", header: "Formato", width: ".7fr", render: (g) => <span className="text-xs font-semibold text-fg-muted">{g.format.toUpperCase()}</span> },
            { key: "dl", header: "", width: "60px", render: (g) => <button aria-label={`Baixar ${g.title}`} onClick={() => downloadAttachment(g.attachmentId, g.fileName)} className="flex size-9 cursor-pointer items-center justify-center text-fg-subtle hover:text-fg"><Download size={16} /></button> },
          ]}
        />
      </Card>

      {exportOpen && <ExportModal period={period} onClose={() => setExportOpen(false)} onDone={() => { gen.reload(); }} />}
    </div>
  );
}

function ExportModal({ period, onClose, onDone }: { period: Period; onClose: () => void; onDone: () => void }) {
  const types = useApi(() => api.reportTypes(), []);
  const [type, setType] = useState("cashflow");
  const [format, setFormat] = useState<"pdf" | "csv">("pdf");
  const [busy, setBusy] = useState(false);
  const preview = useApi(() => api.reportPreview(type, period), [type, JSON.stringify(period)]);

  async function go() {
    setBusy(true);
    try {
      const g = await api.reportExport(type, period, format);
      onDone();
      if (!isDesktop) {
        await downloadAttachment(g.attachmentId, g.fileName);
        onClose();
        return;
      }
      const path = await save({ defaultPath: g.fileName, filters: [{ name: format.toUpperCase(), extensions: [format] }] });
      if (path) { await api.attachmentSaveTo(g.attachmentId, path); toast.success(`Relatório salvo em ${path}`); } else toast.success("Relatório gerado e guardado em Relatórios Gerados.");
      onClose();
    } catch (e) { toast.error(e); } finally { setBusy(false); }
  }

  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title="Exportar relatório" description="O período é o selecionado na tela. Exportações ficam registradas na auditoria." width={760}
      footer={<><Button variant="outline" onClick={onClose} disabled={busy}>Fechar</Button><Button onClick={go} disabled={busy || !preview.data}>{busy ? <LoaderCircle size={14} className="animate-spin" /> : format === "pdf" ? <FileText size={14} /> : <FileSpreadsheet size={14} />} Gerar {format.toUpperCase()}</Button></>}>
      <div className="flex flex-col gap-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <SelectInput label="Relatório" value={type} onChange={setType} options={(types.data ?? []).map((t) => ({ value: t.code, label: t.label }))} />
          <SelectInput label="Formato" value={format} onChange={(v) => setFormat(v as "pdf" | "csv")} options={[{ value: "pdf", label: "PDF" }, { value: "csv", label: "CSV (Excel, separador ;)" }]} />
        </div>
        {preview.error && <ErrorNotice message={preview.error} />}
        {preview.data && (
          <div className="flex flex-col gap-2">
            {preview.data.summary.length > 0 && <div className="flex flex-wrap gap-x-6 gap-y-1 text-[13px]">{preview.data.summary.map(([k, v]) => <span key={k} className="text-fg-muted">{k}: <strong className="text-fg">{v}</strong></span>)}</div>}
            <div className="max-h-[260px] overflow-auto rounded-sm border border-line">
              <table className="w-full text-left text-xs">
                <thead className="sticky top-0 bg-app text-fg-muted"><tr>{preview.data.columns.map((c) => <th key={c} className="px-3 py-2 font-medium whitespace-nowrap">{c}</th>)}</tr></thead>
                <tbody>{preview.data.rows.slice(0, 50).map((r, i) => <tr key={i} className="border-t border-line">{r.map((c, j) => <td key={j} className="px-3 py-2 whitespace-nowrap text-fg-muted">{c}</td>)}</tr>)}</tbody>
              </table>
              {preview.data.rows.length === 0 && <p className="px-4 py-6 text-center text-[13px] text-fg-muted">Sem registros no período.</p>}
            </div>
            <p className="text-[11px] text-fg-subtle">{preview.data.total} registro(s){preview.data.total > 50 ? " — pré-visualização limitada às 50 primeiras linhas; o arquivo contém todos." : ""}</p>
          </div>
        )}
      </div>
    </FormModal>
  );
}
