import { useState } from "react";
import { Ban, FileText, LoaderCircle, Minus, Plus, ReceiptText, ShoppingCart, Undo2, X } from "lucide-react";
import { usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi, useDebounced } from "@/hooks/useApi";
import { api } from "@/services/api";
import type { ClientOption, PaymentMethod, ProductRow, SaleRow } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card, EmptyState, ErrorNotice, Mono, SearchInput, Segmented } from "@/components/ui/layout";
import { StatusBadge } from "@/components/ui/badge";
import { ConfirmDialog, FormModal } from "@/components/ui/dialog";
import { MoneyInput, TextInput } from "@/components/ui/form";
import { ClientPicker } from "@/components/ClientPicker";
import { DocumentPreview } from "@/components/DocumentViewer";
import { DataTable, Pagination, type Column } from "@/components/ui/data-table";
import { RowMenu } from "@/components/RowMenu";
import { toast } from "@/components/ui/toast";
import { METHOD_LABELS, formatBRL, formatDateTime } from "@/lib/format";
import { productIcon } from "@/modules/products/ProductsPage";
import { cn } from "@/lib/utils";

interface CartLine { product: ProductRow; qty: number }
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random()));

export function SalesPage() {
  usePageHeader(null);
  const can = useAuth((s) => s.can);
  const [view, setView] = useState<"pos" | "history">(can("sales.manage") ? "pos" : "history");
  return (
    <div className="flex min-h-full flex-col gap-5">
      <Segmented value={view} onChange={setView} items={[...(can("sales.manage") ? [{ value: "pos" as const, label: "Nova venda" }] : []), { value: "history" as const, label: "Histórico de vendas" }]} className="self-start" />
      {view === "pos" ? <Pos /> : <History />}
    </div>
  );
}

function Pos() {
  const [search, setSearch] = useState("");
  const dq = useDebounced(search);
  const products = useApi(() => api.products({ pageSize: 60, search: dq || undefined }), [dq]);
  const [cart, setCart] = useState<CartLine[]>([]);
  const [client, setClient] = useState<ClientOption | null>(null);
  const [discount, setDiscount] = useState<number | null>(null);
  const [method, setMethod] = useState<PaymentMethod>("pix");
  const [busy, setBusy] = useState(false);
  const [key, setKey] = useState(uid);
  const [receipt, setReceipt] = useState<number | null>(null);

  const subtotal = cart.reduce((s, l) => s + l.product.priceCents * l.qty, 0);
  const disc = Math.min(discount ?? 0, subtotal);
  const total = subtotal - disc;

  function add(p: ProductRow) {
    if (p.availableQty <= 0 || !p.active) return;
    setCart((c) => {
      const i = c.findIndex((l) => l.product.id === p.id);
      if (i >= 0) return c.map((l, j) => (j === i ? { ...l, qty: Math.min(l.qty + 1, p.availableQty) } : l));
      return [...c, { product: p, qty: 1 }];
    });
  }
  const setQty = (id: number, d: number) => setCart((c) => c.flatMap((l) => (l.product.id !== id ? [l] : l.qty + d <= 0 ? [] : [{ ...l, qty: Math.min(l.qty + d, l.product.availableQty) }])));

  async function finish() {
    setBusy(true);
    try {
      const r = await api.saleCreate({ clientId: client?.id ?? null, items: cart.map((l) => ({ productId: l.product.id, qty: l.qty })), discountCents: disc, paymentMethod: method, idempotencyKey: key });
      toast.success(`Venda ${r.code} finalizada.`);
      try { const a = await api.saleReceipt(r.id); setReceipt(a.id); } catch { /* comprovante é opcional */ }
      setCart([]); setDiscount(null); setClient(null); setKey(uid()); products.reload();
    } catch (e) { toast.error(e); } finally { setBusy(false); }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_380px] items-start gap-5">
      <div className="flex min-w-0 flex-col gap-4">
        <SearchInput value={search} onChange={setSearch} placeholder="Buscar produto por nome ou código..." />
        {products.error && <ErrorNotice message={products.error} onRetry={products.reload} />}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4">
          {(products.data?.items ?? []).filter((p) => p.active).map((p) => {
            const Icon = productIcon(p);
            const out = p.availableQty <= 0;
            return (
              <div key={p.id} className={cn("flex min-h-[148px] flex-col gap-2 rounded-md border border-line bg-surface p-3 sm:min-h-[170px] sm:gap-3 sm:p-4", out && "opacity-50")}>
                <div className="flex h-12 items-center justify-center text-fg-muted sm:h-[72px]"><Icon size={26} /></div>
                <div className="min-w-0">
                  <p className="truncate text-[13px] font-medium text-fg">{p.name}</p>
                  <p className="text-[11px] text-fg-subtle">{out ? "Sem estoque" : `${p.availableQty} disponível(is)`}</p>
                </div>
                <div className="mt-auto flex items-center justify-between">
                  <Mono className="font-semibold text-fg">{formatBRL(p.priceCents)}</Mono>
                  <button aria-label={`Adicionar ${p.name}`} disabled={out} onClick={() => add(p)} className="flex size-10 cursor-pointer items-center justify-center rounded-full bg-silver sm:size-7 text-on-silver hover:bg-silver-bright disabled:cursor-not-allowed"><Plus size={14} /></button>
                </div>
              </div>
            );
          })}
        </div>
        {products.data && products.data.items.length === 0 && <EmptyState icon={ShoppingCart} title="Nenhum produto encontrado" text="Cadastre produtos ou registre compras para vendê-los." />}
        {cart.length > 0 && (
          <button type="button" onClick={() => document.getElementById("cart")?.scrollIntoView({ behavior: "smooth", block: "start" })}
            className="sticky bottom-0 z-10 flex cursor-pointer items-center justify-between gap-3 rounded-full bg-gradient-to-b from-gold-bright to-gold px-5 py-3.5 text-sm font-semibold text-on-gold shadow-lg lg:hidden">
            <span className="flex items-center gap-2"><ShoppingCart size={16} /> {cart.reduce((n, l) => n + l.qty, 0)} item(ns) · ver carrinho</span>
            <Mono className="font-bold text-on-gold">{formatBRL(total)}</Mono>
          </button>
        )}
      </div>

      <Card id="cart" className="scroll-mt-2 overflow-hidden lg:sticky lg:top-0">
        <div className="flex items-center gap-2.5 border-b border-line px-5 py-4"><ShoppingCart size={16} className="text-fg-muted" /><h3 className="font-heading text-[15px] font-semibold text-fg">Carrinho</h3></div>
        <div className="flex flex-col gap-4 p-5">
          <ClientPicker label="Cliente" value={client} onChange={setClient} allowEmpty />
          {!client && <p className="-mt-2 text-xs text-fg-subtle">Venda como Consumidor final.</p>}
          <div className="flex min-h-[120px] flex-col gap-3">
            {cart.length === 0 && <p className="py-8 text-center text-[13px] text-fg-muted">Adicione produtos ao carrinho.</p>}
            {cart.map((l) => {
              const Icon = productIcon(l.product);
              return (
                <div key={l.product.id} className="flex items-center gap-3 border-b border-line pb-3 last:border-b-0">
                  <span className="flex size-9 shrink-0 items-center justify-center text-fg-muted"><Icon size={15} /></span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-medium text-fg">{l.product.name}</p>
                    <div className="flex items-center gap-1.5 pt-0.5 text-xs text-fg-subtle">
                      <button aria-label="Diminuir" onClick={() => setQty(l.product.id, -1)} className="cursor-pointer rounded-sm p-2 hover:bg-surface-hover sm:p-0.5"><Minus size={11} /></button>
                      {l.qty}x
                      <button aria-label="Aumentar" onClick={() => setQty(l.product.id, 1)} className="cursor-pointer rounded-sm p-2 hover:bg-surface-hover sm:p-0.5"><Plus size={11} /></button>
                    </div>
                  </div>
                  <Mono className="font-semibold">{formatBRL(l.product.priceCents * l.qty)}</Mono>
                  <button aria-label="Remover" onClick={() => setCart((c) => c.filter((x) => x.product.id !== l.product.id))} className="cursor-pointer p-2 text-fg-subtle hover:text-fg"><X size={14} /></button>
                </div>
              );
            })}
          </div>
          <div className="flex flex-col gap-2.5 border-t border-line pt-4 text-[13px]">
            <div className="flex justify-between text-fg-muted"><span>Subtotal</span><Mono>{formatBRL(subtotal)}</Mono></div>
            <MoneyInput label="Desconto (R$)" cents={discount} onChange={setDiscount} hint="Acima do limite configurado exige autorização de gerente." />
            <div className="flex items-end justify-between pt-1"><span className="text-base font-semibold text-fg">Total</span><Mono className="text-xl font-bold text-fg">{formatBRL(total)}</Mono></div>
          </div>
          <div>
            <p className="pb-2 text-xs text-fg-muted">Forma de pagamento</p>
            <div role="radiogroup" className="grid grid-cols-3 gap-2">
              {(Object.keys(METHOD_LABELS) as PaymentMethod[]).map((m) => (
                <button key={m} role="radio" aria-checked={method === m} onClick={() => setMethod(m)} className={cn("cursor-pointer rounded-sm border px-2 py-2 text-[12px] font-semibold", method === m ? "border-silver bg-silver text-on-silver" : "border-line-strong text-fg hover:bg-surface-hover")}>{METHOD_LABELS[m]}</button>
              ))}
            </div>
          </div>
          <Button className="w-full" disabled={cart.length === 0 || busy} onClick={finish}>{busy && <LoaderCircle size={14} className="animate-spin" />}Finalizar Venda</Button>
        </div>
      </Card>

      <FormModal open={receipt !== null} onOpenChange={(o) => !o && setReceipt(null)} title="Comprovante da venda" width={820}>
        <DocumentPreview attachmentId={receipt} className="h-[66vh]" />
      </FormModal>
    </div>
  );
}

function History() {
  const can = useAuth((s) => s.can);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const dq = useDebounced(search);
  const list = useApi(() => api.sales({ page, pageSize: 8, search: dq || undefined }), [page, dq]);
  const [cancel, setCancel] = useState<SaleRow | null>(null);
  const [ret, setRet] = useState<SaleRow | null>(null);
  const [receipt, setReceipt] = useState<number | null>(null);

  async function showReceipt(s: SaleRow) {
    try { setReceipt((await api.saleReceipt(s.id)).id); } catch (e) { toast.error(e); }
  }

  const columns: Column<SaleRow>[] = [
    { key: "code", header: "Código", width: ".8fr", render: (s) => <Mono className="font-semibold">{s.code}</Mono> },
    { key: "date", header: "Data", width: "1.1fr", render: (s) => <span className="text-fg-muted">{formatDateTime(s.createdAt)}</span> },
    { key: "client", header: "Cliente", width: "1.6fr", render: (s) => <span>{s.clientName ?? "Consumidor final"}</span> },
    { key: "total", header: "Total", width: "1fr", render: (s) => <Mono className="font-semibold">{formatBRL(s.totalCents)}</Mono> },
    { key: "pay", header: "Pagamento", width: "1fr", render: (s) => <span className="text-fg-muted">{METHOD_LABELS[s.paymentMethod]}</span> },
    { key: "status", header: "Status", width: "1.2fr", render: (s) => <StatusBadge status={s.status} /> },
    {
      key: "act", header: "", width: "50px",
      render: (s) => (
        <RowMenu actions={[
          { label: "Comprovante (PDF)", icon: ReceiptText, onSelect: () => showReceipt(s) },
          { label: "Devolução de itens", icon: Undo2, hidden: !can("sales.cancel") || s.status === "cancelled", onSelect: () => setRet(s) },
          { label: "Cancelar venda", icon: Ban, destructive: true, hidden: !can("sales.cancel") || s.status === "cancelled", onSelect: () => setCancel(s) },
        ]} />
      ),
    },
  ];
  return (
    <div className="flex flex-col gap-4">
      <SearchInput value={search} onChange={(v) => { setSearch(v); setPage(1); }} placeholder="Buscar por cliente ou código..." className="w-full sm:w-[280px]" />
      <DataTable columns={columns} rows={list.data?.items} rowKey={(s) => s.id} loading={list.loading} minBodyHeight={360}
        empty={<EmptyState icon={FileText} title="Nenhuma venda registrada" />}
        footer={list.data && <Pagination page={list.data.page} pageSize={list.data.pageSize} total={list.data.total} onPage={setPage} noun="vendas" />} />
      {cancel && <ConfirmDialog open onOpenChange={(o) => !o && setCancel(null)} title={`Cancelar ${cancel.code}`} destructive confirmLabel="Cancelar venda" reasonLabel="Motivo do cancelamento" description="Os itens voltam ao estoque e o pagamento é estornado (o histórico financeiro é preservado)." onConfirm={async (r) => { await api.saleCancel(cancel.id, r); list.reload(); }} successMessage="Venda cancelada." />}
      {ret && <ReturnModal sale={ret} onClose={() => setRet(null)} onDone={() => { setRet(null); list.reload(); }} />}
      <FormModal open={receipt !== null} onOpenChange={(o) => !o && setReceipt(null)} title="Comprovante da venda" width={820}>
        <DocumentPreview attachmentId={receipt} className="h-[66vh]" />
      </FormModal>
    </div>
  );
}

function ReturnModal({ sale, onClose, onDone }: { sale: SaleRow; onClose: () => void; onDone: () => void }) {
  const q = useApi(() => api.sale(sale.id), [sale.id]);
  const [item, setItem] = useState<number | null>(null);
  const [qty, setQty] = useState("1");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const items = q.data?.items.filter((i) => i.qty - i.returnedQty > 0) ?? [];
  async function go() {
    setBusy(true);
    try { const v = await api.saleReturnItem(sale.id, item!, Number(qty), reason); toast.success(`Devolução registrada. Reembolso: ${formatBRL(v)}.`); onDone(); } catch (e) { toast.error(e); } finally { setBusy(false); }
  }
  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title={`Devolução — ${sale.code}`} width={480}
      footer={<><Button variant="outline" onClick={onClose} disabled={busy}>Cancelar</Button><Button onClick={go} disabled={busy || !item || Number(qty) < 1 || reason.trim().length < 3}>Registrar devolução</Button></>}>
      <div className="flex flex-col gap-4">
        <div className="flex flex-col gap-2">
          {items.map((i) => (
            <button key={i.id} onClick={() => { setItem(i.id); setQty("1"); }} className={cn("flex cursor-pointer items-center justify-between rounded-sm border px-4 py-3 text-left text-[13px]", item === i.id ? "border-silver bg-surface-hover" : "border-line hover:bg-surface-hover/50")}>
              <span>{i.productName}<span className="block text-xs text-fg-subtle">{i.qty - i.returnedQty} de {i.qty} devolvível(is)</span></span>
              <Mono>{formatBRL(i.unitPriceCents)}</Mono>
            </button>
          ))}
          {items.length === 0 && <p className="text-[13px] text-fg-muted">Todos os itens já foram devolvidos.</p>}
        </div>
        <TextInput label="Quantidade a devolver" type="number" min={1} value={qty} onChange={setQty} />
        <TextInput label="Motivo" required value={reason} onChange={setReason} hint="O reembolso é proporcional, já considerando o desconto rateado." />
      </div>
    </FormModal>
  );
}
