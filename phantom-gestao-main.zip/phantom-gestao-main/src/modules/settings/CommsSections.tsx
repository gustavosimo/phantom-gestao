import { useEffect, useState } from "react";
import { BadgeCheck, FilePlus2, Pencil, Plug } from "lucide-react";
import { useApi } from "@/hooks/useApi";
import { useAuth } from "@/app/auth-store";
import { api } from "@/services/api";
import type { IntegrationStatus, MessageTemplate, NotificationConfig, TemplateRow } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, ErrorNotice, Notice } from "@/components/ui/layout";
import { Badge } from "@/components/ui/badge";
import { FormModal } from "@/components/ui/dialog";
import { SelectInput, TextArea, TextInput, Toggle } from "@/components/ui/form";
import { toast } from "@/components/ui/toast";
import { formatDate } from "@/lib/format";

export function NotificationsSection() {
  const can = useAuth((s) => s.can);
  const st = useApi(() => api.settings(), []);
  const tpl = useApi(() => api.messageTemplates(), []);
  const editable = can("settings.manage");
  const [c, setC] = useState<NotificationConfig | null>(null);
  const [busy, setBusy] = useState(false);
  const [edit, setEdit] = useState<MessageTemplate | null>(null);

  useEffect(() => {
    const d = st.data;
    if (!d) return;
    setC({
      whatsapp3dBefore: d["collections.whatsapp_3d_before"] === "true", emailOnDue: d["collections.email_on_due"] === "true", callAfter5d: d["collections.call_after_5d"] === "true",
      quietStartHour: Number(d["collections.quiet_start_hour"]), quietEndHour: Number(d["collections.quiet_end_hour"]), allowSunday: d["collections.allow_sunday"] === "true",
      maxPerClientDay: Number(d["collections.max_per_client_day"]), maxPerClientWeek: Number(d["collections.max_per_client_week"]),
      dueSoonDays: Number(d["notifications.due_soon_days"]), collateralDays: Number(d["notifications.collateral_days"]),
    });
  }, [st.data]);

  if (!c) return null;
  const num = (k: keyof NotificationConfig) => (v: string) => setC((x) => (x ? { ...x, [k]: Number(v) } : x));
  const bool = (k: keyof NotificationConfig) => (v: boolean) => setC((x) => (x ? { ...x, [k]: v } : x));

  async function save() {
    setBusy(true);
    try { await api.saveNotificationConfig(c!); toast.success("Configuração de notificações salva."); st.reload(); } catch (e) { toast.error(e); } finally { setBusy(false); }
  }

  return (
    <div className="flex flex-col gap-5">
      <Card>
        <CardHeader title="Regras de Notificação e Cobrança" subtitle="Automação baseada em regras e agendamento (sem IA)" />
        <div className="flex flex-col gap-5 border-t border-line px-6 py-5">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
            <TextInput label="Antecedência de vencimentos (dias)" type="number" min={1} value={String(c.dueSoonDays)} onChange={num("dueSoonDays")} disabled={!editable} />
            <TextInput label="Alerta de prazo de garantias (dias)" type="number" min={1} value={String(c.collateralDays)} onChange={num("collateralDays")} disabled={!editable} />
          </div>
          <h4 className="text-[13px] font-semibold text-fg">Lembretes automáticos (geram tarefas para a equipe)</h4>
          <div className="flex flex-col gap-3">
            {([["whatsapp3dBefore", "WhatsApp 3 dias antes do vencimento"], ["emailOnDue", "E-mail no dia do vencimento"], ["callAfter5d", "Ligação após 5 dias de atraso"]] as const).map(([k, label]) => (
              <div key={k} className="flex items-center justify-between rounded-sm border border-line px-4 py-3"><span className="text-[13px] text-fg">{label}</span><Toggle label={label} checked={c[k]} onChange={bool(k)} disabled={!editable} /></div>
            ))}
          </div>
          <h4 className="text-[13px] font-semibold text-fg">Cobrança não abusiva (LGPD)</h4>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
            <TextInput label="Contato a partir das (h)" type="number" min={0} max={23} value={String(c.quietStartHour)} onChange={num("quietStartHour")} disabled={!editable} />
            <TextInput label="Contato até as (h)" type="number" min={1} max={24} value={String(c.quietEndHour)} onChange={num("quietEndHour")} disabled={!editable} />
            <TextInput label="Máx. contatos/dia" type="number" min={1} value={String(c.maxPerClientDay)} onChange={num("maxPerClientDay")} disabled={!editable} />
            <TextInput label="Máx. contatos/semana" type="number" min={1} value={String(c.maxPerClientWeek)} onChange={num("maxPerClientWeek")} disabled={!editable} />
          </div>
          <div className="flex items-center justify-between rounded-sm border border-line px-4 py-3"><span className="text-[13px] text-fg">Permitir contatos aos domingos</span><Toggle label="Permitir contatos aos domingos" checked={c.allowSunday} onChange={bool("allowSunday")} disabled={!editable} /></div>
        </div>
        {editable && <div className="flex justify-end gap-3 border-t border-line px-6 py-4"><Button variant="outline" onClick={() => st.reload()} disabled={busy}>Cancelar</Button><Button onClick={save} disabled={busy}>Salvar</Button></div>}
      </Card>

      <Card>
        <CardHeader title="Modelos de mensagem" subtitle="Variáveis: {nome} {parcela} {contrato} {valor} {vencimento}" />
        {(tpl.data ?? []).map((t) => (
          <div key={t.id} className="flex items-start justify-between gap-4 border-t border-line px-6 py-4">
            <div className="min-w-0">
              <p className="flex items-center gap-2 text-[13px] font-medium text-fg">{t.name}<Badge>{t.channel === "email" ? "E-mail" : "WhatsApp"}</Badge>{!t.active && <Badge tone="warning">Inativo</Badge>}</p>
              <p className="pt-1 text-xs leading-relaxed text-fg-muted">{t.body}</p>
            </div>
            {editable && <Button variant="ghost" size="icon" aria-label={`Editar ${t.name}`} onClick={() => setEdit(t)}><Pencil size={14} /></Button>}
          </div>
        ))}
      </Card>
      {edit && <TemplateEditor t={edit} onClose={() => setEdit(null)} onDone={() => { setEdit(null); tpl.reload(); }} />}
    </div>
  );
}

function TemplateEditor({ t, onClose, onDone }: { t: MessageTemplate; onClose: () => void; onDone: () => void }) {
  const [body, setBody] = useState(t.body);
  const [active, setActive] = useState(t.active);
  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title={t.name} width={520}
      footer={<><Button variant="outline" onClick={onClose}>Cancelar</Button><Button onClick={async () => { try { await api.messageTemplateSave(t.id, body, active); toast.success("Modelo salvo."); onDone(); } catch (e) { toast.error(e); } }}>Salvar</Button></>}>
      <div className="flex flex-col gap-4">
        <TextArea label="Mensagem" value={body} onChange={setBody} rows={5} hint="Use {nome}, {parcela}, {contrato}, {valor} e {vencimento}." />
        <div className="flex items-center justify-between"><span className="text-[13px] text-fg">Modelo ativo</span><Toggle label="Modelo ativo" checked={active} onChange={setActive} /></div>
      </div>
    </FormModal>
  );
}

const KIND_LABEL: Record<string, string> = { loan: "Empréstimo", collateral: "Garantia", sale: "Venda", purchase: "Compra" };

export function DocumentsSection() {
  const can = useAuth((s) => s.can);
  const list = useApi(() => api.templates(), []);
  const [edit, setEdit] = useState<TemplateRow | "new" | null>(null);
  const [approve, setApprove] = useState<TemplateRow | null>(null);

  return (
    <Card>
      <CardHeader title="Modelos de Contrato" subtitle="Cada alteração gera nova versão e exige nova aprovação do responsável jurídico antes do uso." right={can("contracts.manage") && <Button size="sm" onClick={() => setEdit("new")}><FilePlus2 size={14} /> Novo modelo</Button>} />
      <div className="px-6 pb-4"><Notice tone="warning">Os modelos iniciais são <strong>minutas sem validade jurídica</strong> (placeholders). Contratos só podem ser gerados com modelos aprovados.</Notice></div>
      {list.error && <div className="px-6 pb-4"><ErrorNotice message={list.error} onRetry={list.reload} /></div>}
      {(list.data ?? []).map((t) => (
        <div key={t.id} className="flex items-center justify-between gap-4 border-t border-line px-6 py-4">
          <div className="min-w-0">
            <p className="flex items-center gap-2 text-[13px] font-medium text-fg">{t.name}<Badge>{KIND_LABEL[t.kind]}</Badge>{t.legalStatus === "approved" ? <Badge tone="success">Aprovado</Badge> : <Badge tone="warning">Rascunho</Badge>}{!t.active && <Badge>Inativo</Badge>}</p>
            <p className="pt-1 text-xs text-fg-subtle">Versão {t.version} · {t.legalStatus === "approved" ? `aprovado por ${t.approvedBy} em ${formatDate(t.approvedAt)}` : "aguardando aprovação jurídica"}</p>
          </div>
          <div className="flex shrink-0 gap-2">
            {can("contracts.manage") && <Button size="sm" variant="outline" onClick={() => setEdit(t)}><Pencil size={13} /> Editar</Button>}
            {can("contracts.legal") && t.legalStatus !== "approved" && <Button size="sm" onClick={() => setApprove(t)}><BadgeCheck size={13} /> Aprovar</Button>}
          </div>
        </div>
      ))}
      {edit && <TemplateModal t={edit === "new" ? null : edit} onClose={() => setEdit(null)} onDone={() => { setEdit(null); list.reload(); }} />}
      {approve && <ApproveModal t={approve} onClose={() => setApprove(null)} onDone={() => { setApprove(null); list.reload(); }} />}
    </Card>
  );
}

function TemplateModal({ t, onClose, onDone }: { t: TemplateRow | null; onClose: () => void; onDone: () => void }) {
  const [name, setName] = useState(t?.name ?? "");
  const [kind, setKind] = useState<string>(t?.kind ?? "loan");
  const [body, setBody] = useState(t?.body ?? "");
  const [active, setActive] = useState(t?.active ?? true);
  const [busy, setBusy] = useState(false);
  async function go() {
    setBusy(true);
    try { await api.templateSave({ id: t?.id, kind, name, body, active }); toast.success(t && body !== t.body ? "Nova versão salva — requer nova aprovação jurídica." : "Modelo salvo."); onDone(); } catch (e) { toast.error(e); } finally { setBusy(false); }
  }
  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title={t ? `Editar modelo (v${t.version})` : "Novo modelo"} width={720}
      description="Linhas iniciadas com “# ” viram título e “## ” subtítulo no PDF. Use {variaveis} entre chaves."
      footer={<><Button variant="outline" onClick={onClose} disabled={busy}>Cancelar</Button><Button onClick={go} disabled={busy || name.trim().length < 3 || body.trim().length < 10}>Salvar</Button></>}>
      <div className="flex flex-col gap-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <TextInput label="Nome" required value={name} onChange={setName} />
          <SelectInput label="Tipo" value={kind} onChange={setKind} options={Object.entries(KIND_LABEL).map(([value, label]) => ({ value, label }))} />
        </div>
        <TextArea label="Texto do modelo" required value={body} onChange={setBody} rows={14} />
        <div className="flex items-center justify-between"><span className="text-[13px] text-fg">Modelo ativo</span><Toggle label="Modelo ativo" checked={active} onChange={setActive} /></div>
        <p className="text-[11px] leading-relaxed text-fg-subtle">Variáveis: {"{empresa} {empresa_documento} {cliente_nome} {cliente_documento} {cliente_endereco} {contrato_numero} {data} {valor} {prazo} {taxa_mensal} {cet_anual} {parcela} {total_pagar} {primeiro_vencimento} {emprestimo_numero} {garantia_codigo} {bem_descricao} {bem_serie} {bem_condicao} {bem_avaliacao} {local_custodia} {prazo_custodia} {venda_codigo} {compra_codigo} {produto} {vendedor_nome}"}</p>
      </div>
    </FormModal>
  );
}

function ApproveModal({ t, onClose, onDone }: { t: TemplateRow; onClose: () => void; onDone: () => void }) {
  const [who, setWho] = useState("");
  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title="Aprovação jurídica do modelo" description={`${t.name} — versão ${t.version}`} width={460}
      footer={<><Button variant="outline" onClick={onClose}>Cancelar</Button><Button disabled={who.trim().length < 3} onClick={async () => { try { await api.templateApprove(t.id, who); toast.success("Modelo aprovado."); onDone(); } catch (e) { toast.error(e); } }}>Aprovar modelo</Button></>}>
      <div className="flex flex-col gap-4">
        <TextInput label="Responsável jurídico (nome e registro)" required value={who} onChange={setWho} placeholder="Ex.: Dra. Ana Souza — OAB/SP 000.000" />
        <Notice tone="info">Ao aprovar, você declara que o texto foi fornecido ou validado pelo responsável jurídico. O aceite é registrado na auditoria.</Notice>
      </div>
    </FormModal>
  );
}

const INTEGRATION_META: Record<string, { title: string; desc: string; fields: { key: string; label: string }[]; secretLabel: string }> = {
  whatsapp: { title: "WhatsApp Business API", desc: "Envio de lembretes e cobranças por WhatsApp.", fields: [{ key: "phone_id", label: "ID do número de telefone" }], secretLabel: "Token de acesso" },
  email: { title: "E-mail (SMTP)", desc: "Envio de e-mails de cobrança e avisos.", fields: [{ key: "host", label: "Servidor SMTP" }, { key: "port", label: "Porta" }, { key: "user", label: "Usuário" }], secretLabel: "Senha" },
  fiscal: { title: "Integração fiscal", desc: "Emissão de documentos fiscais conforme as obrigações da empresa.", fields: [{ key: "regime", label: "Regime tributário" }, { key: "provider", label: "Provedor de emissão" }], secretLabel: "Chave/token do provedor" },
};

export function IntegrationsSection() {
  const can = useAuth((s) => s.can);
  const q = useApi(() => api.integrations(), []);
  return (
    <div className="flex flex-col gap-5">
      <Notice tone="info" icon={Plug}>As integrações estão <strong>preparadas</strong> (configuração e armazenamento seguro de credenciais), mas nenhum conector de envio/emissão está ativo nesta versão. Os contatos de cobrança continuam sendo registrados manualmente.</Notice>
      {q.error && <ErrorNotice message={q.error} onRetry={q.reload} />}
      {(q.data ?? []).map((i) => <IntegrationCard key={i.name} i={i} editable={can("settings.manage")} onSaved={q.reload} />)}
    </div>
  );
}

function IntegrationCard({ i, editable, onSaved }: { i: IntegrationStatus; editable: boolean; onSaved: () => void }) {
  const meta = INTEGRATION_META[i.name];
  const [fields, setFields] = useState(i.fields);
  const [secret, setSecret] = useState("");
  const [enabled, setEnabled] = useState(i.enabled);
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try { await api.integrationSave({ name: i.name, enabled, fields, secret: secret || undefined }); toast.success("Integração salva. Credenciais armazenadas cifradas."); setSecret(""); onSaved(); } catch (e) { toast.error(e); } finally { setBusy(false); }
  }
  return (
    <Card>
      <CardHeader title={meta.title} subtitle={meta.desc} right={<div className="flex items-center gap-3"><Badge tone="neutral">Conector indisponível</Badge><Toggle label={`Ativar ${meta.title}`} checked={enabled} onChange={setEnabled} disabled={!editable} /></div>} />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 border-t border-line px-6 py-5">
        {meta.fields.map((f) => <TextInput key={f.key} label={f.label} value={fields[f.key] ?? ""} onChange={(v) => setFields((x) => ({ ...x, [f.key]: v }))} disabled={!editable} />)}
        <TextInput label={meta.secretLabel} type="password" value={secret} onChange={setSecret} disabled={!editable} placeholder={i.secretConfigured ? "•••••••• (configurado — preencha para substituir)" : ""} hint="Gravado cifrado; nunca é exibido." />
      </div>
      {editable && <div className="flex justify-end border-t border-line px-6 py-4"><Button variant="outline" onClick={save} disabled={busy}>Salvar integração</Button></div>}
    </Card>
  );
}
