import { useEffect, useState } from "react";
import { useApi } from "@/hooks/useApi";
import { useAuth } from "@/app/auth-store";
import { api } from "@/services/api";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, Notice } from "@/components/ui/layout";
import { SelectInput, TextInput } from "@/components/ui/form";
import { LogoMark } from "@/components/Logo";
import { Wordmark } from "@/components/Wordmark";
import { toast } from "@/components/ui/toast";
import { maskCpfCnpj, maskPhone, setDateFormat } from "@/lib/format";

const TZ = [
  { value: "-2", label: "Fernando de Noronha (GMT-2)" },
  { value: "-3", label: "Brasília (GMT-3)" },
  { value: "-4", label: "Manaus (GMT-4)" },
  { value: "-5", label: "Rio Branco (GMT-5)" },
];

export function CompanySection() {
  const can = useAuth((s) => s.can);
  const st = useApi(() => api.settings(), []);
  const [f, setF] = useState({ name: "", document: "", email: "", phone: "", address: "" });
  const [reg, setReg] = useState({ dateFormat: "DD/MM/AAAA", tz: "-3" });
  const [busy, setBusy] = useState(false);
  const [busy2, setBusy2] = useState(false);
  const editable = can("settings.manage");

  useEffect(() => {
    const d = st.data;
    if (!d) return;
    setF({ name: d["company.name"] ?? "", document: d["company.document"] ?? "", email: d["company.email"] ?? "", phone: d["company.phone"] ?? "", address: d["company.address"] ?? "" });
    setReg({ dateFormat: d["regional.date_format"] ?? "DD/MM/AAAA", tz: d["regional.tz_offset_hours"] ?? "-3" });
  }, [st.data]);

  const set = (k: keyof typeof f) => (v: string) => setF((x) => ({ ...x, [k]: v }));

  async function save() {
    setBusy(true);
    try { await api.saveCompany(f); toast.success("Dados da empresa salvos."); st.reload(); } catch (e) { toast.error(e); } finally { setBusy(false); }
  }
  async function saveRegional() {
    setBusy2(true);
    try { await api.saveRegional({ dateFormat: reg.dateFormat, tzOffsetHours: Number(reg.tz) }); setDateFormat(reg.dateFormat); toast.success("Preferências regionais salvas."); } catch (e) { toast.error(e); } finally { setBusy2(false); }
  }

  return (
    <div className="flex flex-col gap-5">
      <Card>
        <CardHeader title="Dados da Empresa" subtitle="Informações usadas em contratos, recibos e comunicações" className="!pb-5" />
        <div className="flex flex-col gap-5 border-t border-line px-6 py-6">
          <div className="flex items-center gap-4">
            <LogoMark size={56} />
            <div className="flex flex-col gap-2">
              <Wordmark />
              <p className="text-xs text-fg-muted">Identidade visual oficial — fixa, não alterável pelo sistema.</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <TextInput label="Razão social" value={f.name} onChange={set("name")} disabled={!editable} />
            <TextInput label="CNPJ" mono value={f.document} mask={(v) => maskCpfCnpj(v, "PJ")} onChange={set("document")} disabled={!editable} />
            <TextInput label="E-mail corporativo" type="email" value={f.email} onChange={set("email")} disabled={!editable} />
            <TextInput label="Telefone" value={f.phone} mask={maskPhone} onChange={set("phone")} disabled={!editable} />
          </div>
          <TextInput label="Endereço" value={f.address} onChange={set("address")} disabled={!editable} />
        </div>
        {editable ? (
          <div className="flex justify-end gap-3 border-t border-line px-6 py-4">
            <Button variant="outline" onClick={() => st.reload()} disabled={busy}>Cancelar</Button>
            <Button onClick={save} disabled={busy || f.name.trim().length < 2}>Salvar Alterações</Button>
          </div>
        ) : <div className="border-t border-line px-6 py-4"><Notice tone="info">Seu perfil permite apenas consulta.</Notice></div>}
      </Card>

      <Card>
        <CardHeader title="Preferências Regionais" className="!pb-4" />
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 px-6 pb-6">
          <SelectInput label="Moeda" value="BRL" onChange={() => {}} disabled options={[{ value: "BRL", label: "Real (R$)" }]} />
          <SelectInput label="Fuso horário" value={reg.tz} onChange={(v) => setReg((r) => ({ ...r, tz: v }))} disabled={!editable} options={TZ} />
          <SelectInput label="Formato de data" value={reg.dateFormat} onChange={(v) => setReg((r) => ({ ...r, dateFormat: v }))} disabled={!editable} options={[{ value: "DD/MM/AAAA", label: "DD/MM/AAAA" }, { value: "AAAA-MM-DD", label: "AAAA-MM-DD" }]} />
        </div>
        {editable && <div className="flex justify-end border-t border-line px-6 py-4"><Button variant="outline" onClick={saveRegional} disabled={busy2}>Salvar preferências</Button></div>}
      </Card>
    </div>
  );
}
