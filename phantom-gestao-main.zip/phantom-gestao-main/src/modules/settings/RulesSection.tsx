import { useEffect, useState } from "react";
import { Lock, ShieldAlert, ShieldCheck } from "lucide-react";
import { useApi } from "@/hooks/useApi";
import { useAuth } from "@/app/auth-store";
import { api } from "@/services/api";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, Notice } from "@/components/ui/layout";
import { Badge } from "@/components/ui/badge";
import { ConfirmDialog } from "@/components/ui/dialog";
import { MoneyInput, TextInput } from "@/components/ui/form";
import { toast } from "@/components/ui/toast";
import { formatBp, formatDateTime, parsePercentToBp } from "@/lib/format";

export function RulesSection() {
  const can = useAuth((s) => s.can);
  const st = useApi(() => api.settings(), []);
  const reg = useApi(() => api.regulatory(), []);
  const editable = can("settings.manage");
  const [f, setF] = useState({ rate: "", fee: "", iof: "", lateFee: "", mora: "", term: "", discount: "" });
  const [maxAmount, setMaxAmount] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [toggle, setToggle] = useState<null | { kind: "credit" | "collateral"; enable: boolean }>(null);

  useEffect(() => {
    const d = st.data;
    if (!d) return;
    const bp = (k: string) => formatBp(Number(d[k] ?? 0));
    setF({ rate: bp("loan.default_rate_bp"), fee: bp("loan.origination_fee_bp"), iof: bp("loan.iof_bp"), lateFee: bp("loan.late_fee_bp"), mora: bp("loan.late_interest_month_bp"), term: d["loan.max_term_months"] ?? "60", discount: d["sales.max_discount_pct"] ?? "10" });
    setMaxAmount(Number(d["loan.max_amount_cents"] ?? 0));
  }, [st.data]);

  const set = (k: keyof typeof f) => (v: string) => setF((x) => ({ ...x, [k]: v }));
  const err = (v: string) => (v && parsePercentToBp(v) === null ? "Valor inválido." : null);

  async function save() {
    const p = (v: string) => parsePercentToBp(v);
    if ([f.rate, f.fee, f.iof, f.lateFee, f.mora].some((v) => p(v) === null) || maxAmount === null) { toast.error("Revise os percentuais informados."); return; }
    setBusy(true);
    try {
      await api.saveFinancial({ defaultRateBp: p(f.rate)!, originationFeeBp: p(f.fee)!, iofBp: p(f.iof)!, lateFeeBp: p(f.lateFee)!, lateInterestMonthBp: p(f.mora)!, maxTermMonths: Number(f.term), maxAmountCents: maxAmount, maxDiscountPct: Number(f.discount) });
      toast.success("Regras financeiras salvas.");
      st.reload();
    } catch (e) { toast.error(e); } finally { setBusy(false); }
  }

  const r = reg.data;
  return (
    <div className="flex flex-col gap-5">
      <Card>
        <CardHeader title="Habilitação Regulatória" subtitle="Crédito e operações com garantias permanecem bloqueados para contratação, desembolso e custódia até a validação jurídica." />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 border-t border-line px-6 py-5">
          {([["credit", "Operações de crédito", "Contratação e desembolso de empréstimos"], ["collateral", "Operações com garantias", "Recebimento de bens em custódia"]] as const).map(([kind, title, desc]) => {
            const enabled = kind === "credit" ? r?.creditEnabled : r?.collateralEnabled;
            const note = kind === "credit" ? r?.creditNote : r?.collateralNote;
            const by = kind === "credit" ? r?.creditBy : r?.collateralBy;
            const at = kind === "credit" ? r?.creditAt : r?.collateralAt;
            return (
              <div key={kind} className="flex flex-col gap-3 rounded-sm border border-line p-4">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-[13px] font-semibold text-fg">{enabled ? <ShieldCheck size={15} className="text-success-fg" /> : <Lock size={15} className="text-warning-fg" />}{title}</span>
                  {enabled ? <Badge tone="success">Habilitado</Badge> : <Badge tone="warning">Bloqueado</Badge>}
                </div>
                <p className="text-xs text-fg-muted">{desc}</p>
                {note && <p className="rounded-sm bg-app px-3 py-2 text-xs text-fg-muted">“{note}”<span className="block pt-1 text-[11px] text-fg-subtle">{by ? `por @${by}` : ""} {at ? `em ${formatDateTime(at)}` : ""}</span></p>}
                {can("regulatory.manage") ? (
                  <Button size="sm" variant={enabled ? "destructive" : "outline"} onClick={() => setToggle({ kind, enable: !enabled })}>{enabled ? "Desabilitar" : "Habilitar após validação"}</Button>
                ) : <p className="text-[11px] text-fg-subtle">Somente usuários com a permissão “Habilitar operações reguladas” podem alterar.</p>}
              </div>
            );
          })}
        </div>
        <div className="border-t border-line px-6 py-4"><Notice tone="warning" icon={ShieldAlert}>Habilite somente após a validação do enquadramento jurídico, das autorizações aplicáveis e da modalidade operacional. A referência do parecer é obrigatória e fica registrada na auditoria.</Notice></div>
      </Card>

      <Card>
        <CardHeader title="Taxas e Encargos" subtitle="Valores padrão usados em simulações e na cobrança de atrasos" />
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 border-t border-line px-6 py-5">
          <TextInput label="Taxa de juros padrão (% a.m.)" mono value={f.rate} onChange={set("rate")} error={err(f.rate)} disabled={!editable} />
          <TextInput label="Tarifa de cadastro (% do valor)" mono value={f.fee} onChange={set("fee")} error={err(f.fee)} disabled={!editable} hint="Entra no cálculo do CET." />
          <TextInput label="IOF configurável (% do valor)" mono value={f.iof} onChange={set("iof")} error={err(f.iof)} disabled={!editable} hint="Entra no cálculo do CET." />
          <TextInput label="Multa por atraso (%)" mono value={f.lateFee} onChange={set("lateFee")} error={err(f.lateFee)} disabled={!editable} hint="Cobrada uma vez por parcela." />
          <TextInput label="Juros de mora (% a.m.)" mono value={f.mora} onChange={set("mora")} error={err(f.mora)} disabled={!editable} hint="Pro rata die." />
          <TextInput label="Prazo máximo (parcelas)" type="number" min={1} max={120} value={f.term} onChange={set("term")} disabled={!editable} />
          <MoneyInput label="Valor máximo por empréstimo" cents={maxAmount} onChange={setMaxAmount} disabled={!editable} />
          <TextInput label="Desconto máximo sem autorização (%)" type="number" min={0} max={100} value={f.discount} onChange={set("discount")} disabled={!editable} hint="Vendas acima exigem permissão de gerente." />
        </div>
        {editable && <div className="flex justify-end gap-3 border-t border-line px-6 py-4"><Button variant="outline" onClick={() => st.reload()} disabled={busy}>Cancelar</Button><Button onClick={save} disabled={busy}>Salvar Regras</Button></div>}
      </Card>

      {toggle && (
        <ConfirmDialog open onOpenChange={(o) => !o && setToggle(null)} destructive={!toggle.enable} confirmLabel={toggle.enable ? "Habilitar" : "Desabilitar"} minReason={toggle.enable ? 20 : 5}
          title={`${toggle.enable ? "Habilitar" : "Desabilitar"} ${toggle.kind === "credit" ? "operações de crédito" : "operações com garantias"}`}
          reasonLabel={toggle.enable ? "Referência da validação regulatória (parecer, enquadramento e autorização) — mín. 20 caracteres" : "Motivo da desabilitação"}
          description={toggle.enable ? "Confirme que o enquadramento jurídico, as autorizações e a modalidade operacional da empresa foram validados. Esta ação é registrada na auditoria." : "As operações voltarão a ser bloqueadas imediatamente."}
          onConfirm={async (note) => { await api.regulatorySet(toggle.kind, toggle.enable, note); reg.reload(); }} successMessage="Configuração regulatória atualizada." />
      )}
    </div>
  );
}
