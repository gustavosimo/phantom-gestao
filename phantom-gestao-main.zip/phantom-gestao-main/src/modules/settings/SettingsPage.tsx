import { NavLink, Navigate, useParams } from "react-router-dom";
import { Building2, Users, Lock, Percent, Bell, FileText, DatabaseBackup, History, Plug, Palette, type LucideIcon } from "lucide-react";
import { usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { cn } from "@/lib/utils";
import { CompanySection } from "@/modules/settings/CompanySection";
import { UsersSection, PermissionsSection } from "@/modules/settings/UsersSection";
import { RulesSection } from "@/modules/settings/RulesSection";
import { NotificationsSection, IntegrationsSection } from "@/modules/settings/CommsSections";
import { BackupSection, AuditSection, AppearanceSection } from "@/modules/settings/SystemSections";

interface Section {
  path: string;
  label: string;
  icon: LucideIcon;
  permission: string;
  element: React.ReactNode;
}

const SECTIONS: Section[] = [
  { path: "empresa", label: "Empresa", icon: Building2, permission: "settings.view", element: <CompanySection /> },
  { path: "usuarios", label: "Usuários", icon: Users, permission: "users.manage", element: <UsersSection /> },
  { path: "permissoes", label: "Permissões", icon: Lock, permission: "users.manage", element: <PermissionsSection /> },
  { path: "regras", label: "Regras Financeiras", icon: Percent, permission: "settings.view", element: <RulesSection /> },
  { path: "notificacoes", label: "Notificações", icon: Bell, permission: "settings.view", element: <NotificationsSection /> },
  { path: "documentos", label: "Documentos", icon: FileText, permission: "contracts.manage", element: <Navigate to="/modelos" replace /> },
  { path: "backup", label: "Backup", icon: DatabaseBackup, permission: "backup.manage", element: <BackupSection /> },
  { path: "auditoria", label: "Auditoria", icon: History, permission: "audit.view", element: <AuditSection /> },
  { path: "integracoes", label: "Integrações", icon: Plug, permission: "settings.view", element: <IntegrationsSection /> },
  { path: "aparencia", label: "Aparência", icon: Palette, permission: "settings.view", element: <AppearanceSection /> },
];

export function SettingsPage() {
  usePageHeader(null);
  const { section } = useParams();
  const can = useAuth((s) => s.can);
  const visible = SECTIONS.filter((s) => can(s.permission));
  const current = visible.find((s) => s.path === section);
  if (!section || !current) return <Navigate to={`/configuracoes/${visible[0]?.path ?? "empresa"}`} replace />;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[240px_1fr] items-start gap-5">
      <nav aria-label="Seções de configuração" className="flex gap-1 overflow-x-auto rounded-md border border-line bg-surface p-1 lg:flex-col lg:overflow-visible lg:border-0 lg:bg-transparent lg:p-0">
        {visible.map(({ path, label, icon: Icon }) => (
          <NavLink key={path} to={`/configuracoes/${path}`} className={({ isActive }) => cn("flex shrink-0 items-center gap-2.5 rounded-sm px-3.5 py-2.5 text-[13px] font-medium whitespace-nowrap lg:gap-3", isActive ? "bg-surface-hover text-fg" : "text-fg-muted hover:bg-surface-hover/60 hover:text-fg")}>
            <Icon size={15} /> {label}
          </NavLink>
        ))}
      </nav>
      <div className="min-w-0">{current.element}</div>
    </div>
  );
}
