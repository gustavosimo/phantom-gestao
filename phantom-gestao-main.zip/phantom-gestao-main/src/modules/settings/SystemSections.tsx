import { useState } from "react";
import { DatabaseBackup, FolderOpen, FlaskConical, ShieldCheck } from "lucide-react";
import { useApi, useDebounced } from "@/hooks/useApi";
import { useAuth } from "@/app/auth-store";
import { api, isDesktop } from "@/services/api";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, EmptyState, ErrorNotice, Notice, SearchInput } from "@/components/ui/layout";
import { FormModal } from "@/components/ui/dialog";
import { TextInput, Toggle } from "@/components/ui/form";
import { DataTable, Pagination } from "@/components/ui/data-table";
import { toast } from "@/components/ui/toast";
import { pickDirectory } from "@/lib/files";
import { formatDateTime, formatLocalDateTime } from "@/lib/format";

export function BackupSection() {
  if (!isDesktop) {
    return (
      <Card>
        <CardHeader title="Backup e Recuperação" subtitle="Cópia consistente do banco e dos documentos (cifrados), protegida por senha." />
        <div className="border-t border-line px-6 py-5">
          <Notice tone="info" icon={ShieldCheck}>Backup e restauração gravam no disco do computador que hospeda o sistema e só estão disponíveis no aplicativo desktop. Peça a quem administra o servidor para realizá-los por lá.</Notice>
        </div>
      </Card>
    );
  }
  return <BackupSectionDesktop />;
}

function BackupSectionDesktop() {
  const info = useApi(() => api.backupInfo(), []);
  const logout = useAuth((s) => s.logout);
  const [mode, setMode] = useState<null | "create" | "restore">(null);
  const [dir, setDir] = useState("");
  const [pass, setPass] = useState("");
  const [pass2, setPass2] = useState("");
  const [confirmText, setConfirmText] = useState("");
  const [busy, setBusy] = useState(false);
  const [seedBusy, setSeedBusy] = useState(false);

  function reset() { setMode(null); setDir(""); setPass(""); setPass2(""); setConfirmText(""); }

  async function choose() {
    const d = await pickDirectory();
    if (d) setDir(d);
  }

  async function create() {
    setBusy(true);
    try { const p = await api.backupCreate(dir, pass); toast.success(`Backup criado em ${p}`); info.reload(); reset(); } catch (e) { toast.error(e); } finally { setBusy(false); }
  }

  async function restore() {
    setBusy(true);
    try {
      const safety = await api.backupRestore(dir, pass, confirmText);
      toast.success(`Backup restaurado. Estado anterior salvo em ${safety}. Entre novamente.`);
      reset();
      await logout().catch(() => {});
      location.reload();
    } catch (e) { toast.error(e); } finally { setBusy(false); }
  }

  async function seed() {
    setSeedBusy(true);
    try { await api.demoSeed(); toast.success("Dados de demonstração carregados."); location.reload(); } catch (e) { toast.error(e); } finally { setSeedBusy(false); }
  }

  return (
    <div className="flex flex-col gap-5">
      <Card>
        <CardHeader title="Backup e Recuperação" subtitle="Cópia consistente do banco e dos documentos (cifrados), protegida por senha." />
        <div className="flex flex-col gap-4 border-t border-line px-6 py-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-[13px]">
            <div><p className="text-xs text-fg-subtle">Último backup</p><p className="text-fg">{info.data?.lastAt ? formatLocalDateTime(info.data.lastAt) : "Nenhum backup realizado"}</p></div>
            <div><p className="text-xs text-fg-subtle">Pasta de dados do aplicativo</p><p className="truncate font-mono text-xs text-fg-muted">{info.data?.dataDir ?? "—"}</p></div>
          </div>
          <div className="flex gap-3">
            <Button onClick={() => setMode("create")}><DatabaseBackup size={14} /> Criar backup</Button>
            <Button variant="outline" onClick={() => setMode("restore")}>Restaurar backup</Button>
          </div>
          <Notice tone="info" icon={ShieldCheck}>O backup inclui o banco, os documentos cifrados e a chave de criptografia, esta protegida pela senha que você definir. <strong>Guarde a senha</strong>: sem ela o backup não pode ser restaurado. Antes de qualquer restauração o estado atual é salvo automaticamente.</Notice>
        </div>
      </Card>

      {import.meta.env.DEV && (
        <Card>
          <CardHeader title="Ambiente de desenvolvimento" subtitle="Disponível apenas em builds de desenvolvimento." />
          <div className="flex items-center justify-between gap-4 border-t border-line px-6 py-5">
            <p className="max-w-lg text-xs text-fg-muted">Carrega clientes, produtos, empréstimos, garantias, vendas e pagamentos de demonstração (criados pelos mesmos serviços de negócio). Só funciona em base vazia e habilita crédito/garantias <strong>apenas para demonstração</strong>.</p>
            <Button variant="outline" onClick={seed} disabled={seedBusy}><FlaskConical size={14} /> Carregar demonstração</Button>
          </div>
        </Card>
      )}

      <FormModal open={mode !== null} onOpenChange={(o) => !o && !busy && reset()} width={520} title={mode === "create" ? "Criar backup" : "Restaurar backup"}
        description={mode === "create" ? "Escolha a pasta de destino e defina a senha do backup." : "Ação crítica: os dados atuais serão substituídos pelos do backup."}
        footer={<><Button variant="outline" onClick={reset} disabled={busy}>Cancelar</Button>{mode === "create" ? <Button onClick={create} disabled={busy || !dir || pass.length < 10 || pass !== pass2}>Criar backup</Button> : <Button variant="destructive" onClick={restore} disabled={busy || !dir || pass.length < 10 || confirmText !== "RESTAURAR"}>Restaurar</Button>}</>}>
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" onClick={choose}><FolderOpen size={14} /> {mode === "create" ? "Escolher pasta de destino" : "Escolher pasta do backup"}</Button>
            <span className="truncate font-mono text-xs text-fg-muted">{dir || "Nenhuma pasta selecionada"}</span>
          </div>
          <TextInput label="Senha do backup" type="password" value={pass} onChange={setPass} hint="Mínimo de 10 caracteres." />
          {mode === "create" && <TextInput label="Confirmar senha" type="password" value={pass2} onChange={setPass2} error={pass2 && pass !== pass2 ? "As senhas não coincidem." : null} />}
          {mode === "restore" && (
            <>
              <Notice tone="error">Esta ação substitui o banco e os documentos atuais. O estado atual é guardado em uma pasta de segurança, e você precisará entrar novamente.</Notice>
              <TextInput label="Digite RESTAURAR para confirmar" value={confirmText} onChange={setConfirmText} />
            </>
          )}
        </div>
      </FormModal>
    </div>
  );
}

export function AuditSection() {
  const [search, setSearch] = useState("");
  const dq = useDebounced(search);
  const [page, setPage] = useState(1);
  const q = useApi(() => api.audit({ page, pageSize: 12, search: dq || undefined }), [page, dq]);
  return (
    <Card className="overflow-x-auto">
      <CardHeader title="Trilha de Auditoria" subtitle="Registro imutável de ações sensíveis: acessos, operações financeiras, alterações de configuração." right={<SearchInput value={search} onChange={(v) => { setSearch(v); setPage(1); }} placeholder="Buscar ação, usuário..." className="w-full sm:w-[240px]" />} />
      {q.error && <div className="px-6 pb-4"><ErrorNotice message={q.error} onRetry={q.reload} /></div>}
      <DataTable
        className="rounded-none border-x-0 border-b-0"
        rows={q.data?.items}
        loading={q.loading}
        rowKey={(a) => a.id}
        empty={<EmptyState title="Nenhum registro" />}
        columns={[
          { key: "when", header: "Data", width: "1.1fr", render: (a) => <span className="text-fg-muted">{formatDateTime(a.occurredAt)}</span> },
          { key: "user", header: "Usuário", width: ".9fr", render: (a) => <span className="text-fg">{a.username ? `@${a.username}` : "—"}</span> },
          { key: "action", header: "Ação", width: "1.4fr", render: (a) => <span className="font-mono text-xs text-fg-muted">{a.action}</span> },
          { key: "details", header: "Detalhes", width: "2fr", render: (a) => <span className="text-fg-muted">{[a.entity && `${a.entity}${a.entityId ? ` #${a.entityId}` : ""}`, a.details].filter(Boolean).join(" · ") || "—"}</span> },
        ]}
        footer={q.data && q.data.total > 0 ? <Pagination page={q.data.page} pageSize={q.data.pageSize} total={q.data.total} onPage={setPage} noun="registros" /> : undefined}
      />
    </Card>
  );
}

export function AppearanceSection() {
  const [collapsed, setCollapsed] = useState(() => {
    try { return localStorage.getItem("phantom.sidebar-collapsed") === "1"; } catch { return false; }
  });
  return (
    <Card>
      <CardHeader title="Aparência" subtitle="A identidade visual da Phantom (tema escuro e cores oficiais) é fixa." />
      <div className="flex items-center justify-between gap-4 border-t border-line px-6 py-5">
        <div><p className="text-[13px] font-medium text-fg">Iniciar com o menu lateral recolhido</p><p className="text-xs text-fg-muted">Preferência deste computador; vale na próxima abertura.</p></div>
        <Toggle label="Menu lateral recolhido" checked={collapsed} onChange={(v) => { setCollapsed(v); try { localStorage.setItem("phantom.sidebar-collapsed", v ? "1" : "0"); } catch { /* ignorar */ } }} />
      </div>
    </Card>
  );
}
