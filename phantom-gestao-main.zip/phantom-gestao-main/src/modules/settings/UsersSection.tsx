import { useState } from "react";
import { KeyRound, LockOpen, Pencil, Plus, ShieldCheck } from "lucide-react";
import { useApi } from "@/hooks/useApi";
import { useAuth } from "@/app/auth-store";
import { api } from "@/services/api";
import type { UserRow } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, ErrorNotice, Notice } from "@/components/ui/layout";
import { Badge } from "@/components/ui/badge";
import { FormModal } from "@/components/ui/dialog";
import { SelectInput, TextInput, Toggle } from "@/components/ui/form";
import { DataTable } from "@/components/ui/data-table";
import { RowMenu } from "@/components/RowMenu";
import { toast } from "@/components/ui/toast";
import { formatDateTime } from "@/lib/format";
import { Avatar } from "@/layouts/Sidebar";

const ROLES = [{ value: "admin", label: "Administrador" }, { value: "manager", label: "Gerente" }, { value: "operator", label: "Operador" }, { value: "viewer", label: "Consulta" }];

export function UsersSection() {
  const me = useAuth((s) => s.user);
  const users = useApi(() => api.users(), []);
  const [edit, setEdit] = useState<UserRow | "new" | null>(null);
  const [pwd, setPwd] = useState<UserRow | null>(null);

  async function unlock(u: UserRow) {
    try { await api.userUnlock(u.id); toast.success("Usuário desbloqueado."); users.reload(); } catch (e) { toast.error(e); }
  }

  return (
    <Card className="overflow-x-auto">
      <CardHeader title="Usuários" subtitle="Quem pode acessar o sistema e com qual perfil" right={<Button size="sm" onClick={() => setEdit("new")}><Plus size={14} /> Novo usuário</Button>} />
      {users.error && <div className="px-6 pb-4"><ErrorNotice message={users.error} onRetry={users.reload} /></div>}
      <DataTable
        className="rounded-none border-x-0 border-b-0"
        rows={users.data}
        loading={users.loading}
        rowKey={(u) => u.id}
        columns={[
          { key: "user", header: "Usuário", width: "2fr", render: (u) => <span className="flex items-center gap-3"><Avatar name={u.fullName} size={30} /><span className="min-w-0"><span className="block truncate font-medium text-fg">{u.fullName}{u.id === me?.id && <span className="ml-2 text-[11px] text-fg-subtle">(você)</span>}</span><span className="text-xs text-fg-subtle">@{u.username}</span></span></span> },
          { key: "role", header: "Perfil", width: "1fr", render: (u) => <span className="text-fg-muted">{u.roleName}</span> },
          { key: "status", header: "Situação", width: "1fr", render: (u) => <span className="flex flex-wrap gap-1.5">{u.active ? <Badge tone="success">Ativo</Badge> : <Badge>Inativo</Badge>}{u.locked && <Badge tone="error">Bloqueado</Badge>}</span> },
          { key: "last", header: "Último acesso", width: "1.2fr", render: (u) => <span className="text-fg-muted">{u.lastLoginAt ? formatDateTime(u.lastLoginAt) : "Nunca"}</span> },
          {
            key: "menu", header: "", width: "40px",
            render: (u) => (
              <RowMenu actions={[
                { label: "Editar", icon: Pencil, onSelect: () => setEdit(u) },
                { label: "Redefinir senha", icon: KeyRound, onSelect: () => setPwd(u) },
                { label: "Desbloquear", icon: LockOpen, hidden: !u.locked, onSelect: () => unlock(u) },
              ]} />
            ),
          },
        ]}
      />
      {edit && <UserModal user={edit === "new" ? null : edit} onClose={() => setEdit(null)} onDone={() => { setEdit(null); users.reload(); }} />}
      {pwd && <PasswordModal user={pwd} onClose={() => setPwd(null)} />}
    </Card>
  );
}

function UserModal({ user, onClose, onDone }: { user: UserRow | null; onClose: () => void; onDone: () => void }) {
  const [username, setUsername] = useState(user?.username ?? "");
  const [name, setName] = useState(user?.fullName ?? "");
  const [role, setRole] = useState(user?.roleCode ?? "operator");
  const [active, setActive] = useState(user?.active ?? true);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  async function go() {
    setBusy(true);
    try {
      if (user) await api.userUpdate(user.id, { fullName: name, roleCode: role, active });
      else await api.userCreate({ username, fullName: name, roleCode: role, password });
      toast.success(user ? "Usuário atualizado." : "Usuário criado.");
      onDone();
    } catch (e) { toast.error(e); } finally { setBusy(false); }
  }
  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title={user ? "Editar usuário" : "Novo usuário"} width={460}
      footer={<><Button variant="outline" onClick={onClose} disabled={busy}>Cancelar</Button><Button onClick={go} disabled={busy || name.trim().length < 3 || (!user && (username.trim().length < 3 || password.length < 10))}>Salvar</Button></>}>
      <div className="flex flex-col gap-4">
        <TextInput label="Nome completo" required value={name} onChange={setName} />
        <TextInput label="Nome de usuário" required value={username} onChange={setUsername} disabled={!!user} hint="3 a 32 caracteres: letras, números, ponto, hífen ou sublinhado." />
        <SelectInput label="Perfil" value={role} onChange={setRole} options={ROLES} />
        {!user && <TextInput label="Senha inicial" type="password" required value={password} onChange={setPassword} hint="Mínimo de 10 caracteres, com letras e números." />}
        {user && <div className="flex items-center justify-between rounded-sm border border-line px-4 py-3"><span className="text-[13px] text-fg">Usuário ativo</span><Toggle label="Usuário ativo" checked={active} onChange={setActive} /></div>}
      </div>
    </FormModal>
  );
}

function PasswordModal({ user, onClose }: { user: UserRow; onClose: () => void }) {
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  async function go() {
    setBusy(true);
    try { await api.userResetPassword(user.id, pw); toast.success("Senha redefinida e bloqueio removido."); onClose(); } catch (e) { toast.error(e); } finally { setBusy(false); }
  }
  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title={`Redefinir senha — ${user.fullName}`} width={440}
      footer={<><Button variant="outline" onClick={onClose} disabled={busy}>Cancelar</Button><Button onClick={go} disabled={busy || pw.length < 10}>Redefinir</Button></>}>
      <div className="flex flex-col gap-4">
        <TextInput label="Nova senha" type="password" value={pw} onChange={setPw} hint="Mínimo de 10 caracteres, com letras e números. Informe-a ao usuário por um canal seguro." />
        <Notice tone="info">Senhas nunca são armazenadas em texto puro nem exibidas.</Notice>
      </div>
    </FormModal>
  );
}

export function PermissionsSection() {
  const m = useApi(() => api.rolesMatrix(), []);
  const refreshMe = useAuth((s) => s.init);
  const [busy, setBusy] = useState<string | null>(null);

  async function toggle(role: string, perm: string, granted: boolean) {
    const key = `${role}:${perm}`;
    setBusy(key);
    try { await api.rolePermissionSet(role, perm, granted); await m.reload(); await refreshMe(); } catch (e) { toast.error(e); } finally { setBusy(null); }
  }

  if (m.error) return <ErrorNotice message={m.error} onRetry={m.reload} />;
  if (!m.data) return null;
  return (
    <Card>
      <CardHeader title="Permissões" subtitle="O perfil Administrador é fixo e possui todas as permissões. Alterações valem no próximo login dos usuários e são auditadas." />
      <div className="overflow-x-auto border-t border-line">
        <table className="w-full text-left text-[13px]">
          <thead className="bg-app text-xs text-fg-muted">
            <tr><th className="px-6 py-3 font-medium">Permissão</th>{m.data.roles.map((r) => <th key={r.code} className="px-3 py-3 text-center font-medium">{r.name}</th>)}</tr>
          </thead>
          <tbody>
            {m.data.permissions.map((p) => (
              <tr key={p.code} className="border-t border-line">
                <td className="px-6 py-2.5"><span className="block text-fg">{p.description}</span><span className="font-mono text-[11px] text-fg-subtle">{p.code}</span></td>
                {m.data!.roles.map((r) => {
                  const granted = r.granted.includes(p.code);
                  return (
                    <td key={r.code} className="px-3 py-2.5 text-center">
                      {r.code === "admin" ? <ShieldCheck size={15} className="mx-auto text-fg-muted" aria-label="Sempre concedida" /> : <input type="checkbox" aria-label={`${r.name}: ${p.description}`} checked={granted} disabled={busy === `${r.code}:${p.code}`} onChange={(e) => toggle(r.code, p.code, e.target.checked)} className="size-4 cursor-pointer accent-[#c0c0c0]" />}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
