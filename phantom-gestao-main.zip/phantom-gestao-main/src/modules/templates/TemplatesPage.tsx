import { PdfView, needsPdfJs } from "@/components/PdfView";
import { useEffect, useMemo, useRef, useState } from "react";
import { Image as ImageIcon, PanelBottom, PanelTop, Table as TableIcon, Trash2, Upload, Eye, EyeOff, Maximize2, Minimize2, AlignCenter, AlignJustify, AlignRight, BadgeCheck, Bold, Copy, FilePlus2, Heading1, Heading2, History, HelpCircle, IndentIncrease, Italic, List, ListOrdered, Minus, PenLine, Save, SeparatorHorizontal, Type } from "lucide-react";
import { usePageHeader } from "@/app/page-header";
import { useAuth } from "@/app/auth-store";
import { useApi } from "@/hooks/useApi";
import { api, errorMessage } from "@/services/api";
import type { TemplateRow } from "@/types/domain";
import { Button } from "@/components/ui/button";
import { Card, EmptyState, ErrorNotice, Notice } from "@/components/ui/layout";
import { Badge } from "@/components/ui/badge";
import { FormModal } from "@/components/ui/dialog";
import { SelectInput, TextInput, Toggle } from "@/components/ui/form";
import { toast } from "@/components/ui/toast";
import { blobUrl } from "@/lib/files";
import { formatDate, formatDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";

const KINDS = [
  { value: "loan", label: "Empréstimo" },
  { value: "collateral", label: "Garantia" },
  { value: "sale", label: "Venda" },
  { value: "purchase", label: "Compra" },
];
const KIND_LABEL: Record<string, string> = Object.fromEntries(KINDS.map((k) => [k.value, k.label]));
const TABLE = "\n| Item | Descrição | Valor |\n|---|---|---|\n| 1 |  |  |\n| 2 |  |  |\n";
const SIGNATURE = "\n____________________________________   ____________________________________\nParte 1   Parte 2\n";

interface Draft {
  id?: number;
  kind: string;
  name: string;
  body: string;
  active: boolean;
}

const BLANK: Draft = { kind: "loan", name: "", body: "# TÍTULO DO CONTRATO {contrato_numero}\n\n## Partes\nCREDORA: {empresa}, CNPJ {empresa_documento}.\nDEVEDOR(A): {cliente_nome}, documento {cliente_documento}.\n\n## Cláusulas\n\nData: {data}\n", active: true };

export function TemplatesPage() {
  usePageHeader(null);
  const can = useAuth((s) => s.can);
  const list = useApi(() => api.templates(), []);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [original, setOriginal] = useState<Draft | null>(null);
  const [approve, setApprove] = useState(false);
  const [history, setHistory] = useState(false);
  const [help, setHelp] = useState(false);
  const [images, setImages] = useState(false);
  const [showPreview, setShowPreview] = useState(true);
  const [wide, setWide] = useState(false);
  const [busy, setBusy] = useState(false);
  const area = useRef<HTMLTextAreaElement>(null);

  const current: TemplateRow | undefined = list.data?.find((t) => t.id === draft?.id);
  const dirty = !!draft && !!original && JSON.stringify(draft) !== JSON.stringify(original);
  const vars = useApi(() => (draft ? api.contractVariables(draft.kind) : Promise.resolve([])), [draft?.kind]);

  function open(t: TemplateRow) {
    const d = { id: t.id, kind: t.kind, name: t.name, body: t.body, active: t.active };
    setDraft(d);
    setOriginal(d);
  }
  function openNew(from?: Draft) {
    const d = from ? { ...from, id: undefined, name: `${from.name} (cópia)` } : { ...BLANK };
    setDraft(d);
    setOriginal({ ...d, name: "\u0000" });
  }
  function patch(p: Partial<Draft>) {
    setDraft((d) => (d ? { ...d, ...p } : d));
  }

  function insert(text: string) {
    const el = area.current;
    if (!el || !draft) return;
    const [s, e] = [el.selectionStart, el.selectionEnd];
    const body = draft.body.slice(0, s) + text + draft.body.slice(e);
    patch({ body });
    requestAnimationFrame(() => {
      el.focus();
      el.setSelectionRange(s + text.length, s + text.length);
    });
  }
  /** Envolve a seleção com um marcador (negrito/itálico); repetir remove. */
  function wrap(marker: string) {
    const el = area.current;
    if (!el || !draft) return;
    const [st, en] = [el.selectionStart, el.selectionEnd];
    const sel = draft.body.slice(st, en);
    const already = sel.length >= marker.length * 2 && sel.startsWith(marker) && sel.endsWith(marker);
    const inner = already ? sel.slice(marker.length, sel.length - marker.length) : sel || "texto";
    const text = already ? inner : marker + inner + marker;
    patch({ body: draft.body.slice(0, st) + text + draft.body.slice(en) });
    requestAnimationFrame(() => {
      el.focus();
      const off = already ? 0 : marker.length;
      el.setSelectionRange(st + off, st + off + inner.length);
    });
  }

  function selectedLines(): { start: number; end: number; lines: string[] } | null {
    const el = area.current;
    if (!el || !draft) return null;
    const body = draft.body;
    const start = body.lastIndexOf("\n", el.selectionStart - 1) + 1;
    let end = body.indexOf("\n", el.selectionEnd);
    if (end === -1) end = body.length;
    return { start, end, lines: body.slice(start, end).split("\n") };
  }

  /** Prefixo de linha (título, lista, recuo): aplica a todas as linhas selecionadas; repetir remove. */
  function linePrefix(prefix: string, group: string[] = [prefix]) {
    const sel = selectedLines();
    if (!sel || !draft) return;
    const lines = sel.lines.map((l) => {
      const found = group.find((g) => l.startsWith(g));
      if (found === prefix) return l.slice(prefix.length);
      return prefix + (found ? l.slice(found.length) : l);
    });
    patch({ body: draft.body.slice(0, sel.start) + lines.join("\n") + draft.body.slice(sel.end) });
    requestAnimationFrame(() => area.current?.focus());
  }

  /** Alinhamento e tamanho são tags no início da linha: [c] [d] [j] [p] [g]. */
  function lineTag(tag: string, group: string[]) {
    const sel = selectedLines();
    if (!sel || !draft) return;
    const lines = sel.lines.map((l) => {
      let rest = l;
      let had = false;
      for (;;) {
        const g = group.find((x) => rest.startsWith(x));
        if (!g) break;
        had = had || g === tag;
        rest = rest.slice(g.length);
      }
      return had ? rest : tag + rest;
    });
    patch({ body: draft.body.slice(0, sel.start) + lines.join("\n") + draft.body.slice(sel.end) });
    requestAnimationFrame(() => area.current?.focus());
  }

  async function save() {
    if (!draft) return;
    setBusy(true);
    try {
      const id = await api.templateSave({ id: draft.id, kind: draft.kind, name: draft.name, body: draft.body, active: draft.active });
      const bodyChanged = !!current && current.body !== draft.body;
      toast.success(bodyChanged || !draft.id ? "Modelo salvo. Aguarda aprovação jurídica antes do uso." : "Modelo salvo.");
      const fresh = await api.templates();
      list.reload();
      const t = fresh.find((x) => x.id === id);
      if (t) open(t);
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
    }
  }

  // pré-visualização em PDF (dados fictícios): atualiza com atraso ao digitar e na hora ao abrir outro modelo
  const [req, setReq] = useState<{ kind: string; body: string } | null>(null);
  const lastId = useRef<number | undefined | null>(null);
  useEffect(() => {
    if (!draft) return;
    const switched = lastId.current !== draft.id;
    lastId.current = draft.id;
    const t = setTimeout(() => setReq({ kind: draft.kind, body: draft.body }), switched ? 0 : 600);
    return () => clearTimeout(t);
  }, [draft?.id, draft?.kind, draft?.body]);

  // duplo buffer: o PDF novo carrega por baixo e só troca quando está pronto (sem piscar)
  const [shown, setShown] = useState<string | null>(null);
  const [pending, setPending] = useState<string | null>(null);
  const [previewError, setPreviewError] = useState<string | null>(null);
  useEffect(() => {
    if (!req) return;
    let alive = true;
    api
      .contractTemplatePreview(req.kind, req.body)
      .then((b64) => {
        if (!alive) return;
        const next = blobUrl("application/pdf", b64);
        // celular (pdf.js): o componente já mantém as páginas antigas até as novas ficarem prontas
        if (needsPdfJs()) {
          setShown((old) => {
            if (old) setTimeout(() => URL.revokeObjectURL(old), 3000);
            return next;
          });
        } else setPending(next);
        setPreviewError(null);
      })
      .catch((e) => alive && setPreviewError(errorMessage(e)));
    return () => {
      alive = false;
    };
  }, [req]);
  function swapPreview() {
    setShown((old) => {
      if (old) setTimeout(() => URL.revokeObjectURL(old), 3000);
      return pending;
    });
    setPending(null);
  }

  const common = useMemo(() => (vars.data ?? []).filter((v) => v.common), [vars.data]);
  const specific = useMemo(() => (vars.data ?? []).filter((v) => !v.common), [vars.data]);

  return (
    <div className={cn("grid gap-5 lg:h-full lg:min-h-[640px]", wide ? "grid-cols-1" : "grid-cols-1 lg:grid-cols-[280px_1fr]")}>
      <div className={cn("flex min-h-0 flex-col gap-3", wide && draft && "hidden")}>
        <Button onClick={() => openNew()}><FilePlus2 size={14} /> Novo modelo</Button>
        {list.error && <ErrorNotice message={list.error} onRetry={list.reload} />}
        <div className="flex max-h-[38vh] min-h-0 flex-1 flex-col gap-2 overflow-y-auto lg:max-h-none">
          {(list.data ?? []).map((t) => (
            <button key={t.id} onClick={() => open(t)} className={cn("flex cursor-pointer flex-col gap-1.5 rounded-md border bg-surface p-3.5 text-left hover:bg-surface-hover/50", draft?.id === t.id ? "border-silver-dim" : "border-line")}>
              <span className="text-[13px] font-medium text-fg">{t.name}</span>
              <span className="flex flex-wrap items-center gap-1.5">
                <Badge>{KIND_LABEL[t.kind]}</Badge>
                {t.legalStatus === "approved" ? <Badge tone="success">Aprovado</Badge> : <Badge tone="warning">Rascunho</Badge>}
                {!t.active && <Badge>Inativo</Badge>}
              </span>
              <span className="text-[11px] text-fg-subtle">v{t.version} · {formatDate(t.updatedAt)}</span>
            </button>
          ))}
        </div>
      </div>

      {!draft ? (
        <Card><EmptyState icon={PenLine} title="Selecione ou crie um modelo" text="Monte o texto do contrato, insira variáveis (preenchidas com os dados reais) e veja o PDF ao lado. Modelos só geram contratos depois da aprovação jurídica." /></Card>
      ) : (
        <div className="flex min-h-0 flex-col gap-4">
          <Card className={cn("p-4", wide && "hidden")}>
            <div className="grid grid-cols-1 items-end gap-4 sm:grid-cols-[1fr_200px_auto]">
              <TextInput label="Nome do modelo" required value={draft.name} onChange={(v) => patch({ name: v })} />
              <SelectInput label="Tipo" value={draft.kind} onChange={(v) => patch({ kind: v })} options={KINDS} disabled={!!draft.id} />
              <div className="flex items-center gap-2 pb-2.5"><span className="text-[13px] text-fg-muted">Ativo</span><Toggle label="Modelo ativo" checked={draft.active} onChange={(v) => patch({ active: v })} /></div>
            </div>
            {current && (
              <p className="pt-3 text-xs text-fg-subtle">
                Versão {current.version} · {current.legalStatus === "approved" ? `aprovada por ${current.approvedBy} em ${formatDate(current.approvedAt)}` : "rascunho — aguardando aprovação jurídica"}
                {dirty && current.legalStatus === "approved" && <span className="text-warning-fg"> · salvar alterações no texto cria nova versão e exige nova aprovação</span>}
              </p>
            )}
          </Card>

          <div className={cn("grid min-h-0 flex-1 gap-4", showPreview ? "grid-cols-1 lg:grid-cols-2" : "grid-cols-1")}>
            <Card className="flex min-h-0 flex-col">
              <div className="flex flex-wrap items-center gap-1 border-b border-line bg-[#2a2e37] p-2">
                <ToolBtn label="Negrito" icon={Bold} onClick={() => wrap("**")} />
                <ToolBtn label="Itálico" icon={Italic} onClick={() => wrap("*")} />
                <Sep />
                <ToolBtn label="Título" icon={Heading1} onClick={() => linePrefix("# ", ["# ", "## "])} />
                <ToolBtn label="Subtítulo" icon={Heading2} onClick={() => linePrefix("## ", ["# ", "## "])} />
                <ToolBtn label="Texto pequeno" icon={Type} small onClick={() => lineTag("[p]", ["[p]", "[g]"])} />
                <ToolBtn label="Texto grande" icon={Type} onClick={() => lineTag("[g]", ["[p]", "[g]"])} />
                <Sep />
                <ToolBtn label="Centralizar" icon={AlignCenter} onClick={() => lineTag("[c]", ["[c]", "[d]", "[j]"])} />
                <ToolBtn label="Alinhar à direita" icon={AlignRight} onClick={() => lineTag("[d]", ["[c]", "[d]", "[j]"])} />
                <ToolBtn label="Justificar" icon={AlignJustify} onClick={() => lineTag("[j]", ["[c]", "[d]", "[j]"])} />
                <Sep />
                <ToolBtn label="Lista com marcadores" icon={List} onClick={() => linePrefix("- ", ["- ", "1. "])} />
                <ToolBtn label="Lista numerada" icon={ListOrdered} onClick={() => linePrefix("1. ", ["- ", "1. "])} />
                <ToolBtn label="Recuo" icon={IndentIncrease} onClick={() => linePrefix("> ")} />
                <Sep />
                <ToolBtn label="Linha divisória" icon={Minus} onClick={() => insert("\n---\n")} />
                <ToolBtn label="Nova página" icon={SeparatorHorizontal} onClick={() => insert("\n[quebra]\n")} />
                <ToolBtn label="Assinaturas" icon={PenLine} onClick={() => insert(SIGNATURE)} />
                <Sep />
                <ToolBtn label="Tabela" icon={TableIcon} onClick={() => insert(TABLE)} />
                <ToolBtn label="Imagem" icon={ImageIcon} onClick={() => setImages(true)} />
                <ToolBtn label="Texto de cabeçalho (abaixo do logo)" icon={PanelTop} onClick={() => insert("\n[cabecalho] Endereço, telefone ou texto do cabeçalho\n")} />
                <ToolBtn label="Texto de rodapé (todas as páginas)" icon={PanelBottom} onClick={() => insert("\n[rodape] Texto do rodapé\n")} />
                <ToolBtn label="Ajuda de formatação" icon={HelpCircle} onClick={() => setHelp(true)} />
                <span className="ml-auto flex items-center gap-1">
                  <ToolBtn label={showPreview ? "Ocultar pré-visualização" : "Mostrar pré-visualização"} icon={showPreview ? EyeOff : Eye} onClick={() => setShowPreview((v) => !v)} />
                  <ToolBtn label={wide ? "Reduzir área de edição" : "Ampliar área de edição"} icon={wide ? Minimize2 : Maximize2} onClick={() => setWide((v) => !v)} />
                </span>
              </div>
              <textarea
                ref={area}
                value={draft.body}
                onChange={(e) => patch({ body: e.target.value })}
                spellCheck
                aria-label="Texto do modelo"
                className="min-h-[260px] flex-1 resize-none bg-[#eceef1] p-4 font-mono text-[13px] leading-relaxed text-[#1f2430] caret-[#1f2430] selection:bg-[#b9c7e6] outline-none focus-visible:outline-none"
              />
              <div className="max-h-[170px] overflow-y-auto border-t border-line bg-[#2a2e37] p-3">
                <p className="pb-2 text-[11px] font-semibold tracking-wider text-fg-subtle uppercase">Variáveis — clique para inserir</p>
                <div className="flex flex-wrap gap-1.5">
                  {[...common, ...specific].map((v) => (
                    <button key={v.key} title={v.label} onClick={() => insert(`{${v.key}}`)} className={cn("cursor-pointer rounded-full border px-2.5 py-1 font-mono text-[11px] hover:bg-surface-hover", v.common ? "border-line text-fg-muted" : "border-info-line bg-info-bg text-info-fg")}>
                      {`{${v.key}}`}
                    </button>
                  ))}
                </div>
              </div>
            </Card>

            <Card className={cn("flex min-h-0 flex-col overflow-hidden", !showPreview && "hidden")}>
              <div className="border-b border-line px-4 py-2.5 text-xs text-fg-muted">Pré-visualização do PDF (dados fictícios)</div>
              <div className="relative min-h-[300px] flex-1 bg-app">
                {previewError ? <div className="p-4"><Notice tone="error">{previewError}</Notice></div> : shown && <PdfView url={shown} title="Pré-visualização" className="min-h-[300px]" />}
                {pending && <PdfView key={pending} url={pending} onReady={swapPreview} title="Carregando pré-visualização" className="pointer-events-none absolute inset-0 size-full min-h-0 opacity-0" />}
              </div>
            </Card>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex gap-2">
              {draft.id && <Button variant="outline" size="sm" onClick={() => setHistory(true)}><History size={14} /> Versões</Button>}
              <Button variant="outline" size="sm" onClick={() => openNew(draft)}><Copy size={14} /> Duplicar</Button>
            </div>
            <div className="flex gap-3">
              {current && can("contracts.legal") && current.legalStatus !== "approved" && !dirty && (
                <Button variant="outline" onClick={() => setApprove(true)}><BadgeCheck size={14} /> Aprovar (jurídico)</Button>
              )}
              <Button onClick={save} disabled={busy || draft.name.trim().length < 3 || draft.body.trim().length < 10 || (!dirty && !!draft.id)}><Save size={14} /> Salvar modelo</Button>
            </div>
          </div>
        </div>
      )}

      {images && <ImagesModal onClose={() => setImages(false)} onPick={(id) => { setImages(false); insert(`\n[c] [img:${id} 40%]\n`); }} />}
      {help && <HelpModal onClose={() => setHelp(false)} />}
      {approve && current && <ApproveModal t={current} onClose={() => setApprove(false)} onDone={() => { setApprove(false); list.reload(); }} />}
      {history && draft?.id && <VersionsModal id={draft.id} onClose={() => setHistory(false)} onLoad={(body) => { patch({ body }); setHistory(false); toast.success("Versão carregada no editor. Salve para criar uma nova versão."); }} />}
    </div>
  );
}

function ToolBtn({ label, icon: Icon, onClick, small }: { label: string; icon: typeof Heading1; onClick: () => void; small?: boolean }) {
  return (
    <button type="button" title={label} aria-label={label} onMouseDown={(e) => e.preventDefault()} onClick={onClick} className="flex size-8 cursor-pointer items-center justify-center rounded-sm text-fg-muted hover:bg-surface-hover hover:text-fg">
      <Icon size={small ? 11 : 15} />
    </button>
  );
}

function Sep() {
  return <span className="mx-0.5 h-5 w-px bg-line" />;
}

function HelpModal({ onClose }: { onClose: () => void }) {
  const rows: [string, string][] = [
    ["**texto**", "negrito"],
    ["*texto*", "itálico"],
    ["# Título", "título grande (negrito)"],
    ["## Subtítulo", "subtítulo (negrito)"],
    ["[c] texto", "centralizado"],
    ["[d] texto", "alinhado à direita"],
    ["[j] texto", "justificado"],
    ["[p] texto / [g] texto", "fonte pequena / grande"],
    ["- item", "lista com marcadores"],
    ["1. item", "lista numerada"],
    ["> texto", "parágrafo com recuo"],
    ["---", "linha divisória"],
    ["[quebra]", "nova página"],
    ["texto   texto", "colunas (3 ou mais espaços entre elas)"],
    ["| A | B |  e  |---|---|", "tabela com bordas; a linha |---|---| após a 1ª linha a torna cabeçalho"],
    ["[img:3 40%]", "imagem da biblioteca (3 = número; 40% = largura). Combine com [c] para centralizar"],
    ["[cabecalho] texto", "linha extra logo abaixo do cabeçalho institucional (1ª página)"],
    ["[rodape] texto", "linha extra no rodapé de todas as páginas (até 3)"],
  ];
  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title="Formatação do texto" description="Os botões da barra aplicam estas marcações; você também pode digitá-las. Tags de linha podem ser combinadas, ex.: [c][g] **TÍTULO**." width={560}>
      <div className="flex flex-col divide-y divide-line rounded-sm border border-line">
        {rows.map(([k, v]) => (
          <div key={k} className="grid grid-cols-[1.2fr_1.6fr] gap-4 px-4 py-2.5 text-[13px]"><code className="font-mono text-fg">{k}</code><span className="text-fg-muted">{v}</span></div>
        ))}
      </div>
    </FormModal>
  );
}

function ApproveModal({ t, onClose, onDone }: { t: TemplateRow; onClose: () => void; onDone: () => void }) {
  const [who, setWho] = useState("");
  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title="Aprovação jurídica do modelo" description={`${t.name} — versão ${t.version}`} width={460}
      footer={<><Button variant="outline" onClick={onClose}>Cancelar</Button><Button disabled={who.trim().length < 3} onClick={async () => { try { await api.templateApprove(t.id, who); toast.success("Modelo aprovado."); onDone(); } catch (e) { toast.error(e); } }}>Aprovar modelo</Button></>}>
      <div className="flex flex-col gap-4">
        <TextInput label="Responsável jurídico (nome e registro)" required value={who} onChange={setWho} placeholder="Ex.: Dra. Ana Souza — OAB/SP 000.000" />
        <Notice tone="info">Ao aprovar, você declara que o texto foi fornecido ou validado pelo responsável jurídico. O aceite fica registrado na auditoria.</Notice>
      </div>
    </FormModal>
  );
}

function VersionsModal({ id, onClose, onLoad }: { id: number; onClose: () => void; onLoad: (body: string) => void }) {
  const v = useApi(() => api.templateVersions(id), [id]);
  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title="Versões do modelo" description="Carregue uma versão anterior no editor e salve para criar uma nova versão." width={620}>
      <div className="flex flex-col gap-2">
        {(v.data ?? []).map((x) => (
          <div key={x.version} className="flex items-center justify-between gap-3 rounded-sm border border-line px-4 py-3">
            <div>
              <p className="text-[13px] font-medium text-fg">Versão {x.version} {x.legalStatus === "approved" ? <Badge tone="success" className="ml-2">Aprovada por {x.approvedBy}</Badge> : <Badge tone="warning" className="ml-2">Rascunho</Badge>}</p>
              <p className="text-xs text-fg-subtle">{formatDateTime(x.savedAt)}</p>
            </div>
            <Button size="sm" variant="outline" onClick={() => onLoad(x.body)}>Carregar no editor</Button>
          </div>
        ))}
      </div>
    </FormModal>
  );
}

/** Converte qualquer imagem em JPEG (fundo branco, até 1400 px) e devolve o base64. */
async function toJpegBase64(file: File): Promise<string> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = () => rej(new Error("Não foi possível ler a imagem."));
      i.src = url;
    });
    const k = Math.min(1, 1400 / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(img.naturalWidth * k));
    c.height = Math.max(1, Math.round(img.naturalHeight * k));
    const ctx = c.getContext("2d");
    if (!ctx) throw new Error("Não foi possível processar a imagem.");
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, c.width, c.height);
    ctx.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL("image/jpeg", 0.88).split(",")[1];
  } finally {
    URL.revokeObjectURL(url);
  }
}

function ImagesModal({ onClose, onPick }: { onClose: () => void; onPick: (id: number) => void }) {
  const list = useApi(() => api.templateImages(), []);
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  async function upload(file?: File) {
    if (!file) return;
    setBusy(true);
    try {
      const data = await toJpegBase64(file);
      const id = await api.templateImageAdd(file.name.replace(/\.[^.]+$/, ""), data);
      toast.success("Imagem adicionada.");
      list.reload();
      onPick(id);
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
      if (input.current) input.current.value = "";
    }
  }

  return (
    <FormModal open onOpenChange={(o) => !o && onClose()} title="Imagens do documento" description="Envie uma imagem (PNG, JPG, WebP…) ou escolha uma da biblioteca para inserir no texto." width={640}
      footer={<><Button variant="outline" onClick={onClose}>Fechar</Button><Button disabled={busy} onClick={() => input.current?.click()}><Upload size={14} /> Enviar imagem</Button></>}>
      <input ref={input} type="file" accept="image/*" className="hidden" onChange={(e) => upload(e.target.files?.[0])} />
      {list.error && <ErrorNotice message={list.error} onRetry={list.reload} />}
      {(list.data ?? []).length === 0 ? (
        <p className="py-6 text-center text-[13px] text-fg-muted">Nenhuma imagem na biblioteca ainda.</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {(list.data ?? []).map((im) => (
            <div key={im.id} className="flex flex-col gap-2 rounded-md border border-line p-2">
              <button type="button" onClick={() => onPick(im.id)} title="Inserir no texto" className="flex h-24 cursor-pointer items-center justify-center rounded-sm bg-white">
                <img src={`data:image/jpeg;base64,${im.dataBase64}`} alt={im.name} className="max-h-24 max-w-full object-contain" />
              </button>
              <div className="flex items-center justify-between gap-2">
                <span className="truncate text-xs text-fg-muted" title={im.name}>#{im.id} · {im.name}</span>
                <button type="button" aria-label="Excluir imagem" title="Excluir imagem" className="cursor-pointer text-fg-subtle hover:text-error-fg" onClick={async () => { try { await api.templateImageDelete(im.id); list.reload(); } catch (e) { toast.error(e); } }}><Trash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      )}
    </FormModal>
  );
}
