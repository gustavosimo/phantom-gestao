import { invoke } from "@tauri-apps/api/core";
import type { User } from "@/types/auth";
import type * as T from "@/types/domain";

/** Mensagem exibível de um erro vindo dos comandos Rust (string) ou do runtime. */
export function errorMessage(e: unknown): string {
  if (typeof e === "string") return e;
  if (e instanceof Error) return e.message;
  return "Erro inesperado.";
}

/** Dentro do app desktop a janela expõe a ponte do Tauri; no navegador (modo web) a API é HTTP. */
export const isDesktop = typeof window !== "undefined" && "__TAURI_INTERNALS__" in window;

/** Mesmo contrato do `invoke`: resolve com o dado ou rejeita com a mensagem (string) do backend. */
async function webInvoke<R>(cmd: string, args?: Record<string, unknown>): Promise<R> {
  let res: Response;
  try {
    res = await fetch(`/api/${cmd}`, {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-Requested-With": "phantom" },
      body: JSON.stringify(args ?? {}),
    });
  } catch {
    throw "Sem conexão com o servidor. Verifique a internet e tente novamente.";
  }
  const body = await res.json().catch(() => null);
  if (res.status === 401 && cmd !== "login") window.dispatchEvent(new Event("phantom:session-expired"));
  if (!res.ok) throw typeof body === "string" ? body : "Erro inesperado.";
  return body as R;
}

const call = <R>(cmd: string, args?: Record<string, unknown>) =>
  isDesktop ? invoke<R>(cmd, args) : webInvoke<R>(cmd, args);

export const authApi = {
  setupRequired: () => call<boolean>("setup_required"),
  setupAdmin: (fullName: string, username: string, password: string) =>
    call<User>("setup_admin", { fullName, username, password }),
  login: (username: string, password: string) => call<User>("login", { username, password }),
  logout: () => call<void>("logout"),
  currentUser: () => call<User | null>("current_user"),
  changePassword: (current: string, newPassword: string) => call<void>("change_password", { current, newPassword }),
};

export const api = {
  dashboard: (period: T.Period) => call<T.Dashboard>("dashboard_load", { period }),

  // clientes
  clients: (query: T.PageQuery) => call<T.Page<T.ClientRow>>("clients_list", { query }),
  clientOptions: (search?: string) => call<T.ClientOption[]>("client_options", { search }),
  client: (id: number) => call<T.ClientDetail>("client_get", { id }),
  clientCreate: (input: T.ClientInput) => call<number>("client_create", { input }),
  clientUpdate: (id: number, input: T.ClientInput) => call<void>("client_update", { id, input }),
  clientSetStatus: (id: number, status: string) => call<void>("client_set_status", { id, status }),
  clientSummary: (id: number) => call<T.ClientSummary>("client_summary", { id }),
  clientHistory: (id: number, kind?: string) => call<T.HistoryRow[]>("client_history", { id, kind }),
  clientDocuments: (id: number) => call<T.ClientDocRow[]>("client_documents", { id }),
  clientAddDocument: (clientId: number, docType: string, number?: string, filePath?: string, expiresAt?: string) =>
    call<number>("client_add_document", { clientId, docType, number, filePath, expiresAt }),

  // anexos
  attachments: (ownerType: string, ownerId: number, kind?: string) =>
    call<T.Attachment[]>("attachment_list", { ownerType, ownerId, kind }),
  localImagePreview: (path: string) => call<string>("local_image_preview", { path }),
  attachmentAdd: (ownerType: string, ownerId: number, kind: string, path: string) =>
    call<T.Attachment>("attachment_add", { ownerType, ownerId, kind, path }),
  attachmentRead: (id: number) => call<T.AttachmentData>("attachment_read", { id }),
  attachmentSaveTo: (id: number, path: string) => call<void>("attachment_save_to", { id, path }),

  // produtos
  products: (query: T.PageQuery) => call<T.Page<T.ProductRow>>("products_list", { query }),
  product: (id: number) => call<T.ProductRow>("product_get", { id }),
  productCategories: () => call<string[]>("product_categories"),
  productCreate: (input: T.ProductInput) => call<number>("product_create", { input }),
  productUpdate: (id: number, input: T.ProductInput) => call<void>("product_update", { id, input }),
  productAdjustStock: (id: number, delta: number, reason: string) => call<void>("product_adjust_stock", { id, delta, reason }),
  productInventoryCount: (id: number, counted: number, note: string) => call<number>("product_inventory_count", { id, counted, note }),
  productReserve: (id: number, delta: number) => call<void>("product_reserve", { id, delta }),
  productMovements: (id: number) => call<T.MovementRow[]>("product_movements", { id }),
  productCosts: (id: number) => call<T.CostRow[]>("product_costs", { id }),

  // compras
  purchases: (query: T.PageQuery) => call<T.Page<T.PurchaseRow>>("purchases_list", { query }),
  purchaseRegister: (input: T.PurchaseInput) => call<number>("purchase_register", { input }),
  purchaseConfirm: (id: number) => call<void>("purchase_confirm", { id }),
  purchaseCancel: (id: number, reason: string) => call<void>("purchase_cancel", { id, reason }),
  purchaseReceipt: (id: number) => call<T.Attachment>("purchase_receipt", { id }),

  // vendas
  sales: (query: T.PageQuery) => call<T.Page<T.SaleRow>>("sales_list", { query }),
  sale: (id: number) => call<T.SaleDetail>("sale_get", { id }),
  saleCreate: (input: T.SaleInput) => call<{ id: number; code: string }>("sale_create", { input }),
  saleCancel: (id: number, reason: string) => call<void>("sale_cancel", { id, reason }),
  saleReturnItem: (saleId: number, itemId: number, qty: number, reason: string) =>
    call<number>("sale_return_item", { saleId, itemId, qty, reason }),
  saleReceipt: (id: number) => call<T.Attachment>("sale_receipt", { id }),

  // pagamentos e caixa
  payments: (query: T.PageQuery, filter: { origin?: string; direction?: string } = {}) =>
    call<T.Page<T.PaymentRow>>("payments_list", { query, filter }),
  paymentRegister: (input: T.ManualPaymentInput) => call<number>("payment_register_manual", { input }),
  paymentConfirm: (id: number, method?: string) => call<void>("payment_confirm", { id, method }),
  paymentReverse: (id: number, reason: string) => call<number>("payment_reverse", { id, reason }),
  paymentReceipt: (id: number) => call<T.Attachment>("payment_receipt", { id }),
  installmentPay: (installmentId: number, amountCents: number, method: string, idempotencyKey: string) =>
    call<number>("installment_pay", { installmentId, amountCents, method, idempotencyKey }),
  installmentDue: (installmentId: number) => call<T.InstallmentDue>("installment_due", { installmentId }),
  loanSettle: (loanId: number, method: string, idempotencyKey: string) =>
    call<number>("loan_settle", { loanId, method, idempotencyKey }),
  cash: (query: T.PageQuery) => call<T.Page<T.CashRow>>("cash_list", { query }),
  cashSummary: () => call<T.CashSummary>("cash_summary"),
  cashManual: (kind: "in" | "out", amountCents: number, method: string, description: string) =>
    call<number>("cash_manual", { kind, amountCents, method, description }),
  cashReconcile: (ids: number[], value: boolean) => call<void>("cash_reconcile", { ids, value }),

  // empréstimos
  simulate: (input: T.SimulationInput) => call<T.Simulation>("loan_simulate", { input }),
  loans: (query: T.PageQuery) => call<T.Page<T.LoanRow>>("loans_list", { query }),
  loan: (id: number) => call<T.LoanDetail>("loan_get", { id }),
  applicationCreate: (input: T.ApplicationInput) => call<number>("application_create", { input }),
  applicationUpdate: (id: number, input: T.ApplicationInput) => call<void>("application_update", { id, input }),
  application: (id: number) => call<T.ApplicationRow>("application_get", { id }),
  applications: (status?: string) => call<T.ApplicationRow[]>("applications_list", { status }),
  applicationAnalyze: (id: number, notes?: string) => call<T.Analysis>("application_analyze", { id, notes }),
  applicationDecide: (id: number, approve: boolean, notes: string) => call<void>("application_decide", { id, approve, notes }),
  applicationCancel: (id: number) => call<void>("application_cancel", { id }),
  loanContract: (applicationId: number) => call<number>("loan_contract", { applicationId }),
  loanDisburse: (loanId: number, method: string) => call<void>("loan_disburse", { loanId, method }),
  loanRenegotiate: (input: T.RenegotiationInput) => call<number>("loan_renegotiate", { input }),

  // garantias
  collaterals: (query: T.PageQuery) => call<T.Page<T.CollateralRow>>("collateral_list", { query }),
  collateralStats: () => call<T.CollateralStats>("collateral_stats"),
  collateral: (id: number) => call<T.CollateralDetail>("collateral_get", { id }),
  collateralCreate: (input: T.CollateralInput) => call<number>("collateral_create", { input }),
  collateralValuate: (id: number, valueCents: number, notes?: string) => call<void>("collateral_valuate", { id, valueCents, notes }),
  collateralApprove: (id: number, approve: boolean, notes?: string) => call<void>("collateral_approve", { id, approve, notes }),
  collateralReceive: (id: number, location: string, days: number) => call<void>("collateral_receive", { id, location, days }),
  collateralExtend: (id: number, extraDays: number, reason: string) => call<void>("collateral_extend", { id, extraDays, reason }),
  collateralRelease: (id: number, kind: "redeemed" | "returned", note: string) => call<void>("collateral_release", { id, kind, note }),
  collateralLegal: (id: number, reference: string) => call<void>("collateral_legal", { id, reference }),

  // contratos
  contracts: (query: T.PageQuery) => call<T.Page<T.ContractRow>>("contracts_list", { query }),
  contract: (id: number) => call<T.ContractDetail>("contract_get", { id }),
  contractForRef: (kind: string, refId: number) => call<T.ContractRow | null>("contract_for_ref", { kind, refId }),
  contractGenerate: (kind: string, refId: number, reason?: string) => call<number>("contract_generate", { kind, refId, reason }),
  contractSign: (id: number, signer: string, note?: string) => call<void>("contract_sign", { id, signer, note }),
  contractCancel: (id: number, reason: string) => call<void>("contract_cancel", { id, reason }),
  templates: () => call<T.TemplateRow[]>("contract_templates"),
  templateSave: (input: { id?: number; kind: string; name: string; body: string; active?: boolean }) =>
    call<number>("contract_template_save", { input }),
  contractVariables: (kind: string) => call<{ key: string; label: string; common: boolean }[]>("contract_variables", { kind }),
  templateVersions: (id: number) =>
    call<{ version: number; body: string; legalStatus: string; approvedBy: string | null; savedAt: string }[]>("contract_template_versions", { id }),
  contractTemplatePreview: (kind: string, body: string) => call<string>("contract_template_preview", { kind, body }),
  templateImages: () => call<{ id: number; name: string; width: number; height: number; dataBase64: string }[]>("template_images_list"),
  templateImageAdd: (name: string, dataBase64: string) => call<number>("template_image_add", { name, dataBase64 }),
  templateImageDelete: (id: number) => call<void>("template_image_delete", { id }),
  templateApprove: (id: number, approver: string) => call<void>("contract_template_approve", { id, approver }),

  // notificações e cobranças
  notifications: (query: T.PageQuery) => call<T.Page<T.NotificationRow>>("notifications_list", { query }),
  unreadCount: () => call<number>("notifications_unread_count"),
  markRead: (id: number) => call<void>("notification_mark_read", { id }),
  markAllRead: () => call<void>("notifications_mark_all_read"),
  runRules: () => call<number>("notifications_run_rules"),
  deliveryStats: () => call<T.DeliveryStat[]>("notification_delivery_stats"),
  collections: (scope: "overdue" | "upcoming" | "all") => call<T.CollectionRow[]>("collections_list", { scope }),
  collectionsSummary: () => call<T.CollectionsSummary>("collections_summary"),
  collectionMessage: (channel: string, installmentId: number) =>
    call<string>("collection_render_message", { channel, installmentId }),
  collectionContact: (input: { installmentId: number; channel: string; status: string; message?: string }) =>
    call<{ eventId: number; url: string | null }>("collection_register_contact", { input }),
  collectionHistory: (clientId?: number) => call<T.ContactEventRow[]>("collection_history", { clientId }),
  openExternal: async (url: string) => {
    if (isDesktop) return call<void>("open_external", { url });
    // no navegador só abrimos WhatsApp e e-mail, como no desktop
    if (!(url.startsWith("https://wa.me/") || url.startsWith("mailto:"))) throw "Link não permitido.";
    window.open(url, "_blank", "noopener,noreferrer");
  },

  // relatórios
  reportOverview: (period: T.Period) => call<T.ReportOverview>("report_overview", { period }),
  reportTypes: () => call<{ code: string; label: string }[]>("report_types"),
  reportPreview: (reportType: string, period: T.Period) => call<T.ReportPreview>("report_preview", { reportType, period }),
  reportExport: (reportType: string, period: T.Period, format: "pdf" | "csv") =>
    call<T.GeneratedReport>("report_export", { input: { reportType, period, format } }),
  reportsGenerated: () => call<T.GeneratedReport[]>("report_generated"),

  // configurações
  settings: () => call<Record<string, string>>("settings_all"),
  saveCompany: (input: { name: string; document: string; email: string; phone: string; address: string }) =>
    call<void>("settings_save_company", { input }),
  saveRegional: (input: { dateFormat: string; tzOffsetHours: number }) => call<void>("settings_save_regional", { input }),
  saveFinancial: (input: T.FinancialRules) => call<void>("settings_save_financial", { input }),
  saveNotificationConfig: (input: T.NotificationConfig) => call<void>("settings_save_notifications", { input }),
  messageTemplates: () => call<T.MessageTemplate[]>("message_templates"),
  messageTemplateSave: (id: number, body: string, active: boolean) => call<void>("message_template_save", { id, body, active }),
  regulatory: () => call<T.Regulatory>("regulatory_get"),
  regulatorySet: (kind: "credit" | "collateral", enabled: boolean, note: string) =>
    call<void>("regulatory_set", { kind, enabled, note }),
  integrations: () => call<T.IntegrationStatus[]>("integrations_get"),
  integrationSave: (input: { name: string; enabled: boolean; fields: Record<string, string>; secret?: string }) =>
    call<void>("integration_save", { input }),
  users: () => call<T.UserRow[]>("users_list"),
  userCreate: (input: { username: string; fullName: string; roleCode: string; password: string }) => call<number>("user_create", { input }),
  userUpdate: (id: number, input: { fullName: string; roleCode: string; active: boolean }) => call<void>("user_update", { id, input }),
  userResetPassword: (id: number, newPassword: string) => call<void>("user_reset_password", { id, newPassword }),
  userUnlock: (id: number) => call<void>("user_unlock", { id }),
  rolesMatrix: () => call<T.RoleMatrix>("roles_matrix"),
  rolePermissionSet: (roleCode: string, permission: string, granted: boolean) =>
    call<void>("role_permission_set", { roleCode, permission, granted }),
  audit: (query: T.PageQuery) => call<T.Page<T.AuditRow>>("audit_list", { query }),
  backupInfo: () => call<{ lastAt: string | null; dataDir: string }>("backup_info"),
  backupCreate: (dir: string, passphrase: string) => call<string>("backup_create", { dir, passphrase }),
  backupVerify: (dir: string) => call<number>("backup_verify", { dir }),
  backupRestore: (dir: string, passphrase: string, confirmation: string) =>
    call<string>("backup_restore", { dir, passphrase, confirmation }),
  demoSeed: () => call<void>("demo_seed"),
};
