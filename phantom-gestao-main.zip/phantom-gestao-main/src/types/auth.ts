export interface User {
  id: number;
  username: string;
  fullName: string;
  roleCode: string;
  roleName: string;
  permissions: string[];
}
