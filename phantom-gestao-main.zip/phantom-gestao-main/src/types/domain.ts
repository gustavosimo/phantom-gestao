export interface Page<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface PageQuery {
  page?: number;
  pageSize?: number;
  search?: string;
  status?: string;
  category?: string;
  extra?: string;
  sort?: string;
  desc?: boolean;
}

export type PaymentMethod = "cash" | "pix" | "card" | "transfer" | "boleto";

export interface Period {
  kind: "today" | "7d" | "30d" | "quarter" | "year" | "custom";
  from?: string;
  to?: string;
}

// ------------------------------------------------------------------ clientes
export interface ClientRow {
  id: number;
  kind: "PF" | "PJ";
  name: string;
  document: string;
  phone: string | null;
  status: "active" | "pending" | "inactive" | "late";
  createdAt: string;
}

export interface ClientDetail {
  id: number;
  kind: "PF" | "PJ";
  name: string;
  document: string;
  documentMasked: boolean;
  rg: string | null;
  birthDate: string | null;
  profession: string | null;
  maritalStatus: string | null;
  email: string | null;
  phone: string | null;
  phone2: string | null;
  zip: string | null;
  street: string | null;
  number: string | null;
  complement: string | null;
  district: string | null;
  city: string | null;
  state: string | null;
  notes: string | null;
  status: "active" | "pending" | "inactive";
  derivedStatus: string;
  contactOptOut: boolean;
  createdAt: string;
}

export interface ClientInput {
  kind: "PF" | "PJ";
  name: string;
  document: string;
  rg?: string | null;
  birthDate?: string | null;
  profession?: string | null;
  maritalStatus?: string | null;
  email?: string | null;
  phone?: string | null;
  phone2?: string | null;
  zip?: string | null;
  street?: string | null;
  number?: string | null;
  complement?: string | null;
  district?: string | null;
  city?: string | null;
  state?: string | null;
  notes?: string | null;
  status?: string | null;
  contactOptOut?: boolean | null;
}

export interface ClientOption {
  id: number;
  name: string;
  document: string;
  status: string;
}

export interface ClientSummary {
  totalLentCents: number;
  openBalanceCents: number;
  activeCollaterals: number;
  lastPurchaseAt: string | null;
}

export interface HistoryRow {
  kind: "loan" | "collateral" | "payment" | "sale" | "purchase";
  description: string;
  amountCents: number | null;
  occurredAt: string;
  status: string;
  refId: number;
}

export interface ClientDocRow {
  id: number;
  docType: string;
  number: string | null;
  attachmentId: number | null;
  fileName: string | null;
  expiresAt: string | null;
  createdAt: string;
}

export interface Attachment {
  id: number;
  ownerType: string;
  ownerId: number;
  kind: string;
  originalName: string;
  mime: string;
  sizeBytes: number;
  createdAt: string;
}

export interface AttachmentData {
  meta: Attachment;
  dataBase64: string;
}

// ------------------------------------------------------------------ produtos
export interface ProductRow {
  id: number;
  sku: string;
  name: string;
  category: string;
  brand: string | null;
  model: string | null;
  serialNumber: string | null;
  costCents: number;
  priceCents: number;
  stockQty: number;
  reservedQty: number;
  availableQty: number;
  minStock: number;
  active: boolean;
  status: "available" | "low" | "out" | "inactive";
  notes: string | null;
}

export interface ProductInput {
  sku?: string | null;
  name: string;
  category: string;
  brand?: string | null;
  model?: string | null;
  serialNumber?: string | null;
  costCents: number;
  priceCents: number;
  minStock?: number | null;
  active?: boolean | null;
  notes?: string | null;
}

export interface MovementRow {
  id: number;
  kind: string;
  qty: number;
  unitCostCents: number | null;
  reason: string | null;
  username: string | null;
  createdAt: string;
}

export interface CostRow {
  costCents: number;
  reason: string;
  createdAt: string;
}

// ------------------------------------------------------------------- compras
export interface PurchaseRow {
  id: number;
  sellerClientId: number | null;
  sellerName: string;
  sellerDocument: string | null;
  productId: number;
  productName: string;
  category: string;
  qty: number;
  amountCents: number;
  valuationCents: number | null;
  paymentMethod: PaymentMethod;
  status: "pending" | "confirmed" | "cancelled";
  originProof: string | null;
  purchasedAt: string;
  paymentId: number | null;
  notes: string | null;
}

export interface PurchaseInput {
  sellerClientId?: number | null;
  sellerName?: string | null;
  sellerDocument?: string | null;
  productId?: number | null;
  productName?: string | null;
  category?: string | null;
  brand?: string | null;
  model?: string | null;
  serialNumber?: string | null;
  salePriceCents?: number | null;
  qty?: number | null;
  amountCents: number;
  valuationCents?: number | null;
  paymentMethod: PaymentMethod;
  confirm: boolean;
  dueDate?: string | null;
  originProof?: string | null;
  purchasedAt?: string | null;
  notes?: string | null;
  receiptPath?: string | null;
}

// -------------------------------------------------------------------- vendas
export interface SaleRow {
  id: number;
  code: string;
  clientId: number | null;
  clientName: string | null;
  subtotalCents: number;
  discountCents: number;
  totalCents: number;
  paymentMethod: PaymentMethod;
  status: "completed" | "cancelled" | "partially_returned";
  fiscalStatus: string;
  paymentId: number | null;
  cancelReason: string | null;
  createdAt: string;
}

export interface SaleItemRow {
  id: number;
  productId: number;
  productName: string;
  qty: number;
  unitPriceCents: number;
  unitCostCents: number;
  returnedQty: number;
}

export interface SaleDetail {
  sale: SaleRow;
  items: SaleItemRow[];
}

export interface SaleInput {
  clientId?: number | null;
  items: { productId: number; qty: number }[];
  discountCents: number;
  paymentMethod: PaymentMethod;
  idempotencyKey?: string | null;
}

// ---------------------------------------------------------------- pagamentos
export interface PaymentRow {
  id: number;
  code: string;
  clientId: number | null;
  clientName: string | null;
  direction: "in" | "out";
  originType: string;
  originId: number | null;
  description: string | null;
  amountCents: number;
  method: PaymentMethod;
  status: "pending" | "confirmed" | "reversed" | "overdue";
  dueDate: string | null;
  paidAt: string | null;
  reversalOfId: number | null;
  createdAt: string;
}

export interface CashRow {
  id: number;
  kind: "in" | "out";
  amountCents: number;
  method: string;
  category: string;
  description: string | null;
  paymentId: number | null;
  occurredAt: string;
  reconciled: boolean;
}

export interface CashSummary {
  balanceCents: number;
  inflowCents: number;
  outflowCents: number;
  unreconciledCount: number;
  receivablePendingCents: number;
  payablePendingCents: number;
}

export interface ManualPaymentInput {
  clientId?: number | null;
  partyName?: string | null;
  direction: "in" | "out";
  description: string;
  amountCents: number;
  method: PaymentMethod;
  dueDate?: string | null;
  confirm: boolean;
  idempotencyKey?: string | null;
}

// ------------------------------------------------------------- empréstimos
export interface ScheduleItem {
  number: number;
  dueDate: string;
  amountCents: number;
  principalCents: number;
  interestCents: number;
}

export interface Simulation {
  principalCents: number;
  termMonths: number;
  rateBp: number;
  installmentCents: number;
  totalCents: number;
  totalInterestCents: number;
  feesCents: number;
  netCents: number;
  cetMonthlyBp: number;
  cetAnnualBp: number;
  schedule: ScheduleItem[];
}

export interface SimulationInput {
  amountCents: number;
  termMonths: number;
  rateBp?: number | null;
  firstDueDate: string;
}

export interface LoanRow {
  id: number;
  clientId: number;
  clientName: string;
  principalCents: number;
  balanceCents: number;
  termMonths: number;
  paidInstallments: number;
  totalInstallments: number;
  nextDue: string | null;
  status: "pending_disbursement" | "active" | "paid_off" | "renegotiated" | "cancelled";
  derivedStatus: string;
  contractedAt: string;
}

export interface LateCharges {
  daysLate: number;
  feeCents: number;
  interestCents: number;
}

export interface InstallmentDue {
  installmentId: number;
  remainingCents: number;
  charges: LateCharges;
  totalDueCents: number;
}

export interface InstallmentView {
  id: number;
  loanId: number;
  number: number;
  dueDate: string;
  amountCents: number;
  principalCents: number;
  interestCents: number;
  paidCents: number;
  lateFeeApplied: boolean;
  interestThrough: string | null;
  status: string;
  paidAt: string | null;
  displayStatus: "paid" | "overdue" | "next" | "partial" | "open";
  due: InstallmentDue | null;
}

export interface LoanDetail {
  loan: LoanRow;
  rateBp: number;
  cetAnnualBp: number | null;
  feeCents: number;
  firstDueDate: string;
  disbursedAt: string | null;
  purpose: string | null;
  installments: InstallmentView[];
  paidCents: number;
  scheduledCents: number;
  finalDueDate: string | null;
  nextInstallmentId: number | null;
  renegotiations: number;
  contractId: number | null;
  contractSigned: boolean;
}

export interface ApplicationInput {
  clientId: number;
  amountCents: number;
  termMonths: number;
  rateBp?: number | null;
  purpose?: string | null;
  firstDueDate: string;
  collateralId?: number | null;
}

export interface AnalysisCheck {
  key: string;
  label: string;
  ok: boolean;
  required: boolean;
  detail: string;
}

export interface Analysis {
  checks: AnalysisCheck[];
  exposureCents: number;
  blocking: boolean;
}

export interface ApplicationRow {
  id: number;
  clientId: number;
  clientName: string;
  amountCents: number;
  termMonths: number;
  rateBp: number;
  purpose: string | null;
  firstDueDate: string;
  collateralId: number | null;
  status: "draft" | "analysis" | "approved" | "rejected" | "contracted" | "cancelled";
  analysisNotes: string | null;
  analysis: Analysis | null;
  decisionNotes: string | null;
  decidedAt: string | null;
  loanId: number | null;
  createdAt: string;
}

export interface RenegotiationInput {
  loanId: number;
  newTermMonths: number;
  newRateBp?: number | null;
  firstDueDate: string;
  reason: string;
}

// ------------------------------------------------------------------ garantias
export interface CollateralRow {
  id: number;
  code: string;
  clientId: number;
  clientName: string;
  loanId: number | null;
  applicationId: number | null;
  category: string;
  name: string;
  brand: string | null;
  model: string | null;
  serialNumber: string | null;
  condition: "new" | "refurbished" | "used" | "damaged";
  appraisedCents: number | null;
  linkedValueCents: number | null;
  storageLocation: string | null;
  custodyDays: number | null;
  custodyStart: string | null;
  custodyDue: string | null;
  daysLeft: number | null;
  notes: string | null;
  status: string;
  displayStatus: "evaluating" | "approved" | "in_custody" | "near_deadline" | "redeemed" | "returned" | "legal_procedure" | "rejected";
  createdAt: string;
}

export interface CollateralStats {
  inCustody: number;
  awaitingAppraisal: number;
  nearDeadline: number;
  redeemedMonth: number;
}

export interface CollateralInput {
  clientId: number;
  category: string;
  name: string;
  brand?: string | null;
  model?: string | null;
  serialNumber?: string | null;
  condition: string;
  appraisedCents?: number | null;
  storageLocation?: string | null;
  custodyDays?: number | null;
  notes?: string | null;
  applicationId?: number | null;
  photoPaths?: string[] | null;
}

export interface CollateralEvent {
  id: number;
  kind: string;
  description: string;
  username: string | null;
  createdAt: string;
}

export interface CollateralDetail {
  asset: CollateralRow;
  events: CollateralEvent[];
  photos: Attachment[];
  terms: Attachment[];
}

// ------------------------------------------------------------------ contratos
export interface ContractRow {
  id: number;
  number: string;
  kind: "loan" | "collateral" | "sale" | "purchase";
  refId: number;
  refCode: string;
  clientId: number | null;
  clientName: string | null;
  status: string;
  displayStatus: string;
  signedAt: string | null;
  signedByName: string | null;
  attachmentId: number | null;
  createdAt: string;
  version: number;
}

export interface ContractVersion {
  version: number;
  attachmentId: number;
  fileName: string;
  reason: string | null;
  createdAt: string;
}

export interface ContractDetail {
  contract: ContractRow;
  versions: ContractVersion[];
  documents: Attachment[];
}

export interface TemplateRow {
  id: number;
  kind: "loan" | "collateral" | "sale" | "purchase";
  name: string;
  body: string;
  version: number;
  legalStatus: "draft" | "approved";
  approvedBy: string | null;
  approvedAt: string | null;
  active: boolean;
  updatedAt: string;
}

// -------------------------------------------------------- notificações/cobrança
export interface NotificationRow {
  id: number;
  kind: string;
  category: "alert" | "due" | "payment" | "pending" | "info";
  severity: "info" | "warning" | "error" | "success";
  title: string;
  body: string | null;
  entityType: string | null;
  entityId: number | null;
  read: boolean;
  createdAt: string;
}

export interface DeliveryStat {
  channel: string;
  total: number;
  ok: number;
  failed: number;
  blocked: number;
}

export interface CollectionRow {
  installmentId: number;
  loanId: number;
  clientId: number;
  clientName: string;
  number: number;
  totalInstallments: number;
  remainingCents: number;
  dueDate: string;
  daysLate: number;
  daysToDue: number;
  contactOptOut: boolean;
}

export interface CollectionsSummary {
  dueTodayCount: number;
  dueWeekCount: number;
  overdueCount: number;
  overdueCents: number;
}

export interface ContactEventRow {
  id: number;
  clientName: string;
  channel: "whatsapp" | "email" | "call";
  status: string;
  error: string | null;
  message: string | null;
  username: string | null;
  createdAt: string;
}

// ----------------------------------------------------------------- dashboard
export interface SeriesPoint {
  label: string;
  receivedCents: number;
  forecastCents: number;
}

export interface Dashboard {
  from: string;
  to: string;
  portfolioCents: number;
  received: { value: number; previous: number };
  overdueCents: number;
  overdueCount: number;
  newClients: { value: number; previous: number };
  activeLoans: number;
  outstandingCents: number;
  receivableCents: number;
  collateralInCustody: number;
  salesMonthCents: number;
  receivedTodayCents: number;
  dueSoonCount: number;
  dueSoonCents: number;
  pending: {
    applicationsInAnalysis: number;
    contractsPendingSignature: number;
    collateralAwaitingAppraisal: number;
    purchasesPending: number;
    paymentsPending: number;
    clientsWithoutDocuments: number;
  };
  series: SeriesPoint[];
  seriesGranularity: "day" | "month";
  recent: { clientName: string; kind: string; amountCents: number; occurredAt: string; status: string }[];
  notifications: { id: number; kind: string; severity: string; title: string; body: string | null; createdAt: string }[];
  unreadNotifications: number;
}

// ----------------------------------------------------------------- relatórios
export interface Kpi {
  value: number;
  previous: number;
}

export interface ReportOverview {
  from: string;
  to: string;
  revenue: Kpi;
  newContracts: Kpi;
  avgTicketCents: Kpi;
  delinquencyBp: Kpi;
  revenueSeries: SeriesPoint[];
  operations: { label: string; count: number }[];
}

export interface ReportPreview {
  title: string;
  columns: string[];
  rows: string[][];
  summary: [string, string][];
  total: number;
}

export interface GeneratedReport {
  id: number;
  title: string;
  periodLabel: string;
  format: "pdf" | "csv";
  attachmentId: number;
  fileName: string;
  createdAt: string;
}

// -------------------------------------------------------------- configurações
export interface UserRow {
  id: number;
  username: string;
  fullName: string;
  roleCode: string;
  roleName: string;
  active: boolean;
  lastLoginAt: string | null;
  locked: boolean;
}

export interface RoleMatrix {
  roles: { code: string; name: string; description: string; granted: string[] }[];
  permissions: { code: string; description: string }[];
}

export interface AuditRow {
  id: number;
  occurredAt: string;
  username: string | null;
  action: string;
  entity: string | null;
  entityId: string | null;
  details: string | null;
}

export interface Regulatory {
  creditEnabled: boolean;
  collateralEnabled: boolean;
  creditNote: string;
  collateralNote: string;
  creditBy: string;
  creditAt: string;
  collateralBy: string;
  collateralAt: string;
}

export interface IntegrationStatus {
  name: "whatsapp" | "email" | "fiscal";
  enabled: boolean;
  secretConfigured: boolean;
  fields: Record<string, string>;
  connectorAvailable: boolean;
}

export interface MessageTemplate {
  id: number;
  code: string;
  channel: string;
  name: string;
  body: string;
  active: boolean;
}

export interface FinancialRules {
  defaultRateBp: number;
  originationFeeBp: number;
  iofBp: number;
  lateFeeBp: number;
  lateInterestMonthBp: number;
  maxTermMonths: number;
  maxAmountCents: number;
  maxDiscountPct: number;
}

export interface NotificationConfig {
  whatsapp3dBefore: boolean;
  emailOnDue: boolean;
  callAfter5d: boolean;
  quietStartHour: number;
  quietEndHour: number;
  allowSunday: boolean;
  maxPerClientDay: number;
  maxPerClientWeek: number;
  dueSoonDays: number;
  collateralDays: number;
}
