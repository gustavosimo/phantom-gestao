// Ferramenta de verificação visual: conecta ao WebView2 do app Tauri em execução
// (WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS=--remote-debugging-port=9222) e tira capturas das telas.
import puppeteer from "puppeteer-core";
import fs from "node:fs";

const OUT = process.env.SHOTS ?? "shots";
fs.mkdirSync(OUT, { recursive: true });

export async function connect() {
  const browser = await puppeteer.connect({ browserURL: "http://127.0.0.1:9222", defaultViewport: null });
  const pages = await browser.pages();
  const page = pages.find((p) => p.url().startsWith("http://localhost:1420")) ?? pages[0];
  return { browser, page };
}

export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function shot(page, name) {
  await sleep(500);
  await page.screenshot({ path: `${OUT}/${name}.png` });
  console.log("shot", name);
}

export async function go(page, path) {
  await page.goto(`http://localhost:1420${path}`, { waitUntil: "domcontentloaded" });
  await sleep(2200);
}

export async function clickText(page, text, selector = "button") {
  const ok = await page.evaluate(
    (t, sel) => {
      const el = [...document.querySelectorAll(sel)].find((e) => e.textContent.trim().includes(t) && !e.disabled);
      if (el) { el.click(); return true; }
      return false;
    },
    text,
    selector,
  );
  if (!ok) throw new Error(`não encontrou "${text}"`);
  await sleep(400);
}

export async function typeInto(page, selector, value) {
  await page.click(selector, { clickCount: 3 });
  await page.keyboard.press("Backspace");
  await page.type(selector, value);
}
