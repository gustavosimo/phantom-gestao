import { connect, shot, go, typeInto, clickText, sleep } from "./drive.mjs";

const { browser, page } = await connect();
await page.setViewport({ width: 1440, height: 900 });
await go(page, "/");
await shot(page, "01-setup");
const needsSetup = await page.evaluate(() => !!document.querySelector("#full-name"));
if (needsSetup) {
  await typeInto(page, "#full-name", "Ricardo Martins");
  await typeInto(page, "#username", "ricardo");
  await typeInto(page, "#password", "senhaforte123");
  await typeInto(page, "#confirm", "senhaforte123");
  await clickText(page, "Criar administrador");
  await sleep(2000);
}
await shot(page, "02-dashboard-vazio");
await go(page, "/configuracoes/backup");
await shot(page, "03-backup");
await clickText(page, "Carregar demonstração");
await sleep(4000);
await go(page, "/");
await shot(page, "04-dashboard-demo");
await browser.disconnect();
