import { connect, shot, go, clickText, sleep } from "./drive.mjs";

const { browser, page } = await connect();
await page.setViewport({ width: 1440, height: 900 });
const routes = [
  ["05-clientes", "/clientes"],
  ["06-cliente-novo", "/clientes/novo"],
  ["07-cliente-detalhe", "/clientes/1"],
  ["08-emprestimos", "/emprestimos"],
  ["09-emprestimo-novo", "/emprestimos/novo?cliente=2"],
  ["10-emprestimo-detalhe", "/emprestimos/1"],
  ["11-garantias", "/garantias"],
  ["12-garantia-nova", "/garantias/nova"],
  ["13-garantia-detalhe", "/garantias/1"],
  ["14-produtos", "/produtos"],
  ["15-compras", "/compras"],
  ["16-vendas", "/vendas"],
  ["17-pagamentos", "/pagamentos"],
  ["18-cobrancas", "/cobrancas"],
  ["19-contratos", "/contratos"],
  ["20-notificacoes", "/notificacoes"],
  ["21-relatorios", "/relatorios"],
  ["22-config-empresa", "/configuracoes/empresa"],
];
for (const [name, path] of routes) {
  await go(page, path);
  await shot(page, name);
}
await browser.disconnect();
