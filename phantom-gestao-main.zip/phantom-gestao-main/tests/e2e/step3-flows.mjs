import { connect, shot, go, clickText, sleep } from "./drive.mjs";

const { browser, page } = await connect();
await page.setViewport({ width: 1440, height: 900 });
const results = [];
const check = (name, ok, extra = "") => { results.push([name, ok]); console.log(ok ? "PASS" : "FAIL", name, extra); };

async function fill(label, value, nth = 0) {
  const id = await page.evaluate((l, n) => {
    const labels = [...document.querySelectorAll("label")].filter((x) => x.textContent.replace("*", "").trim().startsWith(l));
    return labels[n]?.htmlFor ?? null;
  }, label, nth);
  if (!id) throw new Error(`campo "${label}" não encontrado`);
  const sel = `[id="${id}"]`;
  await page.click(sel);
  await page.keyboard.down("Control"); await page.keyboard.press("KeyA"); await page.keyboard.up("Control");
  await page.keyboard.press("Backspace");
  if (value) await page.type(sel, value);
}
const toasts = () => page.evaluate(() => [...document.querySelectorAll('[role="alert"],[role="status"]')].map((e) => e.textContent.trim()));
const bodyText = () => page.evaluate(() => document.body.innerText);

// A) cadastro de cliente: CPF inválido, depois válido
await go(page, "/clientes/novo");
await fill("Nome completo", "Teste E2E Cliente");
await fill("CPF", "11111111111");
await clickText(page, "Salvar Cliente");
await sleep(1200);
check("CPF inválido é recusado", (await toasts()).some((t) => /CPF inválido/.test(t)), JSON.stringify(await toasts()));
await fill("CPF", "52998224725");
await clickText(page, "Salvar Cliente");
await sleep(1800);
check("cliente criado e detalhe aberto", /clientes\/\d+$/.test(page.url()) && (await bodyText()).includes("Teste E2E Cliente"), page.url());
check("documento mascarado no detalhe", /529\.\*\*\*\.\*\*\*-25/.test(await bodyText()));
await shot(page, "30-cliente-criado");

// duplicidade
await go(page, "/clientes/novo");
await fill("Nome completo", "Duplicado");
await fill("CPF", "52998224725");
await clickText(page, "Salvar Cliente");
await sleep(1200);
check("CPF duplicado é recusado", (await toasts()).some((t) => /Já existe/.test(t)));

// B) empréstimo: assistente completo
await go(page, "/emprestimos/novo?cliente=1");
await clickText(page, "Avançar para Simulação");
await fill("Valor solicitado", "500000");
await sleep(1200);
check("simulação exibe parcela", /Valor da parcela/.test(await bodyText()) && /R\$\s*\d/.test(await bodyText()));
await shot(page, "31-wizard-simulacao");
await clickText(page, "Avançar para Análise");
await sleep(800);
await clickText(page, "Executar análise");
await sleep(1000);
check("análise sem pendências", (await bodyText()).includes("Cadastro ativo"));
await shot(page, "32-wizard-analise");
await clickText(page, "Avançar para Aprovação");
await fill("Parecer", "Aprovado nos termos da política de crédito.");
await clickText(page, "Aprovar solicitação");
await sleep(1200);
check("solicitação aprovada", (await toasts()).some((t) => /aprovada/i.test(t)) || (await bodyText()).includes("Resumo da operação"));
await shot(page, "33-wizard-resumo");
await clickText(page, "Contratar empréstimo");
await sleep(1800);
check("contratação abre detalhe do empréstimo", /emprestimos\/\d+$/.test(page.url()), page.url());
const loanUrl = page.url();

// contrato → assinatura → desembolso
await clickText(page, "Gerar contrato");
await sleep(1500);
check("contrato gerado", (await toasts()).some((t) => /Contrato gerado/.test(t)) || (await bodyText()).includes("CTR-"));
await clickText(page, "Registrar assinatura");
await sleep(500);
await clickText(page, "Registrar", "[role=dialog] button");
await sleep(1500);
await clickText(page, "Registrar desembolso");
await sleep(500);
await clickText(page, "Registrar desembolso", "[role=dialog] button");
await sleep(2000);
await shot(page, "34-emprestimo-ativo");
check("empréstimo ativo após desembolso", /Em dia/.test(await bodyText()));

// recebimento da 1ª parcela
await clickText(page, "Receber");
await sleep(600);
await shot(page, "35-receber-parcela");
await clickText(page, "Confirmar recebimento");
await sleep(2200);
check("parcela recebida (progresso > 0)", !/^0% quitado/m.test(await bodyText()) || /Pago/.test(await bodyText()));
await shot(page, "36-parcela-paga");

// C) venda no PDV
await go(page, "/vendas");
await page.evaluate(() => {
  const btn = [...document.querySelectorAll('button[aria-label^="Adicionar"]')].find((b) => !b.disabled);
  btn?.click();
});
await sleep(500);
await clickText(page, "Finalizar Venda");
await sleep(2500);
check("venda finalizada", (await toasts()).some((t) => /finalizada/.test(t)), JSON.stringify(await toasts()));
await shot(page, "37-venda-comprovante");

// D) permissão: relatório exporta CSV registrado
await go(page, "/relatorios");
await clickText(page, "Exportar Relatório");
await sleep(1500);
await shot(page, "38-exportar-relatorio");

console.log(`\n${results.filter((r) => r[1]).length}/${results.length} verificações OK`);
await browser.disconnect();
process.exit(results.every((r) => r[1]) ? 0 : 1);
