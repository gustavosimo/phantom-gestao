import { connect, shot, go, clickText, sleep } from "./drive.mjs";

const { browser, page } = await connect();
await page.setViewport({ width: 1440, height: 900 });
await go(page, "/");
if (await page.evaluate(() => !!document.querySelector("header"))) {
await page.evaluate(() => document.querySelector('header [aria-label="Menu do usuário"]').dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, button: 0, pointerType: "mouse" })));
await sleep(500);
await shot(page, "50-menu-usuario");
await clickText(page, "Sair", '[role="menuitem"]');
await sleep(600);
await shot(page, "51-confirmar-sair");
await clickText(page, "Sair", '[role="dialog"] button');
await sleep(1500);
}
await shot(page, "52-login");
const type = async (sel, v) => { await page.click(sel); await page.type(sel, v); };
await type("#username", "ricardo");
await type("#password", "senha-errada-1");
await clickText(page, "Entrar");
await sleep(1500);
await shot(page, "53-login-erro");
await page.click("#password", { clickCount: 3 });
await page.keyboard.press("Backspace");
await page.type("#password", "senhaforte123");
await clickText(page, "Entrar");
await sleep(2500);
await shot(page, "54-login-ok");
await browser.disconnect();
