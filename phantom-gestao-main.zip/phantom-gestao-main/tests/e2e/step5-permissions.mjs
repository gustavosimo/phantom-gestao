import { connect, shot, go, clickText, sleep } from "./drive.mjs";

const { browser, page } = await connect();
await page.setViewport({ width: 1440, height: 900 });
const results = [];
const check = (name, ok, extra = "") => { results.push(ok); console.log(ok ? "PASS" : "FAIL", name, extra); };
const bodyText = () => page.evaluate(() => document.body.innerText);
const labelId = (l) => page.evaluate((t) => [...document.querySelectorAll("label")].find((x) => x.textContent.replace("*", "").trim().startsWith(t))?.htmlFor, l);
async function fill(label, value) {
  const id = await labelId(label);
  await page.click(`[id="${id}"]`);
  await page.keyboard.down("Control"); await page.keyboard.press("KeyA"); await page.keyboard.up("Control");
  await page.keyboard.press("Backspace");
  await page.type(`[id="${id}"]`, value);
}

// cria um operador pela interface
await go(page, "/configuracoes/usuarios");
await clickText(page, "Novo usuário");
await sleep(500);
await fill("Nome completo", "Operador de Teste");
await fill("Nome de usuário", "operador1");
await fill("Senha inicial", "operadorforte1");
await clickText(page, "Salvar", "[role=dialog] button");
await sleep(1500);
check("usuário criado", (await bodyText()).includes("Operador de Teste"));
await shot(page, "60-usuarios");

// sair e entrar como operador
await page.evaluate(() => document.querySelector('header [aria-label="Menu do usuário"]').dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, button: 0, pointerType: "mouse" })));
await sleep(400);
await clickText(page, "Sair", '[role="menuitem"]');
await sleep(500);
await clickText(page, "Sair", '[role="dialog"] button');
await sleep(1500);
await page.click("#username"); await page.type("#username", "operador1");
await page.click("#password"); await page.type("#password", "operadorforte1");
await clickText(page, "Entrar");
await sleep(2500);
const menu = await page.evaluate(() => [...document.querySelectorAll("aside nav a")].map((a) => a.textContent.trim()));
console.log("menu do operador:", menu.join(", "));
check("operador não vê Configurações/Empréstimos/Relatórios", !menu.includes("Configurações") && !menu.includes("Empréstimos") && !menu.includes("Relatórios") && !menu.includes("Garantias"));
check("operador vê Clientes e Vendas", menu.includes("Clientes") && menu.includes("Vendas"));
await shot(page, "61-operador-dashboard");
await go(page, "/configuracoes/usuarios");
check("rota protegida bloqueia acesso direto", (await bodyText()).includes("não tem permissão") || !(await bodyText()).includes("Novo usuário"));
await go(page, "/emprestimos");
check("empréstimos bloqueado por rota", (await bodyText()).includes("não tem permissão"));
await go(page, "/clientes");
const doc = await page.evaluate(() => document.body.innerText.match(/\d{3}\.\*\*\*\.\*\*\*-\d{2}/)?.[0]);
check("documentos mascarados na lista", !!doc, doc);
await shot(page, "62-operador-clientes");

console.log(`\n${results.filter(Boolean).length}/${results.length} verificações OK`);
await browser.disconnect();
process.exit(results.every(Boolean) ? 0 : 1);
