// Verificação do binário de produção: CSP (PDF/imagens), ausência do seed de demonstração.
import puppeteer from "puppeteer-core";
import fs from "node:fs";
const OUT = process.env.SHOTS ?? "shots";
fs.mkdirSync(OUT, { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const browser = await puppeteer.connect({ browserURL: "http://127.0.0.1:9222", defaultViewport: null });
const page = (await browser.pages())[0];
await page.setViewport({ width: 1440, height: 900 });
console.log("url:", page.url());
const base = new URL(page.url()).origin;
const logged = await page.evaluate(() => !!document.querySelector("header"));
if (!logged) {
  await page.waitForSelector("#username");
  await page.type("#username", "ricardo");
  await page.type("#password", "senhaforte123");
  await page.evaluate(() => [...document.querySelectorAll("button")].find((b) => b.textContent.includes("Entrar")).click());
  await sleep(2500);
}
await page.goto(`${base}/contratos`, { waitUntil: "domcontentloaded" });
await sleep(3500);
await page.screenshot({ path: `${OUT}/70-release-contratos.png` });
await page.goto(`${base}/configuracoes/backup`, { waitUntil: "domcontentloaded" });
await sleep(2500);
const text = await page.evaluate(() => document.body.innerText);
console.log("seed de demonstração visível no release?", text.includes("Carregar demonstração"));
await page.screenshot({ path: `${OUT}/71-release-backup.png` });
const csp = await page.evaluate(() => document.querySelector('meta[http-equiv="Content-Security-Policy"]')?.content ?? "(aplicada pelo runtime)");
console.log("csp:", csp.slice(0, 80));
await browser.disconnect();
