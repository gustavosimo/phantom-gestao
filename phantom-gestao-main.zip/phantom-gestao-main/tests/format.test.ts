import { describe, expect, it } from "vitest";
import { formatBRL, parseBRL, maskMoney, inputToCents, centsToInput, maskCpfCnpj, maskPhone, formatBp, parsePercentToBp, formatDate, setDateFormat } from "../src/lib/format";

describe("dinheiro", () => {
  it("formata centavos sem ponto flutuante", () => {
    expect(formatBRL(0)).toBe("R$ 0,00");
    expect(formatBRL(141250)).toBe("R$ 1.412,50");
    expect(formatBRL(248035000)).toBe("R$ 2.480.350,00");
    expect(formatBRL(-5)).toBe("-R$ 0,05");
    expect(formatBRL(null)).toBe("—");
  });

  it("converte texto em centavos", () => {
    expect(parseBRL("R$ 1.412,50")).toBe(141250);
    expect(parseBRL("1500")).toBe(150000);
    expect(parseBRL("10,5")).toBe(1050);
    expect(parseBRL("abc")).toBeNull();
    expect(parseBRL("1,234,56")).toBeNull();
  });

  it("máscara progressiva e ida-e-volta", () => {
    expect(maskMoney("1")).toBe("0,01");
    expect(maskMoney("12345")).toBe("123,45");
    expect(maskMoney("123456789")).toBe("1.234.567,89");
    expect(inputToCents(maskMoney("123456"))).toBe(123456);
    expect(centsToInput(1500000)).toBe("15.000,00");
  });

  it("valores grandes não perdem precisão", () => {
    expect(formatBRL(999999999999)).toBe("R$ 9.999.999.999,99");
  });
});

describe("percentuais", () => {
  it("usa centésimos de ponto percentual", () => {
    expect(formatBp(240)).toBe("2,40");
    expect(formatBp(5)).toBe("0,05");
    expect(parsePercentToBp("2,4%")).toBe(240);
    expect(parsePercentToBp("0.05")).toBe(5);
    expect(parsePercentToBp("x")).toBeNull();
  });
});

describe("máscaras e datas", () => {
  it("CPF, CNPJ e telefone", () => {
    expect(maskCpfCnpj("52998224725", "PF")).toBe("529.982.247-25");
    expect(maskCpfCnpj("11222333000181", "PJ")).toBe("11.222.333/0001-81");
    expect(maskPhone("11984210012")).toBe("(11) 98421-0012");
    expect(maskPhone("1140005000")).toBe("(11) 4000-5000");
  });

  it("formato de data configurável", () => {
    setDateFormat("DD/MM/AAAA");
    expect(formatDate("2024-10-08")).toBe("08/10/2024");
    setDateFormat("AAAA-MM-DD");
    expect(formatDate("2024-10-08")).toBe("2024-10-08");
    setDateFormat("DD/MM/AAAA");
    expect(formatDate(null)).toBe("—");
  });
});
