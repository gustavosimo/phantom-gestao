import { describe, expect, it } from "vitest";
import { ALL_MODULES, NAV_SECTIONS, findModule } from "../src/app/navigation";

describe("navegação", () => {
  it("mantém os 14 módulos do layout aprovado, com caminhos únicos", () => {
    expect(ALL_MODULES).toHaveLength(14);
    expect(new Set(ALL_MODULES.map((m) => m.path)).size).toBe(14);
  });

  it("exige uma permissão por módulo", () => {
    for (const m of ALL_MODULES) expect(m.permission).toMatch(/\.(view|manage)$/);
  });

  it("bloqueia crédito e garantias como operações reguladas", () => {
    const regulated = ALL_MODULES.filter((m) => m.regulated).map((m) => m.path);
    expect(regulated).toEqual(["/emprestimos", "/garantias"]);
  });

  it("resolve o módulo pelo caminho", () => {
    expect(findModule("/")?.label).toBe("Dashboard");
    expect(findModule("/clientes/10")?.label).toBe("Clientes");
    expect(NAV_SECTIONS.length).toBe(4);
  });
});
